-- Name: TCGSetup
-- Author: jb321
-- Date: 8/11/2022
-- Updated: 2/26/2024
-- Version: 1.3b
local mq = require('mq')

local msg = "\at[\aoTCSNe\agX\aot\at]\aw "

local function file_exists(p_name)
    p_name = mq.luaDir .. "\\TCN\\" .. p_name
    local f = io.open(p_name, "r")
    return f ~= nil and io.close(f)
end

local function prize_data_check()
    local count = 0
    local path = mq.luaDir .. "\\TCN\\prize.db"
    for line in io.lines(path) do count = count + 1 end
    if count < 1 then
        print(msg,
              "Extracting prize.zip database file in: " ..
              mq.luaDir .. "\\TCN\\")
        return false
    end
    return true
end

print(msg, "Performing initial TCSNeXt setup")
-- install vc_redist
-- print(msg, "Installing VC_REDIST_x64.exe for use with SQLite")
mq.delay(100)
-- local cmd = mq.luaDir ..
--            "\\vc_redist.x64.exe /install /passive /norestart"
-- local rc = os.execute(cmd)
mq.delay(100)

-- local cmd
-- local rc

-- print(msg, "Installing DB_Browser for SQLite DB Maniupulation")
-- cmd = "msiexec /i " .. mq.luaDir ..
     --     "\\DB.Browser.for.SQLite-3.12.2-win32.msi /norestart"
-- rc = os.execute(cmd)
mq.delay(100)

-- Does the file exist?
local is_bool = file_exists("prize.db")
if not is_bool then
    print(msg, "extracting prize.db from prize.zip file")
    local cmd = "PowerShell Expand-Archive " .. mq.luaDir ..
                    "\\TCN\\Prize.zip " .. mq.luaDir ..
                    "\\TCN\\"
    -- print(cmd)
    local rc = os.execute(cmd)
else
    print(msg, "file exists checking for 0 byte length")
    local bool2
    -- Is the file over 0 bytes?
    if is_bool then bool2 = prize_data_check() end
    mq.delay(1)
    if not bool2 then
        local cmd = "PowerShell Expand-Archive -Force " ..
        mq.luaDir .. "\\TCN\\Prize.zip " ..
        mq.luaDir .. "\\TCN\\"
        -- print(cmd)
        os.execute(cmd)
    else
        print(msg, "File is correct size")
    end
end
