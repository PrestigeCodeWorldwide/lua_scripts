-- create  9/16/2021
-- updated 5/01/2025
-- creator: jb321
-- version 1.43b
-- name: TCN_Shoplist
-- change all mq.delays(1000)  to 750
-- change all mq.delays(1500)  to 900
local mq = require('mq')
local movement = require('TCN_Movement')
local lib = require('TCN_Library')

-- Variables

local msg = "\ap[\atTCSNe\auX\att\ap]\aw "

local function Event_No_Slots() return end

local no_sale = 1

local function Event_No_Sale()
    no_sale = 0
    -- print "no sale firing"
    return
end

local function Event_No_Vend()
    print(msg,
          "\ap[\ayPausing\ap] \ap[\agTCN_SHOPLIST _ Please check your inventory slots\ap]")

    mq.cmd('/beep')

    -- it is because of the events loop that it is cycling?

    mq.cmd('/squelch /lua pause tcn')

    -- mq.cmd('/doevents flush')

    return
end

local function Event_No_Cash()
    print(msg,
          "\ap[\ayPausing\ap] \ap[\agTCN_SHOPLIST _ You are unable to make this purchase, because you are broke\ap]")

    mq.cmd('/squelch /lua pause tcn')

    --  mq.cmd('/doevents flush')

    -- how will this affect tcn_quests?
    return
end

local function Event_No_Hands()
    print(msg,
          "\ap[\ayPausing\ap] \ap[\agTCN_SHOPLIST _ Your hands are full, and cannot make a purchase while they are\ap]")

    mq.cmd('/squelch /lua pause tcn')

    --   mq.cmd('/doevents flush')

    -- how will this affect tcn_quests?
    return
end

local function Event_No_Depot()
    print(msg, "\ap[\aySkipping\ap] \ap[\agYour depot slots are at capacity\ap]")
    GLOBAL_DEPOT_FULL = true
    -- mq.cmd('/doevents flush')
    return
end

-- make specific events to the task at hand

mq.event('noslots', "There are no open slots#*#", Event_No_Vend)
mq.event('novend', "Your inventory appears#*#", Event_No_Vend)
mq.event('handful', "You may not make a#*#", Event_No_Hands)
mq.event('notenough', "#*#but you can't afford to#*#", Event_No_Cash)

mq.event('nodepot', "There is no room remaining in your personal#*#",
         Event_No_Depot)

mq.event('nosale', "#*#I'll give you absolutely nothing#*#", Event_No_Sale)

-- local functions

-- Init Depot
local function tsd_init()

    if not mq.TLO.TradeskillDepot.ItemsReceived() then

        if not mq.TLO.Window('TradeskillDepotWnd').Open() then
            mq.TLO.Window('TradeskillDepotWnd').DoOpen()
            mq.delay(500)
        end

        print(msg, "Initialize Depot")

        -- Wait for list to populate
        while not mq.TLO.TradeskillDepot.ItemsReceived() do
            mq.delay(1000)
        end

    end
    -- mq.TLO.Window('TradeskillDepotWnd').DoClose()

    mq.delay(1)

end

--- Select item to be sold
local function select_inventory_item(p_item_id)

    -- Define random
    local random

    -- Determine specific slot item is in

    -- If there is nothing in inventory - return
    if mq.TLO.FindItemCount(p_item_id)() < 1 or mq.TLO.FindItem(p_item_id)() ==
        nil then return end

    repeat
        mq.delay(100)
        if GLOBAL_ABORT_FLAG == 1 then break end
        if mq.TLO.FindItemCount(p_item_id)() < 1 or mq.TLO.FindItem(p_item_id)() ==
            nil then break end

        local slot1 = mq.TLO.FindItem(p_item_id).ItemSlot()
        local slot2 = mq.TLO.FindItem(p_item_id).ItemSlot2() + 1

        -- Open bag if it is in a bag and not open
        if slot2 ~= 0 then
            local pack = mq.TLO.FindItem(p_item_id).ItemSlot() - 22
            if mq.TLO.Window('pack' .. pack).Open() == nil then
                mq.cmd('/nomodkey /itemnotify ' .. slot1 .. ' rightmouseup')
                mq.delay(500)
            end
            -- Select the item in bag
            mq.cmd('/nomodkey /itemnotify in pack' .. pack .. " " .. slot2 ..
                       ' leftmouseup')
            mq.delay(500)
        else
            -- Select item in inventory slot
            mq.cmd('/nomodkey /itemnotify ' .. slot1 .. ' leftmouseup')
            mq.delay(500)
        end

        random = math.random(500, 1000)
        mq.delay(random)
    until mq.TLO.Merchant.SelectedItem() ~= nil

    return
end

-- Return nearest vendor with a path
local function nearest_vendor_spawn()
    -- Variables
    local suitable_vendor = 0
    local nearest_vendor_name
    local nearest_vendor_dist
    local nearest_vendor_path
    local nearest_vendor_id
    -- local nearest_vendor_LOS

    for c = 1, mq.TLO.SpawnCount('Merchant')() do

        --  print(mq.TLO.NearestSpawn(c, 'Merchant').DisplayName())
        --  print(mq.TLO.NearestSpawn(c, 'Merchant').ID())

        nearest_vendor_id = mq.TLO.NearestSpawn(c, 'Merchant').ID()
        mq.delay(1)

        nearest_vendor_path = mq.TLO.Nav
                                  .PathExists('id ' .. nearest_vendor_id)()

        --   nearest_vendor_LOS = mq.TLO.Spawn(nearest_vendor_id).LineOfSight()

        -- print("Path Exists ", nearest_vendor_path)

        -- Select a vendor
        if nearest_vendor_path and -- nearest_vendor_LOS then
            mq.TLO.NearestSpawn(c, 'Merchant').DisplayName() ~=
            "Culturist Devari" and
            mq.TLO.NearestSpawn(c, 'Merchant').DisplayName() ~=
            "Parcel Delivery Liaison" and
            mq.TLO.NearestSpawn(c, 'Merchant').DisplayName() ~= "Scribe Zikett" then

            nearest_vendor_id = mq.TLO.NearestSpawn(c, 'Merchant').ID()
            nearest_vendor_name = mq.TLO.NearestSpawn(c, 'Merchant')
                                      .DisplayName()
            nearest_vendor_dist = math.ceil(
                                      mq.TLO.Spawn(nearest_vendor_id).Distance())

            if nearest_vendor_dist > 20 then
                print(msg, "Suitable Vendor Found: \ap[\ag",
                      nearest_vendor_name, "\ap] \ap[\agDistance: \ap(\ag",
                      nearest_vendor_dist, "\ap)")
            end
            suitable_vendor = 1
            break
        end
    end

    -- Unable to find vendor with path
    if suitable_vendor == 0 then
        print(msg, "We were unable to find a suitable vendor")
        return nil
    end

    -- print(nearest_vendor_name, " ", nearest_vendor_dist, " ", nearest_vendor_id)
    return nearest_vendor_id
end

local function nav_to_spawn(p_spawn_id)

    local Spawn_Distance = mq.TLO.Spawn(p_spawn_id).Distance()

    -- the direction I am facing? in degrees
    local my_heading = math.ceil(mq.TLO.Me.Heading.DegreesCCW())
    local spawn_heading = math.ceil(mq.TLO.Spawn(p_spawn_id).HeadingTo
                                        .DegreesCCW())

    -- print("my : ", my_heading)
    -- print("my heading to them ", spawn_heading)

    if Spawn_Distance < 15 and mq.TLO.Spawn(p_spawn_id).LineOfSight() then
        if my_heading > spawn_heading or my_heading < spawn_heading then
            local calc = math.abs(my_heading - spawn_heading)
            if calc > 9 then
                --  print("degree calc ", calc)
                print(msg, "Facing \ap[\ag",
                      mq.TLO.Spawn(p_spawn_id).DisplayName(), "\ap]")
                mq.cmd('/squelch /face ', mq.TLO.Spawn(p_spawn_id)())
                mq.delay(900)
            end
        end
        return
    end

    local counter = 0
    local attempts = 0

    print(msg, "\ap[\agNavigating\ap] \ap[\aw",
          mq.TLO.Spawn(p_spawn_id).DisplayName(), "\ap]")

    mq.cmd('/squelch /nav spawn id ' .. p_spawn_id .. ' |dist=14 log=off')
    while mq.TLO.Nav.Active() do

        Spawn_Distance = mq.TLO.Spawn(p_spawn_id).Distance()
        mq.delay(10)
        local Next_Spawn_Distance = mq.TLO.Spawn(p_spawn_id).Distance()

        -- Distance has not changed
        if Spawn_Distance == Next_Spawn_Distance then
            counter = counter + 1

            -- Try to get unstuck by ducking
            if counter == 50 then
                print(msg, "\ap[\awDucking\ap]")
                mq.cmd('/keypress duck')
                mq.delay(2000)
                mq.cmd('/keypress duck')
                counter = 0
                attempts = attempts + 1

                if attempts > 9 then
                    print(msg, "we tried 10 times to get there, giving up!")
                    print(msg,
                          "\ap[\ayPausing\ap] \ap[\agWe are unable to get to our destination\ap]")
                    -- fix script checking

                    -- well this is for selling so I don't think so for other scripts
                    mq.cmd('/squelch /lua pause tcn')

                    -- quests and god?
                end
            end
        end

        mq.delay(1)

    end
    mq.delay(500)

    my_heading = math.ceil(mq.TLO.Me.Heading.DegreesCCW())
    spawn_heading = math.ceil(mq.TLO.Spawn(p_spawn_id).HeadingTo.DegreesCCW())

    if my_heading > spawn_heading or my_heading < spawn_heading then
        local calc = math.abs(my_heading - spawn_heading)
        if calc > 9 then
            --   print("degree calc ", calc)
            print(msg, "Facing \ap[\ag", mq.TLO.Spawn(p_spawn_id).DisplayName(),
                  "\ap]")
            mq.cmd('/squelch /face ', mq.TLO.Spawn(p_spawn_id)())
            mq.delay(900)
        end
    end

    return
end

local function removeDuplicates(arr)
    local newArray = {}
    local checkerTbl = {}
    for _, element in ipairs(arr) do
        if not checkerTbl[element] then -- if there is not yet a value at the index of element, then it will be nil, which will operate like false in an if statement
            checkerTbl[element] = true
            table.insert(newArray, element)
        end
    end
    return newArray
end

local shop = {}

-- collapsed routine info

-- Name: tcn_buy.lua --added to shoplist
-- Version 1.2b
-- Date: 8/30/21
-- Updated: 10/24/25
-- Creator: JB321
--
-- Usage: buy.item ("Lettuce"   ,       1     ,         13906 )
--		           Item Name     Amount To Buy    Item ID

-- tcn_sell.lua
-- creator: jb321
-- created: 10/23/2021
-- updated: 3/23/2022
-- version: 0.3b

local local_vendor_index = 0

function shop.sell_item_ID_to_vendor(p_item_id, p_qty, p_option)

    if mq.TLO.FindItem(p_item_id).NoDrop() or
        mq.TLO.FindItem(p_item_id).NoTrade() then
        print(msg, "\ay" .. mq.TLO.FindItem(p_item_id)() ..
                  " Item is no-trade, not selling")
        return
    end

    -- if local inventory . no trade then return..

    -- Make a list of things not to sell
    -- Don't sell mana bats?

    -- Don't sell fish eggs
    if p_item_id == 16498 then return end

    -- Don't sell magnetic bricks
    if p_item_id == 72159 then return end

    -- Luclinite fish scales add more
    local dont_sell = {166211, 166213, 166212, 166208}

    if GLOBAL_ABORT_FLAG == 1 then return end

    mq.delay(500)

    local l_spawn_id = nearest_vendor_spawn()

    if l_spawn_id ~= nil then
        nav_to_spawn(l_spawn_id)
    else
        print(msg, "no path to vendor or suitable vendor")
        return
    end

    local l_qty = p_qty
    local l_item_id = p_item_id
    local l_item_name = mq.TLO.FindItem(l_item_id)()

    if l_item_name == nil then
        print(msg, "No such item in inventory")
        return
    end

    local l_item_qty = mq.TLO.FindItemCount(l_item_id)()

    if l_qty <= 0 then
        print(msg, "Please don't use negative numbers or zero ", l_qty)
        return
    end

    if l_item_qty <= 0 then
        print(msg, "We don't have the item in that quantity ", l_item_qty)
        return
    end

    local l_item_value = mq.TLO.FindItem(l_item_id).Value()

    if l_item_value == 0 then
        print(msg, l_item_name, " is worthless, we will not sell it")
        return
    end

    if l_qty > l_item_qty then
        print(msg, "we don't have that much but we will sell what we got")
        l_qty = l_item_qty
    end

    -- Open merchant window if not open
    if not mq.TLO.Merchant.Open() then

        repeat
            mq.TLO.Merchant.OpenWindow()
            mq.delay(750)
            if GLOBAL_ABORT_FLAG == 1 then break end
        until mq.TLO.Merchant.Open()

        --  mq.TLO.Merchant.OpenWindow()

    end

    repeat
        mq.delay(1)
        if GLOBAL_ABORT_FLAG == 1 then break end
    until mq.TLO.Merchant.ItemsReceived()
    -- do mq.delay(1) end

    -- how does that work? do delay end? in a repeat

    -- Get stacksize of item
    local l_item_stack_size = mq.TLO.FindItem(l_item_id).StackSize()

    local l_selected_item_count
    local sold_count = 0
    local l_sell_amount = 0

    local remaining_count = mq.TLO.FindItemCount(l_item_id)() - l_qty

    if remaining_count < 1 then remaining_count = 0 end

    -- print("Count to have when we are done selling: ", remaining_count)

    while true do

        if GLOBAL_ABORT_FLAG == 1 then break end

        mq.delay(900)

        if mq.TLO.FindItemCount(l_item_id)() == remaining_count or
            mq.TLO.FindItemCount(l_item_id)() == 0 or
            mq.TLO.FindItem(l_item_id).ID == nil then break end

        mq.delay(1)

        -- Select the item in inventory
        select_inventory_item(l_item_id)
        -- Get the count of the currently selected item
        l_selected_item_count = mq.TLO.Merchant.SelectedItem(l_item_name)
                                    .Stack()

        l_sell_amount = mq.TLO.FindItemCount(l_item_id)() - remaining_count

        --  if mq.TLO.FindItemCount(l_item_id)() == remaining_count or
        --  mq.TLO.FindItemCount(l_item_id)() == 0 then break end

        if l_sell_amount < 0 then break end

        -- print("\atAmount to sell \ag", l_sell_amount)

        -- Sell the stack
        if l_sell_amount >= l_item_stack_size and l_selected_item_count ==
            l_item_stack_size then

            -- Check if container is populated
            local l_item_container_count = mq.TLO.FindItem(l_item_id).Items()

            -- Pause to clean out container
            if l_item_container_count ~= 0 and l_item_container_count ~= nil then
                print(msg, "\ap[\agPausing\ap] \atThere are ",
                      l_item_container_count, " items in the ", l_item_name,
                      ", please clear them out or un-pause to continue selling")
                -- script name checking?
                mq.cmd('/squelch /lua pause tcn')

            end

            --  print("sell the stack ", l_item_stack_size)

            if mq.TLO.FindItemCount(l_item_id)() > 0 then
                mq.TLO.Merchant.Sell(l_item_stack_size)()
            end

            -- Click yes to sell container
            if mq.TLO.Window('ConfirmationDialogBox')() then
                mq.cmd(
                    '/nomodkey /notify ConfirmationDialogBox CD_Yes_Button leftmouseup')
                mq.delay(750)
            end
            sold_count = sold_count + l_item_stack_size

        else

            if mq.TLO.FindItemCount(l_item_id)() < 1 then break end

            if l_sell_amount >= l_item_stack_size and l_selected_item_count ~=
                l_item_stack_size and mq.TLO.FindItemCount(l_item_id)() > 0 then
                --   print("sell some from stack ", l_selected_item_count)
                mq.TLO.Merchant.Sell(l_selected_item_count)()
                sold_count = sold_count + l_selected_item_count

            else
                if l_sell_amount < l_item_stack_size and l_selected_item_count <=
                    l_sell_amount and mq.TLO.FindItemCount(l_item_id)() > 0 then
                    --    print("not stack < sell amount", l_selected_item_count)
                    mq.TLO.Merchant.Sell(l_selected_item_count)()
                    sold_count = sold_count + l_selected_item_count

                else
                    if l_sell_amount < l_item_stack_size and
                        l_selected_item_count >= l_sell_amount and
                        mq.TLO.FindItemCount(l_item_id)() > 0 then
                        --   print("not stack ", l_sell_amount)
                        mq.TLO.Merchant.Sell(l_sell_amount)()
                        sold_count = sold_count + l_sell_amount
                    end
                end
            end
        end

        local break_counter = 0
        while true do
            mq.doevents()
            mq.delay(1)
            break_counter = break_counter + 1
            if break_counter > 4 then break end
        end

        if no_sale == 0 then break end

        mq.delay(1)
        if GLOBAL_ABORT_FLAG == 1 then break end
    end

    if GLOBAL_ABORT_FLAG == 1 or no_sale == 0 then
        no_sale = 1
        lib.ClearCursor()
        mq.delay(750)
        mq.cmd('/cleanup')
        return
    end

    GLOBAL_MAX_TEXT = "Sold: " .. sold_count .. " " .. l_item_name
    print(msg, "\ao[Sold] \ap(\ag", sold_count, "\ap) \ap[\ag", l_item_name,
          "\ap]")
    l_item_qty = mq.TLO.FindItemCount(l_item_id)()
    -- print("\agInventory Left: ", l_item_qty)
    mq.delay(1)

    lib.ClearCursor()
    mq.delay(750)

    if p_option == 0 then mq.cmd('/cleanup') end

    mq.delay(750)
    return
end

function shop.buy_item(ItemAmount, p_ItemID)

    mq.cmd('/doevents flush')

    -- testing
    -- p_ItemID = 37800
    -- BUY_MULT = 7
    -- USE_MULT = true

    local brick_array = {[33260] = true, [33261] = true, [33262] = true}

    -- if multipler and what other conditions

    -- Check if the item is a bought tool
    local is_tool = lib.return_tool_buy(p_ItemID)

    if p_ItemID == 37800 or p_ItemID == 37802 or p_ItemID == 37798 or p_ItemID ==
        37801 or p_ItemID == 37799 then is_tool = 0 end

    if BUY_MULT > 1 and USE_MULT and is_tool ~= 1 then
        GLOBAL_TEXT = "Shopping Multiplier Active X" .. BUY_MULT
        print(msg, "Shopping Multiplier Active X" .. BUY_MULT)
        ItemAmount = ItemAmount * BUY_MULT
    end

    if GLOBAL_ABORT_FLAG == 1 then return 0 end

    lib.ClearCursor()

    local ItemToBuy = lib.return_item_name(p_ItemID)

    -- print(ItemAmount, " ", p_ItemID)

    local l_ItemID = p_ItemID

    -- Checks the Item ID - items can have the same name
    local InvCount = mq.TLO.FindItemCount(l_ItemID)()

    -- Add in Auto-Bank checking

    -- Don't waste time if we already have enough
    if InvCount >= ItemAmount then return 0 end

    -- Uncheck only usuable items
    if mq.TLO.Window('MerchantWnd').Child('MW_UsableButton').Checked() then
        mq.cmd('/notify MerchantWnd MW_UsableButton leftmouseup')
        mq.delay(500)
    end

    mq.delay(500)

    local cycles = 0

    if string.find(ItemToBuy, "Vanazir") or
        string.find(ItemToBuy, "Swiftcleave") or
        string.find(ItemToBuy, "discovery by") then

        -- go through list and find it by id
        local vendor_items_index = mq.TLO.Window('MerchantWnd')
                                       .Child('ItemList').Items()
        for c = 1, vendor_items_index do
            if mq.TLO.Merchant.Item(c).ID() == l_ItemID then
                ItemToBuy = mq.TLO.Merchant.Item(c)()
                repeat
                    if GLOBAL_ABORT_FLAG == 1 then break end
                    mq.TLO.Merchant.SelectItem(ItemToBuy)()
                    mq.delay(750)
                until mq.TLO.Merchant.SelectedItem() ~= nil
                print(msg, "\ap[\agPurchasing\ap] \ap(\ay", ItemAmount,
                      "\ap) \ap[\aw", ItemToBuy, "\ap]")

                GLOBAL_STANDARD_CRAFTING_STATUS_MSG = "Purchasing " ..
                                                          ItemAmount .. " " ..
                                                          ItemToBuy

                GLOBAL_PURCHASE_ID = l_ItemID
                break
            end
        end
        --  os.exit()
    else

        repeat
            if GLOBAL_ABORT_FLAG == 1 then break end
            local_vendor_index = mq.TLO.Window('MerchantWnd').Child('ItemList')
                                     .List('=' .. ItemToBuy, 2)()
            mq.delay(300)
            cycles = cycles + 1

            if brick_array[p_ItemID] and cycles > 30 then return 1 end

            if cycles > 40 then
                print("I don't think the vendor has: ", ItemToBuy,
                      " or the lag monster is attacking.")
                print(
                    "Or there is a race requirement, not implemented yet for vendors.")

                -- watch this
                return 0
            end

        until local_vendor_index ~= nil

        mq.delay(1)

        repeat

            mq.cmd('/nomodkey /notify MerchantWnd ItemList listselect ',
                   local_vendor_index)
            mq.delay(1)
            mq.cmd('/notify MerchantWnd ItemList leftmouseup ',
                   local_vendor_index)

            mq.delay(300)

            if GLOBAL_ABORT_FLAG == 1 then break end

        until mq.TLO.Merchant.SelectedItem() ~= nil

        print(msg, "\ap[\agPurchasing\ap] \ap(\ay", ItemAmount, "\ap) \ap[\aw",
              ItemToBuy, "\ap]")
        GLOBAL_STANDARD_CRAFTING_STATUS_MSG =
            "Purchasing " .. ItemAmount .. " " .. ItemToBuy

        GLOBAL_PURCHASE_ID = l_ItemID

    end

    -- Item Not Found
    if (mq.TLO.Merchant.SelectedItem() == nil) then
        print("Unable to Find: ", ItemToBuy)
        return 0
    end

    local NeedCount = ItemAmount - mq.TLO.FindItemCount(l_ItemID)()

    if GLOBAL_ABORT_FLAG == 1 then return 0 end

    local cycle_count = 0

    while NeedCount > 0 do

        -- Working method to deal with ORE shortage
        if l_ItemID == 3326199999 and NeedCount > 0 then
            repeat
                mq.delay(300)
                if GLOBAL_ABORT_FLAG == 1 then break end
                local_vendor_index = mq.TLO.Window('MerchantWnd').Child(
                                         'ItemList').List('=' .. ItemToBuy, 2)()
                cycle_count = cycle_count + 1
                if cycle_count > 40 then break end

            until local_vendor_index ~= nil
        end

        mq.delay(1)

        -- Redundant?
        local break_counter = 0
        -- while true do
        --    mq.doevents()
        --   mq.delay(1)
        --  break_counter = break_counter + 1
        --  if break_counter == 20 then break end
        --  end

        -- Click Buy

        -- print("need: ",NeedCount)

        if GLOBAL_ABORT_FLAG == 1 then break end

        -- Testing
        -- mq.cmd('/lua pause')

        mq.TLO.Merchant.Buy(NeedCount)()
        --  mq.cmd('/notify MerchantWnd MW_Buy_Button leftmouseup')

        -- Capture events
        break_counter = 0
        while true do
            mq.delay(1)
            mq.doevents()
            break_counter = break_counter + 1
            if break_counter == 20 then break end
        end

        mq.delay(500)
        -- Unable to afford item
        if mq.TLO.Window('MerchantWnd').Child('MW_Buy_Button').Enabled() ~= true then
            print(msg,
                  "\ap[\ayPausing\ap] \ap[\agNot able to afford the item\ap]")
            -- Pause
            mq.cmd('/squelch /lua pause tcn')

            -- Try again
            --    mq.cmd('/notify MerchantWnd MW_Buy_Button leftmouseup')
            --   mq.TLO.Merchant.Buy(NeedCount)()
        end

        -- stack size add

        if (NeedCount < 100) then
            -- Use Quantity Slider
            --   mq.delay(500)
            -- Select Quantity
            --  mq.cmd('/notify QuantityWnd QTYW_slider newvalue', NeedCount)
            --  mq.delay(500)
        end

        mq.delay(750)
        -- Add condition for single item purchase like container
        -- Add condition for non-tradeskill bag auto inv

        mq.doevents()

        while mq.TLO.Cursor.ID() do
            mq.cmd('/autoinv')

            mq.delay(1)
            mq.doevents()

            mq.delay(500)
            if GLOBAL_ABORT_FLAG == 1 then break end
        end

        if GLOBAL_ABORT_FLAG == 1 then break end

        -- Calculate Remaining
        repeat mq.delay(300) until ItemAmount - mq.TLO.FindItemCount(l_ItemID)() ~=
            NeedCount
        -- Calculate need count

        if GLOBAL_ABORT_FLAG == 1 then break end

        NeedCount = ItemAmount - mq.TLO.FindItemCount(l_ItemID)()
        mq.delay(750)
    end

    GLOBAL_PURCHASE_ID = nil

    return 0
end

function shop.go_shopping(p_shopper_array)

    if GLOBAL_ABORT_FLAG == 1 then return end

    local last_vendor = ""

    local l_shopping_list = {}

    -- for c = 1 ,#p_shopper_array do print(p_shopper_array[c]) end os.exit()

    for x = 1, #p_shopper_array do
        table.insert(l_shopping_list, p_shopper_array[x])
    end

    -- for x = 1, #l_shopping_list do print(l_shopping_list[x]) end os.exit()

    -- Wipe out array
    p_shopper_array = {}

    -- Sort table
    -- table.sort(l_shopping_list)

    local go_shopping_flag = 0

    -- for c = 1 ,#l_shopping_list do print(l_shopping_list[c]) end os.exit()

    -- Troubleshooting

    -- should be sorted by vendor

    -- add flag for debug
    for x = 1, #l_shopping_list do
        --  print("\awTCN Go shopping list \at", l_shopping_list[x])
    end
    -- os.exit()

    lib.ClearCursor()
    mq.delay(1000)
    lib.ClearCursor()

    for x = 1, #l_shopping_list do
        -- local l_buy_count = tonumber(lib.return_string(cleaned_array[x], 3))
        local l_buy_count = lib.return_number(l_shopping_list[x], 4)
        local l_item_id = lib.return_number(l_shopping_list[x], 3)
        --  local l_item_id = lib.return_string(cleaned_array[x], 2)
        local l_inv_count = mq.TLO.FindItemCount(l_item_id)()
        mq.delay(1)
        if l_buy_count > l_inv_count then go_shopping_flag = 1 end
    end

    lib.ClearCursor()

    if go_shopping_flag == 1 then print(msg, "\ap[\agVendor Shopping\ap]") end

    -- Nothing to shop for
    if go_shopping_flag == 0 then
        -- GLOBAL_TEXT = "Nothing to shop for"
        return
    end

    -- If current zone is NGH then use shabby lobby door..
    if mq.TLO.Zone.ID() == 737 or mq.TLO.Zone.ID() == 738 or mq.TLO.Zone.ID() ==
        751 then movement.ngh_gl() end

    GLOBAL_TEXT = "Vendor Shopping"

    -- for x = 1, #l_shopping_list do print(l_shopping_list[x]) end

    for x = 1, #l_shopping_list do

        if GLOBAL_ABORT_FLAG == 1 then break end

        -- what would happen if we shopped via zone id?

        local l_vendor_zone_id = lib.return_number(l_shopping_list[x], 1)

        local l_vendor_name = lib.return_string(l_shopping_list[x], 2)

        local l_item_id = lib.return_number(l_shopping_list[x], 3)

        -- Find the closest vendor based on where you are in the zone
        l_vendor_name = lib.vendor_distance(l_item_id)
        -- print("closest vendor is ",l_vendor_name)

        --  l_vendor_name ="Chef Denrun"

        local l_buy_count = lib.return_number(l_shopping_list[x], 4)

        --  local l_item_name = lib.return_string(l_shopping_list[x], 5)

        local InvCount = mq.TLO.FindItemCount(l_item_id)()

        if l_buy_count > InvCount then

            -- New vendor check
            if last_vendor ~= l_vendor_name then
                mq.cmd('/cleanup')
                -- 1 or the other?
                --  mq.cmd('/notify MerchantWnd MW_Done_Button leftmouseup')
                mq.delay(900)
            end

            -- Faction check for vendor
            local faction_check = lib.faction_check(l_vendor_name)

            if faction_check == 0 then
                GLOBAL_TEXT = 'Faction not high enough for ' .. l_vendor_name
                print(msg,
                      "\ap[\agFaction requirement for \ap[\aw" .. l_vendor_name ..
                          "\ap]\ag not met\ap]")
            end

            if faction_check ~= 0 then

                if l_vendor_zone_id == 202 then
                    if mq.TLO.Zone.ID() ~= 202 then
                        print(msg,
                              "\ap[\agTravelling to: \awPlane of Knowledge\ap]")
                        GLOBAL_TEXT = "Heading to Plane of Knowledge"
                    end
                    movement.pok()
                end
                if l_vendor_zone_id == 383 then
                    --   print "west freeport travel under construction"

                    if mq.TLO.Zone.ID() ~= 383 then
                        print(msg, "\ap[\agTravelling to: \awWest Freeport\ap]")
                        GLOBAL_TEXT = "Heading to West Freeport"
                    end
                    movement.wfp()
                end
                -- Thurgadin
                if l_vendor_zone_id == 115 then
                    if mq.TLO.Zone.ID() ~= 115 then
                        print(msg,
                              "\ap[\agTravelling to: \awCity of Thurgadin\ap]")
                    end
                    movement.thurgadin()
                end
                -- Crescent Reach
                if l_vendor_zone_id == 394 then
                    if mq.TLO.Zone.ID() ~= 394 then
                        print(msg, "\ap[\agTravelling to: \awCrescent Reach\ap]")
                        GLOBAL_TEXT = "Heading to Crescent Reach"
                    end
                    mq.cmd('/squelch /travelto crescent')
                    while true do
                        if mq.TLO.Zone.ID() == 394 then
                            break
                        end
                        mq.delay(1)
                    end
                    mq.delay(3000)
                end
                -- Stratos
                if l_vendor_zone_id == 818 then

                    if mq.TLO.Zone.ID() ~= 818 then
                        print(msg, "\ap[\agTravelling to: \awStratos\ap]")
                        GLOBAL_TEXT = "Heading to Stratos"
                    end
                    movement.stratos()
                end

                if l_vendor_zone_id == 203 then

                    if mq.TLO.Zone.ID() ~= 203 then
                        print(msg,
                              "\ap[\agTravelling to: \awPlane of Tranquility\ap]")
                        GLOBAL_TEXT = "Heading to Plane of Tranquility"
                    end

                    mq.cmd('/squelch /travelto potranquility')
                    while true do
                        if mq.TLO.Zone.ID() == 203 then
                            break
                        end
                        mq.delay(1)
                    end
                    mq.delay(3000)
                end

                if l_vendor_zone_id == 422 then
                    if mq.TLO.Zone.ID() ~= 422 then
                        print(msg, "\ap[\agTravelling to: \awBarren Coast\ap]")
                        GLOBAL_TEXT = "Heading to Barren Coast"
                    end
                    mq.cmd('/squelch /travelto barren')
                    while true do
                        if mq.TLO.Zone.ID() == 422 then
                            break
                        end
                        mq.delay(1)
                    end
                    mq.delay(3000)
                end

                if l_vendor_zone_id == 151 then
                    if mq.TLO.Zone.ID() ~= 151 then
                        print(msg, "\ap[\agTravelling to: \awThe Bazaar\ap]")
                        GLOBAL_TEXT = "Heading to The Bazaar"
                    end
                    movement.baz()
                end

                -- Add Shadowhaven for jumjum juice

                GLOBAL_STANDARD_CRAFTING_STATUS_MSG = "Moving: " ..
                                                          l_vendor_name

                if l_vendor_name == "Poisoner Salihah" then
                    movement.crescent_reach_floor_2()
                end

                if l_vendor_name == "Merchant Mandisa" then
                    movement.crescent_reach_floor_2()
                end

                if l_vendor_name == "Smith Yahya" then
                    movement.crescent_reach_floor_2()
                end

                movement.npc(l_vendor_name)
                -- WalkToNPC("Chef Denrun")

                if GLOBAL_ABORT_FLAG == 1 then break end

                if l_vendor_name == "Merchant Woad" then
                    -- local npcID = mq.TLO.NearestSpawn(l_vendor_name).ID()
                    mq.cmd('/squelch /nav spawn Woad')
                    while mq.TLO.Nav.Active() do
                        mq.TLO.Merchant.OpenWindow()
                        if GLOBAL_ABORT_FLAG == 1 then
                            break
                        end
                        mq.delay(1)
                    end
                end

                if GLOBAL_ABORT_FLAG == 1 then break end
                -- Merchant Window Not Open, Click Right Target
                if not mq.TLO.Merchant.Open() then
                    --   mq.cmd('/nomodkey /click right target')
                    repeat
                        mq.TLO.Merchant.OpenWindow()
                        mq.delay(100)
                        if GLOBAL_ABORT_FLAG == 1 then
                            break
                        end
                    until mq.TLO.Merchant.Open()
                end

                -- Need to make sure we dont try to buy things we cant get based on race/class
                -- If it is a special vendor list may never be populated

                -- Wait until the merchant list populated
                while mq.TLO.Merchant.ItemsReceived() ~= true do
                    mq.delay(100)
                end

                -- List of things not to buy for testing
                local dont_buy = {152466, 152474, 12046, 12056}

                local db = 1

                for z = 0, #dont_buy do
                    if l_item_id == dont_buy[z] then
                        --    db = 0
                        --   break
                    end
                    mq.delay(1)
                end

                -- Make list of things not to buy
                if db == 1 then

                    -- NO_BUY flag for testing.. ADD

                    --  mq.cmd('/lua pause')

                    local shop_result = shop.buy_item(l_buy_count, l_item_id)

                    if shop_result == 1 then

                        mq.delay(1)
                        mq.TLO.Window('MerchantWnd').DoClose()
                        mq.delay(2000)

                        movement.npc('Yeril Imsin')
                        mq.delay(1000)

                        if not mq.TLO.Merchant.Open() then
                            --   mq.cmd('/nomodkey /click right target')
                            repeat
                                mq.TLO.Merchant.OpenWindow()
                                mq.delay(100)
                                if GLOBAL_ABORT_FLAG == 1 then
                                    break
                                end
                            until mq.TLO.Merchant.Open()
                        end

                        shop_result = 0

                        shop_result = shop.buy_item(l_buy_count, l_item_id)

                        -- Testing 
                        -- shop_result = 0

                        if shop_result == 1 then

                            mq.delay(1)
                            mq.TLO.Window('MerchantWnd').DoClose()
                            mq.delay(2000)

                            movement.npc('Borik Darkanvil')
                            mq.delay(1000)

                            if not mq.TLO.Merchant.Open() then
                                --   mq.cmd('/nomodkey /click right target')
                                repeat
                                    mq.TLO.Merchant.OpenWindow()
                                    mq.delay(100)
                                    if GLOBAL_ABORT_FLAG == 1 then
                                        break
                                    end
                                until mq.TLO.Merchant.Open()
                            end

                            shop_result = 0

                            shop_result = shop.buy_item(l_buy_count, l_item_id)

                            if shop_result == 1 then

                                mq.delay(1)
                                mq.TLO.Window('MerchantWnd').DoClose()
                                mq.delay(2000)

                                if mq.TLO.MacroQuest.Server() ~= "rizlona" then
                                    movement.npc('Blacksmith Gerta')
                                else
                                    print(msg,
                                          "Rizlona: No vendor has the Refined HQ Ore, exiting")
                                    os.exit()
                                end

                                mq.delay(1000)

                                if not mq.TLO.Merchant.Open() then
                                    --   mq.cmd('/nomodkey /click right target')
                                    repeat
                                        mq.TLO.Merchant.OpenWindow()
                                        mq.delay(100)
                                        if GLOBAL_ABORT_FLAG == 1 then
                                            break
                                        end
                                    until mq.TLO.Merchant.Open()
                                end

                                shop_result = 0

                                shop_result =
                                    shop.buy_item(l_buy_count, l_item_id)

                                if shop_result == 1 then
                                    print(msg,
                                          "No vendor has the Refined HQ Ore, exiting")
                                    --   print(msg,
                                    --   "No vendor has the Refined HQ Ore, Ore Not!")
                                    os.exit()
                                end

                            end

                        end

                        mq.delay(1500)

                    end

                    GLOBAL_STANDARD_CRAFTING_STATUS_MSG = nil

                    mq.delay(300)

                    last_vendor = l_vendor_name

                end

                mq.delay(1)

                if GLOBAL_ABORT_FLAG == 1 then return end

                if mq.TLO.Zone.ID() == 394 then
                    movement.crescent_reach_floor_1()
                end
            end
        end

        -- need to stay on floor if still shopping from same vendor
        -- if mq.TLO.Zone.ID() == 394 then movement.crescent_reach_floor_1() end

    end

    -- Close Vendor window when done shopping overall
    if mq.TLO.Merchant.Open() then
        mq.delay(500)
        mq.TLO.Window('MerchantWnd').DoClose()
        mq.delay(500)
    end

    lib.ClearCursor()

    print(msg, "\ap[\agShopping\ap \ap[\awDONE\ap]")
    return
end

-- Added SQLized 3/17/2022 JB
function shop.create_shopping_list(p_array)

    -- if GLOBAL_ABORT_FLAG == 1 then return end

    -- for x = 1, #p_array do print("\at", p_array[x]) end

    local s_recipe_list_breakdown = {}
    -- Copy table
    for x = 1, #p_array do
        local Set_counts = lib.return_number(p_array[x], 3)
        local Recipe_ID = lib.return_number(p_array[x], 4)
        local Temp_Shop_SQL_Array = lib.return_recipe_shop_info(Recipe_ID,
                                                                Set_counts)
        for c = 1, #Temp_Shop_SQL_Array do
            table.insert(s_recipe_list_breakdown, Temp_Shop_SQL_Array[c])
        end
    end

    -- for c = 1, #s_recipe_list_breakdown do print("\ay", s_recipe_list_breakdown[c]) end
    -- os.exit()

    -- Create shopping list with vendors
    local raw_array = lib.SQL_Shopping_Array(s_recipe_list_breakdown)

    -- for c = 1, #raw_array do print("raw shop: ", raw_array[c]) end
    -- os.exit()

    -- Create final shopping list

    if raw_array[1] == nil then
        -- print("\aoTCN_Shop no shoppable items")
        raw_array = {}
        return raw_array
    end

    if GLOBAL_ABORT_FLAG == 1 then
        -- raw_array = {}
        -- return raw_array
    end

    local zone_array = {}

    -- Extract Zone ID
    for c = 1, #raw_array do
        local zone_id = lib.return_number(raw_array[c], 1)
        local zone_name = mq.TLO.Zone(zone_id)()
        table.insert(zone_array, zone_name)
    end

    -- Remove Duplicate Zone ID
    zone_array = removeDuplicates(zone_array)

    table.insert(zone_array, 1, "ALL")
    -- for c = 1,#zone_array do print(zone_array[c]) end

    -- for c = 1, #raw_array do print(raw_array[c]) end
    -- os.exit()

    return raw_array, zone_array
end

-- Grab stuff from the bank
function shop.go_bank_shopping(p_shopper_array)

    if GLOBAL_ABORT_FLAG == 1 then return end

    -- print(msg, "\ap[\awBank Shopping\ap]")

    -- Zones with banks
    if mq.TLO.Zone.ID() == 737 or mq.TLO.Zone.ID() == 738 or mq.TLO.Zone.ID() ==
        751 or mq.TLO.Zone.ID() == 202 or mq.TLO.Zone.ID() == 203 or
        mq.TLO.Zone.ID() == 344 or mq.TLO.Zone.ID() == 345 or mq.TLO.Zone.ID() ==
        712 or mq.TLO.Zone.ID() == 29 or mq.TLO.Zone.ID() == 394 or
        mq.TLO.Zone.ID() == 852 then
        -- In a bank zone.
    else

        -- If in Gfaydark jump down to the ground
        if mq.TLO.Zone.ID() == 54 then
            mq.cmd('/nav locyx -443 92 |log=off')
            while mq.TLO.Nav.Active() do mq.delay(1000) end
            mq.cmd('/keypress forward hold')
            mq.delay(6000)
            mq.cmd('/keypress forward')
            mq.delay(2000)
        end

        if mq.TLO.Zone.ID() == 394 then movement.crescent_reach_floor_1() end

        mq.cmd('/squelch /travelto poknowledge')
        while true do
            if mq.TLO.Zone.ID() == 202 then break end
            mq.delay(1)
        end
        mq.delay(3000)
    end

    movement.bank()

    for x = 1, #p_shopper_array do
        local l_item_id = lib.return_number(p_shopper_array[x], 2)
        local l_item_qty = lib.return_number(p_shopper_array[x], 3)
        lib.GrabBankItemID(l_item_id, l_item_qty)

        lib.writefile("Withdrawals_" .. mq.TLO.Me.Name() .. "_" ..
                          mq.TLO.MacroQuest.Server(),
                      l_item_id .. "," .. l_item_qty)
        mq.delay(1)
    end

    -- Reset
    mq.cmd('/notify FindItemWnd FIW_Default leftmouseup')
    mq.delay(300)

    mq.cmd('/cleanup')
    mq.delay(750)
    return
end

-- Grab stuff from the depot
function shop.go_depot_shopping(p_shopper_array)

    if GLOBAL_ABORT_FLAG == 1 then return end

    -- print(msg, "\ap[\awDepot Shopping\ap]")

    -- Zones with banks
    if mq.TLO.Zone.ID() == 737 or mq.TLO.Zone.ID() == 738 or mq.TLO.Zone.ID() ==
        751 or mq.TLO.Zone.ID() == 202 or mq.TLO.Zone.ID() == 203 or
        mq.TLO.Zone.ID() == 344 or mq.TLO.Zone.ID() == 345 or mq.TLO.Zone.ID() ==
        712 or mq.TLO.Zone.ID() == 29 or mq.TLO.Zone.ID() == 394 or
        mq.TLO.Zone.ID() == 852 then
        -- In a bank zone.
    else

        -- Use the boat to get out of halas
        if mq.TLO.Zone.ID() == 29 then
            movement.leave_halas()
            mq.cmd('/squelch /travelto poknowledge')
            while true do
                if mq.TLO.Zone.ID() == 202 then break end
                mq.delay(1)
            end
        end

        -- If in Gfaydark jump down to the ground
        if mq.TLO.Zone.ID() == 54 then
            mq.cmd('/nav locyx -443 92 |log=off')
            while mq.TLO.Nav.Active() do mq.delay(1000) end
            mq.cmd('/keypress forward hold')
            mq.delay(6000)
            mq.cmd('/keypress forward')
            mq.delay(2000)
            mq.cmd('/squelch /travelto poknowledge')
            while true do
                if mq.TLO.Zone.ID() == 202 then break end
                mq.delay(1)
            end
        end

        -- if we are in CR go to 1st floor
        if mq.TLO.Zone.ID() == 394 then
            movement.crescent_reach_floor_1()
            mq.cmd('/squelch /travelto poknowledge')
            while true do
                if mq.TLO.Zone.ID() == 202 then break end
                mq.delay(1)
            end
        end

        -- mq.cmd('/squelch /travelto poknowledge')
        -- while true do
        --    if mq.TLO.Zone.ID() == 202 then break end
        --     mq.delay(1)
        --  end
        --  mq.delay(3000)
    end

    if mq.TLO.Merchant.Open() then
        mq.TLO.Window('MerchantWnd').DoClose()
        mq.delay(1500)
    end

    if mq.TLO.Window('TradeskillWnd').Open() then
        mq.TLO.Window('TradeskillWnd').DoClose()
        mq.delay(1500)
    end

    movement.bank()

    -- Open bank window
    if not mq.TLO.Window('BigBankWnd').Open() then
        mq.cmd('/nomodkey /click right target')
        mq.delay(1000)
    end

    if not mq.TLO.Window('TradeskillDepotWnd').Open() then
        mq.TLO.Window('TradeskillDepotWnd').DoOpen()
        mq.delay(500)
    end

    for c = 1, #p_shopper_array do

        local ohc = mq.TLO.FindItemCount(p_shopper_array[c].ID)()

        lib.GrabTSDItemID(p_shopper_array[c].ID, p_shopper_array[c].Quantity)
        -- lib.writefile("DEPOTWithdrawals_" .. mq.TLO.Me.Name() .. "_" ..
        --     mq.TLO.MacroQuest.Server(), p_shopper_array[c].Name ..
        --    "," .. p_shopper_array[c].Quantity)

        mq.delay(1000)

        local do_not = 0
        if do_not == 1 then
            -- Break out counter
            local boc = 0
            -- If the on hand count = current inventory, wait
            while ohc == mq.TLO.FindItemCount(p_shopper_array[c].ID)() do
                print(msg, "Waiting for item count in inventory to update")
                mq.delay(1000)
                boc = boc + 1
                -- Will break out if over 5 seconds
                if boc > 5 then break end
            end
        end

        lib.ClearCursor()
        mq.delay(500)
    end

    if mq.TLO.Window('TradeskillDepotWnd').Open() then
        mq.TLO.Window('TradeskillDepotWnd').DoClose()
        mq.delay(300)
    end

    mq.TLO.Window('BigBankWnd').DoClose()
    mq.delay(300)

    mq.delay(750)

    lib.ClearCursor()

    return
end

function shop.bank_deposit(p_item_id)

    if GLOBAL_ABORT_FLAG == 1 then return end

    local l_inv = mq.TLO.FindItemCount(p_item_id)()
    if l_inv < 1 then return end
    local l_item_name = mq.TLO.FindItem(p_item_id)()

    mq.delay(750)

    -- Add GH/GL bankers
    movement.bank()

    -- Open bank window
    if not mq.TLO.Window('BigBankWnd').Open() then
        mq.cmd('/nomodkey /click right target')
        mq.delay(750)
    end

    GLOBAL_STANDARD_CRAFTING_STATUS_MSG =
        "Depositing tradeskill Item: " .. l_item_name
    print(msg, "\ap[\agDepositing: \ap[\aw", l_item_name, "\ap]")

    lib.GrabItemID(p_item_id, -1)
    mq.delay(500)

    if mq.TLO.MacroQuest.Server() == "rizlonas" then
        mq.cmd('/notify BankWnd BW_AutoButton leftmouseup')
    else
        mq.cmd('/notify BigBankWnd BIGB_AutoButton leftmouseup')
    end

    mq.delay(500)
    lib.event()

    -- lib.writefile("350Deposit_" .. mq.TLO.Me.Name() .. "_" ..
    -- mq.TLO.MacroQuest.Server(), p_item_id)

    if INVENTORY_FLAG == 2 then
        INVENTORY_FLAG = 1
        --  full_bank = 1
        print(msg, " Your bank slots are full!")
        print(msg, "\ap[\ayPausing\ap] \ap[\agNo Bank Slots Available\ap]")

        mq.cmd('/squelch /lua pause tcn')
        --   break
    end

    mq.delay(750)
    mq.cmd('/cleanup')
    mq.delay(750)

    return

end

function shop.return_bank_shopping()

    if GLOBAL_DEPOSIT_FLAG == 0 then return end

    if GLOBAL_ABORT_FLAG == 1 then return end

    mq.delay(750)

    local file_string = "Withdrawals_" .. mq.TLO.Me.Name() .. "_" ..
                            mq.TLO.MacroQuest.Server() .. ".csv"

    local bank_file = lib.readfile_banking(file_string)

    -- check buyable and other tool list..

    -- get tools list and turn them in

    local bank_append = lib.bank_returns_data()

    -- does it get all the tools to start?
    -- any reason to remove dupes?

    if bank_append[1] ~= nil then
        for x = 1, #bank_append do
            table.insert(bank_file, 0, bank_append[x])
        end
    end

    -- If there are any tools in inventory auto-bank them ignore file?

    -- for z = 0, #bank_file do print(bank_file[z]) end
    -- os.exit()

    if bank_file[0] == nil then return end

    -- See if we have anything to return
    local returns = 1
    for x = 0, #bank_file do
        if GLOBAL_ABORT_FLAG == 1 then break end
        local l_id = lib.return_number(bank_file[x], 1)
        local l_qty = lib.return_number(bank_file[x], 2)
        local l_inv_count = mq.TLO.FindItemCount(l_id)()
        if l_inv_count == l_qty then returns = 0 end
    end

    -- Nothing to return return
    if returns == 1 then return end

    -- last chance shopping otehr chars, drone crafting..
    -- return ammo slot to ammo
    -- lev--speed and mounts get rid of!

    ---add gh gl bankers
    GLOBAL_TEXT = "Moving to Bank to store items"
    print(msg, "Moving to bank to store items")
    movement.bank()

    -- Open bank window
    if not mq.TLO.Window('BigBankWnd').Open() then
        mq.cmd('/nomodkey /click right target')
        mq.delay(750)
    end

    -- print(msg, "\ap[\awReturning Items to bank\ap]")

    local full_bank = 0
    for x = 0, #bank_file do
        if GLOBAL_ABORT_FLAG == 1 then break end
        -- add Error checking for nil
        local l_id = lib.return_number(bank_file[x], 1)
        local l_qty = lib.return_number(bank_file[x], 2)
        local l_inv_count = mq.TLO.FindItemCount(l_id)()

        if l_id > 1 and l_inv_count > 0 then
            local return_name = lib.return_item_name(l_id)
            if l_inv_count == l_qty then
                GLOBAL_TEXT = "Storing " .. return_name
                print(msg, "\ap[\agStoring:\ap] \ap(\ag", l_qty, "\ap) \ap(\aw",
                      return_name, "\ap) \ag ID: \ap(\ag", l_id, "\ap)")
                -- erorr checking?
                lib.GrabItemID(l_id, l_qty)

                if mq.TLO.MacroQuest.Server() == "rizlonas" then
                    mq.cmd('/notify BankWnd BW_AutoButton leftmouseup')
                else
                    mq.cmd('/notify BigBankWnd BIGB_AutoButton leftmouseup')
                end

                lib.event()

                -- Should pause in the event not here!
                -- change do events here
                -- mq.event('nobank', "You have no room left in the#*#", Event_No_Bank)

                if INVENTORY_FLAG == 2 then
                    INVENTORY_FLAG = 1
                    --  full_bank = 1
                    print(msg, " Your bank slots are full!")
                    print(msg,
                          "\ap[\ayPausing\ap] \ap[\agNo Bank Slots Available\ap]")

                    mq.cmd('/squelch /lua pause tcn')
                    --   break
                end
                --  mq.TLO.Window('BigBankWnd').Child('BIGB_AutoButton')()
                mq.delay(750)
            end
        end
    end

    if full_bank == 1 then
        GLOBAL_TEXT = "Bank is full of it"
        return
    end

    bank_file = {}

    lib.deletefile(file_string)

    mq.cmd('/cleanup')
    mq.delay(500)
    GLOBAL_TEXT = "Bank Transfer Complete"
    return
end

-- TODO - If at capacity then check for messages
-- TODO - If at 99999 and no slots, abort, and autoinv

-- Added 7/17/2023 JB321
function shop.return_depot()

    -- No Banking/Depot
    if GLOBAL_DEPOT_FLAG == 0 then return end

    if GLOBAL_ABORT_FLAG == 1 then return end

    -- Check for NOS
    if not mq.TLO.TradeskillDepot.Enabled() then
        mq.cmd('/cleanup')
        mq.delay(2000)
        return
    end

    -- Init Depot
    tsd_init()

    mq.delay(1000)

    -- Total count of depot items
    local depot_items_index = mq.TLO.Window('TradeskillDepotWnd').Child(
                                  'TD_Item_List').Items()

    -- If At Capacity Return
    if mq.TLO.TradeskillDepot.Capacity() == depot_items_index then
        --    mq.cmd('/cleanup')
        --    mq.delay(2000)
        --    return
    end

    print(msg,
          "Depot Capacity is: " .. mq.TLO.TradeskillDepot.Capacity() ..
              " Free Slots: " .. mq.TLO.TradeskillDepot.Capacity() -
              depot_items_index)

    -- Open Finditem window
    if not mq.TLO.Window('FindItemWnd').Open() then
        mq.TLO.Window('InventoryWindow').DoOpen()
        -- mq.cmd('/keypress Shift+Alt+F')
        mq.delay(500)
        mq.cmd('/notify InventoryWindow IW_FindItemButton leftmouseup')
        mq.delay(300)
    end

    mq.delay(1000)

    mq.cmd('/notify FindItemWnd FIW_Default leftmouseup')
    mq.delay(1000)

    -- Combobox for Location
    mq.cmd('/notify FindItemWnd FIW_ItemLocationCombobox leftmouseup')
    mq.delay(1000)

    local find_item_location_index = mq.TLO.Window('FindItemWnd').Child(
                                         'FIW_ItemLocationCombobox')
                                         .List('Inventory')()

    -- Select Inventory From Locations Drop-Down
    mq.cmd('/notify FindItemWnd FIW_ItemLocationCombobox listselect ' ..
               find_item_location_index .. ' leftmouseup')

    mq.delay(1000)

    local find_item_type_index = mq.TLO.Window('FindItemWnd').Child(
                                     'FIW_ItemTypeCombobox')
                                     .List('Tradeskill')()

    -- Select Tradeskill Type Drop-Down
    mq.cmd('/notify FindItemWnd FIW_ItemTypeCombobox listselect ' ..
               find_item_type_index .. ' leftmouseup')

    mq.delay(1000)

    -- Execute Search
    mq.cmd('/notify FindItemWnd FIW_QueryButton leftmouseup')
    mq.delay(1000)

    local l_items_index = mq.TLO.Window('FindItemWnd').Child('FIW_ItemList')
                              .Items()

    -- print(l_items_index)

    local count = 0

    local depot_item_array = {}

    for c = 1, l_items_index do

        -- Name of Item
        local l_items_name = mq.TLO.Window('FindItemWnd').Child('FIW_ItemList')
                                 .List(c, 2)()

        -- Quantity of Item
        local l_qty = mq.TLO.Window('FindItemWnd').Child('FIW_ItemList').List(c,
                                                                              3)()

        local l_item_id = mq.TLO.FindItem('=' .. l_items_name).ID()

        local t_type = mq.TLO.FindItem('=' .. l_items_name).Tradeskills()
        local l_type = mq.TLO.FindItem('=' .. l_items_name).Type()
        local s_type = mq.TLO.FindItem('=' .. l_items_name).StackSize()
        local d_type = mq.TLO.FindItem('=' .. l_items_name).NoDrop()
        local nt_type = mq.TLO.FindItem('=' .. l_items_name).NoTrade()
        local r_type = mq.TLO.FindItem('=' .. l_items_name).NoRent()

        if s_type > 99 and not d_type and not r_type and not nt_type then

            count = count + 1

            --  print("Count: ", count, " ", l_items_name, " ", t_type, " ", l_type,
            --       " ", s_type, " ID ", l_item_id, " ", d_type, " ", nt_type, " ",
            --      r_type)

            local is_tool = lib.return_tool_determination(l_item_id)

            local various_array = {
                13006, 13019, 10024, 13073, 10029, 10028, 9662, 13044, 29751,
                10015, 13015
            }

            local is_item = false

            local depot_array_list = lib.read_no_depot()

            --   local depot_array_len = string.len(depot_array_list[1])

            --  if depot_array_len < 1 then
            if #depot_array_list < 1 then
                -- print(msg, "No Global Depot Skip Data")
            else
                for d = 1, #depot_array_list do
                    if depot_array_list[d] == l_item_id then
                        is_item = true
                        break
                    end
                end
            end

            -- for various array, now defunct
            for e = 1, #various_array do
                if various_array[e] == l_item_id then
                    --    is_item = true
                    --    break
                end
            end

            -- is it a tool
            if not is_tool and not is_item then
                table.insert(depot_item_array, l_item_id)
            end

        end

    end

    mq.cmd('/notify FindItemWnd FIW_Default leftmouseup')
    mq.delay(1000)

    -- No TS Items To Deposit - Return
    if #depot_item_array < 1 then
        mq.cmd('/cleanup')
        mq.delay(2000)
        return
    end

    -- Close Find Item Window
    if mq.TLO.Window('FindItemWnd').Open() then
        mq.TLO.Window('FindItemWnd').DoClose()
        mq.delay(500)
    end

    -- Close Inventory
    if mq.TLO.Window('InventoryWindow').Open() then
        mq.TLO.Window('InventoryWindow').DoClose()
        mq.delay(500)
    end

    -- Move to bank
    movement.bank()

    mq.delay(1000)

    -- Open Banker
    if not mq.TLO.Window('BigBankWnd').Open() then
        mq.cmd('/nomodkey /click right target')
        mq.delay(1500)
    end

    -- Open Depot Window
    while not mq.TLO.Window('TradeskillDepotWnd').Open() do
        mq.cmd('/notify BigBankWnd BIGB_TradeskillDepot leftmouseup')
        mq.delay(500)
    end

    mq.TLO.Window('InventoryWindow').DoClose()
    mq.delay(500)

    -- Look for 99999 message

    for c = 1, #depot_item_array do

        -- Total count of depot items
        depot_items_index = mq.TLO.Window('TradeskillDepotWnd').Child(
                                'TD_Item_List').Items()

        -- If At Capacity Return
        -- if mq.TLO.TradeskillDepot.Capacity() == depot_items_index then break end

        if GLOBAL_DEPOT_FULL then
            GLOBAL_DEPOT_FULL = false
            -- break
            mq.delay(1000)
            mq.cmd('/autoinv')
            mq.delay(1000)
        end

        --  local mouseLocX = mq.TLO.Window('TradeskillDepotWnd').X() +
        --                        (mq.TLO.Window('TradeskillDepotWnd').Width() / 2)
        --   local mouseLocY = mq.TLO.Window('TradeskillDepotWnd').Y() +
        --                       (mq.TLO.Window('TradeskillDepotWnd').Height() / 2)

        lib.GrabItemID(depot_item_array[c], 1000)

        mq.delay(500)

        print(msg,
              '\ao Putting \ay' .. mq.TLO.Cursor.Name() .. ' \aoin your depot.')

        while mq.TLO.Cursor() do

            mq.TLO.TradeskillDepot.DepositItem()

            -- mq.cmdf('/mouseto %s %s', mouseLocX, mouseLocY)
            mq.delay(1000)
            -- mq.cmd('/click left')

            mq.cmd('/doevents')
            mq.cmd('/doevents')
            mq.cmd('/doevents')
            mq.cmd('/doevents')
            lib.event()
            mq.delay(300)

            if GLOBAL_DEPOT_FULL then
                mq.cmd('/autoinv')
                --   break
                GLOBAL_DEPOT_FULL = false
                mq.delay(1000)
            end

            if mq.TLO.Window('ConfirmationDialogBox')() then
                mq.cmd('/no') -- Avoid accidentally dropping items on the ground
            end
            mq.delay(1000)
        end

        count = count + 1

    end

    mq.delay(1000)

    mq.cmd('/cleanup')
    mq.delay(2000)
    print(msg, "Depot Transfer Complete")

    if mq.TLO.Window('TradeskillDepotWnd').Open() then
        mq.TLO.Window('TradeskillDepotWnd').DoClose()
        mq.delay(500)
    end

    -- Add in if we get depot full then switch to only items that exist in both inventory and depot

end

return shop
