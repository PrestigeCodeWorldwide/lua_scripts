-- tcn_events.lua
-- description - events for TCSNeXt
-- date 11/29/2022
-- upd
-- creator: jb321
-- version 1.0a
local mq = require('mq')

local msg = "\ap[\atTCSNe\auX\att\ap]\aw "

local function server_done() GL_SWITCH = 1 end

local function no_nothing() GL_SWITCH = 2 end

local function Event_No_Slots()
    print(msg,
          "\ap[\ayPausing\ap] \ap[\agTCN_LIB Unable to place item in any bag or slot\ap]")
    print " lib here"
    -- need to check this..
    mq.cmd('/lua pause tcn')
    return
end

local function Event_No_Bank()
    -- pause here..
    INVENTORY_FLAG = 2
    return
end

local function Event_No_Vend()
    INVENTORY_FLAG = 5
    return
end

-- events

-- mq.event('noslots', "There are no open slots#*#", Event_No_Slots)

mq.event('nobank', "You have no room left in the#*#", Event_No_Bank)

-- mq.event('novend', "Your inventory appears#*#", Event_No_Vend)

mq.event('ServerDone', "Outputfile Complete:#*#", server_done)

mq.event('YouKnowNothingJonSnow', "You haven#*#", no_nothing)

--add more events... migrate