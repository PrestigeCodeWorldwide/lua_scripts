local mq = require('mq')
--
-- tcn_movement.lua
-- Version 1.52b
-- Date: 9/1/2021
-- Updated: 02/07/2025
-- Creator: JB321

-- Usage: movement.function
-- movement functions

-- Add dead event checking

local msg = "\ap[\atTCSNe\auX\att\ap]\aw "

-- Once we get off elevator move to Wood Elf forge.
local function faydark_WE_forge()
    mq.cmd('/keypress forward hold')
    mq.delay(1000)
    mq.cmd('/keypress forward')
    mq.cmd('/squelch /nav locyx -122 -95 |log=off')
    while mq.TLO.Nav.Active() do mq.delay(300) end
    mq.cmd('/squelch /nav locyx -230 27 |log=off')
    while mq.TLO.Nav.Active() do mq.delay(300) end
    mq.cmd('/squelch /nav locyx -319 65 |log=off')
    while mq.TLO.Nav.Active() do mq.delay(300) end
    mq.cmd('/squelch /nav locyx -452 65 |log=off')
    while mq.TLO.Nav.Active() do mq.delay(1000) end
end

-- Crescent reach platform elevator
local function elevator_action()
    local tick = 0
    local setting = 0
    local cur_z = mq.TLO.Switch.Z()
    while true do
        cur_z = mq.TLO.Switch.Z()
        mq.delay(5)
        tick = mq.TLO.Switch.Z()
        if cur_z > tick then
            --  print(msg,cur_z, " Going down")
            print(msg, "Elevator is Going down")
            setting = -89.5
            break
        end

        if tick > cur_z then
            -- print(msg,cur_z, " Going up")
            print(msg, "Elevator is Going up")
            setting = 10.5
            break
        end

        if cur_z == 10.5 or cur_z == -89.5 then
            setting = cur_z
            break
        end
        mq.delay(1)
    end

    cur_z = mq.TLO.Switch.Z()
    while cur_z ~= setting do cur_z = mq.TLO.Switch.Z() end

    return setting
end

local function duck_action()
    if mq.TLO.Nav.Paused() then return end
    print(msg, "\ap[\awDucking\ap]")
    mq.cmd('/keypress duck')
    mq.delay(2000)
    mq.cmd('/keypress duck')
    mq.delay(1000)
    if mq.TLO.Me.Ducking() then
        -- mq.cmd('/stand')
        --  mq.delay(1000)
    end

    return
end

local function jump_action()
    if mq.TLO.Nav.Paused() then return end
    print(msg, "\ap[\awJumping\ap]")
    mq.cmd('/keypress space')
    mq.delay(1000)
    return
end

local function rewind_action()
    if mq.TLO.Nav.Paused() then return end
    print(msg, "\ap[\awRewinding\ap]")
    mq.cmd('/rewind')
    mq.delay(1000)
    return
end

-- Item must be targeted
local function IsItemStuck()

    local counter = 0
    local attempts = 0

    -- Current distance to item
    local l_current_item_target_distance = mq.TLO.ItemTarget.Distance()
    local l_next_item_target_distance

    -- Start loop
    while mq.TLO.Nav.Active() do

        l_current_item_target_distance = math.ceil(mq.TLO.ItemTarget.Distance())
        mq.delay(100)
        l_next_item_target_distance = math.ceil(mq.TLO.ItemTarget.Distance())

        -- Distance has not changed
        if l_current_item_target_distance == l_next_item_target_distance then
            counter = counter + 1

            -- Try to get unstuck by ducking
            if counter == 50 then
                print(msg, "\ap[\awDucking\ap]")
                mq.cmd('/keypress duck')
                mq.delay(2000)
                mq.cmd('/keypress duck')
                counter = 0
                attempts = attempts + 1

                if attempts > 9 then
                    print "we tried 10 times to get there, giving up!"
                    print(msg,
                          "\ap[\ayPausing\ap] \ap[\agWe are unable to get to our destination\ap]")
                    if mq.TLO.Nav.Active() then
                        mq.cmd('/squelch /nav pause')
                    end
                    mq.cmd('/squelch /lua pause tcn')
                end
            end
        else
            counter = 0
        end
        mq.delay(1)
    end
    return
end

-- Are we facing the Item?
local function IsFacingItem()
    if GLOBAL_ABORT_FLAG == 1 then return end
    local my_heading = math.ceil(mq.TLO.Me.Heading.DegreesCCW())
    local item_heading = math.ceil(mq.TLO.ItemTarget.HeadingTo.DegreesCCW())
    -- print("my : ", my_heading)
    -- print("my heading to item ", item_heading)
    if my_heading > item_heading or my_heading < item_heading then
        local calc = math.abs(my_heading - item_heading)
        if calc > 9 then
            --    print("degree calc ", calc)
            print(msg, "\ap[\agFacing\ap[\aw", mq.TLO.ItemTarget(), "\ap]")
            mq.TLO.ItemTarget.DoFace()
            mq.delay(1500)
        end
    end
    return
end

-- Are we facing the NPC?
local function IsFacingNPC(p_npc_id)
    if GLOBAL_ABORT_FLAG == 1 then return end
    local my_heading = math.ceil(mq.TLO.Me.Heading.DegreesCCW())
    local spawn_heading = math.ceil(mq.TLO.Spawn(p_npc_id).HeadingTo
                                        .DegreesCCW())
    if my_heading > spawn_heading or my_heading < spawn_heading then
        local calc = math.abs(my_heading - spawn_heading)
        if calc > 9 then
            --    print("degree calc ", calc)
            --   print(msg, "\ap[\agFacing\ap] \ap[\aw",
            --        mq.TLO.Spawn(p_npc_id).DisplayName(), "\ap]")
            --    mq.cmd('/squelch /face ', mq.TLO.Spawn(p_npc_id)())
            mq.delay(1500)
        end
    end
    return
end

local function StaticItemReached(p_container)
    local l_item_distance = math.ceil(mq.TLO.ItemTarget(p_container).Distance())
    if l_item_distance > 15 then
        print(msg, "\ap[\agMoving\ap] \ap[\ag", p_container,
              "\ap] \ap[\agDistance:\ap] \ap(\ag", l_item_distance, "\ap)")
        return 0
    else
        IsFacingItem()
        return 1
    end
end

local function IsNPCStuck(p_spawn_id)
    --  print "IsNPCstuck"
    local counter = 0
    local attempts = 0

    local start_time = os.time()

    -- Current distance to Spawn
    local current_spawn_distance =
        math.ceil(mq.TLO.Spawn(p_spawn_id).Distance())

    local next_spawn_distance

    local check_spawn_distance = math.ceil(mq.TLO.Spawn(p_spawn_id).Distance())

    -- Start loop
    while mq.TLO.Nav.Active() do

        if GLOBAL_ABORT_FLAG == 1 then break end

        local random = math.random(5, 15)

        local end_time = os.time()
        local elapsed_time = math.ceil(os.difftime(end_time, start_time))
        current_spawn_distance = mq.TLO.Spawn(p_spawn_id).Distance()
        if elapsed_time == random then

            -- Reset timer
            start_time = os.time()
            --  print "checking distance"
            mq.delay(100)
            next_spawn_distance = mq.TLO.Spawn(p_spawn_id).Distance()
            if current_spawn_distance < check_spawn_distance or
                current_spawn_distance == next_spawn_distance then
                local dist_travelled = check_spawn_distance -
                                           current_spawn_distance

                if dist_travelled < 10 or current_spawn_distance ==
                    next_spawn_distance then
                    attempts = attempts + 1

                    duck_action()

                    mq.delay(500)
                    next_spawn_distance = mq.TLO.Spawn(p_spawn_id).Distance()

                    if current_spawn_distance == next_spawn_distance then
                        jump_action()
                    end
                    mq.delay(500)
                    next_spawn_distance = mq.TLO.Spawn(p_spawn_id).Distance()

                    if current_spawn_distance == next_spawn_distance then
                        rewind_action()
                    end

                end
            end
        end
        if attempts > 9 then
            mq.cmd('/beep')
            print(msg, "we tried 10 times to get there, giving up!")
            print(msg,
                  "\ap[\ayPausing\ap] \ap[\agWe are unable to get to the NPC (SPAWN) ",
                  mq.TLO.Spawn(p_spawn_id)(), "\ap]")

            if mq.TLO.Nav.Active() then mq.cmd('/squelch /nav pause') end
            mq.cmd('/squelch /lua pause tcn')
            -- add lev?
        end
        mq.delay(1)
    end
    return
end

local function PathDistanceContainer(p_nav, p_container)

    if GLOBAL_ABORT_FLAG == 1 then return end

    local flag = 0
    -- Current distance to Path
    local l_path_distance = math.ceil(mq.TLO.Nav.PathLength('loc ' .. p_nav)())

    if l_path_distance < 15 then
        flag = 1
        return flag
    end

    print(msg, "\ap[\agContainer\ap] \ap[\aw", p_container,
          "\ap] \ap[\agDistance\ap] \ap(\ag", l_path_distance, "\ap)")

    return flag

end

local function IsPathStuck(p_nav)

    if GLOBAL_ABORT_FLAG == 1 then return end

    -- print "IsPathStuck"
    local start_time = os.time()
    local attempts = 0
    -- Current distance to NAV
    local PathLengthCurrent =
        math.ceil(mq.TLO.Nav.PathLength('loc ' .. p_nav)())
    -- Length for checking
    local PathLengthCheck = math.ceil(mq.TLO.Nav.PathLength('loc ' .. p_nav)())
    -- Start loop

    -- print(" Current1 ", PathLengthCurrent, " Length Check1 ",PathLengthCheck)

    local random
    while mq.TLO.Nav.Active() do

        if GLOBAL_ABORT_FLAG == 1 then break end

        random = math.random(5, 15)
        PathLengthCurrent = math.ceil(mq.TLO.Nav.PathLength('loc ' .. p_nav)())
        mq.delay(100)
        local NextLengthLast = math.ceil(mq.TLO.Nav
                                             .PathLength('loc ' .. p_nav)())
        local end_time = os.time()
        local elapsed_time = os.difftime(end_time, start_time)
        if elapsed_time == random then

            --  print("Path Stuck Random Timer: ",random)

            -- Reset timer
            start_time = os.time()

            --   print(" PathStuck Testing Current ", PathLengthCurrent,
            --     " Length Check ", PathLengthCheck, " nExt Length: ",
            --     NextLengthLast)

            if PathLengthCurrent < PathLengthCheck or PathLengthCurrent ==
                NextLengthLast then
                local dist_travelled = PathLengthCheck - PathLengthCurrent
                if dist_travelled < 10 or PathLengthCurrent == NextLengthLast then
                    attempts = attempts + 1
                    duck_action()
                    mq.delay(500)
                    NextLengthLast = math.ceil(
                                         mq.TLO.Nav.PathLength('loc ' .. p_nav)())

                    if PathLengthCurrent == NextLengthLast then
                        jump_action()
                    end
                    mq.delay(500)
                    NextLengthLast = math.ceil(
                                         mq.TLO.Nav.PathLength('loc ' .. p_nav)())

                    if PathLengthCurrent == NextLengthLast then
                        rewind_action()
                    end
                end
            end
        end

        if attempts > 9 then
            mq.cmd('/beep')
            print (msg,"we tried 10 times to get there, giving up!")
            print(msg,
                  "\ap[\ayPausing\ap] \ap[\agWe are unable to get to the NPC (PATH)\ap]")
            if mq.TLO.Nav.Active() then mq.cmd('/squelch /nav pause') end
            mq.cmd('/squelch /lua pause tcn')
        end
        mq.delay(1)
    end
    -- print "PathDone"
    return
end

local movement = {}

-- containers, people, places..

function movement.gfay_platform()

    mq.cmd('/nav locyx 69 -139 |log=off')
    while mq.TLO.Nav.Active() do mq.delay(1000) end

    mq.cmd('/nav locyx 32 -140 |log=off')
    while mq.TLO.Nav.Active() do mq.delay(1000) end

    mq.cmd('/squelch /doortarget id 80')
    mq.delay(3000)

    while true do

        if mq.TLO.Switch.State() == 1 then
            -- It is at the top bring it down
            if mq.TLO.Switch.Z() > 70 then
                mq.cmd('/squelch /doortarget id 81')
                mq.delay(1000)
                mq.cmd('/squelch /click left door')
                mq.delay(1000)
                mq.cmd('/squelch /doortarget id 80')
                while mq.TLO.Switch.Z() > 2.5 do mq.delay(1000) end
                mq.cmd('/keypress forward hold')
                mq.delay(350)
                mq.cmd('/keypress forward')
                mq.delay(1000)
                mq.cmd('/squelch /doortarget id 81')
                mq.delay(1000)
                mq.cmd('/squelch /click left door')
                mq.delay(1000)
                mq.cmd('/squelch /doortarget id 80')
                while mq.TLO.Switch.Z() < 71.3 do mq.delay(1000) end
                faydark_WE_forge()
                break
            end
        end

        if mq.TLO.Switch.State() == 0 then
            -- It is at the bottom, get on
            if mq.TLO.Switch.Z() < 2.41 then
                mq.cmd('/keypress forward hold')
                mq.delay(350)
                mq.cmd('/keypress forward')
                mq.delay(1000)
                mq.cmd('/squelch /doortarget id 81')
                mq.delay(1000)
                mq.cmd('/squelch /click left door')
                mq.delay(1000)
                mq.cmd('/squelch /doortarget id 80')
                mq.delay(1000)
                while mq.TLO.Switch.Z() < 71.3 do mq.delay(1000) end
                faydark_WE_forge()
                break
            end
        end

        -- It is going up
        if mq.TLO.Switch.State() == 2 then
            while mq.TLO.Switch.Z() < 71.3 do mq.delay(1000) end
            mq.delay(1000)
            mq.cmd('/squelch /doortarget id 81')
            mq.delay(1000)
            mq.cmd('/squelch /click left door')
            mq.delay(1000)
            mq.cmd('/squelch /doortarget id 80')
            while mq.TLO.Switch.Z() > 2.5 do mq.delay(1000) end
            mq.cmd('/keypress forward hold')
            mq.delay(350)
            mq.cmd('/keypress forward')
            mq.delay(1000)
            mq.cmd('/squelch /doortarget id 81')
            mq.delay(1000)
            mq.cmd('/squelch /click left door')
            mq.delay(1000)
            mq.cmd('/squelch /doortarget id 80')
            while mq.TLO.Switch.Z() < 71.3 do mq.delay(1000) end
            faydark_WE_forge()
            break
        end

        -- It is going down
        if mq.TLO.Switch.State() == 3 then
            while mq.TLO.Switch.Z() > 2.41 do mq.delay(1000) end
            mq.cmd('/keypress forward hold')
            mq.delay(350)
            mq.cmd('/keypress forward')
            mq.delay(1000)
            mq.cmd('/squelch /doortarget id 81')
            mq.delay(1000)
            mq.cmd('/squelch /click left door')
            mq.delay(1000)
            mq.cmd('/squelch /doortarget id 80')
            while mq.TLO.Switch.Z() < 71.3 do mq.delay(1000) end
            faydark_WE_forge()
            break
        end

        mq.delay(1000)

    end

end

-- Crescent Reach
--- go to floor 2
function movement.crescent_reach_floor_2()
    if mq.TLO.Me.Z() > 10 then return end
    local cur_z = mq.TLO.Switch.Z()
    mq.cmd('/squelch /doortarget id 1')
    -- print "Stage"
    mq.cmd('/squelch /nav locyx -1313 -1523 |log=off')
    mq.delay(100)
    while mq.TLO.Nav.Active() do mq.delay(1) end
    -- print "Staged"
    -- print "Checking Elevator Status"
    local setting = elevator_action()

    if setting == 10.5 then
        -- print "Top Floor"
        mq.cmd('/squelch /doortarget id 11')
        mq.delay(5)
        -- Click switch
        mq.cmd('/squelch /click left door')
        mq.delay(100)
        mq.cmd('/squelch /doortarget id 1')

        cur_z = mq.TLO.Switch.Z()
        -- Wait for it to come down
        while true do
            cur_z = mq.TLO.Switch.Z()
            if cur_z == -89.5 then
                setting = -89.5
                break
            end
        end
    end
    if setting == -89.5 then
        -- Hop on
        mq.cmd('/squelch /nav locyx -1306 -1540 |log=off')
        mq.delay(2000)

        while true do
            cur_z = mq.TLO.Switch.Z()
            if cur_z == 10.5 then
                mq.delay(100)
                -- Get off
                mq.cmd('/squelch /moveto loc -1305 -1496')
                mq.delay(4000)
                break
            end
        end
    end
end

-- Crescent Reach
-- Go to floor 1
function movement.crescent_reach_floor_1()

    -- already there
    if mq.TLO.Me.Z() < -70 then return end

    local cur_z = mq.TLO.Switch.Z()

    mq.cmd('/squelch /nav locyx -1313 -1523 |log=off')
    while mq.TLO.Nav.Active() do mq.delay(1) end
    --  print "Staged"

    -- Target Elevator if it is not targeted
    if mq.TLO.DoorTarget() == nil then
        mq.delay(1000)
        mq.cmd('/squelch /doortarget id 1')
        mq.delay(1000)
    end

    -- check elevator status

    local setting = elevator_action()

    -- print(setting)
    if setting == -89.5 then
        -- print "Bottom Floor"
        mq.cmd('/squelch /doortarget id 11')
        mq.delay(5)
        -- Click switch
        mq.cmd('/squelch /click left door')
        mq.delay(100)
        mq.cmd('/squelch /doortarget id 1')

        cur_z = mq.TLO.Switch.Z()
        -- Wait for it to come down
        while true do
            cur_z = mq.TLO.Switch.Z()
            if cur_z == 10.5 then
                setting = 10.5
                break
            end
        end
    end
    if setting == 10.5 then
        -- Hop on and click
        mq.cmd('/squelch /moveto loc -1306 -1540')
        mq.delay(2000)
        mq.cmd('/squelch /doortarget id 11')
        mq.delay(5)
        -- Click switch
        mq.cmd('/squelch /click left door')
        mq.delay(100)
        mq.cmd('/squelch /doortarget id 1')

        while true do
            cur_z = mq.TLO.Switch.Z()
            if cur_z == -89.5 then
                mq.delay(100)
                -- print("Getting Off This Crazy Thing")
                mq.cmd('/squelch /moveto loc -1305 -1496')
                mq.delay(4000)
                break
            end
        end
    end
end

-- Determines if you have gate ability
function movement.gate_class()
    local eq_gate_classes = {"CLR", "DRU", "WIZ", "ENC", "MAG", "SHM"}
    local gate_class = 0
    for c = 1, #eq_gate_classes do
        if eq_gate_classes[c] == mq.TLO.Me.Class.ShortName() then
            gate_class = 1
            -- print("I'm a gate class: ",mq.TLO.Me.Class.ShortName())
            break
        end
    end
    return gate_class
end

-- Am I bound in POK or POT?
function movement.where_bound()
    if mq.TLO.Me.ZoneBound.ID() == 202 or mq.TLO.Me.ZoneBound.ID() == 203 then
        return 1
    else
        return 0
    end
end

function movement.gate_action()
    while true do
        if mq.TLO.Me.AltAbilityReady('Gate')() then
            print(" \agUsing: \ayGate")
            GLOBAL_TEXT = "Gating"
            mq.cmd('/alt act 1217')
            mq.delay(12000)
            if mq.TLO.Zone.ID() == 202 or mq.TLO.Zone.ID() == 203 then
                break
            end
        end
        mq.delay(1000)
    end
    return
end

function movement.lebounde_wait_spot()

    mq.delay(1000)
    mq.cmd('/squelch /target Oli')
    mq.delay(1000)

    -- NOTE: CHECK TO SEE IF WE MADE IT TO THE OTHER SIDE
    if not mq.TLO.Nav.PathExists('Target')() then

        -- Get to Boat area
        mq.cmd('/squelch /nav locyxz -477 -2 1 |log=off')
        movement.moving()

        -- swim across
        mq.cmd('/squelch /target Oli')
        mq.delay(2000)
        mq.cmd('/squelch /face Oli')
        mq.delay(2000)
        mq.cmd('/keypress page_up hold')
        mq.delay(2000)
        mq.cmd('/keypress page_up')
        mq.delay(2000)

        print(msg, "\aw[Swimming]")

        while mq.TLO.Target.Distance() > 25 do
            mq.cmd('/keypress forward hold')
            mq.delay(100)
        end
        mq.cmd('/keypress forward')
        mq.delay(1000)
    end

    -- move to the side of the town square 
    mq.cmd('/squelch /nav locyxz 68 -183 2 |log=off')
    movement.moving()

    -- Lebounde Wait Spot
    mq.cmd('/squelch /nav locyxz 174 -416 2 |log=off')
    movement.moving()

    -- While mq.TLO.Target lebounde > 30 do nothing..
    -- wait for labby to be < 30 and los
    -- go visible
    -- do stuff
    -- if questing always be vis..
    return
end

function movement.northman_forge()

    mq.delay(1000)
    mq.cmd('/squelch /target Oli')
    mq.delay(1000)

    -- NOTE: CHECK TO SEE IF WE MADE IT TO THE OTHER SIDE
    if not mq.TLO.Nav.PathExists('Target')() then

        -- Get to Boat area
        mq.cmd('/squelch /nav locyxz -477 -2 1 |log=off')
        movement.moving()

        -- swim across
        mq.cmd('/squelch /target Oli')
        mq.delay(2000)
        mq.cmd('/squelch /face Oli')
        mq.delay(2000)
        mq.cmd('/keypress page_up hold')
        mq.delay(2000)
        mq.cmd('/keypress page_up')
        mq.delay(2000)

        print(msg, "\aw[Swimming]")

        while mq.TLO.Target.Distance() > 25 do
            mq.cmd('/keypress forward hold')
            mq.delay(1)
        end
        mq.cmd('/keypress forward')
        mq.delay(1000)
    end

    -- move to avoid wall 
    mq.cmd('/squelch /nav locyxz 37 1 4 |log=off')
    movement.moving()

    -- move to the side of the town square 
    -- mq.cmd('/squelch /nav locyxz 68 -183 2 |log=off')
    -- movement.moving()

    -- Northman Forge (a couple away)
    mq.cmd('/squelch /nav locyxz 259 -330 4 |log=off')
    movement.moving()

    return
end

function movement.leave_halas()

    -- LEAVING HALAS TOWN SQUARE
    -- Head to North Side Boat Area
    mq.cmd('/nav locyxz -27 12 3 |log=off')
    movement.moving()

    mq.cmd('/nav locyxz -54 11 5 |log=off')
    movement.moving()

    -- Target boat
    mq.delay(1)
    mq.cmd('/tar Gwenavyne')
    mq.delay(1)

    -- Wait while boat is moving away
    while mq.TLO.Target.Fleeing() do mq.delay(1) end

    -- Wait for boat to get close
    while mq.TLO.Target.Distance('The Gwenavyne')() > 80 do
        -- print(mq.TLO.Target.Distance('The Gwenavyne')())
        mq.delay(1)
    end

    --- Wait til boat stops moving
    while mq.TLO.Target.Moving() do mq.delay(1) end

    mq.cmd('/squelch /moveto loc -90 11')

    -- Wait while boat is not moving
    while not mq.TLO.Target.Moving() do mq.delay(1) end

    -- Wait while boat is moving
    while mq.TLO.Target.Moving() do mq.delay(1) end

    -- get on dry land
    mq.cmd('/squelch /moveto loc -484 8 ')
    mq.delay(6000)

    return

end

function movement.port_methods(p_zone_id)

    if GLOBAL_ABORT_FLAG == 1 then return end

    if mq.TLO.Zone.ID() == p_zone_id then return end

    -- print (mq.TLO.Zone.ID(), " ",p_zone_id)
    -- os.exit()
    mq.delay(10000)

    print(msg,
          "\ap[\awTrying to find a way to get back home, wherever that is\ap]")

    if mq.TLO.Me.ZoneBound.ID() == 202 or mq.TLO.Me.ZoneBound.ID() == 203 or
        mq.TLO.Me.ZoneBound.ID() == 344 then

        if mq.TLO.Me.AltAbilityReady('Gate')() then
            print(" \agUsing: \ayGate")
            mq.cmd('/alt act 1217')
            mq.delay(8000)

            -- add more zones make mini table
            if mq.TLO.Zone.ID() == 202 or mq.TLO.Zone.ID() == 203 or
                mq.TLO.Zone.ID() == 344 then return end
        end

    end

    -- Binden Concertia
    -- Secondary gate..
    -- Third gate
    -- Potion

    if mq.TLO.Me.Origin.ID() == 394 then
        if mq.TLO.Me.AltAbilityReady('Origin')() then
            print(msg, "\agUsing: \ayOrigin")
            mq.cmd('/alt act 331')
            mq.delay(60000, function() return mq.TLO.Zone.ID() == 394 end)
            --   while not mq.TLO.Nav.MeshLoaded() do mq.delay(1000) end
            return
        end
    end

    if mq.TLO.Me.AltAbilityReady('Throne Of Heroes')() then
        print(msg, "\agUsing: \ayThrone Of Heroes")
        mq.cmd('/alt act 511')
        mq.delay(60000, function() return mq.TLO.Zone.ID() == 344 end)
        --   while not mq.TLO.Nav.MeshLoaded() do mq.delay(1000) end
        return
    end

    if mq.TLO.FindItem("Drunkard's Stein").ID() ~= nil and
        mq.TLO.FindItem("Drunkard's Stein").TimerReady() == 0 then
        print(msg, "\agUsing: \ayDrunkard's Stein")
        local str = "Drunkard's Stein"
        mq.cmd('/useitem ', str)
        mq.delay(60000, function() return mq.TLO.Zone.ID() == 202 end)
        --   while not mq.TLO.Nav.MeshLoaded() do mq.delay(1000) end
        return
    end

    return
end

function movement.cr_bfm()
    if mq.TLO.Zone.ID() == 395 then return end
    if mq.TLO.Zone.ID() == 394 then
        print(msg, "\aw[Heading To] \ag[Blightfire Moors]")
        mq.cmd('/squelch /nav locyxz -880 -2760 -56 | log = off')
        movement.moving()
        mq.delay(1000)
        mq.delay(60000, function() return mq.TLO.Zone.ID() == 395 end)
        while not mq.TLO.Nav.MeshLoaded() do mq.delay(1000) end
    end
    return
end

function movement.bfm_pok()
    if mq.TLO.Zone.ID() == 202 then return end
    if mq.TLO.Zone.ID() == 395 then
        print(msg, "\aw[Heading To] \ag[Plane Of Knowledge]")
        mq.cmd('/squelch /nav door id 68 click | log = off')
        movement.moving()
        mq.delay(1000)
        mq.delay(60000, function() return mq.TLO.Zone.ID() == 202 end)
        --    while not mq.TLO.Nav.MeshLoaded() do mq.delay(1000) end
    end
    return
end

function movement.nedaria_abysmal()
    if mq.TLO.Zone.ID() == 279 then return end
    -- Zone Nedaria's Landing to Abysmal Sea
    if mq.TLO.Zone.ID() == 182 then
        --   print("\at[TNe\awx\att] \aw[Heading To] \ag[", mq.TLO.Zone(279), "]")
        movement.npc('Magus Wenla')
        movement.moving()
        mq.delay(1000)
        mq.cmd("/say Abysmal Sea")
        mq.delay(60000, function() return mq.TLO.Zone.ID() == 279 end)
        ---    while not mq.TLO.Nav.MeshLoaded() do mq.delay(1000) end
    end
    return
end

function movement.gl_nedaria()
    if mq.TLO.Zone.ID() == 182 then return end
    if mq.TLO.Zone.ID() == 344 then
        --  print("\at[SNe\awx\att] \aw[Heading To] \ag[", mq.TLO.Zone(182), "]")
        movement.npc('Magus Alaria')
        movement.moving()
        mq.delay(1000)
        mq.cmd("/say Nedaria's landing")
        mq.delay(60000, function() return mq.TLO.Zone.ID() == 182 end)
        --   while not mq.TLO.Nav.MeshLoaded() do mq.delay(1000) end
    end
    return
end

function movement.pok_gl()
    if mq.TLO.Zone.ID() == 344 then return end
    if mq.TLO.Zone.ID() == 202 then
        --   print("\at[TNe\awx\att] \aw[Heading To] \ag[", mq.TLO.Zone(344), "]")
        mq.cmd('/squelch /nav door id 17 click | log = off')
        movement.moving()
        mq.delay(1000)
        mq.delay(60000, function() return mq.TLO.Zone.ID() == 344 end)
        --   while not mq.TLO.Nav.MeshLoaded() do mq.delay(1000) end
    end
    return
end

function movement.fp_pok()
    if mq.TLO.Zone.ID() == 202 then return end
    if mq.TLO.Zone.ID() == 383 then
        --   print("\at[Ne\awx\att] \aw[Heading To] \ag[", mq.TLO.Zone(202), "]")
        mq.cmd('/squelch /nav door id 41 click | log = off')
        movement.moving()
        mq.delay(1000)
        mq.delay(60000, function() return mq.TLO.Zone.ID() == 202 end)
        --  while not mq.TLO.Nav.MeshLoaded() do mq.delay(1000) end
        mq.delay(5000)
    end
    return
end

function movement.pok_fp()

    if mq.TLO.Zone.ID() == 383 then return end

    if mq.TLO.Zone.ID() == 202 then

        --   print("\at[TNe\awx\att] \aw[Heading To] \ag[", mq.TLO.Zone(383), "]")
        -- lookup  text? -- cant do loadstring so no bother?
        -- return what based on id.. because it wont matter if we want to get to fp and we are not in pok..
        -- if we said id 383 and there are 2 ways to get to it?
        local str = "/squelch /nav door id 10 click | log = off'"
        -- mq.cmd('/squelch /nav door id 10 click | log = off')
        mq.cmd(str)
        movement.moving()
        -- database?
        -- zone variable.
        mq.delay(1000)
        mq.delay(60000, function() return mq.TLO.Zone.ID() == 383 end)
        -- while not mq.TLO.Nav.MeshLoaded() do mq.delay(1000) end

    end
    return
end

function movement.gl_pok()
    if mq.TLO.Zone.ID() == 202 then return end
    if mq.TLO.Zone.ID() == 344 then
        --  print("\at[TSNe\awx\att] \aw[Heading To] \ag[", mq.TLO.Zone(202), "]")
        -- heading to?
        -- lookup  text? -- cant do loadstring so no bother?
        -- return what based on id.. because it wont matter if we want to get to fp and we are not in pok..
        local str = "/squelch /nav door id 2 click | log = off'"
        -- mq.cmd('/squelch /nav door id 10 click | log = off')
        mq.cmd(str)
        movement.moving()
        -- database?
        -- zone variable.
        mq.delay(1000)
        mq.delay(60000, function() return mq.TLO.Zone.ID() == 202 end)
        -- while not mq.TLO.Nav.MeshLoaded() do mq.delay(1000) end
    end
    return
end

function movement.sgh_gl()
    if mq.TLO.Zone.ID() == 344 then return end
    if mq.TLO.Zone.ID() == 345 then

        --  print("\at[TSNe\awx\att] \aw[Heading To] \ag[", mq.TLO.Zone(202), "]")
        -- heading to?
        -- lookup  text? -- cant do loadstring so no bother?
        -- return what based on id.. because it wont matter if we want to get to fp and we are not in pok..
        local str = "/squelch /nav door id 1 click | log = off'"
        -- mq.cmd('/squelch /nav door id 10 click | log = off')
        mq.cmd(str)
        movement.moving()
        -- database?
        -- zone variable.
        mq.delay(1000)
        mq.delay(60000, function() return mq.TLO.Zone.ID() == 344 end)
        -- while not mq.TLO.Nav.MeshLoaded() do mq.delay(1000) end
        mq.delay(3000)
    end
    return
end

function movement.gl_sgh()
    if mq.TLO.Zone.ID() == 345 then return end
    if mq.TLO.Zone.ID() == 344 then

        --  print("\at[TSNe\awx\att] \aw[Heading To] \ag[", mq.TLO.Zone(202), "]")
        -- heading to?
        -- lookup  text? -- cant do loadstring so no bother?
        -- return what based on id.. because it wont matter if we want to get to fp and we are not in pok..
        local str = "/squelch /nav door id 3 click | log = off'"
        -- mq.cmd('/squelch /nav door id 10 click | log = off')
        mq.cmd(str)
        movement.moving()
        -- database?
        -- zone variable.
        mq.delay(1000)
        mq.delay(60000, function() return mq.TLO.Zone.ID() == 345 end)
        -- while not mq.TLO.Nav.MeshLoaded() do mq.delay(1000) end
        mq.delay(3000)
    end
    return
end

function movement.gl_ngh()
    local guild_zones = {738, 737, 751}
    local flag = 0
    for x = 1, #guild_zones do
        if mq.TLO.Zone.ID() == guild_zones[x] then
            flag = 1
            break
        end
    end
    if flag == 1 then return end

    if mq.TLO.Zone.ID() == 344 then

        --  print("\at[TSNe\awx\att] \aw[Heading To] \ag[", mq.TLO.Zone(202), "]")
        -- lookup  text? -- cant do loadstring 
        -- return what based on id.. because it wont matter if we want to get to fp and we are not in pok..
        -- Click the neighborhood
        local str = "/squelch /nav door id 1 click | log = off'"
        -- mq.cmd('/squelch /nav door id 10 click | log = off')
        mq.cmd(str)

        movement.moving()

        mq.delay(1000)

        while mq.TLO.Zone.ID() == 344 do mq.delay(1500) end
        -- how to squelch nav mesh?
        -- while not mq.TLO.Nav.MeshLoaded() do mq.delay(1000) end

        -- What is the order for this?
        -- mq.delay(60000, function() return mq.TLO.Zone.ID() == 202 end)

        mq.delay(5000)
    end

    return
end

local function srh_gate()

    if GLOBAL_ABORT_FLAG == 1 then return end

    mq.delay(1000)
    mq.cmd('/squelch /nav door id 38 click')
    while mq.TLO.Nav.Active() do mq.delay(1) end

    -- Access 1st plot (if there is one)
    mq.delay(5000)
    mq.cmd(
        '/squelch /notify RealEstateNeighborHoodWnd RENW_MyPlots_Button leftmouseup')
    mq.delay(5000)
    local neighborhood_index = mq.TLO.Window('RealEstateNeighborHoodWnd').Child(
                                   'RENW_NeighborhoodList').Items()

    -- If we don't have plot just select the 1st one
    if neighborhood_index == 0 or neighborhood_index == nil then
        mq.cmd('/cleanup')
        mq.delay(1000)
        mq.cmd('/squelch /nav door id 38 click')
        mq.delay(5000)
        -- wait for pop--add better delay mechanics
        -- window check
        mq.cmd(
            '/notify RealEstateNeighborHoodWnd RENW_NeighborHoodList listselect 1')
        mq.delay(1000)
        mq.cmd('/notify RealEstateNeighborHoodWnd RENW_Go_Button leftmouseup')
    else

        -- Open window wait for window population then do this if no plots
        mq.cmd(
            '/notify RealEstateNeighborHoodWnd RENW_NeighborHoodList listselect 1')
        mq.delay(1000)
        mq.cmd('/notify RealEstateNeighborHoodWnd RENW_Go_Button leftmouseup')
    end
    return
end

function movement.gl_srh()
    if mq.TLO.Zone.ID() == 712 then return end
    if mq.TLO.Zone.ID() == 344 then srh_gate() end
    while mq.TLO.Zone.ID() == 344 do mq.delay(1) end
    return
end

function movement.srh_gl()
    if mq.TLO.Zone.ID() == 344 then return end
    if mq.TLO.Zone.ID() == 712 then
        mq.cmd('/squelch /nav door id 134 click | log = off')
        while mq.TLO.Zone.ID() == 712 do mq.delay(1) end
    end
    return
end

function movement.pok_tgd()
    if mq.TLO.Zone.ID() == 118 then return end
    if mq.TLO.Zone.ID() == 202 then
        --    print("\at[TSNe\awx\att] \aw[Heading To] \ag[", mq.TLO.Zone(118), "]")
        mq.cmd('/squelch /nav door id 15 click |log=off')
        movement.moving()
        mq.delay(1000)

        -- Added 6/4/2023
        -- Click Great Divide Window
        if mq.TLO.Window['LargeDialogWindow'].Child['LDW_NoButton'] then
            if mq.TLO.Window('LargeDialogWindow').Open() then
                mq.TLO.Window('LargeDialogWindow/LDW_NoButton').LeftMouseUp()
            end
        end

        mq.delay(60000, function() return mq.TLO.Zone.ID() == 118 end)
        while not mq.TLO.Nav.MeshLoaded() do mq.delay(100) end
    end
    return
end

function movement.tgd_thurgadin()
    if mq.TLO.Zone.ID() == 115 then return end
    if mq.TLO.Zone.ID() == 118 then
        --    print("\at[TSNe\awx\att] \aw[Heading To] \ag[", mq.TLO.Zone(115), "]")
        mq.cmd('/squelch /nav locyxz 80 -145 100 | log = off')
        movement.moving()
        mq.delay(1000)
        mq.delay(60000, function() return mq.TLO.Zone.ID() == 115 end)
        while not mq.TLO.Nav.MeshLoaded() do mq.delay(100) end
    end
    return
end

function movement.thurgadin_tgd()
    if mq.TLO.Zone.ID() == 118 then return end
    if mq.TLO.Zone.ID() == 115 then
        --    print("\at[TSNe\awx\att] \aw[Heading To] \ag[", mq.TLO.Zone(118), "]")
        mq.cmd('/squelch /nav locyxz -1250 -22 -1 | log = off')
        movement.moving()
        mq.delay(1000)
        mq.delay(60000, function() return mq.TLO.Zone.ID() == 118 end)
        while not mq.TLO.Nav.MeshLoaded() do mq.delay(100) end
    end
    return
end

-- GD to POK
function movement.tgd_pok()
    if mq.TLO.Zone.ID() == 202 then return end
    if mq.TLO.Zone.ID() == 118 then
        --    print("\at[TSNe\awx\att] \aw[Heading To] \ag[", mq.TLO.Zone(202), "]")
        mq.cmd('/squelch /nav door id 77 click |log=off')
        movement.moving()
        mq.delay(1000)
        mq.delay(60000, function() return mq.TLO.Zone.ID() == 202 end)
        while not mq.TLO.Nav.MeshLoaded() do mq.delay(100) end
    end
    return
end

function movement.pot_stratos()
    if mq.TLO.Zone.ID() == 818 then return end
    if mq.TLO.Zone.ID() == 203 then
        --    print("\at[TSNe\awx\att] \aw[Heading To] \ag[", mq.TLO.Zone(202), "]")
        --  mq.cmd('/squelch /nav door id 16 click |log=off')
        mq.cmd('/squelch /travelto stratos')
        movement.moving()
        mq.delay(1000)
        mq.delay(60000, function() return mq.TLO.Zone.ID() == 818 end)
        while not mq.TLO.Nav.MeshLoaded() do mq.delay(100) end
    end
    return
end

function movement.stratos_pot()
    if mq.TLO.Zone.ID() == 203 then return end
    if mq.TLO.Zone.ID() == 818 then
        --    print("\at[TSNe\awx\att] \aw[Heading To] \ag[", mq.TLO.Zone(202), "]")
        --   mq.cmd('/squelch /nav door id 1 click |log=off')
        mq.cmd('/squelch /travelto potranquility')
        movement.moving()
        mq.delay(1000)
        mq.delay(60000, function() return mq.TLO.Zone.ID() == 203 end)
        while not mq.TLO.Nav.MeshLoaded() do mq.delay(100) end
    end
    return
end

function movement.pot_pok()
    if mq.TLO.Zone.ID() == 202 then return end
    if mq.TLO.Zone.ID() == 203 then
        --    print("\at[TSNe\awx\att] \aw[Heading To] \ag[", mq.TLO.Zone(202), "]")
   --     mq.cmd('/squelch /nav door id 77 click |log=off')
        mq.cmd('/squelch /travelto poknowledge')
        movement.moving()
        mq.delay(1000)
        mq.delay(60000, function() return mq.TLO.Zone.ID() == 202 end)
        while not mq.TLO.Nav.MeshLoaded() do mq.delay(100) end
    end
    return
end

function movement.pok_pot()
    if mq.TLO.Zone.ID() == 203 then return end
    if mq.TLO.Zone.ID() == 202 then
        -- print("\at[TSNe\awx\att] \aw[Heading To] \ag[", mq.TLO.Zone(202), "]")
        mq.cmd('/squelch /nav door id 12 click |log=off')
        movement.moving()
        mq.delay(1000)
        mq.delay(60000, function() return mq.TLO.Zone.ID() == 203 end)
        while not mq.TLO.Nav.MeshLoaded() do mq.delay(100) end
    end
    return
end

function movement.thurgadin_pok()
    if mq.TLO.Zone.ID() == 202 then return end
    if mq.TLO.Zone.ID() == 115 or mq.TLO.Zone.ID() == 118 then
        GLOBAL_TEXT = "Heading to Plane of Knowledge"
        -- print("\at[TSNe\awx\att] \aw[Heading To] \ag[", mq.TLO.Zone(202), "]")

        local gate_class_check = movement.gate_class()
        local bind_check = movement.where_bound()

        if gate_class_check == 1 and bind_check == 1 then
            movement.gate_action()
        end

        mq.cmd('/squelch /travelto poknowledge')
        movement.moving()
        mq.delay(1000)
        mq.delay(60000, function() return mq.TLO.Zone.ID() == 202 end)
        while not mq.TLO.Nav.MeshLoaded() do mq.delay(100) end
    end
    return
end

function movement.nexus_pok()
    if mq.TLO.Zone.ID() == 202 then return end
    if mq.TLO.Zone.ID() == 152 then
        GLOBAL_TEXT = "Heading to Plane of Knowledge"
        -- print("\at[TSNe\awx\att] \aw[Heading To] \ag[", mq.TLO.Zone(202), "]")

        --  local gate_class_check = movement.gate_class()
        -- local bind_check = movement.where_bound()

        -- if gate_class_check == 1 and bind_check == 1 then
        --    movement.gate_action()
        -- end

        mq.cmd('/squelch /travelto poknowledge')
        movement.moving()
        mq.delay(1000)
        mq.delay(60000, function() return mq.TLO.Zone.ID() == 202 end)
        while not mq.TLO.Nav.MeshLoaded() do mq.delay(100) end
    end
    return
end

function movement.rm_pok()
    if mq.TLO.Zone.ID() == 202 then return end
    if mq.TLO.Zone.ID() == 50 then
        GLOBAL_TEXT = "Heading to Plane of Knowledge"
        mq.cmd('/squelch /travelto poknowledge')
        movement.moving()
        mq.delay(1000)
        mq.delay(60000, function() return mq.TLO.Zone.ID() == 202 end)
        while not mq.TLO.Nav.MeshLoaded() do mq.delay(100) end
    end
    return
end

function movement.rivervale_pok()
    if mq.TLO.Zone.ID() == 202 then return end
    if mq.TLO.Zone.ID() == 19 then
        GLOBAL_TEXT = "Heading to Plane of Knowledge"
        mq.cmd('/squelch /travelto poknowledge')
        movement.moving()
        mq.delay(1000)
        mq.delay(60000, function() return mq.TLO.Zone.ID() == 202 end)
        while not mq.TLO.Nav.MeshLoaded() do mq.delay(100) end
    end
    return
end

function movement.sharvahl_pok()
    if mq.TLO.Zone.ID() == 202 then return end

    -- Shar Vahl
    if mq.TLO.Zone.ID() == 155 then
        GLOBAL_TEXT = "Heading to Shadeweaver's Thicket"
        mq.cmd('/squelch /nav loc -1688 499 -211 |dist=0 log=off')
        movement.moving()
        mq.cmd('/squelch /face loc -1682, 502, -211')
        mq.delay(2000)
        mq.cmd('/keypress forward hold')
        while mq.TLO.Zone.ID() == 155 do mq.delay(1) end
        mq.cmd('/keypress forward')
        mq.delay(1000)
        mq.delay(60000, function() return mq.TLO.Zone.ID() == 165 end)
        while not mq.TLO.Nav.MeshLoaded() do mq.delay(100) end
    end

    -- Shadeweaver's Thicket
    if mq.TLO.Zone.ID() == 165 then
        GLOBAL_TEXT = "Heading to the Plane Of Knowledge"
        mq.cmd('/squelch /travelto poknowledge')
        movement.moving()
        mq.delay(1000)
        mq.delay(60000, function() return mq.TLO.Zone.ID() == 202 end)
        while not mq.TLO.Nav.MeshLoaded() do mq.delay(100) end
    end

    return
end

function movement.oggok_pok()
    if mq.TLO.Zone.ID() == 202 then return end

    -- Oggok
    if mq.TLO.Zone.ID() == 49 then
        GLOBAL_TEXT = "Heading to the Feerrott"
        mq.cmd('/squelch /nav loc -395 -103 5 |dist=0 log=off')
        movement.moving()
        mq.delay(1000)
        mq.cmd('/keypress forward hold')
        while mq.TLO.Zone.ID() == 49 do mq.delay(1) end
        mq.cmd('/keypress forward')
        mq.delay(1000)
        mq.delay(60000, function() return mq.TLO.Zone.ID() == 47 end)
        while not mq.TLO.Nav.MeshLoaded() do mq.delay(100) end
    end

    -- Feerrott
    if mq.TLO.Zone.ID() == 47 then
        GLOBAL_TEXT = "Heading to the Plane Of Knowledge"
        mq.cmd('/squelch /travelto poknowledge')
        movement.moving()
        mq.delay(1000)
        mq.delay(60000, function() return mq.TLO.Zone.ID() == 202 end)
        while not mq.TLO.Nav.MeshLoaded() do mq.delay(100) end
    end

    return
end

function movement.neriakc_pok()
    if mq.TLO.Zone.ID() == 202 then return end

    -- Cabilis East
    if mq.TLO.Zone.ID() == 42 then
        GLOBAL_TEXT = "Heading to the Plane Of Knowledge"
        -- mq.cmd('/squelch /nav loc -395 -103 5 |dist=0 log=off')
        -- movement.moving()
        -- mq.delay(1000)
        -- mq.cmd('/keypress forward hold')
        -- while mq.TLO.Zone.ID() == 106 do mq.delay(1) end
        --  mq.cmd('/keypress forward')
        -- mq.delay(1000)

        mq.cmd('/squelch /travelto poknowledge')
        movement.moving()

        mq.delay(60000, function() return mq.TLO.Zone.ID() == 202 end)
        while not mq.TLO.Nav.MeshLoaded() do mq.delay(100) end
    end

    return
end

function movement.grobb_pok()
    if mq.TLO.Zone.ID() == 202 then return end
    -- Cabilis East
    if mq.TLO.Zone.ID() == 52 then
        GLOBAL_TEXT = "Heading to the Plane Of Knowledge"
        mq.cmd('/squelch /travelto poknowledge')
        movement.moving()
        mq.delay(60000, function() return mq.TLO.Zone.ID() == 202 end)
        while not mq.TLO.Nav.MeshLoaded() do mq.delay(100) end
    end
    return
end

function movement.nfelwithe_pok()
    if mq.TLO.Zone.ID() == 202 then return end
    -- North Felwithe
    if mq.TLO.Zone.ID() == 61 then
        GLOBAL_TEXT = "Heading to the Plane Of Knowledge"
        mq.cmd('/squelch /travelto poknowledge')
        movement.moving()
        mq.delay(60000, function() return mq.TLO.Zone.ID() == 202 end)
        while not mq.TLO.Nav.MeshLoaded() do mq.delay(100) end
    end
    return
end

function movement.akanon_pok()
    if mq.TLO.Zone.ID() == 202 then return end
    -- Ak'Anon
    if mq.TLO.Zone.ID() == 55 then

        local flr_level = math.ceil(mq.TLO.Me.Z())

        if flr_level == -30 then end

        -- if there is no path to zone then ?

        GLOBAL_TEXT = "Heading to the Plane Of Knowledge"
        mq.cmd('/squelch /travelto poknowledge')
        movement.moving()
        mq.delay(60000, function() return mq.TLO.Zone.ID() == 202 end)
        while not mq.TLO.Nav.MeshLoaded() do mq.delay(100) end
    end
    return
end

function movement.skaladim_pok()
    if mq.TLO.Zone.ID() == 202 then return end
    -- South Kaladim
    if mq.TLO.Zone.ID() == 60 then
        GLOBAL_TEXT = "Heading to the Plane Of Knowledge"
        mq.cmd('/squelch /travelto poknowledge')
        movement.moving()
        mq.delay(60000, function() return mq.TLO.Zone.ID() == 202 end)
        while not mq.TLO.Nav.MeshLoaded() do mq.delay(100) end
    end
    return
end

-- South Qeynos to POK
function movement.sqeynos_pok()
    if mq.TLO.Zone.ID() == 202 then return end
    -- South Qeynos
    if mq.TLO.Zone.ID() == 1 then
        GLOBAL_TEXT = "Heading to the Plane Of Knowledge"
        mq.cmd('/squelch /travelto poknowledge')
        movement.moving()
        mq.delay(60000, function() return mq.TLO.Zone.ID() == 202 end)
        while not mq.TLO.Nav.MeshLoaded() do mq.delay(100) end
    end
    return
end

function movement.cabeast_pok()
    if mq.TLO.Zone.ID() == 202 then return end

    -- Cabilis East
    if mq.TLO.Zone.ID() == 106 then
        GLOBAL_TEXT = "Heading to the Plane Of Knowledge"
        -- mq.cmd('/squelch /nav loc -395 -103 5 |dist=0 log=off')
        -- movement.moving()
        -- mq.delay(1000)
        -- mq.cmd('/keypress forward hold')
        -- while mq.TLO.Zone.ID() == 106 do mq.delay(1) end
        --  mq.cmd('/keypress forward')
        -- mq.delay(1000)

        mq.cmd('/squelch /travelto poknowledge')
        movement.moving()

        mq.delay(60000, function() return mq.TLO.Zone.ID() == 202 end)
        while not mq.TLO.Nav.MeshLoaded() do mq.delay(100) end
    end

    return
end

function movement.barren_pok()
    if mq.TLO.Zone.ID() == 202 then return end
    if mq.TLO.Zone.ID() == 414 or mq.TLO.Zone.ID() == 422 then
        GLOBAL_TEXT = "Heading to Plane of Knowledge"
        -- print("\at[TSNe\awx\att] \aw[Heading To] \ag[", mq.TLO.Zone(202), "]")

        -- can we gate check -if we have gate ability and are bound in pot or pok then..

        local gate_class_check = movement.gate_class()
        local bind_check = movement.where_bound()

        if gate_class_check == 1 and bind_check == 1 then
            movement.gate_action()
        end

        mq.cmd('/squelch /travelto poknowledge')
        movement.moving()
        mq.delay(1000)
        mq.delay(60000, function() return mq.TLO.Zone.ID() == 202 end)
        while not mq.TLO.Nav.MeshLoaded() do mq.delay(100) end
    end
    return
end

function movement.baz_pok()
    if mq.TLO.Zone.ID() == 202 then return end
    if mq.TLO.Zone.ID() == 151 then
        GLOBAL_TEXT = "Heading to Plane of Knowledge"
        -- print("\at[TSNe\awx\att] \aw[Heading To] \ag[", mq.TLO.Zone(202), "]")
        mq.cmd('/squelch /travelto poknowledge')
        movement.moving()
        mq.delay(1000)
        mq.delay(60000, function() return mq.TLO.Zone.ID() == 202 end)
        while not mq.TLO.Nav.MeshLoaded() do mq.delay(100) end
    end
    mq.delay(1)
    return
end

-- ? remove
function movement.barren_tox()
    if mq.TLO.Zone.ID() == 202 then return end
    if mq.TLO.Zone.ID() == 422 then
        -- print("\at[TSNe\awx\att] \aw[Heading To] \ag[", mq.TLO.Zone(202), "]")
        mq.cmd('/squelch /nav locyxz 720 1260 53 |log = off')
        movement.moving()
        mq.delay(1000)
        mq.delay(60000, function() return mq.TLO.Zone.ID() == 202 end)
        while not mq.TLO.Nav.MeshLoaded() do mq.delay(100) end
    end
    return
end

-- ? remove
function movement.tox_pok()
    if mq.TLO.Zone.ID() == 202 then return end
    if mq.TLO.Zone.ID() == 414 then
        --    print("\at[TSNe\awx\att] \aw[Heading To] \ag[", mq.TLO.Zone(202), "]")
        mq.cmd('/squelch /nav door id 1 click |log=off')
        movement.moving()
        mq.delay(1000)
        mq.delay(60000, function() return mq.TLO.Zone.ID() == 202 end)
        while not mq.TLO.Nav.MeshLoaded() do mq.delay(100) end
    end
    return
end

function movement.stratos()
    if mq.TLO.Zone.ID() == 818 then return end
    while mq.TLO.Zone.ID() ~= 818 do
        -- just look up where we are and send string from db I think???
        movement.cr_bfm()
        movement.bfm_pok()
        movement.srh_gl()
        movement.sgh_gl()
        movement.ngh_gl()
        movement.gl_pok()
        movement.fp_pok()

        -- movement.thurgadin_tgd()
        -- movement.tgd_pok()
        movement.thurgadin_pok()

        movement.baz_pok()

        movement.pok_pot()
        movement.pot_stratos()
        movement.port_methods(818)
        mq.delay(1)
    end
    return
end

function movement.pok()
    if mq.TLO.Zone.ID() == 202 then return end
    while mq.TLO.Zone.ID() ~= 202 do
        -- just look up where we are and send string from db I think???
        movement.cr_bfm()
        movement.bfm_pok()
        movement.srh_gl()
        movement.sgh_gl()
        movement.ngh_gl()
        movement.gl_pok()
        movement.fp_pok()

        movement.stratos_pot()

        movement.pot_pok()

        movement.rm_pok()

        movement.oggok_pok()

        movement.akanon_pok()

        movement.grobb_pok()

        movement.nfelwithe_pok()

        movement.rivervale_pok()

        movement.skaladim_pok()

        movement.sqeynos_pok()

        movement.cabeast_pok()

        movement.sharvahl_pok()

        -- 3rd Gate
        movement.neriakc_pok()

        movement.nexus_pok()

        --  movement.thurgadin_tgd()
        --  movement.tgd_pok()

        movement.thurgadin_pok()

        movement.barren_pok()

        movement.baz_pok()

        movement.port_methods(202)
        mq.delay(1)
    end
    return
end

function movement.thurgadin()
    if mq.TLO.Zone.ID() == 115 then return end
    while mq.TLO.Zone.ID() ~= 115 do
        movement.cr_bfm()
        movement.bfm_pok()
        movement.srh_gl()
        movement.sgh_gl()
        movement.ngh_gl()
        movement.gl_pok()
        movement.fp_pok()
        movement.baz_pok()
        movement.stratos_pot()
        movement.pot_pok()
        movement.pok_tgd()
        movement.tgd_thurgadin()
        movement.port_methods(115)
        mq.delay(1)
    end
    return
end

function movement.srh()
    if mq.TLO.Zone.ID() == 712 then return end
    while mq.TLO.Zone.ID() ~= 712 do
        -- just look up where we are and send string from db I think???
        movement.cr_bfm()
        movement.bfm_pok()
        movement.fp_pok()
        movement.baz_pok()
        movement.stratos_pot()
        movement.pot_pok()
        movement.ngh_gl()
        movement.sgh_gl()
        movement.pok_gl()
        movement.gl_srh()
        movement.port_methods(712)
        mq.delay(1)
    end
    return
end

-- add 1 or 2 depth for zones like all the stone zones for sure...?

function movement.baz()
    if mq.TLO.Zone.ID() == 151 then return end
    mq.cmd('/squelch /travelto bazaar')
    while mq.TLO.Zone.ID() ~= 151 do mq.delay(1) end
    mq.delay(1)
    return
end

function movement.wfp()
    if mq.TLO.Zone.ID() == 383 then return end
    while mq.TLO.Zone.ID() ~= 383 do
        -- just look up where we are and send string from db I think???
        movement.cr_bfm()
        movement.bfm_pok()
        movement.baz_pok()
        movement.srh_gl()
        movement.sgh_gl()
        movement.ngh_gl()
        movement.gl_pok()
        movement.stratos_pot()
        movement.pot_pok()
        movement.pok_fp()
        movement.port_methods(383)
        mq.delay(1)
    end
    return
end

function movement.sgh()
    if mq.TLO.Zone.ID() == 345 then return end
    while mq.TLO.Zone.ID() ~= 345 do
        -- just look up where we are and send string from db I think???
        movement.cr_bfm()
        movement.bfm_pok()
        movement.baz_pok()
        movement.fp_pok()
        movement.stratos_pot()
        movement.pot_pok()
        movement.srh_gl()
        movement.pok_gl()
        movement.gl_sgh()
        movement.port_methods(345)
        mq.delay(1)
    end
    return
end

function movement.ngh()

    -- GGH, Palatial, MGH, Standard
    local guild_zones = {738, 737, 751}

    local flag = 0

    for x = 1, #guild_zones do

        if mq.TLO.Zone.ID() == guild_zones[x] then
            flag = 1
            break
        end
    end

    if flag == 1 then return end

    while true do
        -- just look up where we are and send string from db I think???
        movement.cr_bfm()
        movement.bfm_pok()
        movement.baz_pok()
        movement.fp_pok()
        movement.stratos_pot()
        movement.pot_pok()

        -- added 11/1/2023
        movement.barren_pok()

        -- This should rarely happen, but, reasons
        movement.sgh_gl()

        -- now we need to know where are we in relation to the zone..
        -- if are in sunrise hills are we really gonna run there?!

        movement.pok_gl()
        movement.gl_ngh()

        for x = 1, #guild_zones do

            if mq.TLO.Zone.ID() == guild_zones[x] then
                flag = 1
                break
            end
        end

        if flag == 1 then break end

        -- We ended up in the standard guild hall
        if mq.TLO.Zone.ID() == 345 then break end

        -- movement.port_methods(99999)
        -- pass it 99999--- which means check for guild halls
        mq.delay(1000)
    end
    return
end

function movement.ngh_gl()
    if mq.TLO.Zone.ID() == 344 then return end

    if mq.TLO.Zone.ID() == 737 or mq.TLO.Zone.ID() == 738 or mq.TLO.Zone.ID() ==
        751 then

        mq.delay(500)
        mq.cmd('/squelch /itemtarget "Shabby Lobby Door"')
        mq.delay(1000)
        if mq.TLO.ItemTarget() == nil then
            print 'u gotta be kidding me, no shabby lobby door?'
            -- Do it the hard way!
            mq.cmd('/lua tcg pause')
            -- run to GL from SRH
            os.exit()
        end
        mq.cmd('/squelch /nav item |dist=15 los=on log=off')
        movement.moving()
        print(msg, "\ap[\agUsing:\ap] \ap[\ayShabby Lobby Door\ap]")
        mq.delay(1500)
        mq.cmd('/squelch /click right item')
        mq.delay(2000)
        mq.cmd('/squelch /notify "Open the Door to the Lobby" menuselect')
        mq.delay(1500)
        -- do multi line
        -- /multiline ; /invoke ${Ground[Shabby Lobby Door].DoTarget} ; /click right item ; /timed 15 /notify "Open the Door to the Lobby" menuselect
        while mq.TLO.Zone.ID() ~= 344 do mq.delay(1) end
        mq.delay(1000)
    end
    return
end

function movement.zone(p_zone_id)

    if p_zone_id == mq.TLO.Zone.ID() then return end

    print(msg, "\ay[\awTravelling To:\ay] \ay[\ag", mq.TLO.Zone(p_zone_id),
          "\ay]")

    while mq.TLO.Zone.ID() ~= 383 do

        movement.cr_bfm()
        movement.bfm_pok()

        movement.baz_pok()

        -- Add srh to gl
        movement.sgh_gl()
        movement.ngh_gl()

        movement.gl_pok()

        movement.stratos_pot()
        movement.pot_pok()

        -- srh pok

        movement.pok_fp()

        -- Last resort
        movement.port_methods(383)

        mq.delay(1)
    end
    return
end

function movement.crescent()

    if mq.TLO.Zone.ID() == 394 then return end

    mq.cmd('/squelch /travelto crescent')

    while mq.TLO.Zone.ID() ~= 394 do

        -- Crescent Reach ID go to Blightfire Moors

        -- mines to pok or cr?

        --  movement.cr_bfm()
        -- movement.bfm_pok()

        -- movement.baz_pok()

        --  movement.stratos_pot()
        --  movement.pot_pok()
        --  movement.fp_pok()
        -- any chain before..

        -- In Pok

        -- pok to bfm
        -- bfm to cr

        -- movement.port_methods(394)

        mq.delay(1)
    end

    return
end

function movement.halas()

    print(msg, "\ay[\awTravelling To:\ay] \ay[\agHalas\ay]")
    while mq.TLO.Zone.ID() ~= 29 do

        -- In Crescent Reach Go to Blightfire Moors
        if mq.TLO.Zone.ID() == 394 then
            print(msg, "\aw[Heading To] \ag[Blightfire Moors]")
            mq.cmd('/nav locyxz -880 -2760 -56 | log = off')
            movement.moving()
            mq.delay(60000, function() return mq.TLO.Zone.ID() == 395 end)
            --  while not mq.TLO.Nav.MeshLoaded() do mq.delay(1000) end
        end

        -- in Moors goto POK
        if mq.TLO.Zone.ID() == 395 then
            print(msg, "\aw[Heading To] \ag[Plane Of Knowledge]")
            mq.cmd('/squelch /nav door id 68 click | log = off')
            movement.moving()
            mq.delay(1000)
            mq.delay(60000, function() return mq.TLO.Zone.ID() == 202 end)
            --  while not mq.TLO.Nav.MeshLoaded() do mq.delay(1000) end
        end

        -- IN POK go to Everfrost
        if mq.TLO.Zone.ID() == 202 then
            print(msg, "\aw[Heading To] \ag[Everfrost]")
            mq.cmd('/squelch /nav door id 20 click | log = off')
            movement.moving()
            mq.delay(1000)
            mq.delay(60000, function() return mq.TLO.Zone.ID() == 30 end)
            --  while not mq.TLO.Nav.MeshLoaded() do mq.delay(1000) end
        end

        -- IN Everfrost go to Halas
        if mq.TLO.Zone.ID() == 30 then
            print(msg, "\aw[Heading To] \ag[Halas]")
            mq.cmd('/squelch /nav locyxz 3223 593 -61 | log = off')
            movement.moving()
            mq.cmd('/squelch /nav locyxz 3747 373 0 | log = off')
            movement.moving()
            mq.delay(1000)
            mq.delay(60000, function() return mq.TLO.Zone.ID() == 29 end)
            --   while not mq.TLO.Nav.MeshLoaded() do mq.delay(1000) end
        end

        mq.delay(500)

    end
end

function movement.abysmal()

    -- if mq.TLO.Zone.ID() == 279 then return end

    while mq.TLO.Zone.ID() ~= 279 do

        -- Crescent Reach ID go to Blightfire Moors

        -- mines to pok or cr?

        movement.cr_bfm()
        movement.bfm_pok()

        movement.baz_pok()

        movement.stratos_pot()
        movement.pot_pok()
        movement.fp_pok()
        -- any chain before..

        -- In Pok
        movement.pok_gl()
        movement.gl_nedaria()
        movement.nedaria_abysmal()

        movement.port_methods(279)

        mq.delay(100)
    end
    -- Add return 11/17/21
    return
end

function movement.npc(npcName)

    if GLOBAL_ABORT_FLAG == 1 then return end

    -- for now assume in POK

    local org_npc_name = npcName

    -- For purchased guild
    if string.find(npcName, "guild banker") then
        npcName = '"' .. npcName .. '"'
    end

    if string.find(npcName, "Clockwork Merchant IV") then
        npcName = "Clockwork"
    end

    local npcID = mq.TLO.NearestSpawn(npcName).ID()

    -- REVIEW/CHANGE
    if not npcID then

        print(msg, "\ag" .. npcName ..
                  " \aynot up, waiting 10s to try to walk to it")
        print(msg,
              "\ap[\ayPausing\ap] \ap[\agNPC is not up are we are in the wrong zone, or reasons\ap]")
        print(msg,
              "\ap[\ayPausing\ap] \ap[\agMove to NPC and un-pause TCN if possible\ap]")
        mq.cmd('/squelch /lua pause tcn')
    end

    local NPCDistance = math.ceil(mq.TLO.Spawn(npcName).Distance())

    -- Will this work for non-pok zones?
    if NPCDistance < 16 and mq.TLO.Spawn(npcName).LineOfSight() then
        -- Target NPC for interaction
        -- mq.cmd('/cleanup')
        mq.delay(1000)
        if mq.TLO.Target() ~= npcName then mq.cmd('/target', npcName) end
        mq.delay(100)
        IsFacingNPC(npcID)
        mq.delay(1500)
        return
    end

    local nav_path = nil

    -- remove zones

    if string.find(npcName, "Sculptor Radee") then
        --   mq.cmd('/nav locyxz -296 779 -94 |log=off')
        --    nav_path = "-296 779 -94"

        -- movement.moving()
    end

    if string.find(npcName, "Blacksmith Gerta") then

        --   mq.cmd('/nav locyxz -359 718 -94 |log=off')
        --  nav_path = "-359 718 -94"

        -- mq.cmd('/nav locyxz -296 779 -94 |log=off')
        -- movement.moving()
    end

    if string.find(npcName, "Brewmaster Berina") then
        --  nav_path = "-325 973 -94"
        -- mq.cmd('/nav locyxz -325 973 -94 dist=20 log=off')
        -- mq.cmd('/nav spawn id 17087 | dist=20')

    end

    if string.find(npcName, "Culturist Devi") then
        -- nav_path = "-325 973 -94"
        -- mq.cmd('/nav locyxz -325 973 -94 |log=off')

    end

    -- testing for redsa see what it does
    if string.find(npcName, "Alchemist Redsa") then
        --   nav_path = "-335 825 -94"
        --  mq.cmd('/nav locyxz -335 825 -94 |dist=0 los=off log=off')
    end

    if string.find(npcName, "Chef Denrun") then
        --  nav_path = "-294 767 -94"
        --  mq.cmd('/nav locyxz -294 767 -94 |log=off')

    end

    if string.find(npcName, "Jeweler Nonny") then
        -- nav_path = "-314 917 -94"
        -- mq.cmd('/nav locyxz -314 917 -94 |log=off')

    end

    if string.find(npcName, "Tailor Kujen") then
        --   mq.cmd('/nav locyxz -333 938 -94 |log=off')
        --   nav_path = "-333 938 -94"

    end

    if string.find(npcName, "Banker Ceridan") then
        --   mq.cmd('/nav locyxz 451 465 -124 |log=off')
        --  nav_path = "451 465 -124"

    end

    if string.find(npcName, "Bargol Halith") then
        mq.cmd('/nav locyxz 68 234 -124 |dist=0 los=off log=off')
        nav_path = "68 234 -124"
    end

    if string.find(npcName, "Borik Darkanvil") then
        mq.cmd('/nav locyxz -386 498 -124 |dist=0 los=off log=off')
        nav_path = "-386 498 -124"
    end

    if string.find(npcName, "Darius Gandril") then
        mq.cmd('/nav locyxz 55 1517 -124 |los=on log=off')
        nav_path = "55 1517 -124"
    end

    if string.find(npcName, "Kaleras Darkanvil") then
        mq.cmd('/nav locyxz -439 548 -124 |los=off log=off')
        nav_path = "-439 548 -124"
    end

    if string.find(npcName, "Kertak Hammertail") then
        mq.cmd('/nav locyxz 121 1418 -108 |los=off log=off')
        nav_path = "121 1418 -108"
    end

    if string.find(npcName, "Klen Ironstove") then

        -- ignore z distance for non library npcs?
        -- ?-- if z dont match move for 3 seconds?

        --  mq.cmd('/nav locyxz -67 237 -124 |log=off')
        --  nav_path = "-67 237 -124"

        mq.cmd('/nav locyxz -69 238 -124 |los=off log=off')
        nav_path = "-69 238 -124"
    end

    if string.find(npcName, "Melet Ironstove") then
        mq.cmd('/nav locyxz -72 245 -124 |los=off log=off')
        nav_path = "-72 245 -124"
    end

    if string.find(npcName, "Merin Darkanvil") then
        mq.cmd('/nav locyxz -388 490 -123 |los=off log=off')
        nav_path = "-388 490 -123"
    end

    if string.find(npcName, "Perago Crotal") then
        mq.cmd('/nav locyxz 18 238 -124 |los=on log=off')
        nav_path = "18 238 -124"
    end

    if string.find(npcName, "Peras Glickon") then
        mq.cmd('/nav locyxz -55 1519 -124 |los=on log=off')
        nav_path = "-55 1519 -124"
    end

    if string.find(npcName, "Vuli Ironstove") then
        mq.cmd('/nav locyxz -17 236 -124 |los=on log=off')
        nav_path = "-17 236 -124"
    end

    if string.find(npcName, "Wegal Darkanvil") then
        mq.cmd('/nav locyxz -453 545 -124 |los=off log=off')
        nav_path = "-453 545 -124"
    end

    if string.find(npcName, "Zosran Hammertail") then
        mq.cmd('/nav locyxz 121 1418 -107 |los=off log=off')
        nav_path = "121 1418 -107"
    end

    -- Zone = Abysmal Sea
    if mq.TLO.Zone.ID() == 279 then

        print(msg, "\ap[\agWalking To\ap] \ap[\aw", npcName, "\ap]")

        if string.find(npcName, "Ordin") then
            -- Ogre Protection
            mq.cmd('/nav locyxz -137 223 117 |log=off')
            movement.moving()
            mq.cmd('/nav locyxz -106 204 116 |log=off')
            movement.moving()
        end

        if string.find(npcName, "Yitimis") then
            mq.cmd('/nav locyxz -146 170 116 |log=off')
            movement.moving()
        end

        if string.find(npcName, "Glirina Morningbloom") then
            mq.cmd('/nav locyxz -153 236 100 |log=off')
            movement.moving()
        end

        if string.find(npcName, "Imildu Woodstreak") then
            mq.cmd('/squelch /nav locyxz -105 233 100 |log=off')
            movement.moving()
        end

        if string.find(npcName, "Skelontorim Orrthemech") then
            mq.cmd('/squelch /nav locyxz -219 75 96 |log=off')
            movement.moving()
        end

        if string.find(npcName, "Snokin Breaksteel") then
            mq.cmd('/squelch /nav locyxz 104 265 113 |log=off')
            movement.moving()
        end

        if string.find(npcName, "Tonlyei Lyhin") then
            mq.cmd('/squelch /nav locyxz 50 148 112 |log=off')
            movement.moving()
        end

        if string.find(npcName, "Lita Hegeway") then
            mq.cmd('/squelch /nav locyxz 125 -53 96 |log=off')
            movement.moving()
        end

        if string.find(npcName, "Uiyaniv Tu`Vrozix") then
            mq.cmd('/squelch /nav locyxz -199 237 100 |log=off')
            movement.moving()
        end

        if string.find(npcName, "Malkidiv U`Ycionuz") then
            mq.cmd('/squelch /nav locyxz -246 223 96 |log=off')
            movement.moving()
        end

        if string.find(npcName, "Banker Reladia") then
            mq.cmd('/nav locyxz -46 140 100 |log=off')
            movement.moving()
        end

        if mq.TLO.Target() ~= npcName then mq.cmd('/target', npcName) end
        mq.delay(100)
        -- fix add implement this
        --  IsFacingNPC(npcID)
        -- mq.cmd('/face')
        movement.moving()
        return
    end

    -- Zone = Crescent Reach 
    if mq.TLO.Zone.ID() == 394 then

        -- Jeweler's
        if npcName == "Jeweler Chuma" or npcName == "Jeweler Nailah" then
            local NPCDistance = math.ceil(mq.TLO.Spawn(npcName).Distance())
            if NPCDistance > 18 then
                print(msg, "\ay[\agWalking To:\ay] \ay[\aw" .. npcName .. "\ay]")
                mq.cmd('/nav locyxz -1244 -1652 35 |log=off')
                movement.moving()
            end
        end

        -- Researcher's
        if npcName == "Researcher Junna" or npcName == "Researcher Layla" then
            local NPCDistance = math.ceil(mq.TLO.Spawn(npcName).Distance())
            if NPCDistance > 18 then
                print(msg, "\ay[\agWalking To:\ay] \ay[\aw" .. npcName .. "\ay]")
                mq.cmd('/nav locyxz -1440 -1452 -88 |log=off')
                movement.moving()
            end
        end

        -- Tailor Nabirye
        if npcName == "Tailor Nabirye" then
            local NPCDistance = math.ceil(mq.TLO.Spawn(npcName).Distance())
            if NPCDistance > 18 then

                if mq.TLO.Me.Z() < 30 then
                    mq.cmd('/nav locyxz -1356 -1564 32 |log=off')
                    movement.moving()
                end

                print(msg, "\ay[\agWalking To:\ay] \ay[\aw" .. npcName .. "\ay]")
                mq.cmd('/nav locyxz -1460 -1476 33 |log=off')
                movement.moving()
            end
        end

        -- Smith Wamukota
        if npcName == "Smith Wamukota" then
            local NPCDistance = math.ceil(mq.TLO.Spawn(npcName).Distance())
            if NPCDistance > 19 then
                print(msg, "\ay[\agWalking To:\ay] \ay[\aw" .. npcName .. "\ay]")
                mq.cmd('/nav locyxz -1103 -1489 13 |log=off')
                movement.moving()
            end
        end

        -- Baker Sanura
        if npcName == "Baker Sanura" then
            local NPCDistance = math.ceil(mq.TLO.Spawn(npcName).Distance())
            if NPCDistance > 19 then

                if mq.TLO.Me.Z() < 30 then
                    mq.cmd('/nav locyxz -1356 -1564 32 |log=off')
                    movement.moving()
                end

                print(msg, "\ay[\agWalking To:\ay] \ay[\aw" .. npcName .. "\ay]")
                mq.cmd('/nav locyxz -1454 -1526 32 |log=off')
                movement.moving()
            end
        end

        -- Matrum Geerlok or Geerlok Clockwork Merchant IV
        if npcName == "Matrum Geerlok" or npcName == "Clockwork" then
            local NPCDistance = math.ceil(mq.TLO.Spawn(npcName).Distance())
            if NPCDistance > 19 then
                if npcName == "Clockwork" then
                    print(msg,
                          "\ay[\agWalking To:\ay] \ay[\awGeerlok Clockwork Merchant IV\ay]")
                else
                    print(msg,
                          "\ay[\agWalking To:\ay] \ay[\aw" .. npcName .. "\ay]")
                end
                mq.cmd('/nav locyxz -1279 -1263 -88 |log=off')
                movement.moving()
            end
        end

        -- Alchemist's
        if npcName == "Alchemist Naeema" or npcName == "Alchemist Garai" then
            local NPCDistance = math.ceil(mq.TLO.Spawn(npcName).Distance())
            if NPCDistance > 18 then

                if mq.TLO.Me.Z() < 30 then
                    mq.cmd('/nav locyxz -1356 -1564 32 |log=off')
                    movement.moving()
                end

                print(msg, "\ay[\agWalking To:\ay] \ay[\aw" .. npcName .. "\ay]")
                mq.cmd('/nav locyxz -1422 -1592 32 |log=off')
                movement.moving()
            end
        end

        -- Poisoner Kamuzu
        if npcName == "Poisoner Kamuzu" then
            local NPCDistance = math.ceil(mq.TLO.Spawn(npcName).Distance())
            if NPCDistance > 19 then
                print(msg, "\ay[\agWalking To:\ay] \ay[\aw" .. npcName .. "\ay]")
                mq.cmd('/nav locyxz -1243 -1343 11 |log=off')
                movement.moving()
            end
        end

        -- Cook Kosey
        if npcName == "Cook Kosey" then
            local NPCDistance = math.ceil(mq.TLO.Spawn(npcName).Distance())

            if NPCDistance > 19 then

                if mq.TLO.Me.Z() < 30 then
                    mq.cmd('/nav locyxz -1356 -1564 32 |log=off')
                    movement.moving()
                end

                print(msg, "\ay[\agWalking To:\ay] \ay[\aw" .. npcName .. "\ay]")
                mq.cmd('/nav locyxz -1456 -1536 32 |log=off')
                movement.moving()
            end
        end

        -- Smith Yahya
        if npcName == "Smith Yahya" then
            local NPCDistance = math.ceil(mq.TLO.Spawn(npcName).Distance())
            if NPCDistance > 19 then
                print(msg, "\ay[\agWalking To:\ay] \ay[\aw" .. npcName .. "\ay]")
                mq.cmd('/nav locyxz -1115 -1475 11 |log=off')
                movement.moving()
            end
        end

        -- Merchant Rehema
        if npcName == "Merchant Rehema" then
            local NPCDistance = math.ceil(mq.TLO.Spawn(npcName).Distance())
            if NPCDistance > 19 then
                print(msg, "\ay[\agWalking To:\ay] \ay[\aw" .. npcName .. "\ay]")
                mq.cmd('/nav locyxz -1352 -1466 -88 |log=off')
                movement.moving()
            end
        end

        -- Merchant Mandisa
        if npcName == "Merchant Mandisa" then
            local NPCDistance = math.ceil(mq.TLO.Spawn(npcName).Distance())
            if NPCDistance > 19 then
                print(msg, "\ay[\agWalking To:\ay] \ay[\aw" .. npcName .. "\ay]")
                mq.cmd('/nav locyxz -1141 -1427 11 |log=off')
                movement.moving()
            end
        end

        -- Poisoner Salihah
        if npcName == "Poisoner Salihah" then
            local NPCDistance = math.ceil(mq.TLO.Spawn(npcName).Distance())
            if NPCDistance > 19 then
                print(msg, "\ay[\agWalking To:\ay] \ay[\aw" .. npcName .. "\ay]")
                mq.cmd('/nav locyxz -1236 -1369 11 |log=off')
                movement.moving()
            end
        end

        -- Potter Safiya
        if npcName == "Potter Safiya" then
            local NPCDistance = math.ceil(mq.TLO.Spawn(npcName).Distance())
            if NPCDistance > 19 then
                print(msg, "\ay[\agWalking To:\ay] \ay[\aw" .. npcName .. "\ay]")
                mq.cmd('/nav locyxz -1210 -1512 11 |log=off')
                movement.moving()
            end
        end

        -- Brewmaster Ishaq
        if npcName == "Brewmaster Ishaq" then
            local NPCDistance = math.ceil(mq.TLO.Spawn(npcName).Distance())
            if NPCDistance > 17 then
                print(msg, "\ay[\agWalking To:\ay] \ay[\aw" .. npcName .. "\ay]")
                mq.cmd('/nav locyxz -1157 -1613 -88 |log=off')
                movement.moving()
            end
        end

        -- Brewer Mesi
        if npcName == "Brewer Mesi" then
            local NPCDistance = math.ceil(mq.TLO.Spawn(npcName).Distance())
            if NPCDistance > 19 then
                print(msg, "\ay[\agWalking To:\ay] \ay[\aw" .. npcName .. "\ay]")
                mq.cmd('/nav locyxz -1173 -1588 -88 |log=off')
                movement.moving()
            end
        end

        -- Researcher Akila
        if npcName == "Researcher Akila" then
            local NPCDistance = math.ceil(mq.TLO.Spawn(npcName).Distance())
            if NPCDistance > 19 then
                print(msg, "\ay[\agWalking To:\ay] \ay[\aw" .. npcName .. "\ay]")
                mq.cmd('/nav locyxz -1420 -1467 -55 |log=off')
                movement.moving()
            end
        end

        -- Banker Qeb
        if npcName == "Banker Qeb" then
            local NPCDistance = math.ceil(mq.TLO.Spawn(npcName).Distance())
            if NPCDistance > 19 then
                print(msg, "\ay[\agWalking To:\ay] \ay[\aw" .. npcName .. "\ay]")
                mq.cmd('/nav locyxz -1359 -1614 32 |log=off')
                movement.moving()
            end
        end

        -- Banker Jenzeth
        if npcName == "Banker Jenzeth" then
            local NPCDistance = math.ceil(mq.TLO.Spawn(npcName).Distance())
            if NPCDistance > 19 then
                print(msg, "\ay[\agWalking To:\ay] \ay[\aw" .. npcName .. "\ay]")
                mq.cmd('/nav locyxz -1322 -1313 -88 |log=off')
                movement.moving()
            end
        end

        -- Fletcher's
        if npcName == "Fletcher Tahirah" or npcName == "Fletcher Fenuku" then
            local NPCDistance = math.ceil(mq.TLO.Spawn(npcName).Distance())
            if NPCDistance > 19 then
                print(msg, "\ay[\agWalking To:\ay] \ay[\aw" .. npcName .. "\ay]")
                mq.cmd('/nav locyxz -1259 -1452 15 |log=off')
                movement.moving()
                mq.cmd('/nav locyxz -1390 -1410 15 |log=off')
                movement.moving()
            end
        end

        -- No target, target NPC
        if mq.TLO.Target() ~= npcName then mq.cmd('/target', npcName) end
        mq.delay(100)
        -- fix add implement this
        --  IsFacingNPC(npcID)
        -- mq.cmd('/face')
        movement.moving()
        return

    end

    -- if we are in POK
    if mq.TLO.Zone.ID() == 202 then
        mq.delay(100)

        if GLOBAL_ABORT_FLAG == 1 then return end

        print(msg, "\ap[\agWalking To\ap] \ap[\aw", npcName,
              "\ap] \ap[\agDistance:\ap] \ap(\ag", NPCDistance, "\ap)")

        -- Stick_and_move(npcName)
        if nav_path ~= nil then

            IsPathStuck(nav_path)
            mq.delay(1)
            nav_path = nil
        else

            -- print("\aw[Walking To:] \ag[", npcName, "]")
            -- print"dist"
            local random_dist = math.random(10, 16)

            -- print ("random ",random_dist)
            mq.cmdf('/nav spawn id %d |dist=' .. random_dist ..
                        ' los=on log=off', npcID)

            IsNPCStuck(npcID)
        end

        if GLOBAL_ABORT_FLAG == 1 then return end

        NPCDistance = math.ceil(mq.TLO.Spawn(npcName).Distance())

        if NPCDistance > 19 then
            -- print "testing moving closer movement"
            local random_dist = 18
            mq.cmdf('/nav spawn id %d |dist=' .. random_dist ..
                        ' los=on log=off', npcID)
            movement.moving()
        end

        -- Target NPC for interaction
        if mq.TLO.Target() ~= npcName then mq.cmd('/target', npcName) end
        mq.delay(100)

        IsFacingNPC(npcID)

        --  Time to wait while turning?
        mq.delay(1000)
        return
    end

    -- No matches?

    print(msg, "\ap[\agWalking To\ap] \ap[\aw", org_npc_name, "\ap]")
    -- print("\aw[Walking To:] \ag[", npcName, "]")

    if GLOBAL_ABORT_FLAG == 1 then return end

    mq.cmdf('/nav spawn id %d | dist=14 los=on log=off', npcID)
    mq.delay(100)
    while mq.TLO.Nav.Active() do

        if GLOBAL_ABORT_FLAG == 1 then break end

        mq.delay(100)

    end
    -- Target NPC for interaction
    if mq.TLO.Target() ~= npcName then mq.cmd('/tar', npcName) end
    mq.delay(100)
    IsFacingNPC(npcID)

end

-- Guild Hall Banking
function movement.gh_banker()
    if GLOBAL_ABORT_FLAG == 1 then return end

    if mq.TLO.Zone.ID() == 345 then movement.npc("treasurer") end

    if mq.TLO.Zone.ID() == 737 or mq.TLO.Zone.ID() == 738 or mq.TLO.Zone.ID() ==
        751 then
        -- Add Banker not found just return
        movement.npc("a guild banker")
        -- return
    end

    mq.delay(1)

    if not mq.TLO.Window.GuildBankWnd.Open() then
        mq.cmd('/nomodkey /click right target')
        mq.delay(1000)
    end

    return
end

function movement.bank()

    if GLOBAL_ABORT_FLAG == 1 then return end

    local one_time = 1

    ::bankbegin::

    -- Abysmal Banking
    if mq.TLO.Zone.ID() == 279 then
        -- Because Ogres|
        mq.cmd('/squelch /nav locyxz -9 183 100 |log=off')
        -- path movement?
        movement.moving()
        -- Head to Abysmal Banker
        movement.npc("Banker Reladia")
        return
    end

    -- Qeynos South Banking (Human/Half Elf)
    if mq.TLO.Zone.ID() == 1 then
        -- Head to South Qeynos Banker
        mq.cmd('/squelch /nav locyxz 318 -448 3|dist=0 log=off')
        movement.moving()
        mq.cmd('/target Sorn')
        mq.delay(1)
        return
    end

    -- North Felwithe (High Elves)
    if mq.TLO.Zone.ID() == 61 then
        -- Head to North Felwithe Banker
        mq.cmd('/squelch /nav locyxz -61 -454 3|dist=0 log=off')
        movement.moving()
        mq.cmd('/target Tintal')
        mq.delay(1)
        return
    end

    -- Grobb Banking (Trolls)
    if mq.TLO.Zone.ID() == 52 then
        -- Head to Grobb Banker
        movement.npc("Spinkit")
        return
    end

    -- Rathe Mountains Banking (Frogs)
    if mq.TLO.Zone.ID() == 50 then
        -- Head to RM Banker
        -- movement.npc("Dar Banker Zlopps")
        movement.npc("Zlopps")
        return
    end

    -- GFaydark (Fruity Elves)
    if mq.TLO.Zone.ID() == 54 then
        print(msg, "Faydark Bank pathing not available")

        mq.cmd('/nav locyx -443 92 |log=off')
        while mq.TLO.Nav.Active() do mq.delay(1000) end

        mq.cmd('/keypress forward hold')
        mq.delay(6000)
        mq.cmd('/keypress forward')
        mq.delay(2000)

        -- Workaround for Faydark bank pathing for now
        mq.cmd('/squelch /travelto poknowledge')
        while mq.TLO.Zone.ID() ~= 202 do mq.delay(1) end

        movement.bank()

        return
    end

    -- Ak Anon Banking (Gnomes)
    if mq.TLO.Zone.ID() == 55 then
        -- Head to Clockwork Banker
        movement.npc("Banker")
        return
    end

    -- Shar Vahl Banking (Vah Shir)
    if mq.TLO.Zone.ID() == 155 then
        -- Head to Shar Vahl Banker
        movement.npc("Naudi")
        return
    end

    -- Oggok Banking (Ogres)
    if mq.TLO.Zone.ID() == 49 then
        -- Head to Oggok Banker
        movement.npc("Ungral")
        return
    end

    -- Rivervale Banking (Halflings)
    if mq.TLO.Zone.ID() == 19 then
        -- Head to Rivervale Banker
        movement.npc("Donlo")
        return
    end

    -- Halas Banking (Barbarians)
    if mq.TLO.Zone.ID() == 29 then
        -- Head to Halas Banker
        movement.npc("Kevon")
        return
    end

    -- NOS Banking (Eeervyone)
    if mq.TLO.Zone.ID() == 852 then
        -- Head to Halas Banker
        movement.npc("Kjarl")
        return
    end

    -- if we need to set a distance for a specific NPC
    -- mq.cmd('/nav spawn donlo|dist=12 log=off')

    -- return banker name based on zone ID unless there are special configs for movement?

    -- Cabilis East Banking (Iksars)
    if mq.TLO.Zone.ID() == 106 then
        print(msg, "Cabilis Bank pathing not ready")
        --   mq.cmd('/squelch /nav locyxz 698 45 -9|log=off')
        --   movement.moving()

        -- works mostly
        -- make a path from fob to pok so we don't get stuck

        -- Workaround for Cabilis bank pathing for now
        mq.cmd('/squelch /travelto poknowledge')
        while mq.TLO.Zone.ID() ~= 202 do mq.delay(1) end

        movement.bank()

        -- Head to Iksar Banker
        -- movement.npc("Margar")

    end

    -- POK Banking default is Dogle Pitt
    if mq.TLO.Zone.ID() == 202 then

        local pok_bankers = {"Dogle Pitt", "Banker Ceridan"}

        -- add path checking or just do a routine

        local choose_banker = nil

        local Banker_Distance1 = mq.TLO.Spawn(pok_bankers[1]).Distance()
        local Banker_Distance2 = mq.TLO.Spawn(pok_bankers[2]).Distance()

        if Banker_Distance1 < Banker_Distance2 then
            choose_banker = pok_bankers[1]

        else
            choose_banker = pok_bankers[2]
        end
        -- if Banker_Distance2 < Banker_Distance1 then
        --     choose_banker = pok_bankers[2]
        --  end

        if choose_banker == nil then
            print(msg, "Error: Unable to select pok banker")
            os.exit()
        end

        --   mq.cmd('/nav locyxz -305 939 -94 |log=off')

        movement.npc(choose_banker)
        --  movement.npc("Dogle Pitt")
        return
    end

    -- Standard GH Banking
    if mq.TLO.Zone.ID() == 345 then
        -- rightmost banker 19 34 4
        -- left most banker -3 26 4
        movement.npc("a bank broker")
        -- Fix this up later so we stay in front of banker!
        return
    end

    -- Guild Hall Banking

    if mq.TLO.Zone.ID() == 737 or mq.TLO.Zone.ID() == 738 or mq.TLO.Zone.ID() ==
        751 then
        -- Add Banker not found just return
        movement.npc("a personal banker")
        return
    end

    -- SRH
    if mq.TLO.Zone.ID() == 712 then
        mq.cmd('/squelch /nav locyxz -2836 2076 2 |log=off')
        IsPathStuck("-2836 2076 2")
        mq.cmd('/squelch /target Banker Fraener')
        mq.delay(100)
        -- mq.cmd('/face')
        mq.delay(2000)
        return
    end

    -- GL
    if mq.TLO.Zone.ID() == 344 then
        movement.npc("a Shrewd Banker")
        -- change distance?  
        return
    end

    -- POT
    if mq.TLO.Zone.ID() == 203 then
        mq.cmd('/squelch /nav locyxz 862 -1541 -889 | log = off ')

        IsPathStuck("862 -1541 -889")
        mq.delay(500)
        mq.cmd('/squelch /target Paurnil Goldenleaves')
        mq.delay(100)
        --  mq.cmd('/face')
        mq.delay(2000)
        return
    end

    -- Crescent
    if mq.TLO.Zone.ID() == 394 then

        if mq.TLO.Me.Z() >= 11.48 then
            -- 2nd floor
            movement.npc("Banker Qeb")
            return
        end

        if mq.TLO.Me.Z() <= 9 then
            -- 1st floor
            movement.npc("Banker Jenzeth")
            return
        end

    end

    -- Add more bankers
    print(msg, "No Bankers in this zone, heading to POK")

    movement.pok()

    -- We are now in a banking zone, go to the bank
    if one_time == 1 then
        one_time = 0
        goto bankbegin
    end

    return
end

function movement.container(ContainerName)

    mq.delay(1000)

    -- print("movement ", ContainerName)

    -- Abysmal Sea
    if mq.TLO.Zone.ID() == 279 then

        if string.find(ContainerName, "Kiln") then
            mq.cmd('/nav locyxz -338 269 96 |log=off')
            movement.moving()
            mq.cmd('/nav locyxz -336 235 96 |log=off')
            movement.moving()
            mq.cmd('/squelch /itemtarget ' .. ContainerName)
            -- change this to isfacingitem?
        end

        if string.find(ContainerName, "Pottery Wheel") then
            mq.cmd('/nav locyxz -254 203 97 |log=off')
            movement.moving()
            mq.cmd('/squelch /itemtarget ' .. ContainerName)
        end

        if string.find(ContainerName, "Brewing Barrel") then
            mq.cmd('/squelch /nav locyxz -202 169 116 |log=off')
            -- mq.cmd()
            movement.moving()
            mq.cmd('/squelch /itemtarget Brew Barrel')
        end

        -- sewing
        if string.find(ContainerName, "Loom") then
            mq.cmd('/nav locyxz 61 124 112 | log = off')
            movement.moving()
            mq.cmd('/squelch /itemtarget ' .. ContainerName)
        end

        --  GOD Forge
        if string.find(ContainerName, "Forge") then
            mq.cmd('/squelch /nav locyxz 54 277 113 |log=off')
            movement.moving()
            mq.cmd('/squelch /itemtarget ' .. ContainerName)
        end

        -- GOD Oven
        if string.find(ContainerName, "Oven") then
            mq.cmd('/squelch /nav locyxz -65 165 112 |log=off')
            movement.moving()
            mq.cmd('/squelch /itemtarget ' .. ContainerName)
        end

        mq.cmd('/squelch /nav item |dist=14 log=off')
        movement.moving()
        mq.TLO.ItemTarget.DoFace()
        return
    end

    -- Crescent Reach
    if mq.TLO.Zone.ID() == 394 then

        -- CR Kiln
        if string.find(ContainerName, "Kiln") then
            mq.cmd('/nav locyxz -1210 -1512 11 |log=off')
            movement.moving()
            mq.cmd('/squelch /itemtarget ' .. ContainerName)
        end

        -- CR Pottery Wheel
        if string.find(ContainerName, "Pottery Wheel") then
            mq.cmd('/nav locyxz -1210 -1512 11 |log=off')
            movement.moving()
            mq.cmd('/squelch /itemtarget ' .. ContainerName)
        end

        -- CR Brewing
        if string.find(ContainerName, "Brewing Barrel") then
            mq.cmd('/squelch /nav locyxz -1153 -1606 -88 |log=off')
            movement.moving()
            mq.cmd('/squelch /itemtarget Brewing Barrel')
        end

        -- CR Loom
        if string.find(ContainerName, "Loom") then
            mq.cmd('/nav locyxz -1460 -1498 33 | log = off')
            movement.moving()
            mq.cmd('/squelch /itemtarget ' .. ContainerName)
        end

        --  CR Forge
        if string.find(ContainerName, "Crystalwing") then
            mq.cmd('/squelch /nav locyxz -1106 -1525 13 |log=off')
            -- mq.cmd('/squelch /nav locyxz -1104 -1496 15 |log=off')
            -- mq.cmd('/squelch /nav locyxz -1104 -1488 15 |log=off')
            movement.moving()
            --   mq.cmd('/squelch /itemtarget ' .. ContainerName)
            mq.cmd('/squelch /itemtarget forge')
        end

        --  CR Forge
        if ContainerName == "Forge" then
            mq.cmd('/squelch /nav locyxz -1103 -1489 13 |log=off')
            -- mq.cmd('/squelch /nav locyxz -1104 -1496 15 |log=off')
            -- mq.cmd('/squelch /nav locyxz -1104 -1488 15 |log=off')
            movement.moving()
            mq.cmd('/squelch /itemtarget ' .. ContainerName)
        end

        -- CR Oven
        if string.find(ContainerName, "Oven") then
            mq.cmd('/squelch /nav locyxz -1458 -1526 35 |log=off')
            movement.moving()
            mq.cmd('/squelch /itemtarget ' .. ContainerName)
        end

        if mq.TLO.ItemTarget.Distance() > 19 then
            mq.cmd('/squelch /nav item |dist=19 log=off')
            movement.moving()
        end
        mq.TLO.ItemTarget.DoFace()
        return
    end

    -- Rathe Mountains
    if mq.TLO.Zone.ID() == 50 then
        local nav_path = nil
        local nav_string = nil

        -- if ContainerName == "Guktan Forge" then
        -- travelto rathemtn
        -- nav to forge
        -- end

        -- if container name = "forge"

        -- if zone this then do this..
        -- if zone that then do that..

        -- RM Forge
        if ContainerName == "Forge" or ContainerName == "Guktan Forge" then
            nav_path = "-1710 335 0"
            nav_string = '/squelch /nav loc ' .. nav_path .. " |dist=0 log=off"
            mq.cmd(nav_string)
            movement.moving()
            ContainerName = "Forge"
            mq.cmd('/squelch /itemtarget ' .. ContainerName)
            GLOBAL_TEXT = ContainerName .. " Selected"
            movement.moving()
        end
        return
    end

    -- Woodelf forge
    if mq.TLO.Zone.ID() == 54 then
        local nav_path = nil
        local nav_string = nil

        -- Feir`Dal Forge
        if ContainerName == "Forge" or ContainerName == "Feir`Dal Forge" then
            nav_path = "-475 88 161"
            nav_string = '/squelch /nav loc ' .. nav_path .. " |dist=0 log=off"
            mq.cmd(nav_string)
            movement.moving()
            ContainerName = "Forge"
            mq.cmd('/squelch /itemtarget ' .. ContainerName)
            GLOBAL_TEXT = ContainerName .. " Selected"
            movement.moving()
        end
        return
    end

    -- Iksar (LizardLand)
    if mq.TLO.Zone.ID() == 106 then
        local nav_path = nil
        local nav_string = nil

        -- Iksar Forge
        if ContainerName == "Forge" or ContainerName == "Iksar Forge" then
            nav_path = "-531 -14 60"
            nav_string = '/squelch /nav loc ' .. nav_path .. " |dist=0 log=off"
            mq.cmd(nav_string)
            movement.moving()
            ContainerName = "Forge"
            mq.cmd('/squelch /itemtarget ' .. ContainerName)
            GLOBAL_TEXT = ContainerName .. " Selected"
            movement.moving()
        end
        return
    end

    -- Gnome (Shrimps)
    if mq.TLO.Zone.ID() == 55 then
        local nav_path = nil
        local nav_string = nil

        -- Clockwork Forge
        if ContainerName == "Forge" or ContainerName == "Clockwork Forge" then
            nav_path = "1229 -735 -26"
            nav_string = '/squelch /nav loc ' .. nav_path .. " |dist=0 log=off"
            mq.cmd(nav_string)
            movement.moving()
            ContainerName = "Forge"
            mq.cmd('/squelch /itemtarget ' .. ContainerName)
            GLOBAL_TEXT = ContainerName .. " Selected"
            movement.moving()
        end
        return
    end

    -- Human (Humies)
    if mq.TLO.Zone.ID() == 1 and mq.TLO.Me.Race() == "Human" then
        local nav_path = nil
        local nav_string = nil

        -- Antonican Forge
        if ContainerName == "Forge" or ContainerName == "Antonican Forge" then
            nav_path = "378 -364 3"
            nav_string = '/squelch /nav loc ' .. nav_path .. " |dist=0 log=off"
            mq.cmd(nav_string)
            movement.moving()
            ContainerName = "Forge"
            mq.cmd('/squelch /itemtarget ' .. ContainerName)
            GLOBAL_TEXT = ContainerName .. " Selected"
            movement.moving()
        end
        return
    end

    -- High Elves (HIE)
    if mq.TLO.Zone.ID() == 61 then
        local nav_path = nil
        local nav_string = nil

        -- Koada`Dal Forge
        if ContainerName == "Forge" or ContainerName == "Koada`Dal Forge" then
            nav_path = "-61 -384 3"
            nav_string = '/squelch /nav loc ' .. nav_path .. " |dist=0 log=off"
            mq.cmd(nav_string)
            movement.moving()
            ContainerName = "Forge"
            mq.cmd('/squelch /itemtarget ' .. ContainerName)
            GLOBAL_TEXT = ContainerName .. " Selected"
            movement.moving()
        end
        return
    end

    -- Half Elf
    if mq.TLO.Zone.ID() == 1 and mq.TLO.Me.Race() == "Half Elf" then
        local nav_path = nil
        local nav_string = nil

        -- Half Elf Forge
        if ContainerName == "Forge" or ContainerName == "Half Elf Forge" then
            nav_path = "486 -170 3"
            nav_string = '/squelch /nav loc ' .. nav_path .. " |dist=0 log=off"
            mq.cmd(nav_string)
            movement.moving()
            ContainerName = "Forge"
            mq.cmd('/squelch /itemtarget ' .. ContainerName)
            GLOBAL_TEXT = ContainerName .. " Selected"
            movement.moving()
        end
        return
    end

    -- Vah Shir (CatLand)
    if mq.TLO.Zone.ID() == 155 then
        local nav_path = nil
        local nav_string = nil

        -- Vah Shir Forge
        if ContainerName == "Forge" or ContainerName == "Shar Vahl Forge" then
            nav_path = "181 -199 -187"
            nav_string = ' /nav loc ' .. nav_path .. " |dist=0 log=off"
            mq.cmd(nav_string)
            movement.moving()
            ContainerName = "Forge"
            mq.cmd('/squelch /itemtarget ' .. ContainerName)
            GLOBAL_TEXT = ContainerName .. " Selected"
            movement.moving()
        end
        return
    end

    if mq.TLO.Zone.ID() == 19 then
        local nav_path = nil
        local nav_string = nil
        -- Vale Forge
        if ContainerName == "Forge" or ContainerName == "Vale Forge" then
            nav_path = "177 -178 0"
            nav_string = ' /nav loc ' .. nav_path .. " |dist=0 log=off"
            mq.cmd(nav_string)
            movement.moving()
            ContainerName = "Forge"
            mq.cmd('/squelch /itemtarget ' .. ContainerName)
            GLOBAL_TEXT = ContainerName .. " Selected"
            movement.moving()
        end
        return
    end

    -- Oggok (Ogreland)
    if mq.TLO.Zone.ID() == 49 then
        local nav_path = nil
        local nav_string = nil

        -- Ogre Forge
        if ContainerName == "Forge" or ContainerName == "Ogre Forge" then
            nav_path = "138 921 40"
            nav_string = '/squelch /nav loc ' .. nav_path .. " |dist=0 log=off"
            mq.cmd(nav_string)
            movement.moving()
            ContainerName = "Forge"
            mq.cmd('/squelch /itemtarget ' .. ContainerName)
            GLOBAL_TEXT = ContainerName .. " Selected"
            movement.moving()
        end
        return
    end

    -- Dark Elves (DarkieLand)
    if mq.TLO.Zone.ID() == 42 then
        local nav_path = nil
        local nav_string = nil

        -- Dark Elf Forge
        if ContainerName == "Forge" or ContainerName == "Teir`Dal Forge" then
            nav_path = "834 -1568 -80"
            nav_string = '/squelch /nav loc ' .. nav_path .. " |dist=0 log=off"
            mq.cmd(nav_string)
            movement.moving()
            ContainerName = "Forge"
            mq.cmd('/squelch /itemtarget ' .. ContainerName)
            GLOBAL_TEXT = ContainerName .. " Selected"
            movement.moving()
        end
        return
    end

    -- Barbarians (Frozen Tundra)
    if mq.TLO.Zone.ID() == 29 then
        local nav_path = nil
        local nav_string = nil

        -- Barbarian Cultural Forge
        if ContainerName == "Forge" or ContainerName == "Northman Forge" then
            nav_path = "237 -324 4"
            nav_string = '/squelch /nav loc ' .. nav_path .. " |dist=0 log=off"
            mq.cmd(nav_string)
            movement.moving()
            ContainerName = "Forge"
            mq.cmd('/squelch /itemtarget ' .. ContainerName)
            GLOBAL_TEXT = ContainerName .. " Selected"
            movement.moving()
        end
        return
    end

    -- Drakkin (Dragon Breath)
    if mq.TLO.Zone.ID() == 394 then
        local nav_path = nil
        local nav_string = nil

        -- Barbarian Cultural Forge
        if ContainerName == "Forge" or ContainerName == "Crystalwing Forge" then
            nav_path = "-1106 -1525 13"
            nav_string = '/squelch /nav loc ' .. nav_path .. " |dist=0 log=off"
            mq.cmd(nav_string)
            movement.moving()
            ContainerName = "Forge"
            mq.cmd('/squelch /itemtarget ' .. ContainerName)
            GLOBAL_TEXT = ContainerName .. " Selected"
            movement.moving()
        end
        return
    end

    -- Troll (TrollLand)
    if mq.TLO.Zone.ID() == 52 then
        local nav_path = nil
        local nav_string = nil

        -- Troll Forge
        if ContainerName == "Forge" or ContainerName == "Troll Forge" then
            nav_path = "543 -218 -21"
            nav_string = '/squelch /nav loc ' .. nav_path .. " |dist=0 log=off"
            mq.cmd(nav_string)
            movement.moving()
            ContainerName = "Forge"
            mq.cmd('/squelch /itemtarget ' .. ContainerName)
            GLOBAL_TEXT = ContainerName .. " Selected"
            movement.moving()
        end
        return
    end

    -- Make an array with zone ID and nav loc so we can just grab it based on zone id and reduce code

    -- Dwarves (DwarfLand)
    if mq.TLO.Zone.ID() == 60 then
        local nav_path = nil
        local nav_string = nil

        -- Stormguard Forge
        if ContainerName == "Forge" or ContainerName == "Stormguard Forge" then
            nav_path = "111 387 2"
            nav_string = '/squelch /nav loc ' .. nav_path .. " |dist=0 log=off"
            mq.cmd(nav_string)
            movement.moving()
            ContainerName = "Forge"
            mq.cmd('/squelch /itemtarget ' .. ContainerName)
            GLOBAL_TEXT = ContainerName .. " Selected"
            movement.moving()
        end
        return
    end

    -- POK
    if mq.TLO.Zone.ID() == 202 then

        local nav_path = nil
        local nav_string = nil

        -- POK Containers

        -- POK Tinkering Table
        if (ContainerName == "Tinkering Table") then
            nav_path = "-290 830 -94"
            nav_string = '/squelch /nav loc ' .. nav_path .. " |dist=0 log=off"
        end
        -- | POK Mixing Bowl
        if ContainerName == "Mixing Bowl" then
            -- if we have it on us should we just use it?
            nav_path = "-282 755 -94"
            nav_string = '/squelch /nav loc ' .. nav_path .. " |dist=0 log=off"
        end
        -- | POK Spell Research Table
        if (ContainerName == "Spell Research Table") then
            nav_path = "-252 731 -91"
            nav_string = '/squelch /nav loc ' .. nav_path .. " |dist=0 log=off"
        end
        -- POK Jewelry Table
        if (ContainerName == "Jewelry Making Table") then
            nav_path = "-297 932 -94"
            nav_string = '/squelch /nav loc ' .. nav_path .. " |dist=0 log=off"
        end
        -- POK Loom
        if (ContainerName == "Loom") then
            -- choose container based on distance/random or? and zone

            local random = math.random(1, 3)
            -- choose Tanaan looms all the time
            random = 3
            local static_container_nav = {
                "148 1461 -121", "92 1469 -105", "-336 931 -94"
            }
            nav_path = static_container_nav[random]
            nav_string = '/squelch /nav loc ' .. static_container_nav[random] ..
                             " |dist=0 log=off"
        end

        -- Use Tanaan Loom if recipe requires it!
        if (ContainerName == "New Tanaan Loom") then
            nav_path = "92 1469 -105"
            nav_string = '/squelch /nav loc ' .. nav_path .. " |dist=0 log=off"
            ContainerName = "Loom"
        end

        -- POK Forge
        if (ContainerName == "Forge") then
            -- Ignore main forge (bank dogle (1))
            -- Use Tanaan forges only
            local random = math.random(2, 5)

            -- use bank forge for testing
            --  print "bank forge testing movement"
            random = 1

            local static_container_nav = {
                "-345 761 -92", "-422 556 -124", "-396 477 -124",
                "-394 434 -124", "97 1437 -108"
            }
            -- forge by distance closest forge to me?
            --  random = 1
            nav_path = static_container_nav[random]
            nav_string = '/squelch /nav loc ' .. static_container_nav[random] ..
                             " |dist=0 log=off"

            -- local spawn id nearest forge?
        end

        -- Use Tanaan Forge if recipe requires it!
        if (ContainerName == "New Tanaan Forge") then
            nav_path = "-422 556 -124"
            nav_string = '/squelch /nav loc ' .. nav_path .. " |dist=0 log=off"
            ContainerName = "Forge"
        end

        -- POK Oven
        if (ContainerName == "Oven") then
            -- random 3 for pok oven
            -- Use Tanaan ovens only
            local random = math.random(1, 2)

            -- print "use pok bank oven for tsting movement"
            random = 3

            local static_container_nav = {
                "-81 260 -121", "-87 238 -121", "-351 777 -94"
            }
            -- random = 1
            nav_path = static_container_nav[random]
            nav_string = '/squelch /nav loc ' .. static_container_nav[random] ..
                             " |dist=0 log=off"
            -- start making db if  it is one loc or if multi locs then make an recipe type index for navs
        end
        -- POK PoisonCrafting Table
        if (ContainerName == "Poisoncrafting Table") then
            nav_path = "-280 807 -92"
            nav_string = '/squelch /nav loc ' .. nav_path .. " |dist=0 log=off"
        end
        -- POK Alchemy Table
        if (ContainerName == "Alchemy Table") then
            nav_path = "-305 807 -92"
            nav_string = '/squelch /nav loc ' .. nav_path .. " |dist=0 log=off"
            --   mq.cmd('/nav locyxz -305 807 -92 |dist=0 log=off')

        end
        -- POK Brewing Barrel
        -- if ContainerName == "Brewing Barrel" or ContainerName == "Brew Barrel" then
        if ContainerName == "Brewing Barrel" then
            local choose_barrel = nil
            local barrel_distance1 = mq.TLO.Nav.PathLength('loc -312 970 -92')()
            local barrel_distance2 = mq.TLO.Nav.PathLength('loc 12 210 -123')()
            -- print("distance to barrels ",barrel_distance1,  " ",barrel_distance2)
            if barrel_distance1 < barrel_distance2 then
                choose_barrel = "-312 970 -92"
                ContainerName = "Brewing Barrel"
                -- print("barrel 1 is closer ", barrel_distance1, " barrel 2 ",
                --    barrel_distance2)
            else
                choose_barrel = "12 210 -123"
                ContainerName = "Brew Barrel"
                -- print("barrel 2 is closer ", barrel_distance2, " barrel 1 ",
                --    barrel_distance1)
            end
            -- Tanaan Brew Barrel
            nav_path = choose_barrel
            nav_string = '/squelch /nav loc ' .. nav_path .. " |dist=0 log=off"
            -- ContainerName = "Brew Barrel"
            --   mq.cmd('/nav locyxz -314 976 -94 |log=off')
        end

        -- closest or random or both?

        -- POK Pottery Wheel
        if (ContainerName == "Pottery Wheel") then
            local random = math.random(1, 2) -- 3

            random = 3
            --    print "use pok bank pottery wheel for testing"

            -- Use only Tanaan Pottery Wheels
            local static_container_nav = {
                "339 802 -89", "359 1002 -89", "-285 778 -94"
            }
            nav_path = static_container_nav[random]
            -- random = 3
            nav_string = '/squelch /nav loc ' .. static_container_nav[random] ..
                             " |dist=0 log=off"
            -- original
            -- -- mq.cmd('/nav locyxz -286 778 -94 |log=off')
        end

        -- Use Tanaan Pottery Wheel if recipe requires it!
        if (ContainerName == "New Tanaan Pottery Wheel") then
            nav_path = "359 1002 -89"
            nav_string = '/squelch /nav loc ' .. nav_path .. " |dist=0 log=off"
            ContainerName = "Pottery Wheel"
        end

        -- POK Kiln
        if (ContainerName == "Kiln") then
            local random = math.random(1, 2) -- 3

            random = 3
            -- print "use pok bank kiln for testing"

            -- Use only Tanaan Kilns
            local static_container_nav = {
                "341 815 -89", "380 992 -89", "-348 790 -89"
            }
            -- random = 3
            nav_path = static_container_nav[random]
            nav_string = '/squelch /nav loc ' .. static_container_nav[random] ..
                             " |dist=0 log=off"
        end

        -- Use Tanaan Kiln if recipe requires it!
        if (ContainerName == "New Tanaan Kiln") then
            nav_path = "380 992 -89"
            nav_string = '/squelch /nav loc ' .. nav_path .. " |dist=0 log=off"
            ContainerName = "Kiln"
        end

        -- POK Ice Cream Churn
        if (ContainerName == "Ice Cream Churn") then
            nav_path = "-327 759 -92"
            nav_string = '/squelch /nav loc ' .. nav_path .. " |dist=0 log=off"
        end
        -- POK Fletching Table
        if (ContainerName == "Fletching Table") then
            nav_path = "-326 861 -91"
            nav_string = '/squelch /nav loc ' .. nav_path .. " |dist=0 log=off"
        end
        -- POK Fly Making Bench
        if (ContainerName == "Fly Making Bench") then
            ContainerName = "Fishing Table"
            nav_path = "-325 858 -91"
            nav_string = '/squelch /nav loc ' .. nav_path .. " |dist=0 log=off"
        end

        mq.delay(1)

        if nav_string == nil or nav_path == nil then
            print "what gives TCN_movement no path or string ? Possibly, portable container"
            print(ContainerName)
            os.exit()
        end

        local flag = PathDistanceContainer(nav_path, ContainerName)

        if flag == 0 then
            mq.cmd(nav_string)
            IsPathStuck(nav_path)
        end

        -- dorightclick
        mq.cmd('/squelch /itemtarget ' .. ContainerName)

        if mq.TLO.ItemTarget() == nil then
            print(msg, "No container selected error POK")
            print(msg, "Pausing")
            mq.cmd('/squelch /lua pause tcn')
        end

        --  print(mq.TLO.ItemTarget())

        if mq.TLO.ItemTarget.Distance() > 15 then
            --  print"great distance"
            mq.cmd('/squelch /nav item |dist=14 log=off')
            -- Change to IsItemStuck
            movement.moving()
        end

        mq.delay(500)

        IsFacingItem()

        -- print(msg, "\ap[\ag", mq.TLO.ItemTarget(), " Distance\ap] \ap[\aw",
        --  math.ceil(mq.TLO.ItemTarget.Distance()), "\ap]")

        if GLOBAL_ABORT_FLAG == 1 then return end

        if mq.TLO.ItemTarget.Distance() > 20 then
            print(msg, "Too far away from ", mq.TLO.ItemTarget(), " ",
                  math.ceil(mq.TLO.ItemTarget.Distance()))
            print(msg,
                  "\ap[\ayPausing\ap] \ap[\agPlease move closer to the container\ap]")
            mq.cmd('/squelch /lua pause tcn')
        end

        return

        -- END POK Static Items
    end

    -- need to watch movement for SRH.. 

    -- Modest, Grand, Palatial, -- 712 Sunrise Hills
    if mq.TLO.Zone.ID() == 751 or mq.TLO.Zone.ID() == 738 or mq.TLO.Zone.ID() ==
        737 -- Standard Guild Hall!
    -- or mq.TLO.Zone.ID() == 345 
    -- SRH 712
    then

        --  print(ContainerName)

        if ContainerName == "Fly Making Bench" then
            ContainerName = "Guild Fly Making Bench"
        end

        if ContainerName == "Forge" then ContainerName = "Guild Forge" end

        if ContainerName == "Ice Cream Churn" then
            ContainerName = "Churn"
        end

        -- Put " around container name
        ContainerName = '"' .. ContainerName .. '"'

        mq.cmd('/squelch /itemtarget ' .. ContainerName)
        mq.TLO.ItemTarget.DoFace()
        mq.delay(500)
        if mq.TLO.ItemTarget() == nil then
            print(msg, ContainerName,
                  " \ap[\awnot in zone or not implemented\ap]")
            return
        end

        print(msg, "Using: \ap\aw", mq.TLO.ItemTarget(), "\ap]")
        mq.cmd('/squelch /nav item ' .. ContainerName ..
                   ' |dist=14 log=off los=on')

        while mq.TLO.ItemTarget.Distance() > 15 do mq.delay(1) end

        if mq.TLO.Nav.Active() then mq.cmd('/squelch /nav stop') end

        return
    end

    -- Standard (Only has 6 containers)
    if mq.TLO.Zone.ID() == 345 then
        -- print(ContainerName)
        ContainerName = '"' .. ContainerName .. '"'
        -- mq.cmd('/itemtarget ' .. ContainerName)
        mq.cmd('/squelch /itemtarget ' .. ContainerName)
        mq.TLO.ItemTarget.DoFace()
        mq.delay(500)
        if mq.TLO.ItemTarget() == nil then
            print(msg, ContainerName,
                  " \ap[\awnot in zone or not implemented\ap]")
            return
        end
        print(msg, "Using: \ap\aw", mq.TLO.ItemTarget(), "\ap]")
        mq.cmd('/squelch /nav item ' .. ContainerName ..
                   ' |dist=14 log=off los=on')

        while mq.TLO.ItemTarget.Distance() > 15 do mq.delay(1) end
        if mq.TLO.Nav.Active() then mq.cmd('/squelch /nav stop') end
        return
    end

    -- Sunrise Hills Static Items
    if mq.TLO.Zone.ID() == 712 then

        if ContainerName == "Fly Making Bench" then
            ContainerName = "Fishing Table"
        end

        mq.cmd('/squelch /itemtarget ' .. ContainerName)

        if mq.TLO.ItemTarget() == nil then
            print(msg, "\ap[\ag", ContainerName,
                  "\ap] \ap[\ayNot in zone or not implemented\ap]")
            return
        end

        local flag = StaticItemReached(ContainerName)

        if flag == 1 then return end

        if ContainerName == "Fishing Table" then
            mq.cmd('/nav locyxz -2831 2100 2 | los=off log=off')
            IsPathStuck("-2831 2100 2")
        end

        if ContainerName == "Ice Cream Churn" then
            mq.cmd('/nav locyxz -2773 2107 2 | log=off los=off')
            IsPathStuck("-2773 2107 2")
        end

        if ContainerName == "Mixing Bowl" then
            mq.cmd('/nav locyxz -2779 2107 2 | log=off los=off')
            IsPathStuck("-2779 2107 2")
        end

        if ContainerName == "Oven" then
            mq.cmd('/nav locyxz -2786 2106 2 | log=off los=off')
            IsPathStuck("-2786 2106 2")
        end

        if ContainerName == "Brewing Barrel" then
            mq.cmd('/nav locyxz -2803 2106 2 | log=off los=off')
            IsPathStuck("-2803 2106 2")
        end

        if ContainerName == "Poisoncrafting Table" then
            mq.cmd('/nav locyxz -2815 2109 2 | log=off los=off')
            IsPathStuck("-2815 2109 2")
        end

        if ContainerName == "Alchemy Table" then
            mq.cmd('/nav locyxz -2824 2103 2 | log=off los=off')
            IsPathStuck("-2824 2103 2")
        end

        if ContainerName == "Loom" then
            mq.cmd('/nav locyxz -2772 2009 2 | log=off los=off')
            IsPathStuck("-2772 2009 2")
        end

        if ContainerName == "Jewelry Making Table" then
            mq.cmd('/nav locyxz -2753 2015 2 | log=off los=off')
            IsPathStuck("-2753 2015 2")
        end

        if ContainerName == "Fletching Table" then
            mq.cmd('/nav locyxz -2746 2026 2 | log=off los=off')
            IsPathStuck("-2746 2026 2")
        end

        if ContainerName == "Forge" then
            mq.cmd('/nav locyxz -2745 2044 2 | log=off los=off')
            IsPathStuck("-2745 2044 2")
        end

        if ContainerName == "Kiln" then
            mq.cmd('/nav locyxz -2747 2058 2 | log=off los=off')
            IsPathStuck("-2747 2058 2")
        end

        if ContainerName == "Pottery Wheel" then
            mq.cmd('/nav locyxz -2751 2075 2 | log=off los=off')
            IsPathStuck("-2751 2075 2")
        end

        if ContainerName == "Tinkering Table" then
            mq.cmd('/nav locyxz -2762 1993 2 | log=off los=off')
            IsPathStuck("-2762 1993 2")
        end
        --
        -- distance update ? in gui?
        --
        mq.delay(500)
        --
        IsFacingItem()
        -- add CR for TSS
        return
    end

    print(msg, "MOVEMENT: Static Container not in zone or implemented yet")

    return
end

function movement.moving()
    while mq.TLO.Nav.Active() do mq.delay(1) end
    -- mq.delay(500)
    return
end

return movement
