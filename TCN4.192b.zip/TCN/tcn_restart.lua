-- tcg_restart.lua
-- description - stops and restarts tcg system
-- date 11/21/21
-- upd
-- creator: jb321
local mq = require('mq')

mq.cmd('/squelch /lua stop tcn\\tcn_trophy_quests')
mq.cmd('/squelch /lua stop tcn\\tcn_quests')
mq.cmd('/squelch /lua stop tcn\\tcn_god')
mq.cmd('/squelch /lua stop tcn\\tcn_levutil')
mq.cmd('/lua stop tcn')

mq.delay(1000)
mq.cmd('/lua run tcn')
