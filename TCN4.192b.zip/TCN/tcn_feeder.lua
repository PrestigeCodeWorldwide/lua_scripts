-- feeder 10/20/21
-- updated 09/11/25
-- ver 2.36b
-- creator jb321
local mq = require('mq')

-- local PackageMan = require('mq/PackageMan')
-- local sqlite3 = PackageMan.Require('lsqlite3')
local sqlite3 = require('lsqlite3')

local db = sqlite3.open(mq.luaDir .. '\\TCN\\Artisan.db')

local lib = require('tcn_library')

local crunch = require('cruncher')

local m_crunch = require('m_cruncher')

local craft = require('tcn_craft')

local shop = require('tcn_shoplist')

local movement = require('tcn_movement')

local rip = require('rip')

local msg = "\ap[\atTCSNe\auX\att\ap]\aw "

local batch_loop_flag = 1

local chars =
"\ap_______________________________________________________________________________"

local l_ammo_slot_id = GLOBAL_AMMO_SLOT

-- Local Functions

local function convert_race(p_race)
    local race_map = {
        OGR = "Ogre",
        IKS = "Iksar",
        DEF = "Dark Elf",
        DWF = "Dwarf",
        FRG = "Froglok",
        TRL = "Troll",
        VAH = "Vah Shir",
        GNM = "Gnome",
        HFL = "Halfling",
        HUM = "Human",
        HEF = "Half Elf",
        ERU = "Erudite",
        HIE = "High Elf",
        ELF = "Wood Elf",
        DRK = "Drakkin",
        BAR = "Barbarian"
    }
    return race_map[p_race]
end

local function return_string(str, int)
    local counter = 0
    for word in string.gmatch(str, '([^,]+)') do
        counter = counter + 1
        if counter == int then return word end
    end
end

local function return_number(str, int)
    if int == nil or str == nil then
        print(str, " ", int, " TCG Return_number error")
        return 0
    end

    local counter = 0
    for number in string.gmatch(str, '([^,]+)') do
        counter = counter + 1
        if counter == int then return tonumber(number) end
    end
    --  return 0
end

local function convert_shopping_data(p_shop_data)
    -- Convert data to data structure format for sorting shopping data
    local converted_shopping_data = {}
    for c = 1, #p_shop_data do
        local shop_item_id = return_number(p_shop_data[c], 3)
        local shop_item_price = return_number(p_shop_data[c], 6)
        local shop_item_name = return_string(p_shop_data[c], 5)
        if string.find(shop_item_name, "@") then
            shop_item_name = shop_item_name:gsub('@', ',')
        end
        local shop_item_count = return_number(p_shop_data[c], 4)
        local shop_item_zone_id = return_number(p_shop_data[c], 1)
        local shop_item_zone_name = mq.TLO.Zone(shop_item_zone_id)()
        local shop_item_vendor_name = return_string(p_shop_data[c], 2)

        -- Convert to Platinum Currency Format
        shop_item_price = shop_item_price * .001

        local item = {
            ID = shop_item_id,
            Price = shop_item_price,
            Name = shop_item_name,
            Quantity = shop_item_count,
            ZoneID = shop_item_zone_id,
            ZoneName = shop_item_zone_name,
            Vendor = shop_item_vendor_name
        }
        table.insert(converted_shopping_data, item)
    end
    return converted_shopping_data
end

local function convert_farm_data(p_farm_data)
    -- Convert data to data structure format for sorting farmed data
    local converted_farm_data = {}
    for c = 1, #p_farm_data do
        local farm_item_name = return_string(p_farm_data[c], 1)
        if string.find(farm_item_name, "@") then
            farm_item_name = farm_item_name:gsub('@', ',')
        end
        local farm_item_id = return_number(p_farm_data[c], 2)
        local farm_item_count = return_number(p_farm_data[c], 3)
        local farm_item_action = return_string(p_farm_data[c], 4)
        local farm_item_zone_name = return_string(p_farm_data[c], 5)
        if string.find(farm_item_zone_name, "@") then
            farm_item_zone_name = farm_item_zone_name:gsub('@', ',')
        end
        --  if farm_item_zone_name  == "Plane of Knowledge" then farm_item_zone_name  = "The Plane of Knowledge" end
        -- local farm_item_zone_id = mq.TLO.Zone(farm_item_zone_name).ID
        local item = {
            ID = farm_item_id,
            Action = farm_item_action,
            Name = farm_item_name,
            Quantity = farm_item_count,
            ZoneName = farm_item_zone_name
        }
        table.insert(converted_farm_data, item)
    end
    return converted_farm_data
end

-- Get Hoard Inventory
-- Change to use finditem later, more accurate with Item ID
local function hoard_inventory()
    local hoard_bank_array = {}

    -- Index Count of Hoard Items
    local hoard_index_items = mq.TLO.Window('DragonHoardWnd').Child(
        'DH_Item_List').Items()

    for c = 1, hoard_index_items do
        -- Hoard Item
        local hoard_item = mq.TLO.Window('DragonHoardWnd').Child('DH_Item_List')
            .List(c, 2)()
        -- Hoard Item Count
        local hoard_item_count = tonumber(
            mq.TLO.Window('DragonHoardWnd').Child(
                'DH_Item_List').List(c, 3)())

        -- print("Item: ",hoard_item," Count: ",hoard_item_count)

        -- Add Hoard Items to array in SQL Format
        if hoard_item_count ~= nil then
            table.insert(hoard_bank_array, string.format('("%s",%d)',
                hoard_item,
                hoard_item_count))
        end
    end

    -- Put Guild Bank in SQL Mem Table
    local db_hoard = sqlite3.open(":memory:")
    local insert = table.concat(hoard_bank_array, ", ")
    local t_table = "Temp_Hoard"
    local sql_string = 'DROP TABLE IF EXISTS ' .. t_table .. ';CREATE TABLE ' ..
        t_table .. ' (Name, Count);'

    db_hoard:exec(sql_string)

    db_hoard:exec(string.format("INSERT INTO " .. t_table ..
        " ('Name','Count') VALUES %s;", insert))

    local final_hoard_table = {}

    for x in db_hoard:nrows(
        "SELECT Name,Sum(Count) as Count FROM Temp_Hoard group by Name") do
        local array_item = { Name = x.Name, Count = x.Count }
        table.insert(final_hoard_table, array_item)
        --  print(x.Name, " ", x.Count)
    end

    db_hoard:close()

    return final_hoard_table
end

-- Get Guild Hall Inventory
local function gh_inventory()
    local guild_bank_array = {}
    -- Index Count of Guild Items
    local guild_index_items = mq.TLO.Window('GuildBankWnd').Child(
        'GBANK_ItemList').Items()

    for c = 1, guild_index_items do
        -- Guild Item
        local guild_item = mq.TLO.Window('GuildBankWnd').Child('GBANK_ItemList')
            .List(c, 2)()
        -- Guild Item Count
        local guild_item_count = tonumber(
            mq.TLO.Window('GuildBankWnd').Child(
                'GBANK_ItemList').List(c, 3)())
        -- Guild Permission
        local guild_permission = mq.TLO.Window('GuildBankWnd').Child(
            'GBANK_ItemList').List(c, 4)()
        -- Public and not nil
        if guild_permission == "Public" and guild_item_count ~= nil then
            table.insert(guild_bank_array, string.format('("%s",%d)',
                guild_item,
                guild_item_count))
        end
    end

    -- Put Guild Bank in SQL Mem Table
    local db_gh = sqlite3.open(":memory:")
    local insert = table.concat(guild_bank_array, ", ")
    local t_table = "Temp_GH"
    local sql_string = 'DROP TABLE IF EXISTS ' .. t_table .. ';CREATE TABLE ' ..
        t_table .. ' (Name, Count);'

    db_gh:exec(sql_string)

    db_gh:exec(string.format("INSERT INTO " .. t_table ..
        " ('Name','Count') VALUES %s;", insert))

    local final_gh_bank_table = {}

    for x in db_gh:nrows(
        "SELECT Name,Sum(Count) as Count FROM Temp_GH group by Name") do
        local array_item = { Name = x.Name, Count = x.Count }
        table.insert(final_gh_bank_table, array_item)
        --  print(x.Name, " ", x.Count)
    end

    db_gh:close()

    return final_gh_bank_table
end

local function recipe_comp_check(p_array)
    local shopping_check_flag = 0
    for x = 1, #p_array do
        local l_buy_count = lib.return_number(p_array[x], 4)
        local l_item_id = lib.return_number(p_array[x], 3)
        local l_inv_count = mq.TLO.FindItemCount(l_item_id)()
        if l_buy_count > l_inv_count then shopping_check_flag = 1 end
    end
    return shopping_check_flag
end

local function removeDuplicates(arr)
    local newArray = {}
    local checkerTbl = {}
    for _, element in ipairs(arr) do
        if not checkerTbl[element] then -- if there is not yet a value at the index of element, then it will be nil, which will operate like false in an if statement
            checkerTbl[element] = true
            table.insert(newArray, element)
        end
    end
    return newArray
end

local function ammo_swap_slot(p_item_id)
    if mq.TLO.FindItem(p_item_id)() == nil or mq.TLO.FindItemCount(p_item_id)() <
        1 then
        return
    end

    if mq.TLO.Me.Inventory(22).ID() == p_item_id then return end
    if mq.TLO.Me.Inventory(22).ID() == nil then return end

    if p_item_id == nil or p_item_id == 0 then return end

    if GLOBAL_PRIMARY_SLOT == nil then return false end
    if GLOBAL_PRIMARY_SLOT == mq.TLO.Me.Inventory(13).ID() then return false end
    -- GrabItemID(GLOBAL_PRIMARY_SLOT)

    if mq.TLO.Me.Inventory(22).ID() ~= nil then
        mq.cmd('/nomodkey /itemnotify 22 leftmouseup')
        mq.delay(1000)
    end

    lib.GrabItemID(p_item_id, 1)
    mq.delay(1)
    print(msg, "\ap[\agReturning\ap \ap[\aw", lib.return_item_name(p_item_id),
        "\ap]")
    mq.delay(500)
    mq.cmd('/nomodkey /itemnotify 22 leftmouseup')
    mq.delay(500)
    lib.ClearCursor()
    return
end

local function toggle_local_echo(p_state)
    if p_state then
        mq.cmd('/squelch /dnet localecho on')
        mq.delay(300)
    end
    return
end

local function query_dannet(peer, query, timeout)
    mq.cmdf('/dquery %s -q "%s"', peer, query)
    mq.delay(timeout or 200)
    local value = mq.TLO.DanNet(peer).Q(query)()
    return value
end

-- Select preferred crafting zone  SRH , POK , NGH
local function crafting_zone(p_zone_id)
    local crafting_zone_id = p_zone_id

    if crafting_zone_id == 712 and mq.TLO.Zone.ID() ~= 712 then
        --  print(msg, "\ap[\awPreferred Crafting Zone: \ap[\agSunrise Hills\ap]")
        movement.srh()
    end

    if mq.TLO.Me.Guild() == nil then crafting_zone_id = 202 end

    -- Use the boat to get out of halas
    if mq.TLO.Zone.ID() == 29 then
        movement.leave_halas()

        mq.cmd('/squelch /travelto poknowledge')
        while true do
            if mq.TLO.Zone.ID() == 202 then break end
            mq.delay(1)
        end
    end

    -- if we are in CR go to 1st floor
    if mq.TLO.Zone.ID() == 394 then
        movement.crescent_reach_floor_1()

        mq.cmd('/squelch /travelto poknowledge')
        while true do
            if mq.TLO.Zone.ID() == 202 then break end
            mq.delay(1)
        end
    end

    -- need to add GFAY and Erudian

    if crafting_zone_id == 202 and mq.TLO.Zone.ID() ~= 202 then
        -- print(msg,
        --    "\ap[\awPreferred Crafting Zone: \ap[\agPlane Of Knowledge\ap]")

        movement.pok()
    end
    -- Standard Guild Hall
    if crafting_zone_id == 345 and mq.TLO.Zone.ID() ~= 345 then
        -- print(msg,
        --      "\ap[\awPreferred Crafting Zone: \ap[\agStandard Guild Hall\ap]")
        movement.sgh()
    end
    -- GGH, Palatial, MGH
    if crafting_zone_id == 99999 then
        local guild_crafting_zone_ids = { 738, 737, 751 }
        local flag = 0
        -- doubt we need this :)
        for z = 1, #guild_crafting_zone_ids do
            if mq.TLO.Zone.ID() == guild_crafting_zone_ids[z] then
                flag = 1
                break
            end
        end
        if flag == 0 then
            -- print(msg,
            --   "\ap[\awPreferred Crafting Zone: \ap[\agNeighborhood Guild Hall\ap]")
            movement.ngh()
        end
    end
    return
end

-- need to remove tools
local function depot_squash(p_depot_array)
    local depot_c_table = {}

    for x = 1, #p_depot_array do
        local ItemName = p_depot_array[x].Name
        local Quantity = p_depot_array[x].Quantity
        local ItemID = p_depot_array[x].ID
        table.insert(depot_c_table,
            string.format('(%d,%d,"%s")', ItemID, Quantity, ItemName))
    end

    -- for c = 1, #depot_c_table do print(depot_c_table[c]) end

    local db_dep = sqlite3.open(":memory:")

    db_dep:exec(
        "DROP TABLE IF EXISTS DEPOT_COLLAPSE;CREATE TEMP TABLE DEPOT_COLLAPSE (ItemID,Quantity,ItemName);")

    local insert = table.concat(depot_c_table, ", ")

    db_dep:exec(string.format(
        "INSERT INTO DEPOT_COLLAPSE ('ItemID','Quantity','ItemName') VALUES %s;",
        insert))

    -- for x in db_dep:nrows(
    --           "SELECT ItemID,SUM(Quantity) AS Quantity,ItemName FROM DEPOT_COLLAPSE GROUP BY ID") do
    --  local l_count = x.Count
    --  local is_crafted = lib.toolcheck(x.ID)
    --  if is_crafted == 1 then
    -- print("original count is:", x.Count)
    --      l_count = 1
    --  end
    --  print(x.ItemID, " ", x.RecName, " ", x.ID, " ", l_count)
    -- table.insert(depot_insert_array,
    --        x.ItemID .. "," .. x.ItemName .. "," .. x.Quantity)
    -- end
    -- watch out for tools, we should never put them in Depot

    local cleansed_depot_array = {}

    for x in db_dep:nrows(
        "SELECT ItemID,SUM(Quantity) AS Quantity,ItemName FROM DEPOT_COLLAPSE GROUP BY ItemID") do
        -- print(x.ItemID .. "," .. x.ItemName .. "," .. x.Quantity)
        local item = { Name = x.ItemName, Quantity = x.Quantity, ID = x.ItemID }
        table.insert(cleansed_depot_array, item)
    end

    db_dep:close()

    return cleansed_depot_array
end

-- Add global setting
local preferred_crafting_zone = 202

local function navigate_to_forge(l_recipe_id)
    local l_container_name = lib.return_container_name(l_recipe_id)
    local zone_data = {
        ["Guktan Forge"] = { id = 50, cmd = "/travelto rathemtn", text = "Heading to Rathe Mountains (Frogland)" },
        ["Ogre Forge"] = { id = 49, cmd = "/travelto oggok", text = "Heading to Oggok (Ogreland)" },
        ["Iksar Forge"] = { id = 106, cmd = "/travelto cabeast", text = "Heading to Cabilis East (LizardLand)" },
        ["Teir`Dal Forge"] = { id = 42, cmd = "/travelto neriakc", text = "Heading to 3rd Gate (Dark Elf Land)" },
        ["Troll Forge"] = { id = 52, cmd = "/travelto grobb", text = "Heading to Grobb (TrollLand)" },
        ["Stormguard Forge"] = { id = 60, cmd = "/travelto kaladima", text = "Heading to Grobb (DorfLand)" },
        ["Shar Vahl Forge"] = { id = 155, cmd = "/travelto sharvahl", text = "Heading to Shar Vahl (Catland)" },
        ["Vale Forge"] = { id = 19, cmd = "/travelto rivervale", text = "Heading to Rivervale (Halfwits)" },
        ["Antonican Forge"] = { id = 1, cmd = "/travelto qeynos", text = "Heading to South Qeynos (Humans/Half Elfs)" },
        ["Half Elf Forge"] = { id = 1, cmd = "/travelto qeynos", text = "Heading to South Qeynos (Humans/Half Elfs)" },
        ["Koada`Dal Forge"] = { id = 61, cmd = "/travelto felwithea", text = "Heading to Northern Felwithe (High Elves)" },
        ["Clockwork Forge"] = { id = 55, cmd = "/travelto akanon", text = "Heading to Ak'Anon (Shrimps)" },
        ["Northman Forge"] = { id = 29, cmd = "/travelto halas", text = "Heading to Halas (Barbs)" },
        ["Crystalwing Forge"] = { id = 394, cmd = "/travelto crescent", text = "Heading to Crescent Reach (Dragon Breath)" },
        ["Feir`Dal Forge"] = { id = 54, cmd = "/travelto gfaydark", text = "Heading to Greater Faydark (FruityElves)" }
    }

    local target = zone_data[l_container_name]
    if target then
        if mq.TLO.Zone.ID() ~= target.id then
            mq.cmd('/squelch ' .. target.cmd)
            GLOBAL_TEXT = target.text
        end

        while mq.TLO.Zone.ID() ~= target.id do
            mq.delay(1)
        end

        mq.delay(60000, function() return mq.TLO.Zone.ID() == target.id end)
        while not mq.TLO.Nav.MeshLoaded() do
            mq.delay(1000)
        end

        if l_container_name == "Northman Forge" then
            movement.northman_forge()
        elseif l_container_name == "Crystalwing Forge" then
            movement.crescent_reach_floor_2()
        elseif l_container_name == "Feir`Dal Forge" and mq.TLO.Me.Z() < 10 then
            movement.gfay_platform()
        end
    else
        crafting_zone(preferred_crafting_zone)
    end
end

-- Colors (RGBA, 0-1 range)
local COLOR_MAIN_RECIPE   = { 0.20, 0.45, 0.95, 1.0 } -- bright royal blue (keep)
local COLOR_SUB_RECIPE    = { 0.25, 0.75, 0.65, 1.0 } -- slightly muted turquoise
local COLOR_ITEM          = { 0.70, 0.40, 0.85, 1.0 } -- medium orchid (keep)
local COLOR_COUNT         = { 0.0, 0.9, 0.0, 1.0 }    -- softer green for counts
local COLOR_VENDOR_TEXT   = { 0.0, 0.8, 0.0, 0.8 }    -- brightest green
local COLOR_FARMED_TEXT   = { 0.95, 0.85, 0.3, 1.0 }  -- warm gold for farmed tag
local COLOR_BRACKETS      = { 0.0, 0.8, 0.8, 1.0 }    -- teal (keep)
local COLOR_HIGHLIGHT_NUM = { 0.75, 0.80, 0.40, 1.0 } -- warm gold-olive

-- Helper: check if an ItemID is sold by a vendor
local function isVendorItem(itemID)
    if not itemID then return false end
    local query = string.format("SELECT 1 FROM VendorTable WHERE ItemID = %d LIMIT 1", itemID)
    for _ in db:nrows(query) do
        return true
    end
    return false
end

local tcn_req = {}

local recipe_attempts = 0

-- Global Functions

-- Recursive recipe fetch (now includes Trivial and ItemID)
function tcn_req.getRecipeTree(recipe_id)
    local recipe_query = string.format(
        "SELECT RecipeID, RecipeName, Yield, Container, Skill, Trivial FROM masterrecipetable WHERE RecipeID = %d AND RecipeID != 0",
        recipe_id
    )

    local recipe
    for row in db:nrows(recipe_query) do
        recipe = {
            id = row.RecipeID,
            name = row.RecipeName,
            yield = row.Yield,
            container = row.Container,
            skill = row.Skill,
            trivial = row.Trivial,
            ingredients = {}
        }
    end
    if not recipe then return nil end

    local ing_query = string.format(
        "SELECT ItemID, ItemName, ItemCount, SubRecipeID FROM mastercomptable WHERE RecipeID = %d AND RecipeID != 0",
        recipe_id
    )

    for ing in db:nrows(ing_query) do
        local ingredient = {
            id = ing.ItemID,
            name = ing.ItemName,
            count = ing.ItemCount or 1,
            subrecipe = nil
        }
        if ing.SubRecipeID and ing.SubRecipeID > 0 then
            ingredient.subrecipe = tcn_req.getRecipeTree(ing.SubRecipeID)
        end
        table.insert(recipe.ingredients, ingredient)
    end

    return recipe
end

function tcn_req.drawRecipeTree(recipe, countNeeded, isMain, Mode)
    local qty = countNeeded or 1

    -- Force expand/collapse if requested
    if Mode == "E" then
        ImGui.SetNextItemOpen(true, ImGuiCond.Always)
    elseif Mode == "C" then
        ImGui.SetNextItemOpen(false, ImGuiCond.Always)
    end

    -- Start TreeNode with recipe name
    local col = isMain and COLOR_MAIN_RECIPE or COLOR_SUB_RECIPE
    ImGui.PushStyleColor(ImGuiCol.Text, col[1], col[2], col[3], col[4])
    local treeOpen = ImGui.TreeNodeEx(string.format("(%d) %s", qty, recipe.name or "Unknown"))
    ImGui.PopStyleColor()

    if treeOpen then
        -- Whole details section in one color
        ImGui.SameLine()
        ImGui.PushStyleColor(ImGuiCol.Text,
            COLOR_HIGHLIGHT_NUM[1], COLOR_HIGHLIGHT_NUM[2],
            COLOR_HIGHLIGHT_NUM[3], COLOR_HIGHLIGHT_NUM[4]
        )
        ImGui.Text(string.format("(Yield: %s, Container: %s, Skill: %s, Trivial: %s)",
            tostring(recipe.yield or "?"),
            tostring(recipe.container or "?"),
            tostring(recipe.skill or "?"),
            tostring(recipe.trivial or "?")
        ))
        ImGui.PopStyleColor()


        --ImGui.SameLine(0, 0)
        --ImGui.Text(")")

        -- Separate items and subrecipes
        local items, subs = {}, {}
        for _, ing in ipairs(recipe.ingredients or {}) do
            if ing.subrecipe then
                table.insert(subs, ing)
            else
                table.insert(items, ing)
            end
        end

        -- Draw items first
        for _, ing in ipairs(items) do
            local isVendor = isVendorItem(ing.id)

            -- Bullet + (count) in bright green
            ImGui.PushStyleColor(ImGuiCol.Text, COLOR_COUNT[1], COLOR_COUNT[2], COLOR_COUNT[3], COLOR_COUNT[4])
            ImGui.Bullet()
            ImGui.Text(string.format("(%d)", ing.count or 1))
            ImGui.PopStyleColor()

            -- [Vendor] or [Farmed] with no spaces inside brackets
            ImGui.SameLine()
            ImGui.PushStyleColor(ImGuiCol.Text, COLOR_BRACKETS[1], COLOR_BRACKETS[2], COLOR_BRACKETS[3],
                COLOR_BRACKETS[4])
            ImGui.Text("[")
            ImGui.PopStyleColor()

            ImGui.SameLine(0, 0)
            if isVendor then
                ImGui.PushStyleColor(ImGuiCol.Text, COLOR_VENDOR_TEXT[1], COLOR_VENDOR_TEXT[2], COLOR_VENDOR_TEXT[3],
                    COLOR_VENDOR_TEXT[4])
                ImGui.Text("Vendor")
                ImGui.PopStyleColor()
            else
                ImGui.PushStyleColor(ImGuiCol.Text, COLOR_FARMED_TEXT[1], COLOR_FARMED_TEXT[2], COLOR_FARMED_TEXT[3],
                    COLOR_FARMED_TEXT[4])
                ImGui.Text("Farmed")
                ImGui.PopStyleColor()
            end

            ImGui.SameLine(0, 0)
            ImGui.PushStyleColor(ImGuiCol.Text, COLOR_BRACKETS[1], COLOR_BRACKETS[2], COLOR_BRACKETS[3],
                COLOR_BRACKETS[4])
            ImGui.Text("]")
            ImGui.PopStyleColor()

            -- Item name in purple
            ImGui.SameLine()
            ImGui.PushStyleColor(ImGuiCol.Text, COLOR_ITEM[1], COLOR_ITEM[2], COLOR_ITEM[3], COLOR_ITEM[4])
            ImGui.Text(ing.name or "Unknown")
            ImGui.PopStyleColor()
        end

        -- Then draw subrecipes
        for _, ing in ipairs(subs) do
            --tcn_req.drawRecipeTree(ing.subrecipe, ing.count or 1, false)
            tcn_req.drawRecipeTree(ing.subrecipe, ing.count or 1, false, Mode)
        end

        ImGui.TreePop()
    end
end

function tcn_req.return_depot_convert_data(p_depot_data)
    -- Convert data to data structure format for sorting depot data
    local converted_depot_data = {}
    for c = 1, #p_depot_data do
        local farm_item_name = return_string(p_depot_data[c], 1)
        if string.find(farm_item_name, "@") then
            farm_item_name = farm_item_name:gsub('@', ',')
        end
        local farm_item_id = return_number(p_depot_data[c], 2)
        local farm_item_count = return_number(p_depot_data[c], 3)
        local farm_item_action = return_string(p_depot_data[c], 4)
        local farm_item_zone_name = return_string(p_depot_data[c], 5)
        if string.find(farm_item_zone_name, "@") then
            farm_item_zone_name = farm_item_zone_name:gsub('@', ',')
        end
        --  if farm_item_zone_name  == "Plane of Knowledge" then farm_item_zone_name  = "The Plane of Knowledge" end
        -- local farm_item_zone_id = mq.TLO.Zone(farm_item_zone_name).ID
        local item = {
            ID = farm_item_id,
            Action = farm_item_action,
            Name = farm_item_name,
            Quantity = farm_item_count,
            ZoneName = farm_item_zone_name
        }
        table.insert(converted_depot_data, item)
    end
    return converted_depot_data
end

-- Return logo texture name
function tcn_req.return_logo(p_exp_name)
    local l_logo_exp = nil

    local logo_array = {
        "EQU", 'A_EQ', "ROK", 'A_ROK', "SOV", 'A_SOV', "SOL", 'A_SOL', "POP",
        'A_POP', "LOY", 'A_LOY', "LDON", 'A_LDON', "GOD", 'A_GOD', "OOW",
        'A_OOW', "DON", 'A_DON', "DODH", 'A_DOD', "POR", 'A_POR', "TSS",
        'A_TSS', "TBS", 'A_TBS', "SOF", 'A_SOF', "SOD", 'A_SOD', "UF", 'A_UND',
        "HOT", 'A_HOT', "VOA", 'A_VOA', "ROF", 'A_ROF', "COTF", 'A_COTF', "TDS",
        'A_TDS', "TBM", 'A_TBM', "EOK", 'A_EOK', "ROS", 'A_ROS', "TBL", 'A_TBL',
        "TOV", 'A_TOV', "COV", 'A_COV', "TOL", 'A_TOL', "NOS", 'A_NOS', "LSO",
        "A_LS", "TOB", "A_TOB"
    }

    -- logos come from EQUI_Animations.xml

    for c = 1, #logo_array, 2 do
        -- print(logo_array[c])
        if logo_array[c] == p_exp_name then
            l_logo_exp = logo_array[c + 1]
            break
        end
    end

    return l_logo_exp
end

-- Reload DANNET if new peer shows up that we've never seen
function tcn_req.reload_dannet()
    mq.cmd('/squelch /plugin mq2dannet unload')
    mq.delay(1000)
    mq.cmd('/squelch /plugin mq2dannet load')
    mq.delay(1000)
end

function tcn_req.request_items(p_item_id, p_item_qty)
    -- if mq.TLO.FindItemCount(p_item_id)() >= p_item_qty + mq.TLO.FindItemCount(p_item_id)() then return end

    local p_item_name = lib.return_item_name(p_item_id)

    GLOBAL_TEXT = "Does anyone have " .. p_item_name .. " on them?"

    local l_requested_qty = p_item_qty
    local l_item_name = p_item_name

    local l_item_id = 0

    local l_have_item = 0

    local l_remote_qty = 0

    local l_standard_name = nil

    local l_local_echo_status = mq.TLO.DanNet.LocalEcho()

    if l_local_echo_status then
        mq.cmd('/squelch /dnet localecho off')
        mq.delay(300)
    end

    for x = 1, mq.TLO.DanNet.PeerCount() do
        -- Get server and peer names
        local peer_name = mq.TLO.DanNet.Peers(x)()

        if peer_name == nil then break end

        local my_server = mq.TLO.MacroQuest.Server()

        if string.find(peer_name, "_") and string.find(peer_name, my_server) then
            -- Strip server from name
            peer_name = peer_name:gsub(mq.TLO.MacroQuest.Server() .. "_", "")
        end

        -- NIL out players that are not on same server
        if string.find(peer_name, "_") then peer_name = nil end

        -- Fullnames off and not on same server
        local l_remote_server = query_dannet(peer_name, '"MacroQuest.Server"',
            400)
        --  print("Remote Server: ", l_remote_server, " Local Server: ",
        --     mq.TLO.MacroQuest.Server())
        if l_remote_server ~= mq.TLO.MacroQuest.Server() then
            peer_name = nil
        end

        -- Don't query myself
        if peer_name == string.lower(mq.TLO.Me()) then peer_name = nil end

        -- Peer on a different server
        if peer_name ~= nil then
            -- Peer on my server (redundant)
            --  if string.find(peer_name, mq.TLO.MacroQuest.Server()) then

            local l_remote_zone_id = tonumber(
                query_dannet(peer_name, "Zone.ID", 400))

            if l_remote_zone_id == mq.TLO.Zone.ID() then
                -- Strip server from name
                l_standard_name = peer_name:gsub(
                    mq.TLO.MacroQuest.Server() .. "_", "")

                -- Get quantity by ID
                l_remote_qty = tonumber(query_dannet(peer_name,
                    "FindItemCount[" ..
                    p_item_id .. "]", 400))

                local l_trade_tag = query_dannet(peer_name, "FindItem[" ..
                    p_item_id .. "].NoDrop",
                    400)

                -- print("remote qty: ", l_remote_qty)

                -- Count is good and we are in game
                if l_remote_qty ~= 0 and l_remote_qty ~= nil and l_remote_qty >=
                    l_requested_qty then
                    local l_remote_zone_id = tonumber(
                        query_dannet(peer_name,
                            "Zone.ID", 400))

                    -- print (l_remote_zone_id, " my zone", mq.TLO.Zone.ID())

                    -- how to tell if it has no drop tag?

                    if l_remote_zone_id == mq.TLO.Zone.ID() and l_trade_tag ~=
                        "TRUE" then
                        local c =
                            l_standard_name .. "," .. l_remote_qty .. "," ..
                            l_item_id .. "," .. l_item_name
                        l_have_item = 1

                        local l_remote_item_id = p_item_id

                        --     l_standard_name = "fakename"

                        GLOBAL_TEXT = l_standard_name .. " is bringing you " ..
                            l_item_name

                        print("\ag", l_standard_name, " has \ap(\ag",
                            l_remote_qty, "\ap) \ap\ap[\ag", l_item_name,
                            "\ap] \awand is bringing you what you want")

                        local l_give_string =
                            l_remote_item_id .. "," .. l_requested_qty .. "," ..
                            mq.TLO.Me.ID()

                        -- Get it for me!
                        mq.cmd('/dexecute ' .. peer_name ..
                            ' /lua run tcn//tcn_give ' .. l_give_string)

                        toggle_local_echo(l_local_echo_status)

                        break
                    else
                        if l_trade_tag == "TRUE" then
                            GLOBAL_TEXT = "Item is no trade"
                            mq.delay(1)
                            print("\at", l_standard_name, " has \ap(\ag",
                                l_remote_qty, "\ap) \ap[\ag", l_item_name,
                                "\ap] \awbut it is no trade ")
                        else
                            -- GLOBAL_TEXT =
                            --    l_standard_name .. " has " .. l_item_name ..
                            --        " ,but is in another zone"

                            -- mq.delay(1)
                            -- print("\at", l_standard_name, " has \ap(\ag",
                            --      l_remote_qty, "\ap) \ap[\ag", l_item_name,
                            -- "\ap] \awbut is in a different zone ")
                        end
                        toggle_local_echo(l_local_echo_status)
                    end
                end
            end
        end
    end

    if l_have_item == 0 then
        toggle_local_echo(l_local_echo_status)
        --  GLOBAL_TEXT = "No local items available"
        --     print("No one has what you want or in the quantity requested locally")
        return 0
    end

    -- Wait for them to get to me
    local PC_Distance = mq.TLO.Spawn(l_standard_name).Distance()

    while PC_Distance > 30 do
        PC_Distance = mq.TLO.Spawn(l_standard_name).Distance()
        mq.delay(1)
        -- mq.delay(50) check if they are moving -- or observe.. but moving doesn't mean distance
    end

    -- Wait For Trade Ready
    while not mq.TLO.Window('TradeWnd').HisTradeReady() do
        mq.cmd('/doevents')
        mq.delay(1)
    end

    -- Click Trade
    mq.delay(1500)
    mq.cmd('/notify TradeWnd TRDW_Trade_Button leftmouseup')
    return 1
end

function tcn_req.request_tsd_items(p_item_id, p_item_qty)
    local p_item_name = lib.return_item_name(p_item_id)

    GLOBAL_TEXT = "Does anyone have " .. p_item_name .. " in the depot?"

    local l_requested_qty = p_item_qty
    local l_item_name = p_item_name
    local l_item_id = 0
    local l_have_item = 0
    local l_remote_qty = 0
    local l_standard_name = nil

    local l_local_echo_status = mq.TLO.DanNet.LocalEcho()

    if l_local_echo_status then
        mq.cmd('/squelch /dnet localecho off')
        mq.delay(400)
    end

    for x = 1, mq.TLO.DanNet.PeerCount() do
        -- Get server and peer names
        local peer_name = mq.TLO.DanNet.Peers(x)()
        if peer_name == nil then break end
        local my_server = mq.TLO.MacroQuest.Server()
        if string.find(peer_name, "_") and string.find(peer_name, my_server) then
            -- Strip server from name
            peer_name = peer_name:gsub(mq.TLO.MacroQuest.Server() .. "_", "")
        end

        -- NIL out players that are not on same server
        if string.find(peer_name, "_") then peer_name = nil end

        -- Fullnames off and not on same server
        local l_remote_server = query_dannet(peer_name, '"MacroQuest.Server"',
            400)
        --  print("Remote Server: ", l_remote_server, " Local Server: ",
        --     mq.TLO.MacroQuest.Server())
        if l_remote_server ~= mq.TLO.MacroQuest.Server() then
            peer_name = nil
        end
        -- Don't query myself
        if peer_name == string.lower(mq.TLO.Me()) then peer_name = nil end

        -- set to nil if not enabled
        if peer_name ~= nil then
            local l_tsd_enabled = query_dannet(peer_name,
                "TradeskillDepot.Enabled", 400)
            if l_tsd_enabled ~= "TRUE" then peer_name = nil end
        end

        local l_remote_zone_id = tonumber(
            query_dannet(peer_name, "Zone.ID", 400))

        if l_remote_zone_id ~= mq.TLO.Zone.ID() then peer_name = nil end

        -- Initialize TSD
        if peer_name ~= nil then
            mq.cmd('/dexecute ' .. peer_name .. ' /lua run tcn//tcn_tsd_init')
            mq.delay(2000)
        end

        -- Peer on a different server
        if peer_name ~= nil then
            local l_remote_zone_id = tonumber(
                query_dannet(peer_name, "Zone.ID", 400))

            if l_remote_zone_id == mq.TLO.Zone.ID() then
                -- Peer on my server (redundant)
                --  if string.find(peer_name, mq.TLO.MacroQuest.Server()) then
                -- Strip server from name
                l_standard_name = peer_name:gsub(
                    mq.TLO.MacroQuest.Server() .. "_", "")

                -- check expansion if so then check count

                -- Get quantity by ID
                l_remote_qty = tonumber(query_dannet(peer_name,
                    "TradeskillDepot.FindItemCount[" ..
                    p_item_id .. "]", 400))
                -- Count is good and we are in game
                if l_remote_qty ~= 0 and l_remote_qty ~= nil and l_remote_qty >=
                    l_requested_qty then
                    local l_remote_zone_id = tonumber(
                        query_dannet(peer_name,
                            "Zone.ID", 400))

                    -- print (l_remote_zone_id, " my zone", mq.TLO.Zone.ID())

                    local l_trade_tag = query_dannet(peer_name,
                        "TradeskillDepot.FindItem[" ..
                        p_item_id .. "].NoDrop",
                        400)

                    if l_remote_zone_id == mq.TLO.Zone.ID() and l_trade_tag ~=
                        "TRUE" then
                        local c =
                            l_standard_name .. "," .. l_remote_qty .. "," ..
                            l_item_id .. "," .. l_item_name
                        l_have_item = 1

                        local l_remote_item_id = p_item_id

                        --    l_standard_name = "fakename"

                        GLOBAL_TEXT = l_standard_name .. " is bringing you " ..
                            l_item_name .. " from the depot"

                        print("\ag", l_standard_name, " has \ap(\ag",
                            l_remote_qty, "\ap) \ap\ap[\ag", l_item_name,
                            "\ap] \awand is bringing it to you from the depot")

                        local l_give_string =
                            l_remote_item_id .. "," .. l_requested_qty .. "," ..
                            mq.TLO.Me.ID()

                        -- Get it for me!
                        mq.cmd('/dexecute ' .. peer_name ..
                            ' /lua run tcn//tcn_tsd_give ' ..
                            l_give_string)

                        toggle_local_echo(l_local_echo_status)

                        break
                    else
                        --     l_standard_name = "fakename"
                        if l_trade_tag == "TRUE" then
                            GLOBAL_TEXT = "Item is no trade"
                            mq.delay(1)
                            print("\at", l_standard_name, " has \ap(\ag",
                                l_remote_qty, "\ap) \ap[\ag", l_item_name,
                                "\ap] \awbut it is no trade ")
                        else
                            --   GLOBAL_TEXT =
                            --    l_standard_name .. " has " .. l_item_name ..
                            --    " ,but is in another zone"
                            --  mq.delay(1)
                            -- print("\at", l_standard_name, " has \ap(\ag",
                            --      l_remote_qty, "\ap) \ap[\ag", l_item_name,
                            --   "\ap] \awbut is in a different zone ")
                        end
                        toggle_local_echo(l_local_echo_status)
                    end
                end
            end
        end
    end

    if l_have_item == 0 then
        toggle_local_echo(l_local_echo_status)

        -- print(
        -- "No one has what you want or in the quantity requested, or is not in zone")
        return 0
    end

    -- Wait for them to get to me
    local PC_Distance = mq.TLO.Spawn(l_standard_name).Distance()

    -- Check for LD...

    while PC_Distance > 30 do
        PC_Distance = mq.TLO.Spawn(l_standard_name).Distance()
        mq.delay(1)
    end

    -- Wait For Trade Ready
    while not mq.TLO.Window('TradeWnd').HisTradeReady() do
        mq.cmd('/doevents')
        mq.delay(1)
    end

    -- Click Trade
    mq.delay(1000)
    mq.cmd('/notify TradeWnd TRDW_Trade_Button leftmouseup')
    mq.delay(1)
    return
end

function tcn_req.request_bank_items(p_item_id, p_item_qty)
    local p_item_name = lib.return_item_name(p_item_id)

    GLOBAL_TEXT = "Does anyone have " .. p_item_name .. " in the bank?"

    local l_requested_qty = p_item_qty
    local l_item_name = p_item_name
    local l_item_id = 0
    local l_have_item = 0
    local l_remote_qty = 0
    local l_standard_name = nil

    local l_local_echo_status = mq.TLO.DanNet.LocalEcho()

    if l_local_echo_status then
        mq.cmd('/squelch /dnet localecho off')
        mq.delay(400)
    end

    for x = 1, mq.TLO.DanNet.PeerCount() do
        -- Get server and peer names
        local peer_name = mq.TLO.DanNet.Peers(x)()
        if peer_name == nil then break end
        local my_server = mq.TLO.MacroQuest.Server()
        if string.find(peer_name, "_") and string.find(peer_name, my_server) then
            -- Strip server from name
            peer_name = peer_name:gsub(mq.TLO.MacroQuest.Server() .. "_", "")
        end

        -- NIL out players that are not on same server
        if string.find(peer_name, "_") then peer_name = nil end

        -- Fullnames off and not on same server
        local l_remote_server = query_dannet(peer_name, '"MacroQuest.Server"',
            400)
        --  print("Remote Server: ", l_remote_server, " Local Server: ",
        --     mq.TLO.MacroQuest.Server())
        if l_remote_server ~= mq.TLO.MacroQuest.Server() then
            peer_name = nil
        end
        -- Don't query myself
        if peer_name == string.lower(mq.TLO.Me()) then peer_name = nil end
        -- Peer on a different server
        if peer_name ~= nil then
            local l_remote_zone_id = tonumber(
                query_dannet(peer_name, "Zone.ID", 400))

            if l_remote_zone_id == mq.TLO.Zone.ID() then
                -- Peer on my server (redundant)
                --  if string.find(peer_name, mq.TLO.MacroQuest.Server()) then
                -- Strip server from name
                l_standard_name = peer_name:gsub(
                    mq.TLO.MacroQuest.Server() .. "_", "")
                -- Get quantity by ID
                l_remote_qty = tonumber(query_dannet(peer_name,
                    "FindItemBankCount[" ..
                    p_item_id .. "]", 400))
                -- Count is good and we are in game
                if l_remote_qty ~= 0 and l_remote_qty ~= nil and l_remote_qty >=
                    l_requested_qty then
                    local l_remote_zone_id = tonumber(
                        query_dannet(peer_name,
                            "Zone.ID", 400))

                    -- print (l_remote_zone_id, " my zone", mq.TLO.Zone.ID())

                    local l_trade_tag = query_dannet(peer_name,
                        "FindItemBank[" ..
                        p_item_id .. "].NoDrop",
                        400)

                    if l_remote_zone_id == mq.TLO.Zone.ID() and l_trade_tag ~=
                        "TRUE" then
                        local c =
                            l_standard_name .. "," .. l_remote_qty .. "," ..
                            l_item_id .. "," .. l_item_name
                        l_have_item = 1

                        local l_remote_item_id = p_item_id

                        --    l_standard_name = "fakename"

                        GLOBAL_TEXT = l_standard_name .. " is bringing you " ..
                            l_item_name .. " from the bank"

                        print("\ag", l_standard_name, " has \ap(\ag",
                            l_remote_qty, "\ap) \ap\ap[\ag", l_item_name,
                            "\ap] \awand is bringing it to you from the bank")

                        local l_give_string =
                            l_remote_item_id .. "," .. l_requested_qty .. "," ..
                            mq.TLO.Me.ID()

                        -- Get it for me!
                        mq.cmd('/dexecute ' .. peer_name ..
                            ' /lua run tcn//tcn_bank_give  ' ..
                            l_give_string)

                        toggle_local_echo(l_local_echo_status)

                        break
                    else
                        --     l_standard_name = "fakename"
                        if l_trade_tag == "TRUE" then
                            GLOBAL_TEXT = "Item is no trade"
                            mq.delay(1)
                            print("\at", l_standard_name, " has \ap(\ag",
                                l_remote_qty, "\ap) \ap[\ag", l_item_name,
                                "\ap] \awbut it is no trade ")
                        else
                            --   GLOBAL_TEXT =
                            --    l_standard_name .. " has " .. l_item_name ..
                            --    " ,but is in another zone"
                            --  mq.delay(1)
                            -- print("\at", l_standard_name, " has \ap(\ag",
                            --      l_remote_qty, "\ap) \ap[\ag", l_item_name,
                            --   "\ap] \awbut is in a different zone ")
                        end
                        toggle_local_echo(l_local_echo_status)
                    end
                end
            end
        end
    end

    if l_have_item == 0 then
        toggle_local_echo(l_local_echo_status)
        -- print(
        -- "No one has what you want or in the quantity requested, or is not in zone")
        return 0
    end

    -- Wait for them to get to me
    local PC_Distance = mq.TLO.Spawn(l_standard_name).Distance()

    while PC_Distance > 30 do
        PC_Distance = mq.TLO.Spawn(l_standard_name).Distance()
        mq.delay(1)
    end

    -- Wait For Trade Ready
    while not mq.TLO.Window('TradeWnd').HisTradeReady() do
        mq.cmd('/doevents')
        mq.delay(1)
    end

    -- Click Trade
    mq.delay(1000)
    mq.cmd('/notify TradeWnd TRDW_Trade_Button leftmouseup')
    mq.delay(1)
    return 1
end

-- Iter the request array and deliver items if we have them
function tcn_req.request_item_cycle(p_request_array)
    -- Check inventory for items

    -- tcn_req.reload_dannet()

    mq.delay(1000)

    for c = 1, #p_request_array do
        local item_id = lib.return_number(p_request_array[c], 1)
        local item_count = lib.return_number(p_request_array[c], 2)
        local got_item = tcn_req.request_items(item_id, item_count)
        mq.delay(1)
        if got_item ~= 1 then
            local bank_got_item =
                tcn_req.request_bank_items(item_id, item_count)
            -- request from TSD
            if bank_got_item ~= 1 then
                tcn_req.request_tsd_items(item_id, item_count)
            end
            mq.delay(1)
        end
    end
    mq.delay(1)
    return
end

-- Block these spell effects
function tcn_req.block_cursor_loot()
    local spells_to_block = {
        52, 53, 55, 56, 1503, 2538, 6893, 6895, 10763, 10764, 10765, 3188, 50,
        10700, 27465, 44807, 8141, 18745, 51573, 2716, 36018, 14678, 8146
    }
    for x = 1, #spells_to_block do
        mq.cmd('/blockspell add me ', spells_to_block[x])
        mq.delay(1000)
    end
end

function tcn_req.trophy_quests()
    -- Only run this if we open tabs/headers that  do tasks
    lib.open_journal()
    mq.delay(1000)
    local m = lib.available_trophy_quests(0)
    return m
end

-- Search Recipe Components SQL
function tcn_req.component_search_results(p_arg)
    local m = {}
    local sql_string

    if p_arg == "#" then
        -- Numeric names branch: matches ItemName starting with 0–99
        sql_string = [[
            SELECT DISTINCT ItemName, ItemID, Bugged
            FROM mastercomptable
            WHERE ItemID != 0
              AND (Bugged IS NULL OR Bugged != 1)
              AND UPPER(ItemName) > '0'
              AND UPPER(ItemName) <= '99%'
            ORDER BY ItemName ASC
        ]]
    else
        -- Escape single quotes in search term for safety
        local safe_arg = p_arg:gsub("'", "''")
        -- Partial match anywhere in the name
        sql_string = string.format([[
            SELECT DISTINCT ItemName, ItemID, Bugged
            FROM mastercomptable
            WHERE ItemID != 0
              AND (Bugged IS NULL OR Bugged != 1)
              AND ItemName LIKE '%%%s%%'
            ORDER BY ItemName ASC
        ]], safe_arg)
    end

    for r in db:nrows(sql_string) do
        table.insert(m, {
            Name = r.ItemName,
            ID   = r.ItemID
        })
    end

    return m
end

function tcn_req.component_search_results_single_char(p_arg)
    -- Special case: "#" means start with "1"
    if p_arg == "#" then p_arg = "1" end

    local m = {}
    local sql_string

    -- If the search term looks numeric (your old "1" check), handle numeric range
    if string.find(p_arg, "1") then
        sql_string = string.format([[
            SELECT DISTINCT
              r.RecipeID   AS RID,
              r.RecipeName AS Name,
              m.ItemName   AS ItemName,
              m.ItemID     AS ID
            FROM mastercomptable m
            JOIN masterrecipetable r
              ON r.RecipeID = m.RecipeID
            WHERE m.ItemID != 0
              AND (m.Bugged IS NULL OR m.Bugged != 1)
              AND m.RecipeID != 0
              AND UPPER(m.ItemName) > '0'
              AND UPPER(m.ItemName) <= '99%%'
            ORDER BY m.ItemName ASC
        ]])
    else
        -- Normal case: search by starting letters of ItemName
        sql_string = string.format([[
            SELECT DISTINCT
              r.RecipeID   AS RID,
              r.RecipeName AS Name,
              m.ItemName   AS ItemName,
              m.ItemID     AS ID
            FROM mastercomptable m
            JOIN masterrecipetable r
              ON r.RecipeID = m.RecipeID
            WHERE m.ItemID != 0
              AND (m.Bugged IS NULL OR m.Bugged != 1)
              AND m.RecipeID != 0
              AND m.ItemName LIKE '%s%%'
            ORDER BY m.ItemName ASC
        ]], p_arg:gsub("'", "''"))
    end

    for r in db:nrows(sql_string) do
        table.insert(m, {
            RID = r.RID,
            Name = r.Name,         -- RecipeName from masterrecipetable
            ItemName = r.ItemName, -- Component's item name
            ID = r.ID              -- ItemID
        })
    end

    return m
end

-- Search Recipe Components SQL
function tcn_req.component_search_recipe_results(p_arg)
    local m = {}
    local sql_string = string.format([[
        SELECT DISTINCT
          r.RecipeID   AS RID,
          r.RecipeName AS Name,
          m.ItemName   AS ItemName,
          m.ItemID     AS ID
        FROM mastercomptable m
        JOIN masterrecipetable r
          ON r.RecipeID = m.RecipeID
        WHERE m.ItemID = %d
          AND m.ItemID != 0
          AND (m.Bugged IS NULL OR m.Bugged != 1)
          AND m.RecipeID != 0
        ORDER BY r.RecipeName ASC
    ]], p_arg)

    for r in db:nrows(sql_string) do
        table.insert(m, {
            RID = r.RID,
            Name = r.Name,
            ItemName = r.ItemName,
            ID = r.ID
        })
    end

    return m
end

-- Combined search for components and recipes
-- mode:
--   "id"     = exact ItemID match 
--   "like"   = partial match anywhere in ItemName 
--   "start"  = starts-with match 
--   "num"    = numeric name range (old "#" branch)
function tcn_req.item_recipe_search(p_arg, mode)
    local m = {}
    local sql_string
    local safe_arg = p_arg and tostring(p_arg):gsub("'", "''") or ""

    if mode == "contains" or mode == "like" then
        -- Contains match anywhere in ItemName
        if p_arg == "#" then
            safe_arg = "1"
        else
            safe_arg = "%" .. safe_arg .. "%"
        end

        sql_string = string.format([[
            SELECT DISTINCT
              m.ItemName,
              m.ItemID
            FROM mastercomptable m
            WHERE m.ItemID != 0
              AND m.ItemName LIKE '%s'
            ORDER BY m.ItemName ASC
        ]], safe_arg)

        -- Numeric recipes check
        if string.find(safe_arg, "1") then
            sql_string = [[
                SELECT DISTINCT
                  m.ItemName,
                  m.ItemID
                FROM mastercomptable m
                WHERE UPPER(m.ItemName) > '0'
                  AND UPPER(m.ItemName) <= '99%%'
                  AND m.ItemID != 0
                ORDER BY m.ItemName ASC
            ]]
        end

        for r in db:nrows(sql_string) do
            table.insert(m, { Name = r.ItemName, ID = r.ItemID })
        end

    elseif mode == "starts" or mode == "start" then
        -- Starts-with match
        if p_arg == "#" then safe_arg = "1" end

        sql_string = string.format([[
            SELECT DISTINCT
              m.ItemName,
              m.ItemID
            FROM mastercomptable m
            WHERE m.ItemID != 0
              AND m.ItemName LIKE '%s%%'
            ORDER BY m.ItemName ASC
        ]], safe_arg)

        if string.find(safe_arg, "1") then
            sql_string = [[
                SELECT DISTINCT
                  m.ItemName,
                  m.ItemID
                FROM mastercomptable m
                WHERE UPPER(m.ItemName) > '0'
                  AND UPPER(m.ItemName) <= '99%%'
                  AND m.ItemID != 0
                ORDER BY m.ItemName ASC
            ]]
        end

        for r in db:nrows(sql_string) do
            table.insert(m, { Name = r.ItemName, ID = r.ItemID })
        end

    elseif mode == "recipe" then
        -- Exact ItemID match, returning recipe info
        sql_string = string.format([[
            SELECT DISTINCT
              m.RecipeID,
              r.RecipeName,
              m.ItemName,
              m.ItemID
            FROM mastercomptable m
            JOIN masterrecipetable r
              ON r.RecipeID = m.RecipeID
            WHERE m.ItemID = %d
              AND m.ItemID != 0
              AND m.RecipeID != 0
              AND (r.Bugged IS NULL OR r.Bugged != 1)
            ORDER BY m.ItemName ASC
        ]], tonumber(p_arg) or 0)

        for r in db:nrows(sql_string) do
            table.insert(m, {
                RID      = r.RecipeID,
                Name     = r.RecipeName,
                ItemName = r.ItemName,
                ID       = r.ItemID
            })
        end

    elseif mode == "id" then
        -- Exact ItemID match, returning recipe info (same as recipe mode but ordered by recipe name)
        sql_string = string.format([[
            SELECT DISTINCT
              r.RecipeID   AS RID,
              r.RecipeName AS Name,
              m.ItemName   AS ItemName,
              m.ItemID     AS ID
            FROM mastercomptable m
            JOIN masterrecipetable r
              ON r.RecipeID = m.RecipeID
            WHERE m.ItemID = %d
              AND m.ItemID != 0
              AND m.RecipeID != 0
              AND (r.Bugged IS NULL OR r.Bugged != 1)
            ORDER BY r.RecipeName ASC
        ]], tonumber(p_arg) or 0)

        for r in db:nrows(sql_string) do
            table.insert(m, {
                RID      = r.RID,
                Name     = r.Name,
                ItemName = r.ItemName,
                ID       = r.ID
            })
        end
    end

    return m
end

function tcn_req.single_recipe_search_results(p_arg, p_search_type)
    local m = {}

    if p_search_type == 0 then
        p_arg = p_arg .. '%'
    else
        p_arg = '%' .. p_arg .. '%'
    end

    -- p_arg = '"' .. p_arg:gsub('[\'"]', '\\%0') .. '"'

    -- p_arg = '"' .. p_arg .. '"'

    -- print("passed: ", p_arg)

    local sql_string

    sql_string =
        "SELECT * FROM MasterRecipeTable WHERE RecipeID !=0 AND ItemID !=0 AND RecipeID < 90000000 AND Upper(RecipeName) LIKE " ..
        p_arg .. " ORDER BY RecipeName ASC"

    sql_string =
        "SELECT * FROM MasterRecipeTable WHERE RecipeID !=0 AND ItemID !=0 AND RecipeID < 90000000 AND Upper(RecipeName) LIKE '%" ..
        p_arg:gsub("'", "''") .. "%' ORDER BY RecipeName ASC"

    -- sql_string =
    -- "SELECT * FROM MasterRecipeTable WHERE RecipeID !=0 AND ItemID !=0 AND RecipeID < 90000000 AND Upper(RecipeName) LIKE '%" ..
    -- p_arg:gsub("'", "''"):gsub(",", "\\,") .. "%' ORDER BY RecipeName ASC"

    -- fix batch search also

    -- print(sql_string)

    m = {}

    for r in db:nrows(sql_string) do
        if tonumber(r.Trivial) == 0 or tonumber(r.Trivial) == nil then
            r.Trivial = 15
        end

        local item = {
            RID = r.RecipeID,
            Name = r.RecipeName,
            Trivial = r.Trivial,
            Skill = r.Skill,
            Yield = r.Yield,
            Container = r.Container,
            ID = r.ItemID,
            SkillRequired = r.ReqSkill,
            Expansion = r.Expansion,
            ReqRace = r.ReqRace
        }

        -- jb321 added checking for NA, some results were set to NA
        -- Omit bugged recipes from search results and if there is no race requirement
        if r.Bugged ~= 1 and (r.ReqRace == nil or r.ReqRace == "NA") then
            table.insert(m, item)
        end

        -- table.insert(m, item)
        local l_c_race = convert_race(r.ReqRace)

        -- Add race requirement recipes to search results
        if l_c_race == mq.TLO.Me.Race() then table.insert(m, item) end
    end

    --  for c = 1 ,#m do print("\ag",m[c].Name) end
    --  print(#m)

    return m
end

-- Search Recipes SQL
function tcn_req.recipe_search_results(p_arg, p_options)
    -- print(p_arg, " ", p_options)

    if p_arg == "#" then p_arg = "1" end

    local m = {}

    p_options = "'" .. p_options .. "'"

    p_arg = p_arg .. '%'

    p_arg = "'" .. p_arg .. "'"

    -- print("passed: ", p_arg, " ", p_options)

    local sql_string

    -- filter by skill and container ?
    if p_options ~= "'Default'" then
        --  print("\ay",p_options)
        sql_string =
            "SELECT * FROM MasterRecipeTable WHERE RecipeID !=0 AND ItemID !=0 AND RecipeID < 90000000 AND Skill=" ..
            p_options .. " AND Upper(RecipeName) LIKE " .. p_arg ..
            " ORDER BY RecipeName ASC"

        --   print("string ",sql_string)

        -- Check for numeric recipes
        if string.find(p_arg, "1") then
            sql_string =
                "SELECT * FROM MasterRecipeTable WHERE RecipeID !=0 AND ItemID !=0 AND RecipeID < 90000000 AND Skill=" ..
                p_options ..
                " AND Upper(RecipeName) > '0' AND Upper(RecipeName) <= '99%' ORDER BY RecipeName ASC"
        end
    else
        sql_string =
            "SELECT * FROM MasterRecipeTable WHERE RecipeID !=0 AND ItemID !=0 AND RecipeID < 90000000 AND Upper(RecipeName) LIKE " ..
            p_arg .. " ORDER BY RecipeName ASC"
    end

    -- print(sql_string)

    -- Edit the master recipe table to put in 0s instead of null

    -- Show bugged recipes
    -- sql_string =
    -- "SELECT * FROM MasterRecipeTable WHERE RecipeID !=0 AND ItemID !=0 AND RecipeID < 90000000 AND Bugged = 1 AND Upper(RecipeName) LIKE " ..
    --  p_arg .. " ORDER BY RecipeName ASC"

    for r in db:nrows(sql_string) do
        --  highlight_recipe_requirements(make_row.Skill, make_row.RecipeID,

        if tonumber(r.Trivial) == 0 or tonumber(r.Trivial) == nil then
            r.Trivial = 15
        end

        local item = {
            RID = r.RecipeID,
            Name = r.RecipeName,
            Trivial = r.Trivial,
            Skill = r.Skill,
            Yield = r.Yield,
            Container = r.Container,
            ID = r.ItemID,
            SkillRequired = r.ReqSkill,
            Expansion = r.Expansion,
            ReqRace = r.ReqRace
        }

        -- Omit bugged recipes from search results and if there is no race requirement
        if r.Bugged ~= 1 and (r.ReqRace == nil or r.ReqRace == "NA") then
            table.insert(m, item)
        end

        local l_c_race = convert_race(r.ReqRace)

        -- Add race requirement recipes to search results
        if l_c_race == mq.TLO.Me.Race() then table.insert(m, item) end
    end

    -- for c = 1 , #m do print (m[c].RID, " ",m[c].Name) end

    return m
end

-- Return favorites based on ID array
function tcn_req.recipe_search_favorites(p_array)
    local m = {}
    local sql_string
    sql_string = string.format(
        "Select * FROM MasterRecipeTable WHERE RecipeID IN (%s)",
        table.concat(p_array, ", "))

    -- Edit the master recipe table to put in 0s instead of null

    for r in db:nrows(sql_string) do
        if tonumber(r.Trivial) == 0 or tonumber(r.Trivial) == nil then
            r.Trivial = 15
        end

        local item = {
            RID = r.RecipeID,
            Name = r.RecipeName,
            Trivial = r.Trivial,
            Skill = r.Skill,
            Yield = r.Yield,
            Container = r.Container,
            ID = r.ItemID,
            SkillRequired = r.ReqSkill,
            Expansion = r.Expansion,
            ReqRace = r.ReqRace
        }

        -- print("ID: ",r.RecipeID," Name: ",r.RecipeName)

        -- Omit bugged recipes from search results and if there is no race requirement
        if r.Bugged ~= 1 and (r.ReqRace == nil or r.ReqRace == "NA") then
            table.insert(m, item)
        end

        local l_c_race = convert_race(r.ReqRace)

        -- Add race requirement recipes to search results
        if l_c_race == mq.TLO.Me.Race() then table.insert(m, item) end
    end
    return m
end

-- Return results for a single query in batch search window (text search)
function tcn_req.recipe_batch_single_result(p_arg)
    local m = {}
    p_arg = p_arg .. '%'
    -- p_arg = "'" .. p_arg .. "'"
    -- print("passed: ", p_arg)

    local sql_string =
        "SELECT * FROM MasterRecipeTable WHERE RecipeID !=0 AND ItemID !=0 AND RecipeID < 90000000 AND Upper(RecipeName) LIKE " ..
        p_arg .. " ORDER BY RecipeName ASC"

    sql_string =
        "SELECT * FROM MasterRecipeTable WHERE RecipeID !=0 AND ItemID !=0 AND RecipeID < 90000000 AND Upper(RecipeName) LIKE '%" ..
        p_arg:gsub("'", "''") .. "%' ORDER BY RecipeName ASC"

    -- print(sql_string)
    for r in db:nrows(sql_string) do
        if tonumber(r.Trivial) == 0 or tonumber(r.Trivial) == nil then
            r.Trivial = 15
        end
        local item = {
            RID = r.RecipeID,
            Name = r.RecipeName,
            Trivial = r.Trivial,
            Skill = r.Skill,
            Yield = r.Yield,
            Container = r.Container,
            ID = r.ItemID,
            SkillRequired = r.ReqSkill,
            ReqRace = r.ReqRace
        }

        -- Omit bugged recipes from search results and if there is no race requirement
        if r.Bugged ~= 1 and (r.ReqRace == nil or r.ReqRace == "NA") then
            table.insert(m, item)
        end
        local l_c_race = convert_race(r.ReqRace)
        -- Add race requirement recipes to search results
        if l_c_race == mq.TLO.Me.Race() then table.insert(m, item) end
    end
    return m
end

-- Search Batch Recipes SQL
-- function tcn_req.recipe_batch_results(p_arg, p_options,p_exp_name)
function tcn_req.recipe_batch_results(p_options, p_exp_name)
    local m = {}

    -- print(p_options)
    -- print(p_arg)

    p_options = "'" .. p_options .. "'"
    -- p_arg = p_arg .. '%'
    -- p_arg = "'" .. p_arg .. "'"

    -- Expansions
    local exp_names = {
        "The Outer Brood", "TOB", "Laurion's Song", "LSO", "Night of Shadows",
        "NOS", "Terror of Luclin", "TOL", "Claws of Veeshan", "COV",
        "Torment of Velious", "TOV", "The Burning Lands", "TBL",
        "Ring of Scale", "ROS", "Empires of Kunark", "EOK", "The Darkened Sea",
        "TDS", "Call of the Forsaken", "COTF", "Rain of Fear", "ROF",
        "Veil of Alaris", "VOA", "House of Thule", "HOT", "Underfoot", "UF",
        "Seeds of Destruction", "SOD", "Secrets of Faydwer", "SOF",
        "The Buried Sea", "TBS", "The Serpent's Spine", "TSS", "Prophecy of Ro",
        "POR", "Depths of Darkhollow", "DODH", "Dragons of Norrath", "DON",
        "Omens of War", "OOW", "Gates of Discord", "GOD",
        "Lost Dungeons of Norrath", "LDON", "Legacy of Ykesha", "LOY",
        "Planes of Power", "POP", "Shadows of Luclin", "SOL",
        "Scars of Velious", "SOV", "Ruins of Kunark", "ROK", "Everquest", "EQU"
    }

    for c = 1, #exp_names do
        if exp_names[c] == p_exp_name then
            p_exp_name = exp_names[c + 1]
            break
        end
    end

    p_exp_name = "'" .. p_exp_name .. "'"

    --  print("passed: ", p_options, " ", p_exp_name)

    local sql_string
    -- filter by skill and container ?
    if p_options ~= "'Default'" then
        --  print("\ay",p_options)
        sql_string =
            "SELECT * FROM MasterRecipeTable WHERE RecipeID !=0 AND ItemID !=0 AND RecipeID < 90000000 AND Skill=" ..
            p_options .. " AND Expansion=" .. p_exp_name -- .." ORDER BY RecipeName ASC"
        -- .." AND Upper(RecipeName) LIKE " .. p_arg ..
        -- " ORDER BY RecipeName ASC"

        --  sql_string = "SELECT * FROM MasterRecipeTable WHERE RecipeID !=0 AND ItemID !=0 AND RecipeID < 90000000 AND Skill=" ..
        --    p_options .. " AND Expansion="..exp_name..
        --   " ORDER BY RecipeName ASC"

        --    print("string ",sql_string)
    else
        sql_string =
            "SELECT * FROM MasterRecipeTable WHERE RecipeID !=0 AND ItemID !=0 AND RecipeID < 90000000 AND Expansion=" ..
            p_exp_name
        -- ..
        -- " AND Upper(RecipeName) LIKE " ..
        --     p_arg .. " ORDER BY RecipeName ASC"
    end

    -- sql_string =
    --    "SELECT * FROM MasterRecipeTable WHERE RecipeID !=0 AND ItemID !=0 AND RecipeID < 90000000 WHERE RecipeName LIKE " ..
    --       p_arg .. " AND ItemID !=0 ORDER BY ItemName ASC"

    -- print(sql_string)

    -- os.exit()
    -- print(sql_string)

    -- Edit the master recipe table to put in 0s instead of null

    -- Show bugged recipes
    -- sql_string =
    -- "SELECT * FROM MasterRecipeTable WHERE RecipeID !=0 AND ItemID !=0 AND RecipeID < 90000000 AND Bugged = 1 AND Upper(RecipeName) LIKE " ..
    --  p_arg .. " ORDER BY RecipeName ASC"

    for r in db:nrows(sql_string) do
        --  highlight_recipe_requirements(make_row.Skill, make_row.RecipeID,
        --      make_row.RecipeName, make_row.Yield,
        --    make_row.Trivial)

        if tonumber(r.Trivial) == 0 or tonumber(r.Trivial) == nil then
            r.Trivial = 15
        end

        local item = {
            RID = r.RecipeID,
            Name = r.RecipeName,
            Trivial = r.Trivial,
            Skill = r.Skill,
            Yield = r.Yield,
            Container = r.Container,
            ID = r.ItemID,
            SkillRequired = r.ReqSkill,
            ReqRace = r.ReqRace
        }

        -- Omit bugged recipes from search results and if there is no race requirement

        if r.Bugged ~= 1 and (r.ReqRace == nil or r.ReqRace == "NA") then
            table.insert(m, item)
        end

        local l_c_race = convert_race(r.ReqRace)

        -- Add race requirement recipes to search results
        if l_c_race == mq.TLO.Me.Race() then table.insert(m, item) end
    end

    return m
end

function tcn_req.dannet_peers()
    print("Reloading DanNet")
    tcn_req.reload_dannet()

    local peer_name
    local local_peers = {}
    for x = 1, mq.TLO.DanNet.PeerCount() do
        peer_name = mq.TLO.DanNet.Peers(x)()

        local l_remote_server = lib.query_dannet(peer_name,
            '"MacroQuest.Server"', 200)
        local l_remote_zone_id = tonumber(
            lib.query_dannet(peer_name, '"Zone.ID"',
                200))
        local l_remote_name = lib.query_dannet(peer_name, 'Me', 200)

        -- Don't add ourselves
        if l_remote_server == mq.TLO.MacroQuest.Server() and l_remote_name ~=
            mq.TLO.Me() and mq.TLO.Zone.ID() == l_remote_zone_id then
            table.insert(local_peers, l_remote_name)
        end
    end

    -- for c = 1, #local_peers do print(local_peers[c]) end
    return local_peers
end

-- look up item name via DB
function tcn_req.item_name_lookup(p_item_id)
    local item_name = lib.return_item_name(p_item_id)
    return item_name
end

function tcn_req.return_counts(p_item_id, p_item_array)
    local add_item_count = 0

    for x = 1, #p_item_array do
        if p_item_id == lib.return_number(p_item_array[x], 2) then
            --      local temp_item_name = lib.return_string(p_item_array[x], 1)
            local temp_item_count = lib.return_number(p_item_array[x], 3)
            --       local temp_zone = lib.return_string(p_item_array[x], 4)
            --       local temp_action = lib.return_string(p_item_array[x], 5)

            -- print("temp id: ", temp_item_id, " last id: ",last_temp_item_id, " count ",temp_item_count)
            --
            add_item_count = add_item_count + temp_item_count
        end
    end

    if add_item_count == 0 then add_item_count = 1 end

    return add_item_count
end

function tcn_req.cleanse_purchased_tools(p_max_array)
    local temp_array = {}

    -- for c = 1, #p_max_array do print(p_max_array[c]) end os.exit()

    for c = 1, #p_max_array do
        local p_item_id = lib.return_number(p_max_array[c], 3)
        local is_purchased = lib.check_purchased_tools(p_item_id)

        if is_purchased == 1 then
            local toon_inv = mq.TLO.FindItemCount(p_item_id)()
            local bank_inv = mq.TLO.FindItemBankCount(p_item_id)()
            if toon_inv + bank_inv == 0 then
                table.insert(temp_array, p_max_array[c])
            end
        end

        if is_purchased ~= 1 then
            table.insert(temp_array, p_max_array[c])
        end
    end

    return temp_array
end

function tcn_req.generate_max_farm_list(p_max_array)
    -- for c = 1, #p_max_array do print("gen max farm ",p_max_array[c]) end

    -- TODO? make a global array and erase it when we click here.. so we don't have to make a sql file?

    rip.create_toon_inventory()

    if GLOBAL_ABORT_FLAG == 1 then return end

    local m = {}

    local gnome_table_recipes = {}

    local temp_table = {}

    local temp_tool_table = {}

    -- local recipe_max_table = {}

    local bank_max_table = {}

    local component_max_table = {}

    local test_e_array = {}

    local recipe_max_table = {}

    -- Check if recipe is bugged
    local bugged_flag = 1

    local prog_calc = GLOBAL_MAX_HOWMANY - GLOBAL_MAX_KNOWN
    local pct_calc = 1 / prog_calc

    local iter_val = #p_max_array

    local gen_start_tick = GLOBAL_MAX_START

    -- Start/End Logic

    if gen_start_tick < 1 then gen_start_tick = 1 end
    if gen_start_tick > iter_val then gen_start_tick = iter_val end

    if GLOBAL_MAX_GEN > #p_max_array then GLOBAL_MAX_GEN = #p_max_array end

    if GLOBAL_MAX_GEN > 0 and GLOBAL_MAX_GEN <= #p_max_array then
        iter_val = GLOBAL_MAX_GEN
    else
        if GLOBAL_MAX_GEN > 0 and GLOBAL_MAX_GEN > #p_max_array then
            iter_val = #p_max_array
        else
            iter_val = #p_max_array
        end
    end

    if GLOBAL_MAX_GEN == 0 then
        iter_val = #p_max_array
    else
        iter_val = gen_start_tick + iter_val
        if iter_val > #p_max_array then iter_val = #p_max_array end
    end

    local start_time = os.time()

    local counter = 0

    for max_iter = gen_start_tick, iter_val do
        -- Count recipes for generate list
        counter = counter + 1
        GLOBAL_MAX_RECIPE_COUNT = counter

        -- for max_iter = 170, 175 do

        PCT_DONE = PCT_DONE + pct_calc

        if GLOBAL_ABORT_FLAG == 1 then break end

        -- Check for bugged recipes and omit
        bugged_flag = 1
        local l_single_recipe_information =
            lib.load_recipe_table(p_max_array[max_iter])
        if l_single_recipe_information[1].RecipeBugged == 1 then
            bugged_flag = 0
        end

        if GLOBAL_ABORT_FLAG == 1 then break end

        if bugged_flag == 1 then
            -- Use this way for trophy quests and other stuff

            -- MAX
            local recipe_data, tool_list, bank_data, component_data,
            e_tool_array = m_crunch.items(p_max_array[max_iter], 1, 0, 0)

            -- for  c = 1 ,#component_data do print("comp: ",component_data[c]) end

            if recipe_data == nil then end

            --  print(#tool_list)
            --  print(#bank_data)
            --  print(#component_data)
            --  print(#e_tool_array)

            for c = 1, #e_tool_array do
                table.insert(test_e_array, e_tool_array[c])
                -- print("\ao", e_tool_array[c])
            end

            -- Add each main crafted tool recipe to crunch later
            for c = 1, #tool_list do
                table.insert(temp_tool_table, tool_list[c])
                -- print("\ao", tool_list[c])
            end

            for c = 1, #bank_data do
                table.insert(bank_max_table, bank_data[c])
                -- print(bank_max_table[c])
            end

            for c = 1, #component_data do
                table.insert(component_max_table, component_data[c])
                -- print(component_data[c])
            end

            -- Add recipe data for race/class determinations
            if recipe_data ~= nil then
                for c = 1, #recipe_data do
                    local rec_max_id = lib.return_number(recipe_data[c], 4)
                    if rec_max_id ~= nil then
                        table.insert(recipe_max_table, rec_max_id)
                        --   print(rec_max_id)
                    end
                end
            end

            --  GLOBAL_MAX_RECIPE_COUNTER = max_iter
            --  GLOBAL_TEXT = "Querying Recipe (" .. max_iter .. ") " ..
            --           l_single_recipe_information[1].RecipeName
        end
    end

    -- Remove recipe ID dups
    recipe_max_table = removeDuplicates(recipe_max_table)

    mq.delay(1)

    local c_farm_table = {}
    local c_vend_table = {}
    local max_depot_table = {}
    local max_sl = {}

    local special_gnome = {}

    -- Add special tools
    if test_e_array ~= nil then
        local myrace = mq.TLO.Me.Race()

        -- Open SQL Memory for tool additions
        local db_test_sort = sqlite3.open(":memory:")
        -- Create Table
        db_test_sort:exec(
            [[DROP TABLE IF EXISTS TTA;CREATE TEMP TABLE TTA (ItemName,RecipeID,ItemCount);]])
        local insert = table.concat(test_e_array, ", ")
        -- Insert Data into SQL Table
        db_test_sort:exec(string.format(
            "INSERT INTO TTA ('ItemName','RecipeID','ItemCount') VALUES %s;",
            insert))
        -- SQL String
        local sql_string =
        "SELECT Distinct ItemName,RecipeID,ItemCount FROM TTA ORDER BY ItemName DESC"

        -- SIM wipe out all components from array to show just tool components
        -- component_max_table = {}

        for r in db_test_sort:nrows(sql_string) do
            --  print("\agData: ", r.ItemName, " ", r.RecipeID, " ", r.ItemCount)

            -- Muramite Needle
            if r.RecipeID == 63767 then
                local c_string = "Bone Chips,13073,4"
                table.insert(component_max_table, c_string)
                c_string = "Muramite Residue,60178,1"
                table.insert(component_max_table, c_string)
            end

            -- Non-Stick Frying Pan
            if r.RecipeID == 97063 then
                local c_string = "Frying Pan Mold,8158,1"
                table.insert(component_max_table, c_string)
            end

            -- Race Specific (Gnome)

            -- Gem Cutter
            if r.RecipeID == 101251 and myrace == "Gnome" then
                local c_string = "Diamond Dust,16884,1"
                table.insert(component_max_table, c_string)
            end

            -- Dihydrous Oxide Glaciator
            if r.RecipeID == 11298 and myrace == "Gnome" then
                local c_string = "Dark Matter,58242,1"
                table.insert(component_max_table, c_string)
                c_string = "Vial of Viscous Mana,10250,1"
                table.insert(component_max_table, c_string)
                c_string = "Ice of Velious,11789,1"
                table.insert(component_max_table, c_string)
                c_string = "Bundle of Super Conductive Wires,9426,1"
                table.insert(component_max_table, c_string)
                c_string = "Rune of Frost,11780,1"
                table.insert(component_max_table, c_string)
                c_string = "Vial of Distilled Mana,10253,1"
                table.insert(component_max_table, c_string)
                c_string = "Brick of Electrified Copper,29539,1"
                table.insert(component_max_table, c_string)
            end

            -- Geerlok Laminating Device
            if r.RecipeID == 35563 and myrace == "Gnome" then
                local c_string = "Belt of Leathery Fungus Flesh,7481,1"
                table.insert(component_max_table, c_string)
                c_string = "Pinion,9178,1"
                table.insert(component_max_table, c_string)
                c_string = "Steel Ball Bearing,9184,1"
                table.insert(component_max_table, c_string)
                c_string = "Steel Casing,9194,1"
                table.insert(component_max_table, c_string)
            end

            -- Corking Device
            if r.RecipeID == 101062 and myrace == "Gnome" then
                local c_string = "Branch of Sylvan Oak,19140,1"
                table.insert(component_max_table, c_string)
            end

            -- Crab Cracker
            if r.RecipeID == 101063 and myrace == "Gnome" then
                local c_string = "Knuckle Joint,29789,1"
                table.insert(component_max_table, c_string)
            end

            -- Wok
            if r.RecipeID == 101838 and myrace == "Gnome" then
                local c_string = "Clockwork Carapace,29761,1"
                table.insert(component_max_table, c_string)
            end

            -- No Gnome Tool Logic
            if r.RecipeID == 101251 and myrace ~= "Gnome" then
                table.insert(special_gnome,
                    "\agNot able to make Tool: \atGem Cutter \agbecause we need the services of a \aoMechanist")
            end
            if r.RecipeID == 11298 and myrace ~= "Gnome" then
                table.insert(special_gnome,
                    "\agNot able to make Tool: \atDihydrous Oxide Glaciator \agbecause we need the services of a \aoMechanist")
            end
            if r.RecipeID == 35563 and myrace ~= "Gnome" then
                table.insert(special_gnome,
                    "\agNot able to make Tool: \atGeerlok Laminating Device \agbecause we need the services of a \aoMechanist")
            end
            if r.RecipeID == 101062 and myrace ~= "Gnome" then
                table.insert(special_gnome,
                    "\agNot able to make Tool: \atCorking Device \agbecause we need the services of a \aoMechanist")
            end
            if r.RecipeID == 101063 and myrace ~= "Gnome" then
                table.insert(special_gnome,
                    "\agNot able to make Tool: \atCrab Cracker \agbecause we need the services of a \aoMechanist")
            end
            if r.RecipeID == 101838 and myrace ~= "Gnome" then
                table.insert(special_gnome,
                    "\agNot able to make Tool: \atWok \agbecause we need the services of a \aoMechanist")
            end
        end

        -- for c = 1, #component_max_table do print(component_max_table[c]) end
        -- os.exit()

        db_test_sort:close()
        -- end SQL Tool Section
    end

    -- print(#recipe_max_table,' rec tab')

    for c = 1, #recipe_max_table do
        local gnome_rec_check = tonumber(recipe_max_table[c])

        local myrace = mq.TLO.Me.Race()

        -- No Gnome Crafted Item Logic (Artisan Mass)
        if gnome_rec_check == 35562 and myrace ~= "Gnome" then
            table.insert(special_gnome,
                "\agNot able to make Recipe: \atBattle Bow Cam \agbecause we need the services of a \aoMechanist")

            table.insert(gnome_table_recipes, 97005)
            -- add in  local c_string = "Bone Chips,13073,4" seach the comp table and look for something in array?
        end
        if gnome_rec_check == 101066 and myrace ~= "Gnome" then
            table.insert(special_gnome,
                "\agNot able to make Recipe: \atE'cian Ice Bow Cam \agbecause we need the services of a \aoMechanist")

            table.insert(gnome_table_recipes, 29535)
        end
        if gnome_rec_check == 101409 and myrace ~= "Gnome" then
            table.insert(special_gnome,
                "\agNot able to make Recipe: \atInnovative Bow Cam \agbecause we need the services of a \aoMechanist")

            table.insert(gnome_table_recipes, 30498)
            table.insert(gnome_table_recipes, 30499)
        end
        if gnome_rec_check == 101413 and myrace ~= "Gnome" then
            table.insert(special_gnome,
                "\agNot able to make Recipe: \atMolten Metal Bow Cam \agbecause we need the services of a \aoMechanist")
            table.insert(gnome_table_recipes, 29534)
        end
        if gnome_rec_check == 101534 and myrace ~= "Gnome" then
            table.insert(special_gnome,
                "\agNot able to make Recipe: \atPlanar Steel Bow Cam \agbecause we need the services of a \aoMechanist")
            table.insert(gnome_table_recipes, 29536)
        end
        if gnome_rec_check == 101837 and myrace ~= "Gnome" then
            table.insert(special_gnome,
                "\agNot able to make Recipe: \atWind Metal Bow Cam \agbecause we need the services of a \aoMechanist")
            table.insert(gnome_table_recipes, 29537)
        end

        -- do print(recipe_max_table[c]," ",c)
    end

    print(msg, "\ap[\aoSorting Mass Data List\ap]")

    local c_data = lib.return_sorted_counts_array(component_max_table)

    -- on abort doesnt do banked list..?

    -- add gh banking checking in here if the checkmark is checked..

    print(msg, "\ap[\aoGenerating Mass Farm List\ap]")

    for c = 1, #c_data do
        local z_id = lib.return_number(c_data[c], 2)
        local z_count = lib.return_number(c_data[c], 3)

        -- Coldain Smithing Hammer
        if z_id == 30140 then z_count = 1 end

        -- Artisan Mass list

        -- Note: the accurate way is to count and squash the amount of recipes and then divide by yield

        -- Discordian Rock
        if z_id == 58028 and z_count > 2 then
            z_count = math.ceil(z_count / 2)
        elseif z_id == 58028 and z_count <= 2 then
            z_count = 1
        end

        -- Taelosian Rock
        if z_id == 58030 and z_count > 2 then
            z_count = math.ceil(z_count / 2)
        elseif z_id == 58030 and z_count <= 2 then
            z_count = 1
        end

        -- Dragon Fin Spikes
        if z_id == 45618 and z_count > 10 then
            z_count = math.ceil(z_count / 10)
        elseif z_id == 45618 and z_count <= 10 then
            z_count = 1
        end

        -- Dragon Wing Bones
        if z_id == 45620 and z_count > 10 then
            z_count = math.ceil(z_count / 10)
        elseif z_id == 45620 and z_count <= 10 then
            z_count = 1
        end

        local myrace = mq.TLO.Me.Race()

        -- Do gnome recipe components mass artisan

        -- print(#gnome_table_recipes,"  testing")

        if #gnome_table_recipes > 0 then
            for d = 1, #gnome_table_recipes do
                if gnome_table_recipes[d] == z_id then
                    -- SHM/ROG needs ---

                    if z_id == 29537 and z_count > 0 then
                        table.insert(special_gnome,
                            "\agTinkered Recipe: \agneeds: (\ay" ..
                            z_count .. "\ag) Chunk of Wind Metal")
                    end

                    if z_id == 29534 and z_count > 0 then
                        table.insert(special_gnome,
                            "\agTinkered Recipe: \agneeds: (\ay" ..
                            z_count .. "\ag) Brick of Molten Ore")
                    end

                    if z_id == 30498 and z_count > 0 then
                        table.insert(special_gnome,
                            "\agTinkered Recipe: \agneeds: (\ay" ..
                            z_count ..
                            "\ag) Innovative Clockwork Bolts")
                    end

                    if z_id == 30499 and z_count > 0 then
                        table.insert(special_gnome,
                            "\agTinkered Recipe: \agneeds: (\ay" ..
                            z_count ..
                            "\ag) Innovative Clockwork Gears")
                    end

                    if z_id == 29535 and z_count > 0 then
                        table.insert(special_gnome,
                            "\agTinkered Recipe: \agneeds: (\ay" ..
                            z_count .. "\ag) Chunk of E'cian Ice")
                    end

                    if z_id == 29536 and z_count > 0 then
                        table.insert(special_gnome,
                            "\agTinkered Recipe: \agneeds: (\ay" ..
                            z_count ..
                            "\ag) Brick of Immaculate Steel")
                    end

                    if z_id == 97005 and z_count > 0 then
                        table.insert(special_gnome,
                            "\agTinkered Recipe: \agneeds: (\ay" ..
                            z_count .. "\ag) Broken Battle Blade")
                    end

                    if z_id == 12564 and z_count > 0 then
                        table.insert(special_gnome,
                            "\agTinkered Recipe: \agneeds: (\ay" ..
                            z_count .. "\ag) Clockwork Grease")
                    end
                end
            end
        end

        -- Notes: Should we add tab?
        -- Notes: Should we just get rid of the recipes and add just comps?
        -- Notes: Should we count recipes and divide by yield and the break down by component?

        local z_name = lib.return_string(c_data[c], 1)

        local l_inv_count = mq.TLO.FindItemCount(z_id)()
        local l_bnk_count = mq.TLO.FindItemBankCount(z_id)()

        local l_tot_count = l_inv_count + l_bnk_count

        -- Full Bank
        if l_bnk_count > 0 and l_inv_count < 1 and l_tot_count >= z_count then
            local c_string = z_name .. "," .. z_id .. "," .. z_count
            table.insert(bank_max_table, c_string)
        end

        -- Partial Bank
        if l_bnk_count > 0 and l_inv_count < 1 and l_tot_count < z_count then
            local c_string = z_name .. "," .. z_id .. "," .. l_bnk_count
            table.insert(bank_max_table, c_string)
        end

        -- Half and Halfish
        if l_bnk_count > 0 and l_inv_count > 0 and l_tot_count >= z_count and
            l_inv_count < z_count then
            local calc = z_count - l_inv_count
            local c_string = z_name .. "," .. z_id .. "," .. calc
            table.insert(bank_max_table, c_string)
        end

        local ven = lib.vendor_has_item(z_id)

        -- Generate Mass Farm Table Data

        if ven == 0 then
            if l_tot_count < z_count then
                -- local farm_action, farm_zone = lib.return_item_source(z_id)
                -- local c_string =
                --  z_name .. "," .. z_id .. "," .. z_count .. "," ..
                --    farm_action .. "," .. farm_zone

                local c_string = z_name .. "," .. z_id .. "," .. z_count

                if mq.TLO.TradeskillDepot.Enabled() then
                    local tsd_count = mq.TLO.TradeskillDepot
                        .FindItemCount(z_id)()

                    local l_d_calc = 0

                    -- Bank and inventory have something and depot has more than both
                    if l_tot_count > 0 and tsd_count > l_tot_count and tsd_count +
                        l_tot_count >= z_count then
                        -- l_d_calc = tsd_count - l_tot_count
                        l_d_calc = z_count - l_tot_count
                    end

                    -- Bank and inventory have something and depot has less than both
                    if l_tot_count > 0 and tsd_count < l_tot_count and tsd_count +
                        l_tot_count >= z_count then
                        l_d_calc = z_count - l_tot_count
                    end

                    -- Bank and inventory have something and depot has an equal amount
                    if l_tot_count > 0 and tsd_count == l_tot_count and
                        tsd_count + l_tot_count >= z_count then
                        l_d_calc = math.ceil(z_count / 2)
                    end

                    -- Nothing in Bank or Inventory, but we meet or exceed needed count
                    if l_tot_count < 1 and tsd_count >= z_count then
                        l_d_calc = z_count
                    end

                    -- Set to max amount we have (artisan)
                    if tsd_count < z_count and tsd_count > 0 then
                        l_d_calc = tsd_count
                        table.insert(c_farm_table, c_string)
                    end

                    if l_d_calc > 0 then
                        local depot_item = {
                            Name = z_name,
                            ID = z_id,
                            Quantity = l_d_calc
                        }

                        --  print("calc ", depot_string)
                        -- Add to artisan depot table
                        table.insert(max_depot_table, depot_item)
                    else
                        -- Add to farm table
                        table.insert(c_farm_table, c_string)
                    end
                else
                    -- No Tradeskill Depot, Add to farm table
                    table.insert(c_farm_table, c_string)
                end
            end
        end

        -- Vendor to Depot (Artisan Mass)
        if mq.TLO.TradeskillDepot.Enabled() and z_count > 0 and ven == 1 then
            local tsd_count = mq.TLO.TradeskillDepot.FindItemCount(z_id)()
            local l_d_calc = 0
            local depot_item = { Name = z_name, ID = z_id, Quantity = l_d_calc }
            -- (Vendor) Nothing in Bank or Inv
            if tsd_count > 0 and l_tot_count < 1 then
                -- Full
                if tsd_count >= z_count then l_d_calc = z_count end
                -- Partial
                if tsd_count < z_count then l_d_calc = tsd_count end
            end
            if tsd_count > 0 and l_tot_count > 0 and tsd_count + l_tot_count >=
                z_count then
                -- (Vendor) Bank and inventory have something and depot has more than both
                if tsd_count > l_tot_count then
                    l_d_calc = z_count - l_tot_count
                end
                -- (Vendor) Bank and inventory have something and depot has less than both
                if tsd_count < l_tot_count then
                    l_d_calc = z_count - l_tot_count
                end
                -- (Vendor) Bank and inventory have something and depot has an equal amount
                if tsd_count == l_tot_count then
                    l_d_calc = math.ceil(z_count / 2)
                end
            end
            if l_d_calc > 0 then
                depot_item = { Name = z_name, ID = z_id, Quantity = l_d_calc }
                table.insert(max_depot_table, depot_item)
            end
        end

        -- Vendor Table to shop
        if ven == 1 then
            local l_vendor_name = nil
            local faction_check = 1

            -- Faction check for vendor
            if z_id == 28021 or z_id == 10425 or z_id == 22564 or z_id == 22098 or
                z_id == 21625 then
                l_vendor_name = lib.return_vendor_name(z_id)
            end

            if l_vendor_name == "Ping Fuzzlecutter" or l_vendor_name ==
                "Nimren Stonecutter" or l_vendor_name == "Talem Tucter" or
                l_vendor_name == "Meg Tucter" then
                faction_check = lib.faction_check(l_vendor_name)
            end

            if faction_check == 0 then
                -- Total Inventory Count < Need Count = Add to farm table
                if l_tot_count < z_count then
                    local c_string = z_name .. "," .. z_id .. "," .. z_count
                    table.insert(c_farm_table, c_string)
                end
            else
                -- No Faction/Faction Good =  Add To Vendor Table
                local c_string = z_name .. "," .. z_id .. "," .. z_count
                table.insert(c_vend_table, c_string)
            end
        end
    end

    print(msg, "\ap[\aoGenerating Mass Shopping List\ap]")

    -- Create Shopping List Section
    local MAX_SHOP_LIST, MAX_ZONE_LIST = {}, {}

    for c = 1, #c_vend_table do
        local vi = lib.return_number(c_vend_table[c], 2)
        local vic = lib.return_number(c_vend_table[c], 3)
        local s_data_string = lib.return_vendor_data(vi, vic)
        table.insert(max_sl, s_data_string)
    end

    table.sort(max_sl)

    MAX_SHOP_LIST = max_sl

    local zone_array = {}

    -- Extract Zone ID
    for c = 1, #max_sl do
        local zone_id = lib.return_number(max_sl[c], 1)
        local zone_name = mq.TLO.Zone(zone_id)()
        table.insert(zone_array, zone_name)
    end

    -- Remove Duplicate Zone ID
    zone_array = removeDuplicates(zone_array)

    table.insert(zone_array, 1, "ALL")

    MAX_ZONE_LIST = zone_array

    MAX_SHOP_LIST = tcn_req.cleanse_purchased_tools(MAX_SHOP_LIST)
    -- End Shopping List Section

    print(msg, "\ap[\aoGenerating Mass Bank Shopping List\ap]")

    local temp_bank_max_table = {}

    for c = 1, #bank_max_table do
        local id = lib.return_number(bank_max_table[c], 2)
        local count = lib.return_number(bank_max_table[c], 3)
        local name = lib.return_string(bank_max_table[c], 1)
        table.insert(temp_bank_max_table, string.format('("%s", %d, %d)',
            name:gsub("'", "''"),
            id, count))
    end

    if bank_max_table[1] ~= nil then
        bank_max_table = lib.SQL_Bank_Array(temp_bank_max_table)
    end

    -- Change 4/3/2022
    GLOBAL_SOILED_ARRAY = c_farm_table

    -- Sort tool table
    table.sort(temp_tool_table)

    local final_tool_table = {}

    local last_tool_id = 0

    -- Remove Duplicate Crafted Tools
    for x = 1, #temp_tool_table do
        -- local tool_id = lib.return_number(tool_array[x],1)
        -- print(tool_id)
        if last_tool_id ~= temp_tool_table[x] then
            -- print("\agTool: ", tool_array[x])
            table.insert(final_tool_table, temp_tool_table[x])
        end
        last_tool_id = temp_tool_table[x]
    end

    GLOBAL_TEXT = "Processing Data..."

    local end_time = os.time()

    local time_calc = end_time - start_time

    if time_calc > 60 then
        local minute_calc = time_calc / 60
        print(msg, "\ap[\aoRecipe Cycle Time: \ap] \ap(\ag",
            math.ceil(minute_calc), "\ap) \aominutes")
        GLOBAL_TEXT = "Recipe Cycle Time... " .. math.ceil(minute_calc) ..
            " Minutes"
    else
        print(msg, "\ap[\aoRecipe Cycle Time: \ap] \ap(\ag",
            end_time - start_time, "\ap) \aoseconds")
        -- Make more precise
        GLOBAL_TEXT = "Recipe Cycle Time... " .. end_time - start_time ..
            " Seconds"
    end

    start_time = os.time()

    table.sort(temp_table)

    local temp_global_array = lib.SQL_Sort_Array(GLOBAL_SOILED_ARRAY)

    GLOBAL_SOILED_ARRAY = temp_global_array
    temp_global_array = {}

    end_time = os.time()

    print(msg, "\ap[\aoList Processing Time: \ap] \ap(\ag",
        end_time - start_time, "\ap) \aoseconds")

    -- Make more precise
    GLOBAL_TEXT = "Processing Time... " .. end_time - start_time .. " Seconds"

    -- Create GH Banking Array
    local gh_banking_array = {}
    for c = 1, #GLOBAL_SOILED_ARRAY do
        local ItemName = lib.return_string(GLOBAL_SOILED_ARRAY[c], 1)
        local ItemCount = lib.return_number(GLOBAL_SOILED_ARRAY[c], 3)
        local LocalItemCount = mq.TLO.FindItemCount('=' .. ItemName)()
        --  if LocalItemCount > 0 then ItemCount = ItemCount - LocalItemCount end
        if ItemCount > 0 then
            local array_item = { Name = ItemName, Count = ItemCount }
            table.insert(gh_banking_array, array_item)
        end
    end

    -- Add to dragon hoard array

    local dh_banking_array = gh_banking_array

    -- for c = 1 ,#gh_banking_array do print(gh_banking_array[c].Name," GH") end
    -- for c = 1 ,#dh_banking_array do print(dh_banking_array[c].Name," DH") end

    if special_gnome[1] ~= nil then
        print(msg,
            "\arIf this is a quest we will not be able to complete it based on:")
        for c = 1, #special_gnome do
            print(msg, "\ay" .. special_gnome[c])
        end
    end

    if MAX_SHOP_LIST[1] == nil then
        print(msg, "\ap[\agNo Items to shop for\ap]")
    end

    -- Convert to ID, NAME, QUANTITY FORMAT
    local converted_shopping_data = convert_shopping_data(MAX_SHOP_LIST)

    -- Convert to ID, NAME, QUANTITY FORMAT
    local converted_farm_data = convert_farm_data(GLOBAL_SOILED_ARRAY)

    gnome_table_recipes = {}

    -- mq.cmd('/lua pause')

    return GLOBAL_SOILED_ARRAY, MAX_SHOP_LIST, MAX_ZONE_LIST, bank_max_table,
        gh_banking_array, dh_banking_array, converted_shopping_data,
        converted_farm_data, max_depot_table
end

-- Query TCN Recipe
function tcn_req.query_recipe(p_id, p_count)
    -- print("\atfeeder testing PID ", p_id, " Count ",p_count)

    local ignore_data = {}
    local farmed_data = {}
    local shopping_data = {}
    local recipe_data = {}
    local bank_data = {}
    local l_depot_data = {}

    local recipe_disposition_data = {}

    local id = lib.return_recipe_item_id(p_id)
    local id_inv = mq.TLO.FindItemCount(id)()
    -- Set make count correctly
    if id_inv < p_count then p_count = p_count - id_inv end

    -- QUERY
    recipe_data, ignore_data, bank_data, farmed_data, shopping_data, l_depot_data =
        crunch.items(p_id, p_count, 0)

    -- SIM No Shopping Data
    -- shopping_data = {}

    -- Disposition Processing
    for c = 1, #recipe_data do
        local rec_id = lib.return_number(recipe_data[c], 4)
        --  local rec_id = recipe_data[c].RecipeID
        -- Change load to better name
        local get_single_recipe_info = lib.load_recipe_table(rec_id)
        local data_elements = {
            RecipeID = get_single_recipe_info[1].RecipeID,
            RecipeName = get_single_recipe_info[1].RecipeName,
            RecipeSkillLevel = get_single_recipe_info[1].SkillRequired,
            RecipeSkillUsed = get_single_recipe_info[1].Skill,
            RecipeRace = convert_race(get_single_recipe_info[1].RaceRequired)
        }

        if get_single_recipe_info[1].RaceRequired ~= nil then
            local converted_race = convert_race(
                get_single_recipe_info[1].RaceRequired)

            -- print(converted_race, " ", mq.TLO.Me.Race(), " ",
            --   get_single_recipe_info[1].RaceRequired)

            -- Not Used, Filtered in Search Results
            if converted_race ~= mq.TLO.Me.Race() and converted_race ~= nil then
                table.insert(recipe_disposition_data, data_elements)
            end
        end

        -- This is auto-converted in function library.load_recipe_table(p_id)
        -- if get_single_recipe_info[1].SkillRequired == nil then get_single_recipe_info[1].SkillRequired = 0 end

        -- Not a special scenario and skill LT reqskill
        if mq.TLO.Me.Skill(get_single_recipe_info[1].Skill)() <
            get_single_recipe_info[1].SkillRequired and
            not (get_single_recipe_info[1].Skill == "Alchemy" or
                get_single_recipe_info[1].Skill == "Make Poison" or
                get_single_recipe_info[1].Skill == "Tinkering") then
            table.insert(recipe_disposition_data, data_elements)
        end

        if get_single_recipe_info[1].Skill == "Alchemy" and mq.TLO.Me.Class() ~=
            "Shaman" then
            table.insert(recipe_disposition_data, data_elements)
        else
            if get_single_recipe_info[1].Skill == "Make Poison" and
                mq.TLO.Me.Class() ~= "Rogue" then
                table.insert(recipe_disposition_data, data_elements)
            else
                if get_single_recipe_info[1].Skill == "Tinkering" and
                    mq.TLO.Me.Race() ~= "Gnome" then
                    table.insert(recipe_disposition_data, data_elements)
                else
                    -- Stop Rogues from trying to make something if skill is too low
                    if mq.TLO.Me.Skill(get_single_recipe_info[1].Skill)() <
                        get_single_recipe_info[1].SkillRequired and
                        mq.TLO.Me.Class() == "Rogue" and
                        get_single_recipe_info[1].Skill == "Make Poison" then
                        table.insert(recipe_disposition_data, data_elements)
                    else
                        -- Stop Shaman from trying to make something if skill is too low
                        if mq.TLO.Me.Skill(get_single_recipe_info[1].Skill)() <
                            get_single_recipe_info[1].SkillRequired and
                            mq.TLO.Me.Class() == "Shaman" and
                            get_single_recipe_info[1].Skill == "Alchemy" then
                            table.insert(recipe_disposition_data, data_elements)
                        else
                            -- Stop Mechanist from trying to make something if skill is too low
                            if mq.TLO.Me
                                .Skill(get_single_recipe_info[1].Skill)() <
                                get_single_recipe_info[1].SkillRequired and
                                mq.TLO.Me.Race() == "Gnome" and
                                get_single_recipe_info[1].Skill == "Tinkering" then
                                table.insert(recipe_disposition_data,
                                    data_elements)
                            else
                                -- Skill Level 0 Checking
                                if mq.TLO.Me.Skill(
                                        get_single_recipe_info[1].Skill)() < 1 then
                                    data_elements = {
                                        RecipeID = get_single_recipe_info[1]
                                            .RecipeID,
                                        RecipeName = get_single_recipe_info[1]
                                            .RecipeName,
                                        RecipeSkillLevel = 999,
                                        RecipeSkillUsed = get_single_recipe_info[1]
                                            .Skill,
                                        RecipeRace = convert_race(
                                            get_single_recipe_info[1]
                                            .RaceRequired)
                                    }
                                    table.insert(recipe_disposition_data,
                                        data_elements)
                                end
                            end
                        end
                    end
                end
            end
        end
    end

    local temp_bank_data = {}
    for c = 1, #bank_data do
        local temp_name = lib.return_string(bank_data[c], 1)
        local temp_id = lib.return_number(bank_data[c], 2)
        local temp_count = lib.return_number(bank_data[c], 3)

        local array_item = {
            Name = temp_name,
            ID = temp_id,
            Quantity = temp_count
        }

        table.insert(temp_bank_data, array_item)
    end

    bank_data = temp_bank_data

    -- if GLOBAL_ABORT_FLAG == 1 then return end

    -- SIM no recipes to make
    -- recipe_data = {}

    -- Convert data to data structure format for sorting recipe data
    local converted_recipe_data = {}
    for c = 1, #recipe_data do
        local RECIPE_ID = lib.return_number(recipe_data[c], 4)
        local RECIPE_NAME = lib.return_string(recipe_data[c], 2)
        local RECIPE_COUNT = lib.return_number(recipe_data[c], 3)
        local ITEM_ID = lib.return_number(recipe_data[c], 1)
        if string.find(RECIPE_NAME, "@") then
            RECIPE_NAME = RECIPE_NAME:gsub('@', ',')
        end
        local item = {
            ID = ITEM_ID,
            RID = RECIPE_ID,
            Name = RECIPE_NAME,
            Quantity = RECIPE_COUNT
        }
        -- print("RID: ",RECIPE_ID," ITEM ID: ",ITEM_ID," Name: ",RECIPE_NAME," Count ",RECIPE_COUNT)
        table.insert(converted_recipe_data, item)
    end

    -- Convert to ID, NAME, QUANTITY FORMAT
    local converted_shopping_data = convert_shopping_data(shopping_data)

    -- Convert to ID, NAME, QUANTITY FORMAT
    local converted_farm_data = convert_farm_data(farmed_data)

    -- for c = 1, #l_depot_data do
    --  print(l_depot_data[c].ID .. "," .. l_depot_data[c].Name .. "," ..
    --           l_depot_data[c].Quantity)
    -- end

    return recipe_disposition_data, farmed_data, shopping_data, recipe_data,
        bank_data, converted_shopping_data, converted_farm_data,
        converted_recipe_data, l_depot_data
end

function tcn_req.db_count()
    local m = lib.return_database_count()
    return m
end

function tcn_req.batch_crafting_routine(p_id, p_make_count)
    -- SIM No shopping/Bank
    -- GLOBAL_BANK_FLAG = 0
    -- GLOBAL_SHOP_FLAG = 0

    local fake_make_count = 0

    local l_recipe_list
    local tool_list
    local farmed_list
    local bank_list
    local l_depot_list = {}

    local random

    if GLOBAL_ABORT_FLAG == 1 then return end

    -- get info from recipe table item = {id,count,etc}

    local l_item_id = lib.return_recipe_item_id(p_id)

    -- Revisit and remove skill up check

    -- Skill Up Check
    if GLOBAL_STANDARD_SKILL_ID ~= 0 and GLOBAL_STANDARD_SKILL_ID ==
        tonumber(p_id) then
        local l_recipe_skill = lib.return_recipe_skill(p_id)
        local l_recipe_trivial = lib.return_recipe_trivial(p_id)
        if mq.TLO.Me.Skill(l_recipe_skill)() >= l_recipe_trivial then
            print(msg, "\ap\ag[Trivial Met\ap] \ap[\aw", l_recipe_skill,
                " Skill\ap] \ap(\ag", l_recipe_trivial, "\ap)")
            GLOBAL_TEXT = "Skill Goal Achieved"
            mq.delay(1)
            mq.cmd('/cleanup')
            GLOBAL_STANDARD_AUTOCONTINUE = 0
            -- shop.return_bank_shopping()
            return
        end
    else
        -- Make count no skill
        if GLOBAL_STANDARD_SKILL_ID == 0 and mq.TLO.FindItemCount(l_item_id)() >=
            tonumber(p_make_count) and p_id == GLOBAL_STANDARD_ID then
            GLOBAL_STANDARD_AUTOCONTINUE = 0
            GLOBAL_TEXT = "Count Achieved"
            -- shop.return_bank_shopping()
            return
        end
    end

    -- Check for class or race requirements

    local result = lib.check_raceclass(p_id)
    if result == 0 then return end

    -- faction  / bugged

    -- print(msg, "\aw[Checking Tool Requirements...]")
    -- result = ToolCraft(p_id)
    -- if result == 0 then return end

    -- Craft Loop
    while true do
        -- Abort process
        if GLOBAL_ABORT_FLAG == 1 then
            mq.cmd('/cleanup')
            mq.delay(1500)
            -- shop.return_bank_shopping()
            break
        end

        p_make_count = tonumber(p_make_count)

        if GLOBAL_STANDARD_AUTOCONTINUE == 1 then
            print(msg, "\ap[\awAuto-Continue MODE:\ap] \ap[\atEngaged\ap]")
            random = math.random(5000, 10000)
            mq.delay(random)
        end

        -- print(msg, "\aw[Checking Recipe...]")

        l_item_id = lib.return_recipe_item_id(p_id)

        if l_item_id == nil then
            print(msg, "\ayError: Invalid Recipe?: ", p_id)
            os.exit()
            -- Change to pause?
        end

        local l_inv = mq.TLO.FindItemCount(l_item_id)()

        -- Change make count for main recipe
        -- print("Feeder Batch: ",GLOBAL_STANDARD_ID, " ",GLOBAL_STANDARD_ID, " ",p_id)
        if GLOBAL_STANDARD_ID ~= 0 and GLOBAL_STANDARD_ID == p_id then
            fake_make_count = p_make_count - l_inv
        end

        if fake_make_count == 0 then
            print("means no global ID, real make count: ", p_make_count)
            os.exit()
        end

        local dummy_array = {}

        -- Crunch recipe (BATCH)
        l_recipe_list, tool_list, bank_list, farmed_list, dummy_array, l_depot_list =
            crunch.items(p_id, fake_make_count, 0)

        -- print(p_make_count, " fake: ",fake_make_count) os.exit()

        -- Added: 2/11/2024 - Check if we can make 1 recipe and if there are farmed items

        -- can we make 1
        local farmed_one = {}

        dummy_array, dummy_array, dummy_array, farmed_one, dummy_array, dummy_array =
            crunch.items(p_id, 1, 0)

        -- do we need both crunch queries, or can we live with just 1??

        -- Batch Routine

        batch_loop_flag = 1

        -- Counts, squash etc..
        if farmed_one[1] ~= nil then
            GLOBAL_TEXT = "Missing Items"
            local return_rec_name = lib.return_recipe_name(p_id)
            print(msg, "\ap[\agRecipe:\ap] \ap[\aw", return_rec_name,
                "\ap] \ap[\agID: \ap(\ag" .. p_id .. "\ap)\ap]")
            print(msg, "\ap[\agMISSING ITEMS\ap]")

            if farmed_one[1] ~= nil then
                for c = 1, #farmed_one do
                    print(msg, "\ap[\awNeed\ap] \ap[\ag",
                        lib.return_string(farmed_one[c], 1), "\ap] \ap(\ag",
                        lib.return_number(farmed_one[c], 3), "\ap)")
                end
            end

            print(msg, "\ap[\agMissing List Completed\ap]")
            batch_loop_flag = 0
            break
        end

        -- Do we have enough to make 1 recipe
        --  local check = lib.single_recipe_check(p_id)

        -- Used to re-crunch in case recipe order got mixed up
        -- l_recipe_list = crunch.items(p_id, p_make_count, 0)

        -- Make table for removing recipes for shopping
        local t_recipe_list = {}
        for c = #l_recipe_list, 1, -1 do
            table.insert(t_recipe_list, l_recipe_list[c])
        end

        -- Craft the list
        for x = #l_recipe_list, 1, -1 do
            if GLOBAL_ABORT_FLAG == 1 then
                mq.cmd('/cleanup')
                mq.delay(1500)
                --   shop.return_bank_shopping()
                break
            end

            -- for swaps to work it needs to know the other sub-recipes in the list
            local clean_string = string.gsub(l_recipe_list[x], "'", '')
            local l_recipe_id = lib.return_number(clean_string, 4)
            local l_make_count = lib.return_number(clean_string, 5)

            -- print(clean_string)

            --  print("what have we got Recipe ID ", l_recipe_id, " Global Recipe ID", GLOBAL_STANDARD_ID)

            -- Make first recipe use quantity not baked into the recipe list
            if GLOBAL_STANDARD_ID ~= 0 and l_recipe_id == GLOBAL_STANDARD_ID then
                l_make_count = p_make_count
                -- print("batch passed make: count: ", p_make_count)
            end

            -- Bank Shopping (BATCH) Flag
            if GLOBAL_BANK_FLAG == 1 then
                -- Bank Shopping
                if bank_list[1] ~= nil then
                    GLOBAL_TEXT = "Bank Shopping"
                    shop.go_bank_shopping(bank_list)
                    local temp_table = {}
                    for c = 1, #bank_list do
                        local bank_id = lib.return_number(bank_list[c], 2)
                        local bank_count = lib.return_number(bank_list[c], 3)
                        if mq.TLO.FindItemCount(bank_id)() < bank_count then
                            table.insert(temp_table, bank_list[c])
                        end
                    end
                    bank_list = temp_table
                    temp_table = {}
                end
            end

            -- Batch Depot Shopping
            if GLOBAL_BANK_FLAG == 1 and mq.TLO.TradeskillDepot.Enabled() and
                l_depot_list[1] ~= nil then
                print(msg, "Depot Shopping")
                GLOBAL_TEXT = "Depot Shopping"

                shop.go_depot_shopping(l_depot_list)
                local temp_table = {}
                for c = 1, #l_depot_list do
                    if mq.TLO.FindItemCount(l_depot_list[c].ID)() <
                        l_depot_list[c].Quantity then
                        table.insert(temp_table, l_depot_list[c])
                    end
                end
                l_depot_list = temp_table
                temp_table = {}
            end

            local shopping_list = shop.create_shopping_list(t_recipe_list)

            -- for c = 1 ,#shopping_list do print(shopping_list[c]) end os.exit()

            -- Auto-shop
            if GLOBAL_SHOP_FLAG == 1 then
                -- Recipes to make
                -- changed to n from l
                if t_recipe_list[1] ~= nil then
                    -- Shopping to be done
                    if shopping_list[1] ~= nil then
                        -- Switch to use bank to make withdrawals
                        -- Platinum Check
                        if GLOBAL_PLATINUM > 0 then
                            if mq.TLO.Me.PlatinumBank() >= GLOBAL_PLATINUM or
                                mq.TLO.Me.PlatinumShared() >= GLOBAL_PLATINUM then
                                local plat_get = GLOBAL_PLATINUM
                                if mq.TLO.Me.Platinum() > 0 then
                                    plat_get = plat_get - mq.TLO.Me.Platinum()
                                end
                                if mq.TLO.Me.Platinum() < GLOBAL_PLATINUM / 2 then
                                    -- Withdraw Platinum From Bank
                                    -- Head To Bank
                                    movement.bank()
                                    -- Grab Platinum
                                    lib.bank_withdrawal(plat_get)
                                end
                            end
                        end
                    end
                end
            end

            if shopping_list[1] ~= nil then
                if GLOBAL_SHOP_FLAG == 1 then
                    -- Use the boat to get out of halas
                    if mq.TLO.Zone.ID() == 29 then
                        movement.leave_halas()

                        mq.cmd('/squelch /travelto poknowledge')
                        while true do
                            if mq.TLO.Zone.ID() == 202 then
                                break
                            end
                            mq.delay(1)
                        end
                    end

                    -- if we are in CR go to 1st floor
                    if mq.TLO.Zone.ID() == 394 then
                        movement.crescent_reach_floor_1()

                        mq.cmd('/squelch /travelto poknowledge')
                        while true do
                            if mq.TLO.Zone.ID() == 202 then
                                break
                            end
                            mq.delay(1)
                        end
                    end

                    if mq.TLO.Zone.ID() == 54 and mq.TLO.Me.Z() > 10 then
                        mq.cmd('/nav locyx -443 92 |log=off')
                        while mq.TLO.Nav.Active() do
                            mq.delay(1000)
                        end
                        mq.cmd('/keypress forward hold')
                        mq.delay(6000)
                        mq.cmd('/keypress forward')
                        mq.delay(2000)

                        mq.cmd('/squelch /travelto poknowledge')
                        while true do
                            if mq.TLO.Zone.ID() == 202 then
                                break
                            end
                            mq.delay(1)
                        end
                    end

                    -- Go shopping
                    shop.go_shopping(shopping_list)
                end
            end

            for c = 1, #shopping_list do
                --   print("standard shopping list: ", shopping_list[c])
            end

            -- Check if we can make a single recipe
            local check = lib.single_recipe_check(l_recipe_id)
            -- doesn't work for swaps :(
            if check == 0 then
                print("\arcan't make (", l_recipe_id,
                    ") notification (out of materials (Ignored Feeder)")
                --  mq.cmd('/lua pause')

                --   break
            end

            if GLOBAL_CRAFTING_ZONE == 1 and mq.TLO.Me.Guild() ~= nil then
                preferred_crafting_zone = 99999

                if mq.TLO.Zone.ID() == 738 or mq.TLO.Zone.ID() == 738 or
                    mq.TLO.Zone.ID() == 751 then
                    -- GLOBAL_TEXT = " "
                else
                    GLOBAL_TEXT = "Heading to Neighborhood Guild Hall"
                end
            else
                preferred_crafting_zone = 202
            end

            -- GLOBAL_REQ_RACE = "Froglok"

            navigate_to_forge(l_recipe_id)

            -- Get recipe info from item = {id,item,skill etc}

            GLOBAL_STANDARD_CRAFTING_RECIPE_NAME =
                lib.return_recipe_name(l_recipe_id)

            -- print(GLOBAL_STANDARD_CRAFTING_RECIPE_NAME," ID: ",l_recipe_id," make:", l_make_count)

            -- lookup container???
            -- move.container???
            -- movement container first..

            lib.trophy_selector(l_recipe_id)

            craft.main(l_recipe_id, l_make_count, 0, 0)
            EXP_FLAG = 0

            -- Remove recipe that we attempted from shopping recipe list
            table.remove(t_recipe_list, 1)
            --    l_recipe_list[x])

            -- remove recipe from new table we made by id?

            GLOBAL_STANDARD_CRAFTING_RECIPE_NAME = nil
            lib.ClearCursor()
            lib.ClearCursor()
            lib.ClearCursor()

            -- Attempt failed - re-calculate?
            if GLOBAL_MAX_FAILED_FLAG == 1 then
                GLOBAL_MAX_FAILED_FLAG = 0
                -- displays last recipe with a failure..
                -- serves no real purpose?
                -- print("Testing Feeder Standard: ", l_recipe_id)
                -- what happens without this?
                -- testing
                --   break
            end
        end

        -- Final recipe, now do checks

        l_item_id = lib.return_recipe_item_id(p_id)
        l_inv = mq.TLO.FindItemCount(l_item_id)()

        -- Skill Up Check (Validated)
        if GLOBAL_STANDARD_SKILL_ID ~= 0 and GLOBAL_STANDARD_SKILL_ID ==
            tonumber(p_id) then
            local l_recipe_skill = lib.return_recipe_skill(p_id)
            local l_recipe_trivial = lib.return_recipe_trivial(p_id)
            -- Skill met
            if mq.TLO.Me.Skill(l_recipe_skill)() >= l_recipe_trivial then
                print(msg, "\ap\ag[Trivial Met\ap] \ap[\aw", l_recipe_skill,
                    " Skill\ap] \ap(\ag", l_recipe_trivial, "\ap)")
                mq.delay(1)
                GLOBAL_STANDARD_AUTOCONTINUE = 0
                -- Sell / Skill achieved
                if mq.TLO.FindItemCount(l_item_id)() > 0 then
                    if GLOBAL_STANDARD_SELL_ID ~= 0 and
                        mq.TLO.FindItem(l_item_id).Value() >
                        GLOBAL_STANDARD_SELL_THRESHOLD then
                        GLOBAL_STANDARD_CRAFTING_STATUS_MSG = "Selling"
                        shop.sell_item_ID_to_vendor(l_item_id, l_inv, 0)
                        GLOBAL_STANDARD_SELL_ID = 0
                    else
                        -- Believe this is handled in TCN_Craft - redundant
                        -- Destroy
                        if GLOBAL_STANDARD_DESTROY_ID ~= 0 then
                            GLOBAL_STANDARD_CRAFTING_STATUS_MSG = "Destroying"
                            lib.DestroyItemID(l_item_id)
                            GLOBAL_STANDARD_DESTROY_ID = 0
                        end
                    end
                end

                mq.cmd('/cleanup')
                mq.delay(3000)

                --   ammo_swap_slot(GLOBAL_AMMO_SLOT)

                lib.swap_ammo_slot_back(GLOBAL_AMMO_SLOT)

                -- Fishing
                lib.return_primary_item()

                -- shop.return_bank_shopping()
                break
            end

            if mq.TLO.FindItemCount(GLOBAL_STANDARD_SELL_ID)() > 0 then
                local check_ts_status = lib.check_ts_status(l_item_id)

                local backpack_free_space =
                    lib.backpack_free_slots(check_ts_status)

                -- Break if inventory < x and sell when we get back to standard crafting routine
                if backpack_free_space < 4 and GLOBAL_STANDARD_SELL_ID ~= 0 and
                    mq.TLO.FindItem(l_item_id).Value() >
                    GLOBAL_STANDARD_SELL_THRESHOLD then
                    GLOBAL_STANDARD_CRAFTING_STATUS_MSG = "Selling"
                    shop.sell_item_ID_to_vendor(l_item_id, l_inv, 0)
                    -- GLOBAL_STANDARD_SELL_ID = 0
                end
            end
        else
            print(msg, "Craft Results:")

            if mq.TLO.FindItemCount(l_item_id)() >= p_make_count and
                GLOBAL_STANDARD_SKILL_ID == 0 then
                --  print(msg, "FEEDER2 We have make count goals")
                print(msg, "\agWanted: ", p_make_count, " Have: ",
                    mq.TLO.FindItemCount(l_item_id)())
                GLOBAL_STANDARD_AUTOCONTINUE = 0
                -- Sell / Count achieved
                if GLOBAL_STANDARD_SELL_ID ~= 0 and
                    mq.TLO.FindItem(l_item_id).Value() >
                    GLOBAL_STANDARD_SELL_THRESHOLD then
                    GLOBAL_STANDARD_CRAFTING_STATUS_MSG = "Selling"
                    shop.sell_item_ID_to_vendor(l_item_id, l_inv, 0)
                    GLOBAL_STANDARD_SELL_ID = 0
                else
                    -- Destroy
                    if GLOBAL_STANDARD_DESTROY_ID ~= 0 then
                        GLOBAL_STANDARD_CRAFTING_STATUS_MSG = "Destroying"
                        lib.DestroyItemID(l_item_id)
                        GLOBAL_STANDARD_DESTROY_ID = 0
                    end
                end
                mq.cmd('/cleanup')

                mq.delay(3000)

                lib.swap_ammo_slot_back(GLOBAL_AMMO_SLOT)

                --     ammo_swap_slot(GLOBAL_AMMO_SLOT)
                --   shop.return_bank_shopping()
                -- Fishing
                lib.return_primary_item()

                break
            else
                -- Conditions Not Met For Count/Skill
                print(msg, "\ayWanted: ", p_make_count, " \agHave: ",
                    mq.TLO.FindItemCount(l_item_id)())

                if mq.TLO.FindItemCount(GLOBAL_STANDARD_SELL_ID)() > 0 then
                    -- Sell / no goal achieved
                    if GLOBAL_STANDARD_SELL_ID ~= 0 and
                        mq.TLO.FindItem(l_item_id).Value() >
                        GLOBAL_STANDARD_SELL_THRESHOLD then
                        GLOBAL_STANDARD_CRAFTING_STATUS_MSG = "Selling"
                        shop.sell_item_ID_to_vendor(l_item_id, l_inv, 0)
                        --   GLOBAL_STANDARD_SELL_ID = 0
                    end
                end

                if GLOBAL_STANDARD_AUTOCONTINUE == 0 then
                    GLOBAL_STANDARD_SELL_ID = 0
                    --  shop.return_bank_shopping()
                    -- turn off sell/destroyskill etc...?
                    lib.swap_ammo_slot_back(GLOBAL_AMMO_SLOT)
                    --   ammo_swap_slot(GLOBAL_AMMO_SLOT)
                    -- Fishing
                    lib.return_primary_item()
                    break
                end
            end
        end

        print(msg, chars)

        -- Will this work for skill ups and stuffs? stop endless skillup????
        -- if outer_break == 1 and
        if GLOBAL_STANDARD_AUTOCONTINUE == 0 then
            --   shop.return_bank_shopping()
            lib.swap_ammo_slot_back(GLOBAL_AMMO_SLOT)
            --   ammo_swap_slot(GLOBAL_AMMO_SLOT)
            -- Fishing
            lib.return_primary_item()
            break
        end
    end

    -- if GLOBAL_STANDARD_AUTOCONTINUE == 0 then shop.return_bank_shopping() end

    return batch_loop_flag
end

----------- Standard Crafting ------
function tcn_req.standard_crafting_routine(p_id, p_make_count)
    -- SIM No shopping/bank
    -- GLOBAL_BANK_FLAG = 0
    -- GLOBAL_SHOP_FLAG = 0

    -- Get inventory and subtract from p_make_count to make fake make count?

    local fake_make_count = 0

    local l_recipe_list
    local shopping_list
    local tool_list
    local farmed_list
    local bank_list
    local l_depot_list

    local random

    if GLOBAL_ABORT_FLAG == 1 then return end

    -- get info from recipe table item = {id,count,etc}

    local l_item_id = lib.return_recipe_item_id(p_id)

    -- Skill Up Check
    if GLOBAL_STANDARD_SKILL_ID ~= 0 and GLOBAL_STANDARD_SKILL_ID ==
        tonumber(p_id) then
        local l_recipe_skill = lib.return_recipe_skill(p_id)
        local l_recipe_trivial = lib.return_recipe_trivial(p_id)
        if mq.TLO.Me.Skill(l_recipe_skill)() >= l_recipe_trivial then
            print(msg, "\ap\ag[Trivial Met\ap] \ap[\aw", l_recipe_skill,
                " Skill\ap] \ap(\ag", l_recipe_trivial, "\ap)")
            GLOBAL_TEXT = "Skill Goal Achieved"
            mq.delay(1)
            mq.cmd('/cleanup')
            GLOBAL_STANDARD_AUTOCONTINUE = 0
            shop.return_bank_shopping()
            shop.return_depot()
            return
        end
    else
        -- Make count no skill
        if GLOBAL_STANDARD_SKILL_ID == 0 and mq.TLO.FindItemCount(l_item_id)() >=
            tonumber(p_make_count) and p_id == GLOBAL_STANDARD_ID then
            GLOBAL_STANDARD_AUTOCONTINUE = 0
            GLOBAL_TEXT = "Count Achieved"
            shop.return_bank_shopping()
            shop.return_depot()
            return
        end
    end

    -- Check for class or race requirements

    local result = lib.check_raceclass(p_id)
    if result == 0 then return end

    -- faction  / bugged

    -- Craft Loop
    while true do
        -- Abort process
        if GLOBAL_ABORT_FLAG == 1 then
            mq.cmd('/cleanup')
            mq.delay(1500)
            shop.return_bank_shopping()
            shop.return_depot()
            break
        end

        p_make_count = tonumber(p_make_count)

        -- Auto-continue sell..
        if mq.TLO.FindItemCount(GLOBAL_STANDARD_SELL_ID)() > 0 and
            mq.TLO.FindItem(GLOBAL_STANDARD_SELL_ID).Value() >
            GLOBAL_STANDARD_SELL_THRESHOLD * 1000 and GLOBAL_STANDARD_SELL_ID >
            0 then
            shop.sell_item_ID_to_vendor(GLOBAL_STANDARD_SELL_ID, mq.TLO
                .FindItemCount(
                    GLOBAL_STANDARD_SELL_ID)(), 0)
        end

        -- Auto-continue destroy
        if mq.TLO.FindItemCount(GLOBAL_STANDARD_DESTROY_ID)() > 0 and
            GLOBAL_STANDARD_DESTROY_ID > 0 then
            lib.DestroyItemID(GLOBAL_STANDARD_DESTROY_ID)
        end

        if GLOBAL_STANDARD_AUTOCONTINUE == 1 then
            print(msg, "\ap[\awAuto-Continue MODE:\ap] \ap[\atEngaged\ap]")
            random = math.random(5000, 10000)
            mq.delay(random)
        end

        -- print(msg, "\aw[Checking Recipe...]")

        l_item_id = lib.return_recipe_item_id(p_id)

        if l_item_id == nil then
            print(msg, "\ayError: Invalid Recipe?: ", p_id)
            os.exit()
            -- Change to pause?
        end

        local l_inv = mq.TLO.FindItemCount(l_item_id)()

        -- print("Feeder Standard GLOBAL ID: ",GLOBAL_STANDARD_ID, " ",GLOBAL_STANDARD_ID, " ",p_id)

        -- Change make count for main recipe
        if GLOBAL_STANDARD_ID ~= 0 and GLOBAL_STANDARD_ID == p_id then
            fake_make_count = p_make_count - l_inv
        end

        -- Crunch recipe (STANDARD)
        l_recipe_list, tool_list, bank_list, farmed_list, shopping_list, l_depot_list =
            crunch.items(p_id, fake_make_count, 0)

        -- if we reverse it here from cruncher then we can have the order in display from bottom to top..
        -- but would have to check other crafting routines that crunch to do proper order.
        -- for c = #l_recipe_list,1,-1 do print(l_recipe_list[c]) end
        -- os.exit()

        -- SIM
        -- Erase farmed list
        -- farmed_list = {}

        if GLOBAL_CULT_TESTING == 1 then farmed_list = {} end

        if farmed_list[1] ~= nil then
            GLOBAL_TEXT = "Missing Items"
            local return_rec_name = lib.return_recipe_name(p_id)
            print(msg, "\ap[\agRecipe:\ap] \ap[\aw", return_rec_name,
                "\ap] \ap[\agID: \ap(\ag" .. p_id .. "\ap)\ap]")
            print(msg, "\ap[\agMISSING ITEMS\ap]")

            if farmed_list[1] ~= nil then
                for c = 1, #farmed_list do
                    print(msg, "\ap[\awNeed\ap] \ap[\ag",
                        lib.return_string(farmed_list[c], 1), "\ap] \ap(\ag",
                        lib.return_number(farmed_list[c], 3), "\ap)")
                end
            end

            print(msg, "\ap[\agMissing List Completed\ap]")
            break
        end

        -- Make table for removing recipes for shopping
        local t_recipe_list = {}
        for c = #l_recipe_list, 1, -1 do
            table.insert(t_recipe_list, l_recipe_list[c])
        end

        -- Craft the list
        for x = #l_recipe_list, 1, -1 do
            if GLOBAL_ABORT_FLAG == 1 then
                mq.cmd('/cleanup')
                mq.delay(1500)
                shop.return_bank_shopping()
                shop.return_depot()
                break
            end

            -- for swaps to work it needs to know the other sub-recipes in the list
            local clean_string = string.gsub(l_recipe_list[x], "'", '')
            local l_recipe_id = lib.return_number(clean_string, 4)
            local l_make_count = lib.return_number(clean_string, 5)

            -- print(clean_string)

            --  print("what have we got Recipe ID ", l_recipe_id, " Global Recipe ID", GLOBAL_STANDARD_ID)

            -- Make first recipe use quantity not baked into the recipe list
            if GLOBAL_STANDARD_ID ~= 0 and l_recipe_id == GLOBAL_STANDARD_ID then
                l_make_count = p_make_count
                --  print("passed make: count: ", p_make_count)
            end

            -- Bank Shopping (STANDARD) Flag
            if GLOBAL_BANK_FLAG == 1 then
                -- Bank Shopping
                if bank_list[1] ~= nil then
                    GLOBAL_TEXT = "Bank Shopping"
                    shop.go_bank_shopping(bank_list)
                    local temp_table = {}
                    for c = 1, #bank_list do
                        local bank_id = lib.return_number(bank_list[c], 2)
                        local bank_count = lib.return_number(bank_list[c], 3)
                        if mq.TLO.FindItemCount(bank_id)() < bank_count then
                            table.insert(temp_table, bank_list[c])
                        end
                    end
                    bank_list = temp_table
                    temp_table = {}
                end
            end

            -- Depot Shopping (STANDARD)
            if GLOBAL_BANK_FLAG == 1 and mq.TLO.TradeskillDepot.Enabled() and
                l_depot_list[1] ~= nil then
                GLOBAL_TEXT = "Depot Shopping"

                shop.go_depot_shopping(l_depot_list)
                local temp_table = {}
                for c = 1, #l_depot_list do
                    if mq.TLO.FindItemCount(l_depot_list[c].ID)() <
                        l_depot_list[c].Quantity then
                        table.insert(temp_table, l_depot_list[c])
                    end
                end
                l_depot_list = temp_table
                temp_table = {}
            end

            -- Create shopping list after every attempt
            shopping_list = shop.create_shopping_list(t_recipe_list)

            -- Auto-shop
            if GLOBAL_SHOP_FLAG == 1 then
                -- Recipes to make
                -- changed to n from l
                if t_recipe_list[1] ~= nil then
                    -- Shopping to be done
                    if shopping_list[1] ~= nil then
                        -- Switch to use bank to make withdrawals
                        -- Platinum Check

                        if GLOBAL_PLATINUM > 0 then
                            if mq.TLO.Me.PlatinumBank() >= GLOBAL_PLATINUM or
                                mq.TLO.Me.PlatinumShared() >= GLOBAL_PLATINUM then
                                local plat_get = GLOBAL_PLATINUM
                                if mq.TLO.Me.Platinum() > 0 then
                                    plat_get = plat_get - mq.TLO.Me.Platinum()
                                end
                                if mq.TLO.Me.Platinum() < GLOBAL_PLATINUM / 2 then
                                    -- Withdraw Platinum From Bank
                                    -- Head To Bank
                                    movement.bank()
                                    -- Grab Platinum
                                    lib.bank_withdrawal(plat_get)
                                end
                            end
                        end
                    end
                end
            end

            local shopping_check_result = recipe_comp_check(shopping_list)

            -- Does not affect multiplier and stops NAV to POK if we have the amount to make
            if shopping_check_result == 0 then shopping_list = {} end

            if shopping_list[1] ~= nil then
                if GLOBAL_SHOP_FLAG == 1 then
                    -- Use the boat to get out of halas
                    if mq.TLO.Zone.ID() == 29 then
                        movement.leave_halas()

                        mq.cmd('/squelch /travelto poknowledge')
                        while true do
                            if mq.TLO.Zone.ID() == 202 then
                                break
                            end
                            mq.delay(1)
                        end
                    end

                    -- if we are in CR go to 1st floor
                    if mq.TLO.Zone.ID() == 394 then
                        movement.crescent_reach_floor_1()
                        mq.cmd('/squelch /travelto poknowledge')
                        while true do
                            if mq.TLO.Zone.ID() == 202 then
                                break
                            end
                            mq.delay(1)
                        end
                    end

                    if mq.TLO.Zone.ID() == 54 and mq.TLO.Me.Z() > 10 then
                        mq.cmd('/nav locyx -443 92 |log=off')
                        while mq.TLO.Nav.Active() do
                            mq.delay(1000)
                        end
                        mq.cmd('/keypress forward hold')
                        mq.delay(6000)
                        mq.cmd('/keypress forward')
                        mq.delay(2000)

                        mq.cmd('/squelch /travelto poknowledge')
                        while true do
                            if mq.TLO.Zone.ID() == 202 then
                                break
                            end
                            mq.delay(1)
                        end
                    end

                    -- Go shopping
                    shop.go_shopping(shopping_list)
                end
            end

            -- Where to put this because it is pre-checked before getting here??? REVISIT

            -- Check if we can make a single recipe
            local check = lib.single_recipe_check(l_recipe_id)

            -- SIM
            -- Simulate we can make the recipe
            -- check = 1

            if GLOBAL_CULT_TESTING == 1 then check = 1 end

            -- doesn't work for swaps :(
            if check == 0 then
                print("\arcan't make ", l_recipe_id,
                    " notification (out of materials")
                --  mq.cmd('/lua pause')
                break
            end

            if GLOBAL_CRAFTING_ZONE == 1 and mq.TLO.Me.Guild() ~= nil then
                preferred_crafting_zone = 99999
                if mq.TLO.Zone.ID() == 738 or mq.TLO.Zone.ID() == 738 or
                    mq.TLO.Zone.ID() == 751 then
                    -- GLOBAL_TEXT = " "
                else
                    GLOBAL_TEXT = "Heading to Neighborhood Guild Hall"
                end
            else
                preferred_crafting_zone = 202
            end

            -- GLOBAL_REQ_RACE = "Froglok"

            navigate_to_forge(l_recipe_id)

            -- Get recipe info from item = {id,item,skill etc}

            GLOBAL_STANDARD_CRAFTING_RECIPE_NAME =
                lib.return_recipe_name(l_recipe_id)

            -- print(GLOBAL_STANDARD_CRAFTING_RECIPE_NAME," ID: ",l_recipe_id," make:", l_make_count)

            lib.trophy_selector(l_recipe_id)

            craft.main(l_recipe_id, l_make_count, 0, 0)

            EXP_FLAG = 0

            -- Remove recipe that we attempted from shopping recipe list
            table.remove(t_recipe_list, 1)
            --    l_recipe_list[x])

            -- remove recipe from new table we made by id?

            GLOBAL_STANDARD_CRAFTING_RECIPE_NAME = nil
            lib.ClearCursor()
            lib.ClearCursor()
            lib.ClearCursor()

            -- Attempt failed - re-calculate?
            if GLOBAL_MAX_FAILED_FLAG == 1 then
                GLOBAL_MAX_FAILED_FLAG = 0
                -- displays last recipe with a failure..
                -- serves no real purpose?
                -- print("Testing Feeder Standard: ", l_recipe_id)
                -- what happens without this?
                -- testing
                --   break
            end
        end

        -- Final recipe, now do checks

        l_item_id = lib.return_recipe_item_id(p_id)
        l_inv = mq.TLO.FindItemCount(l_item_id)()

        -- Skill Up Check (Validated)
        if GLOBAL_STANDARD_SKILL_ID ~= 0 and GLOBAL_STANDARD_SKILL_ID ==
            tonumber(p_id) then
            local l_recipe_skill = lib.return_recipe_skill(p_id)
            local l_recipe_trivial = lib.return_recipe_trivial(p_id)
            -- Skill met
            if mq.TLO.Me.Skill(l_recipe_skill)() >= l_recipe_trivial then
                print(msg, "\ap\ag[Trivial Met\ap] \ap[\aw", l_recipe_skill,
                    " Skill\ap] \ap(\ag", l_recipe_trivial, "\ap)")
                mq.delay(1)
                GLOBAL_STANDARD_AUTOCONTINUE = 0
                -- Sell / Skill achieved
                if mq.TLO.FindItemCount(l_item_id)() > 0 then
                    if GLOBAL_STANDARD_SELL_ID ~= 0 and
                        mq.TLO.FindItem(l_item_id).Value() >
                        GLOBAL_STANDARD_SELL_THRESHOLD then
                        GLOBAL_STANDARD_CRAFTING_STATUS_MSG = "Selling"
                        shop.sell_item_ID_to_vendor(l_item_id, l_inv, 0)
                        GLOBAL_STANDARD_SELL_ID = 0
                    else
                        -- Believe this is handled in TCN_Craft - redundant
                        -- Destroy
                        if GLOBAL_STANDARD_DESTROY_ID ~= 0 then
                            GLOBAL_STANDARD_CRAFTING_STATUS_MSG = "Destroying"
                            lib.DestroyItemID(l_item_id)
                            GLOBAL_STANDARD_DESTROY_ID = 0
                        end
                    end
                end

                mq.cmd('/cleanup')
                mq.delay(2500)

                lib.swap_ammo_slot_back(GLOBAL_AMMO_SLOT)
                --   ammo_swap_slot(GLOBAL_AMMO_SLOT)
                -- Fishing
                lib.return_primary_item()

                shop.return_bank_shopping()
                shop.return_depot()

                break
            end

            -- bam
            if mq.TLO.FindItemCount(GLOBAL_STANDARD_SELL_ID)() > 0 then
                -- get type and stack here  l_item_id

                local check_ts_status = lib.check_ts_status(l_item_id)

                local backpack_free_space =
                    lib.backpack_free_slots(check_ts_status)
                -- Break if inventory < x and sell when we get back to standard crafting routine
                if backpack_free_space < 4 and GLOBAL_STANDARD_SELL_ID ~= 0 and
                    mq.TLO.FindItem(l_item_id).Value() >
                    GLOBAL_STANDARD_SELL_THRESHOLD then
                    GLOBAL_STANDARD_CRAFTING_STATUS_MSG = "Selling"
                    shop.sell_item_ID_to_vendor(l_item_id, l_inv, 0)
                    -- GLOBAL_STANDARD_SELL_ID = 0
                end
            end
        else
            print(msg, "Craft Results:")

            if mq.TLO.FindItemCount(l_item_id)() >= p_make_count and
                GLOBAL_STANDARD_SKILL_ID == 0 then
                --  print(msg, "FEEDER2 We have make count goals")
                print(msg, "\agWanted: ", p_make_count, " Have: ",
                    mq.TLO.FindItemCount(l_item_id)())
                GLOBAL_STANDARD_AUTOCONTINUE = 0
                -- Sell / Count achieved
                if GLOBAL_STANDARD_SELL_ID ~= 0 and
                    mq.TLO.FindItem(l_item_id).Value() >
                    GLOBAL_STANDARD_SELL_THRESHOLD then
                    GLOBAL_STANDARD_CRAFTING_STATUS_MSG = "Selling"
                    shop.sell_item_ID_to_vendor(l_item_id, l_inv, 0)
                    GLOBAL_STANDARD_SELL_ID = 0
                else
                    -- Destroy
                    if GLOBAL_STANDARD_DESTROY_ID ~= 0 then
                        GLOBAL_STANDARD_CRAFTING_STATUS_MSG = "Destroying"
                        lib.DestroyItemID(l_item_id)
                        GLOBAL_STANDARD_DESTROY_ID = 0
                    end
                end
                mq.cmd('/cleanup')
                mq.delay(2500)

                -- print(GLOBAL_AMMO_SLOT, " global ammo slot")
                --    ammo_swap_slot(GLOBAL_AMMO_SLOT)

                lib.swap_ammo_slot_back(GLOBAL_AMMO_SLOT)

                -- Fishing
                --  print(GLOBAL_PRIMARY_SLOT, " global primary slot")
                lib.return_primary_item()

                shop.return_bank_shopping()

                shop.return_depot()

                break
            else
                -- Conditions Not Met For Count/Skill
                print(msg, "\ayWanted: ", p_make_count, " \agHave: ",
                    mq.TLO.FindItemCount(l_item_id)())

                if mq.TLO.FindItemCount(GLOBAL_STANDARD_SELL_ID)() > 0 then
                    -- Sell / no goal achieved
                    if GLOBAL_STANDARD_SELL_ID ~= 0 and
                        mq.TLO.FindItem(l_item_id).Value() >
                        GLOBAL_STANDARD_SELL_THRESHOLD then
                        GLOBAL_STANDARD_CRAFTING_STATUS_MSG = "Selling"
                        shop.sell_item_ID_to_vendor(l_item_id, l_inv, 0)
                        --   GLOBAL_STANDARD_SELL_ID = 0
                    end
                end

                if GLOBAL_STANDARD_AUTOCONTINUE == 0 then
                    GLOBAL_STANDARD_SELL_ID = 0

                    -- turn off sell/destroyskill etc...?
                    --     ammo_swap_slot(GLOBAL_AMMO_SLOT)

                    -- print(GLOBAL_AMMO_SLOT)
                    lib.swap_ammo_slot_back(GLOBAL_AMMO_SLOT)
                    -- Fishing
                    lib.return_primary_item()

                    shop.return_bank_shopping()

                    shop.return_depot()
                    break
                end
            end
        end

        print(msg, chars)

        -- Will this work for skill ups and stuffs? stop endless skillup????
        -- if outer_break == 1 and
        if GLOBAL_STANDARD_AUTOCONTINUE == 0 then
            lib.swap_ammo_slot_back(GLOBAL_AMMO_SLOT)
            --     ammo_swap_slot(GLOBAL_AMMO_SLOT)
            -- Fishing
            lib.return_primary_item()

            shop.return_bank_shopping()

            shop.return_depot()

            break
        end
    end

    -- Sell after a run
    if mq.TLO.FindItemCount(GLOBAL_STANDARD_SELL_ID)() > 0 and
        mq.TLO.FindItem(GLOBAL_STANDARD_SELL_ID).Value() >
        GLOBAL_STANDARD_SELL_THRESHOLD * 1000 and GLOBAL_STANDARD_SELL_ID > 0 then
        shop.sell_item_ID_to_vendor(GLOBAL_STANDARD_SELL_ID, mq.TLO
            .FindItemCount(GLOBAL_STANDARD_SELL_ID)(),
            0)
    end

    -- Destroy after a run
    if mq.TLO.FindItemCount(GLOBAL_STANDARD_DESTROY_ID)() > 0 and
        GLOBAL_STANDARD_DESTROY_ID > 0 then
        lib.DestroyItemID(GLOBAL_STANDARD_DESTROY_ID)
    end

    if GLOBAL_STANDARD_AUTOCONTINUE == 0 then
        lib.swap_ammo_slot_back(GLOBAL_AMMO_SLOT)
        --   ammo_swap_slot(GLOBAL_AMMO_SLOT)
        -- Fishing
        lib.return_primary_item()
        --  shop.return_depot()

        shop.return_bank_shopping()
    end

    return
end

-- Standard Crafting END--

------------FULL MAX CRAFTING------------
function tcn_req.full_max_crafting_routine(p_id)
    if GLOBAL_ABORT_FLAG == 1 then return end
    -- p_id = 12066
    -- rotgut rum

    -- returns out of loop for containers, will this work?

    local keep_going = 1

    local fail_count = 0

    while keep_going == 1 do
        local what_skill = lib.return_recipe_skill(p_id)
        local goal_set = 350
        if what_skill == "Fishing" then goal_set = 250 end
        if GLOBAL_THREEFITTY and mq.TLO.Me.Skill(what_skill)() >= goal_set then
            keep_going = 0
            break
        end

        -- get skill we are using, check if it is above 349, and also have a checkbox?

        -- User sets recipes to skip in prize.db with flag 1 for on
        local skip_recipe_flag = lib.return_max_skip_flag(p_id)

        -- User sets flag to 1 to skip recipe in DB
        if skip_recipe_flag == 1 then
            GLOBAL_TEXT = "Skipping Recipe Per User Configuration"
            return
        end

        local l_recipe_item_id = lib.return_recipe_item_id(p_id)
        local toolcheck_status = lib.toolcheck(p_id)

        -- Ignores recipe if the tool is in inventory/bank
        -- Revisit for proper tool counts
        if toolcheck_status == 1 then
            local in_inv = mq.TLO.FindItemCount(l_recipe_item_id)()
            local in_bank = mq.TLO.FindItemBankCount(l_recipe_item_id)()
            if (in_inv > 0 or in_bank > 0) and toolcheck_status == 1 then
                -- GLOBAL_TEXT ="We have the tool already"
                return
            end
        end

        -- Revisit for jars

        local chk_portables = {
            "Coffin Poison Bottle", "Reinforced Jeweler's Kit", "Glaze Mortar",
            "Mystical Furnace of Ro", "Druzzil's Mystical Sewing Kit",
            "Portable Drink Barrel", "Sacred Urn", "Guktan Sewing Kit",
            "Erudite Sewing Kit", "Teir`Dal Sewing Kit",
            "White Rose Assembly Kit", "Justice Plate Assembly Kit",
            "Northern Wolf Plate Assembly Kit", "Wind Spirits Assembly Kit",
            "Curing Kit", "Ogre Sewing Kit", "Feir`Dal Sewing Kit",
            "Crystalwing Sewing Kit", "Northman Sewing Kit",
            "Shar Vahl Sewing Kit", "Vale Sewing Kit", "Clockwork Sewing Kit",
            "Iksar Sewing Kit", "Troll Sewing Kit", "Half Elf Sewing Kit",
            "Antonican Sewing Kit", "Gnomish Recharging Kit",
            "Koada`Dal Sewing Kit", "Small Clay Jar", "Medium Clay Jar"
        }

        local con_name = lib.return_container_name(p_id)

        local have_portable = 1

        -- if have portable then dont return eh -- in bank or inv then just continue

        -- Will need to find out what is missing, but no need if we don't have the container
        -- Should break out not return...
        for c = 1, #chk_portables do
            if chk_portables[c] == con_name then
                local in_inv = mq.TLO.FindItemCount(con_name)()
                local in_bank = mq.TLO.FindItemBankCount(con_name)()

                if in_inv > 0 or in_bank > 0 then
                    -- do nothing
                else
                    local l_rec_name = lib.return_recipe_name(p_id)

                    GLOBAL_TEXT = " Unable to make " .. l_rec_name ..
                        " Missing " .. con_name
                    print(msg, "\atWe don't have ", con_name,
                        " in bank or inventory")
                    mq.delay(1500)
                    -- mq.cmd('/lua pause')
                    return
                end
            end
        end

        -- Set Recipe ID for MAX
        GLOBAL_MAX_RECIPE_ID = p_id
        -- Set Item ID for MAX
        GLOBAL_MAX_ITEM_ID = l_recipe_item_id

        -- if flag
        if GLOBAL_MAX_DESTROY_FLAG == 1 then
            GLOBAL_MAX_DESTROY_ID = l_recipe_item_id
        else
            GLOBAL_MAX_DESTROY_ID = 0
        end

        if GLOBAL_MAX_SELL_FLAG == 1 then
            GLOBAL_MAX_SELL_ID = l_recipe_item_id
        end

        -- tool check
        -- if it is tool and we have it already then just return for now

        -- Return if we have item already (Testing)
        -- local l_inv_count = mq.TLO.FindItemCount(l_recipe_item_id)()
        -- if l_inv_count > 0 then return end

        -- Generate recipe list (FULL MAX)
        local l_recipe_list, tools, bank_list, farmed_list, shopping_list,
        l_depot_list = crunch.items(p_id, 1, 0)

        -- Skill and Race/Class checking -- need to add cultural and enchanter stuff
        local l_rec_name
        local l_skill_result
        local l_skill_level_result
        local l_recipe_skill_level
        local l_recipe_skill

        -- Check skill level and race/class/bugged requirements all in one :)
        for recipe_iter = 1, #l_recipe_list do
            local rec_id = lib.return_number(l_recipe_list[recipe_iter], 4)

            -- change load to better name
            local get_single_recipe_info = lib.load_recipe_table(rec_id)

            local data_elements = {
                RecipeID = get_single_recipe_info[1].RecipeID,
                RecipeName = get_single_recipe_info[1].RecipeName,
                RecipeSkillLevel = get_single_recipe_info[1].SkillRequired,
                RecipeSkillUsed = get_single_recipe_info[1].Skill
            }

            if mq.TLO.Me.Skill(get_single_recipe_info[1].Skill)() <
                get_single_recipe_info[1].SkillRequired and
                not (get_single_recipe_info[1].Skill == "Alchemy" or
                    get_single_recipe_info[1].Skill == "Make Poison" or
                    get_single_recipe_info[1].Skill == "Tinkering") then
                --    table.insert(l_max_rn_disposition_data, data_elements)
            end

            if get_single_recipe_info[1].Skill == "Alchemy" and
                mq.TLO.Me.Class() ~= "Shaman" then
                --  table.insert(l_max_rn_disposition_data, data_elements)
            end
            if get_single_recipe_info[1].Skill == "Make Poison" and
                mq.TLO.Me.Class() ~= "Rogue" then
                --    table.insert(l_max_rn_disposition_data, data_elements)
            end
            if get_single_recipe_info[1].Skill == "Tinkering" and
                mq.TLO.Me.Race() ~= "Gnome" then
                --     table.insert(l_max_rn_disposition_data, data_elements)
            end

            -- Erase afterwards

            if GLOBAL_ABORT_FLAG == 1 then break end

            local l_check_recipe_id = lib.return_number(
                l_recipe_list[recipe_iter], 4)

            l_rec_name = lib.return_recipe_name(p_id)
            l_recipe_skill_level = lib.return_recipe_skill_level(
                l_check_recipe_id)
            l_recipe_skill = lib.return_recipe_skill(l_check_recipe_id)
            local l_my_skill = mq.TLO.Me.Skill(l_recipe_skill)()
            -- print ("testing ",l_recipe_skill_level, " ",l_recipe_skill," my skill level ",l_my_skill)
            -- Check Skill Level
            if l_recipe_skill_level > l_my_skill then
                l_skill_level_result = 0
                break
            end

            -- Check if gnome , rogue, shaman needed
            l_skill_result = lib.special_conditions(l_check_recipe_id)

            --  print (l_check_recipe_id)
            --  print(msg," feeder testing ", l_skill_result)

            if l_skill_result == 0 then break end
        end

        -- faction check is per component, not recipe

        -- faction check?
        -- race check

        l_rec_name = lib.return_recipe_name(p_id)

        if l_skill_result == 0 or l_skill_level_result == 0 then
            --  print(msg, "\ap[\ayUnable to make\ap] \ap[\aw", l_rec_name, "\ap] ",
            --       "\agID: \aw", p_id)
            GLOBAL_TEXT = "Unable to make: " .. l_rec_name
            return
        end

        if GLOBAL_ABORT_FLAG == 1 then return end

        -- farmed missing -- here

        -- for c = 1 ,#farmed_list do print(farmed_list[c])end

        if farmed_list[1] ~= nil then
            -- print(msg, "\ap[\ayUnable to make\ap] \ap[\aw", l_rec_name, "\ap] ",
            --       "\agID: \aw", p_id)
            GLOBAL_TEXT = "Unable to make: " .. l_rec_name
            if farmed_list[1] ~= nil then keep_going = 0 end
            return
        end

        -- keeps track of attempts not used currently
        recipe_attempts = recipe_attempts + 1

        -- local result = ToolCraft(p_id)
        -- if result == 0 then
        --  print "unable to make tool or reasons"
        --  return
        -- end

        if GLOBAL_ABORT_FLAG == 1 then return end

        -- Full Max

        -- Generate recipe list (again, just in case)
        --  l_recipe_list, tools, bank_list, farmed_list = crunch.items(
        --                                                           p_id, 1, 0)
        -- Welcome to EverCraft

        print(msg, "\ap[\atAttempting\ap] \ap[\aw", l_rec_name,
            "\ap] \ap[\agID: \aw(\ag" .. p_id, "\aw)\ap]")
        GLOBAL_TEXT = "Attempting: " .. l_rec_name
        GLOBAL_MAX_RECIPE = l_rec_name

        -- Bank List Checking Full Max
        local blc = 1
        if blc == 1 then
            -- for c = 1, #bank_list do print(bank_list[c]) end
            --  print("bank array size: ",#bank_list)

            if bank_list[1] ~= nil then
                shop.go_bank_shopping(bank_list)
            end
            bank_list = {}
        end

        -- Full Max Depot Shopping
        if blc == 1 and mq.TLO.TradeskillDepot.Enabled() then
            -- for c = 1, #bank_list do print(bank_list[c]) end
            if l_depot_list[1] ~= nil then
                shop.go_depot_shopping(l_depot_list)
            end
            l_depot_list = {}
        end

        -- l_depot_list[c].Quantity

        -- Full Max

        -- Create shopping list
        --  local shopping_list = shop.create_shopping_list(l_recipe_list)

        -- Get cash from bank
        if shopping_list[1] ~= nil then
            -- Plat Check
            if GLOBAL_PLATINUM > 0 then
                if mq.TLO.Me.PlatinumBank() >= GLOBAL_PLATINUM or
                    mq.TLO.Me.PlatinumShared() >= GLOBAL_PLATINUM then
                    local plat_get = GLOBAL_PLATINUM
                    if mq.TLO.Me.Platinum() > 0 then
                        plat_get = plat_get - mq.TLO.Me.Platinum()
                    end
                    if mq.TLO.Me.Platinum() < GLOBAL_PLATINUM / 2 then
                        -- if we are not in a bank zone then go to pok..
                        movement.bank()
                        lib.bank_withdrawal(plat_get)
                    end
                end
            end
            if shopping_list[1] ~= nil then
                -- Go shopping
                if GLOBAL_SHOP_FLAG == 1 then
                    -- for c = 1, #shopping_list do
                    --  print("\at", shopping_list[c])
                    -- end
                    shop.go_shopping(shopping_list)
                end
            end
        end

        if GLOBAL_CRAFTING_ZONE == 1 and mq.TLO.Me.Guild() ~= nil then
            preferred_crafting_zone = 99999
            if mq.TLO.Zone.ID() == 738 or mq.TLO.Zone.ID() == 738 or
                mq.TLO.Zone.ID() == 751 then
                --  GLOBAL_TEXT = " "
            else
                GLOBAL_TEXT = "Heading to Neighborhood Guild Hall"
            end
        else
            preferred_crafting_zone = 202
            -- GLOBAL_CRAFTING_ZONE = 0
        end

        -- Go to preferred crafting zone
        crafting_zone(preferred_crafting_zone)

        -- Recipes to make
        if l_recipe_list[1] ~= nil then
            for x = #l_recipe_list, 1, -1 do
                if GLOBAL_ABORT_FLAG == 1 then break end

                -- print("\awTCG feeder  CRAFT ROUTINE ", l_recipe_list[x], " array size: ", #l_recipe_list)
                local l_rec_id = lib.return_number(l_recipe_list[x], 4)
                -- Shop from our bank
                local check = lib.single_recipe_check(l_rec_id)

                local l_recipe_id = lib.return_number(l_recipe_list[x], 4)

                local recipe_comp_array =
                    lib.return_recipe_components(l_recipe_id)

                local clean_string = string.gsub(l_recipe_list[x], "'", '')

                l_recipe_id = lib.return_number(clean_string, 4)
                local l_make_count = lib.return_number(clean_string, 5)

                -- Craft Item

                GLOBAL_MAX_LEARNED_FLAG = 0

                mq.cmd('/doevents flush')

                --  print("Feeder: ", l_recipe_id, " max make count: ", l_make_count)

                lib.trophy_selector(l_recipe_id)

                -- Working on Egg Yolk Logic - This is addressed in TCN_Craft
                -- if l_recipe_id == 9996728 and mq.TLO.FindItemCount(96730)() >= l_make_count then end

                craft.main(l_recipe_id, l_make_count, 0, 0)

                if EXP_FLAG == 1 then
                    EXP_FLAG = 0
                    keep_going = 0
                end

                if CRAFT_STATUS_FLAG == 1 then
                    -- Trivial writing area defunct
                    CRAFT_STATUS_FLAG = 0
                    break
                end

                lib.ClearCursor()

                l_recipe_item_id = lib.return_number(clean_string, 1)

                local l_recipe_name = lib.return_string(clean_string, 2)
                local l_inv = mq.TLO.FindItemCount(l_recipe_item_id)()

                --   print("feeder recipe item id ", l_recipe_item_id, " ", l_recipe_name)

                -- If it is multi conversion make sure it is using the item ID of the bottom recipe (ie 1 lb for 15 lb)

                -- Failed pre-combine
                if l_recipe_id ~= p_id and l_inv < 1 then
                    --   if GLOBAL_MAX_FAILED_FLAG == 1
                    -- need want count

                    -- print ("TCN TEST ",p_id, " ",l_recipe_id, " ",l_recipe_name," ",l_recipe_item_id)
                    --  lib.writefile("failedprecombines", p_id .. "," .. l_recipe_id ..
                    --             "," .. l_recipe_item_id .. "," ..
                    --         l_recipe_name)
                    print(msg, "\ap[\ayUnsuccessful Combine\ap] \ap[\aw",
                        l_recipe_name, "\ap]")
                    GLOBAL_MAX_LEARNED_FLAG = 0
                else
                    -- Made pre-combine
                    if l_recipe_id ~= p_id then
                        -- print(l_recipe_id, " ", p_id)
                        print(msg, "\ap[\agSuccessful Combine\ap] \ap[\aw",
                            l_recipe_name, "\ap]")
                        GLOBAL_MAX_LEARNED_FLAG = 0
                    end
                    -- Made final combine
                    if l_recipe_id == p_id and GLOBAL_MAX_LEARNED_FLAG == 1 then
                        -- GLOBAL_MAX_LEARNED_FLAG = 1
                    end
                end

                if GLOBAL_ABORT_FLAG == 1 then break end
            end

            local l_recipe_name = lib.load_recipe_table(p_id)

            l_recipe_item_id = lib.return_number(l_recipe_list[1], 1)

            -- SIM set to 0 to act like we learned recipe
            local learn_bypass = 1

            -- Recipe Success
            if GLOBAL_MAX_LEARNED_FLAG == 1 or learn_bypass == 0 then
                GLOBAL_MAX_LEARNED_FLAG = 0

                -- if we learned continue flag off and then on again

                -- GLOBAL_TEXT = "Learned: " .. l_recipe_name[1].RecipeName

                local used = lib.return_max_used(GLOBAL_MAX_RECIPE_ID, 0)

                -- return ts item to bank if used in other craft
                -- add in banking routine for main recipe
                if GLOBAL_MAX_BANK_FLAG == 1 and used == 1 then
                    shop.bank_deposit(l_recipe_item_id)
                end

                local l_inv = mq.TLO.FindItemCount(l_recipe_item_id)()

                -- Doesn't sell or destroy item if it is part of a task update
                if GLOBAL_TASK_UPDATE == 1 then
                    GLOBAL_TASK_UPDATE = 0
                    GLOBAL_TEXT = "Task Update: " .. l_recipe_name[1].RecipeName
                    return
                end

                -- Don't sell item that is used for Artisan's tradeskill
                if GLOBAL_MAX_USED == 1 then
                    GLOBAL_MAX_USED = 0
                    return
                end

                -- Artisan Sell Threshold
                if l_inv > 0 and mq.TLO.FindItem(l_recipe_item_id).Value() >
                    GLOBAL_MAX_SELL_THRESHOLD * 1000 and GLOBAL_MAX_SELL_FLAG ==
                    1 then
                    print("testing FEEDER ", GLOBAL_MAX_SELL_THRESHOLD, " ", GLOBAL_MAX_SELL_FLAG)
                    shop.sell_item_ID_to_vendor(l_recipe_item_id, l_inv, 0)
                end

                -- all we need to know is are we selling it or banking it?
                local tradeskill_flag = mq.TLO.FindItem(l_recipe_item_id)
                    .Tradeskills()
                -- Determine sell value
                local value = mq.TLO.FindItem(l_recipe_item_id).Value()

                keep_going = 0
            else
                -- Recipe Fail
                GLOBAL_TEXT = "Failed Attempt: " .. l_recipe_name[1].RecipeName

                print(msg, "\ap[\awUnsuccessful Attempt\ap] \ap[\aw",
                    l_recipe_name[1].RecipeName, "\ap]")

                fail_count = fail_count + 1

                -- Exit if we fail main recipe 10 times
                if fail_count > 9 and GLOBAL_MAX_CONT == 1 then
                    fail_count = 0
                    keep_going = 0
                end
            end
        end
        -- Wait random time to start next craft
        -- local delay = math.random(1000, 90000)
        if GLOBAL_MAX_TIMER > 0 then
            mq.delay(GLOBAL_MAX_TIMER * 1000)
            GLOBAL_TEXT = "Delaying For " .. GLOBAL_MAX_TIMER .. " Seconds"
        else
            GLOBAL_TEXT = "No Delay"
        end
        -- print(msg, "\ap[\awRandom Delay Timer\ap]")
        -- mq.delay(delay)

        if GLOBAL_MAX_CONT == 0 then
            print(msg, "Max Continue Off")
            keep_going = 0
        end
    end

    return
end

--- FULL MAX CRAFT END --

------------MAX CRAFTING------------
function tcn_req.max_crafting_routine(p_id)
    local what_skill = lib.return_recipe_skill(p_id)
    local goal_set = 350
    if what_skill == "Fishing" then goal_set = 250 end
    if GLOBAL_THREEFITTY and mq.TLO.Me.Skill(what_skill)() >= goal_set then
        return
    end

    if GLOBAL_ABORT_FLAG == 1 then return end

    -- prismatic palladium bar
    -- p_id = 89483

    -- User sets recipes to skip in prize.db with flag 1 for on
    local skip_recipe_flag = lib.return_max_skip_flag(p_id)

    -- User sets flag to 1 to skip recipe in DB
    if skip_recipe_flag == 1 then
        GLOBAL_TEXT = "Skipping Recipe Per User Configuration"
        print(msg, "Skipping Recipe Per User Configuration")
        return
    end

    local l_recipe_item_id = lib.return_recipe_item_id(p_id)
    local toolcheck_status = lib.toolcheck(p_id)

    -- Ignores recipe if the tool is in inventory/bank
    -- Revisit for proper tool counts
    if toolcheck_status == 1 then
        local in_inv = mq.TLO.FindItemCount(l_recipe_item_id)()
        local in_bank = mq.TLO.FindItemBankCount(l_recipe_item_id)()
        if (in_inv > 0 or in_bank > 0) and toolcheck_status == 1 then
            -- GLOBAL_TEXT ="We have the tool already"
            return
        end
    end

    -- Revisit for jars

    local chk_portables = {
        "Coffin Poison Bottle", "Reinforced Jeweler's Kit", "Glaze Mortar",
        "Mystical Furnace of Ro", "Druzzil's Mystical Sewing Kit",
        "Portable Drink Barrel", "Sacred Urn", "Guktan Sewing Kit",
        "Erudite Sewing Kit", "Teir`Dal Sewing Kit", "White Rose Assembly Kit",
        "Justice Plate Assembly Kit", "Northern Wolf Plate Assembly Kit",
        "Wind Spirits Assembly Kit", "Curing Kit", "Ogre Sewing Kit",
        "Feir`Dal Sewing Kit", "Crystalwing Sewing Kit", "Northman Sewing Kit",
        "Shar Vahl Sewing Kit", "Vale Sewing Kit", "Clockwork Sewing Kit",
        "Iksar Sewing Kit", "Troll Sewing Kit", "Half Elf Sewing Kit",
        "Antonican Sewing Kit", "Gnomish Recharging Kit",
        "Koada`Dal Sewing Kit", "Small Clay Jar", "Medium Clay Jar"
    }

    local con_name = lib.return_container_name(p_id)

    local have_portable = 1

    -- if have portable then dont return eh -- in bank or inv then just continue

    -- Will need to find out what is missing, but no need if we don't have the container
    -- Should break out not return...
    for c = 1, #chk_portables do
        if chk_portables[c] == con_name then
            local in_inv = mq.TLO.FindItemCount(con_name)()
            local in_bank = mq.TLO.FindItemBankCount(con_name)()

            if in_inv > 0 or in_bank > 0 then
                -- do nothing
                -- print('we have ',con_name," ",in_inv," ",in_bank) os.exit()
            else
                local l_rec_name = lib.return_recipe_name(p_id)

                GLOBAL_TEXT = " Unable to make " .. l_rec_name .. " Missing " ..
                    con_name
                print(msg, "\atWe don't have ", con_name,
                    " in bank or inventory")
                mq.delay(1500)
                -- mq.cmd('/lua pause')
                return
            end
        end
    end

    -- Set Recipe ID for MAX
    GLOBAL_MAX_RECIPE_ID = p_id
    -- Set Item ID for MAX
    GLOBAL_MAX_ITEM_ID = l_recipe_item_id

    -- if flag
    if GLOBAL_MAX_DESTROY_FLAG == 1 then
        GLOBAL_MAX_DESTROY_ID = l_recipe_item_id
    else
        GLOBAL_MAX_DESTROY_ID = 0
    end

    if GLOBAL_MAX_SELL_FLAG == 1 then GLOBAL_MAX_SELL_ID = l_recipe_item_id end

    -- Return if we have item already (Testing)
    -- local l_inv_count = mq.TLO.FindItemCount(l_recipe_item_id)()
    -- if l_inv_count > 0 then return end

    -- Generate recipe list (MAX)
    local l_recipe_list, tools, bank_list, farmed_list, shopping_list =
        crunch.items(p_id, 1, 0)

    -- Bank List Checking DEBUG
    local blc = 0
    if blc == 1 then
        for c = 1, #bank_list do print(bank_list[c]) end
        -- if bank_list[1] ~= nil then shop.go_bank_shopping(bank_list) end
        return
    end

    -- Skill and Race/Class checking -- need to add cultural and enchanter stuff
    local l_rec_name
    local l_skill_result
    local l_skill_level_result
    local l_recipe_skill_level
    local l_recipe_skill
    local l_depot_list

    -- Check skill level and race/class/bugged requirements all in one :)
    for recipe_iter = 1, #l_recipe_list do
        local rec_id = lib.return_number(l_recipe_list[recipe_iter], 4)

        -- change load to better name
        local get_single_recipe_info = lib.load_recipe_table(rec_id)

        local data_elements = {
            RecipeID = get_single_recipe_info[1].RecipeID,
            RecipeName = get_single_recipe_info[1].RecipeName,
            RecipeSkillLevel = get_single_recipe_info[1].SkillRequired,
            RecipeSkillUsed = get_single_recipe_info[1].Skill
        }

        if mq.TLO.Me.Skill(get_single_recipe_info[1].Skill)() <
            get_single_recipe_info[1].SkillRequired and
            not (get_single_recipe_info[1].Skill == "Alchemy" or
                get_single_recipe_info[1].Skill == "Make Poison" or
                get_single_recipe_info[1].Skill == "Tinkering") then
            --    table.insert(l_max_rn_disposition_data, data_elements)
        end

        if get_single_recipe_info[1].Skill == "Alchemy" and mq.TLO.Me.Class() ~=
            "Shaman" then
            --  table.insert(l_max_rn_disposition_data, data_elements)
        end
        if get_single_recipe_info[1].Skill == "Make Poison" and
            mq.TLO.Me.Class() ~= "Rogue" then
            --    table.insert(l_max_rn_disposition_data, data_elements)
        end
        if get_single_recipe_info[1].Skill == "Tinkering" and mq.TLO.Me.Race() ~=
            "Gnome" then
            --     table.insert(l_max_rn_disposition_data, data_elements)
        end

        -- erase afterwards

        if GLOBAL_ABORT_FLAG == 1 then break end

        local l_check_recipe_id = lib.return_number(l_recipe_list[recipe_iter],
            4)

        l_rec_name = lib.return_recipe_name(p_id)
        l_recipe_skill_level = lib.return_recipe_skill_level(l_check_recipe_id)
        l_recipe_skill = lib.return_recipe_skill(l_check_recipe_id)
        local l_my_skill = mq.TLO.Me.Skill(l_recipe_skill)()
        -- print ("testing ",l_recipe_skill_level, " ",l_recipe_skill," my skill level ",l_my_skill)
        -- Check Skill Level
        if l_recipe_skill_level > l_my_skill then
            l_skill_level_result = 0
            break
        end

        -- Check if gnome , rogue, shaman needed
        l_skill_result = lib.special_conditions(l_check_recipe_id)

        --  print (l_check_recipe_id)
        --  print(msg," feeder testing ", l_skill_result)

        if l_skill_result == 0 then break end
    end

    -- faction check is per component, not recipe

    -- faction check?
    -- race check

    l_rec_name = lib.return_recipe_name(p_id)

    if l_skill_result == 0 or l_skill_level_result == 0 then
        --  print(msg, "\ap[\ayUnable to make\ap] \ap[\aw", l_rec_name, "\ap] ",
        --       "\agID: \aw", p_id)
        GLOBAL_TEXT = "Unable to make: " .. l_rec_name
        return
    end

    if GLOBAL_ABORT_FLAG == 1 then return end

    -- farmed missing -- here

    if farmed_list[1] ~= nil then
        --   print(msg, "\ap[\ayUnable to make\ap] \ap[\aw", l_rec_name, "\ap] ",
        --   "\agID: \aw", p_id)
        GLOBAL_TEXT = "Unable to make: " .. l_rec_name
        return
    end

    -- set this adjustable?
    recipe_attempts = recipe_attempts + 1

    --  if recipe_attempts > 19 then  recipe_attempts = print(msg," We have tried " , recipe_attempts, "let's take a break") return end

    if GLOBAL_ABORT_FLAG == 1 then return end

    -- Generate recipe list (again, just in case) (MAX)
    l_recipe_list, tools, bank_list, farmed_list, shopping_list, l_depot_list =
        crunch.items(p_id, 1, 0)
    -- welcome to EverCraft

    print(msg, "\ap[\atAttempting\ap] \ap[\aw", l_rec_name,
        "\ap] \ap[\agID: \aw(\ag" .. p_id, "\aw)\ap]")
    GLOBAL_TEXT = "Attempting: " .. l_rec_name
    GLOBAL_MAX_RECIPE = l_rec_name

    -- local r_max_array = {}

    -- Recipes to make
    if l_recipe_list[1] ~= nil then
        for x = #l_recipe_list, 1, -1 do
            if GLOBAL_ABORT_FLAG == 1 then break end

            -- print("\awTCG feeder  CRAFT ROUTINE ", l_recipe_list[x], " array size: ", #l_recipe_list)
            local l_rec_id = lib.return_number(l_recipe_list[x], 4)
            -- Shop from our bank
            local check = lib.single_recipe_check(l_rec_id)
            -- maybe change to auto-bank?
            --  if check == 0 then

            -- MAX
            if bank_list[1] ~= nil then
                -- bank flag here
                GLOBAL_TEXT = "Bank Shopping"
                shop.go_bank_shopping(bank_list)

                local temp_table = {}
                for h = 1, #bank_list do
                    -- name id count
                    local bank_id = lib.return_number(bank_list[h], 2)
                    local bank_count = lib.return_number(bank_list[h], 3)
                    if mq.TLO.FindItemCount(bank_id)() < bank_count then
                        table.insert(temp_table, bank_list[h])
                    end
                end
                bank_list = temp_table
                temp_table = {}
            end

            -- MAX
            if GLOBAL_BANK_FLAG == 1 and mq.TLO.TradeskillDepot.Enabled() and
                l_depot_list[1] ~= nil then
                GLOBAL_TEXT = "Depot Shopping"
                shop.go_depot_shopping(l_depot_list)
                local temp_table = {}
                for c = 1, #l_depot_list do
                    if mq.TLO.FindItemCount(l_depot_list[c].ID)() <
                        l_depot_list[c].Quantity then
                        table.insert(temp_table, l_depot_list[c])
                    end
                end
                l_depot_list = temp_table
                temp_table = {}
            end

            --  r_max_array[1] = l_recipe_list[x]

            local l_recipe_id = lib.return_number(l_recipe_list[x], 4)

            local recipe_comp_array = lib.return_recipe_components(l_recipe_id)

            local ignore_routine = 0

            if ignore_routine == 1 then
                -- Check vendor or inventory for items to make recipe
                local no_make = 1

                for z = 0, #recipe_comp_array do
                    local l_inv_item = tonumber(lib.return_number(
                        recipe_comp_array[z], 1))

                    if l_inv_item == nil then
                        print("tcg inventory check error for ",
                            recipe_comp_array[z])
                        os.exit()
                    end

                    local l_inv = mq.TLO.FindItemCount(l_inv_item)()
                    local l_vendor_has_item = lib.vendor_has_item(l_inv_item)
                    if l_vendor_has_item == 0 then
                        local l_row_count =
                            tonumber(lib.return_number(recipe_comp_array[z], 2))
                        if l_inv < l_row_count then
                            --  local rn = lib.return_number(recipe_comp_array[z],1)
                            -- print(l_row_count, " ", recipe_comp_array[z], " ",lib.return_item_name(rn))
                            no_make = 0
                        end
                    end
                end

                -- Missing components
                if no_make == 0 then
                    print(msg, "\ap[\awMissing Components\ap]")
                    -- more info
                    break
                end
            end

            -- Create shopping list
            --  local shopping_list = shop.create_shopping_list(r_max_array)

            -- Get cash from bank
            if shopping_list[1] ~= nil then
                -- Plat Check
                if GLOBAL_PLATINUM > 0 then
                    if mq.TLO.Me.PlatinumBank() >= GLOBAL_PLATINUM or
                        mq.TLO.Me.PlatinumShared() >= GLOBAL_PLATINUM then
                        local plat_get = GLOBAL_PLATINUM
                        if mq.TLO.Me.Platinum() > 0 then
                            plat_get = plat_get - mq.TLO.Me.Platinum()
                        end
                        if mq.TLO.Me.Platinum() < GLOBAL_PLATINUM / 2 then
                            -- if we are not in a bank zone then go to pok..
                            movement.bank()
                            lib.bank_withdrawal(plat_get)
                        end
                    end
                end

                if shopping_list[1] ~= nil then
                    -- Go shopping
                    if GLOBAL_SHOP_FLAG == 1 then
                        shop.go_shopping(shopping_list)
                    end
                end
            end

            if GLOBAL_CRAFTING_ZONE == 1 and mq.TLO.Me.Guild() ~= nil then
                preferred_crafting_zone = 99999
                if mq.TLO.Zone.ID() == 738 or mq.TLO.Zone.ID() == 738 or
                    mq.TLO.Zone.ID() == 751 then
                    -- GLOBAL_TEXT = " "
                else
                    GLOBAL_TEXT = "Heading to Neighborhood Guild Hall"
                end
            else
                preferred_crafting_zone = 202
                -- GLOBAL_CRAFTING_ZONE = 0
            end

            -- Go to preferred crafting zone
            crafting_zone(preferred_crafting_zone)

            local clean_string = string.gsub(l_recipe_list[x], "'", '')

            l_recipe_id = lib.return_number(clean_string, 4)
            local l_make_count = lib.return_number(clean_string, 5)

            -- Craft Item

            GLOBAL_MAX_LEARNED_FLAG = 0

            mq.cmd('/doevents flush')

            --  print("Feeder: ", l_recipe_id, " max make count: ", l_make_count)

            lib.trophy_selector(l_recipe_id)

            craft.main(l_recipe_id, l_make_count, 0, 0)

            if EXP_FLAG == 1 then
                EXP_FLAG = 0
                CRAFT_STATUS_FLAG = 0
                print(msg, "\ap[\ayNot experienced enough\ap]")
                break
            end

            if CRAFT_STATUS_FLAG == 1 then
                -- Testing writing trivials for recipes we couldnt make based on experience

                -- fix
                local rt = lib.return_recipe_trivial(l_recipe_id)
                local rn = lib.return_recipe_name(l_recipe_id)
                --  lib.writefile("experienced",
                --     rn .. "," .. l_recipe_id .. "," .. rt)

                CRAFT_STATUS_FLAG = 0
                break
            end

            lib.ClearCursor()

            l_recipe_item_id = lib.return_number(clean_string, 1)

            local l_recipe_name = lib.return_string(clean_string, 2)
            local l_inv = mq.TLO.FindItemCount(l_recipe_item_id)()

            --   print("feeder recipe item id ", l_recipe_item_id, " ", l_recipe_name)

            -- If it is multi conversion make sure it is using the item ID of the bottom recipe (ie 1 lb for 15 lb)

            -- Failed pre-combine
            if l_recipe_id ~= p_id and l_inv < 1 then
                --   if GLOBAL_MAX_FAILED_FLAG == 1
                -- need want count

                -- print ("TCN TEST ",p_id, " ",l_recipe_id, " ",l_recipe_name," ",l_recipe_item_id)
                --  lib.writefile("failedprecombines", p_id .. "," .. l_recipe_id ..
                --             "," .. l_recipe_item_id .. "," ..
                --         l_recipe_name)
                print(msg, "\ap[\ayUnsuccessful Combine\ap] \ap[\aw",
                    l_recipe_name, "\ap]")
                GLOBAL_MAX_LEARNED_FLAG = 0
                break
            else
                -- Made pre-combine
                if l_recipe_id ~= p_id then
                    -- print(l_recipe_id, " ", p_id)
                    print(msg, "\ap[\agSuccessful Combine\ap] \ap[\aw",
                        l_recipe_name, "\ap]")
                    GLOBAL_MAX_LEARNED_FLAG = 0
                end
                -- Made final combine
                if l_recipe_id == p_id and GLOBAL_MAX_LEARNED_FLAG == 1 then
                    -- GLOBAL_MAX_LEARNED_FLAG = 1
                end
            end

            if GLOBAL_ABORT_FLAG == 1 then break end
        end

        local l_recipe_name = lib.load_recipe_table(p_id)

        l_recipe_item_id = lib.return_number(l_recipe_list[1], 1)

        -- SIM set to 0 to act like we learned recipe
        local learn_bypass = 1

        -- Recipe Success
        if GLOBAL_MAX_LEARNED_FLAG == 1 or learn_bypass == 0 then
            GLOBAL_MAX_LEARNED_FLAG = 0

            -- GLOBAL_TEXT = "Learned: " .. l_recipe_name[1].RecipeName

            local used = lib.return_max_used(GLOBAL_MAX_RECIPE_ID, 0)

            -- add in banking routine for main recipe
            if GLOBAL_MAX_BANK_FLAG == 1 and used == 1 then
                shop.bank_deposit(l_recipe_item_id)
            end

            local l_inv = mq.TLO.FindItemCount(l_recipe_item_id)()

            -- Doesn't sell or destroy item if it is part of a task update
            if GLOBAL_TASK_UPDATE == 1 then
                GLOBAL_TASK_UPDATE = 0
                GLOBAL_TEXT = "Task Update: " .. l_recipe_name[1].RecipeName
                return
            end

            -- Don't sell item that is used for Artisan's tradeskill
            if GLOBAL_MAX_USED == 1 then
                GLOBAL_MAX_USED = 0
                return
            end

            -- Artisan Sell Threshold
            if l_inv > 0 and mq.TLO.FindItem(l_recipe_item_id).Value() >
                GLOBAL_MAX_SELL_THRESHOLD * 1000 and GLOBAL_MAX_SELL_FLAG == 1 then
                shop.sell_item_ID_to_vendor(l_recipe_item_id, l_inv, 0)
            end

            -- all we need to know is are we selling it or banking it?
            local tradeskill_flag = mq.TLO.FindItem(l_recipe_item_id)
                .Tradeskills()
            -- Determine sell value
            local value = mq.TLO.FindItem(l_recipe_item_id).Value()
        else
            -- Recipe Fail
            GLOBAL_TEXT = "Failed Attempt: " .. l_recipe_name[1].RecipeName

            print(msg, "\ap[\awUnsuccessful Attempt\ap] \ap[\aw",
                l_recipe_name[1].RecipeName, "\ap]")
        end
    end
    -- Wait random time to start next craft
    -- local delay = math.random(1000, 90000)
    if GLOBAL_MAX_TIMER > 0 then
        mq.delay(GLOBAL_MAX_TIMER * 1000)
        GLOBAL_TEXT = "Delaying For " .. GLOBAL_MAX_TIMER .. " Seconds"
    else
        GLOBAL_TEXT = "No Delay"
    end
    -- print(msg, "\ap[\awRandom Delay Timer\ap]")
    -- mq.delay(delay)
    return
end

--- MAX CRAFT END --

-- Load Recipe File for Quest Name
function tcn_req.load_quest_recipes(p_quest_name)
    local quest_max = {}
    -- Get quest ID from quest name
    local quest_id = mq.TLO.Task(p_quest_name).ID()
    -- print (quest_id)
    quest_max = lib.return_quest_recipes(quest_id, p_quest_name)
    -- for c = 1, #quest_max do print(quest_max[c]) end
    if quest_max == nil then mq.delay(1) end
    -- for c = 1, #quest_max do print(quest_max[c]) end
    return quest_max
end

-- Loads recipe file for maxing Artisan Prize
function tcn_req.load_max_recipes(p_skill)
    -- Bugged recipes are filtered out in the generate recipes routine (1st recipe only, not stack)
    local trophy_max = {}
    local u_max = {}
    local k_max = {}

    trophy_max, u_max, k_max = lib.generate_recipes(p_skill)

    if trophy_max == nil then
        mq.delay(1)
        -- check race/class before trying to load the file..
        -- print(msg, "Don't know any recipes or wrong race\\class")
    end

    -- for c = 1, #trophy_max do print(trophy_max[c]) end

    return trophy_max, u_max, k_max
end

function tcn_req.window_go_depot_shopping(p_depot_array)
    shop.go_depot_shopping(p_depot_array)
end

-- Shop from Info Window
function tcn_req.window_shop(p_shop_array)
    -- if GLOBAL_SHOP_FLAG == 1 then

    -- Use the boat to get out of halas
    if mq.TLO.Zone.ID() == 29 then
        movement.leave_halas()

        mq.cmd('/squelch /travelto poknowledge')
        while true do
            if mq.TLO.Zone.ID() == 202 then break end
            mq.delay(1)
        end
    end

    -- if we are in CR go to 1st floor
    if mq.TLO.Zone.ID() == 394 then
        movement.crescent_reach_floor_1()

        mq.cmd('/squelch /travelto poknowledge')
        while true do
            if mq.TLO.Zone.ID() == 202 then break end
            mq.delay(1)
        end
    end

    if mq.TLO.Zone.ID() == 54 and mq.TLO.Me.Z() > 10 then
        mq.cmd('/nav locyx -443 92 |log=off')
        while mq.TLO.Nav.Active() do mq.delay(1000) end
        mq.cmd('/keypress forward hold')
        mq.delay(6000)
        mq.cmd('/keypress forward')
        mq.delay(2000)

        mq.cmd('/squelch /travelto poknowledge')
        while true do
            if mq.TLO.Zone.ID() == 202 then break end
            mq.delay(1)
        end
    end

    -- Go shopping
    shop.go_shopping(p_shop_array)
    -- end
    mq.delay(1000)
    if mq.TLO.Merchant.Open() then mq.TLO.Window('MerchantWnd').DoClose() end
    -- May need other methods to get back to POK

    if mq.TLO.Zone.ID() ~= 202 then mq.cmd('/squelch /travelto poknowledge') end
    return
end

-- Run batch list of recipes
function tcn_req.run_batch_list(p_batch_array)
    if GLOBAL_ABORT_FLAG == 1 then return end
    -- local batch_shop_array = {}
    -- Insert recipes into shopping recipe table
    for max_iter = 1, #p_batch_array do
        -- table.insert(batch_shop_array, p_batch_array[max_iter])
    end

    local b_test = 1
    if b_test == 1 then
        local batch_recipe_data = {}

        local l_depot_data = {}
        local l_depot_array = {}

        local shopping_data = {}

        local batch_recipe_bank_data = {}
        local rec_data, tools_data, bank_data, farm_data
        for max_iter = 1, #p_batch_array do
            -- maybe improve code here
            local b_recipe_id = p_batch_array[max_iter].BatchItemRecipe
            local b_item_count = p_batch_array[max_iter].BatchItemMake

            if mq.TLO.FindItemCount(p_batch_array[max_iter].BatchItemID)() > 0 then
                -- Used to calc proper amount to buy
                b_item_count = b_item_count -
                    mq.TLO
                    .FindItemCount(
                        p_batch_array[max_iter].BatchItemID)()
            end

            -- BATCH
            GLOBAL_TEXT = "Processing Batch Recipe ID: " .. b_recipe_id
            rec_data, tools_data, bank_data, farm_data, shopping_data, l_depot_data =
                crunch.items(b_recipe_id, b_item_count, 0)

            --  print("depot batch pre: ",#l_depot_data)

            -- remove dup tools

            for c = 1, #rec_data do
                table.insert(batch_recipe_data, rec_data[c])
            end

            for c = 1, #bank_data do
                table.insert(batch_recipe_bank_data, bank_data[c])
            end

            -- Add depot items
            for c = 1, #l_depot_data do
                table.insert(l_depot_array, l_depot_data[c])
            end

            --  for c = 1 ,#shopping_data do print(shopping_data[c]) end
        end

        GLOBAL_TEXT = "Batch Recipes Processed"

        -- Process Depot Data
        l_depot_data = depot_squash(l_depot_array)

        -- print("squash depot: ",#l_depot_data)
        -- for c = 1,#l_depot_data do print(l_depot_data[c].Name) end
        -- for c = 1,#l_depot_data do print(l_depot_data[c].Quantity) end

        local batch_c_table = {}
        -- test table for sql
        for x = 1, #batch_recipe_data do
            -- print(batch_recipe_data[x]) os.exit()
            local ItemID = lib.return_number(batch_recipe_data[x], 1)
            local RecipeName = lib.return_string(batch_recipe_data[x], 2)
            local Set_counts = lib.return_number(batch_recipe_data[x], 3)
            local Recipe_ID = lib.return_number(batch_recipe_data[x], 4)
            table.insert(batch_c_table, string.format('(%d,"%s",%d, %d)',
                ItemID, RecipeName,
                Recipe_ID, Set_counts))
        end

        --  for c = 1,#batch_c_table do print("test ",batch_c_table[c]) end os.exit()

        -- Changed to SQL memory 5/10/2022
        local dbw = sqlite3.open(":memory:")

        dbw:exec(
            "DROP TABLE IF EXISTS BATCHCOLLAPSE;CREATE TEMP TABLE BATCHCOLLAPSE (ItemID,RecName,ID,Count);")
        -- mq.delay(1)
        local batch_insert_array = {}
        local insert = table.concat(batch_c_table, ", ")
        -- for c  =1 ,#batch_c_table do print(batch_c_table[c]) end
        dbw:exec(string.format(
            "INSERT INTO BATCHCOLLAPSE ('ItemID','RecName','ID', 'Count') VALUES %s;",
            insert))
        for x in dbw:nrows(
            "SELECT RecName,ItemID,ID,SUM(Count) AS Count FROM BATCHCOLLAPSE GROUP BY ID") do
            local l_count = x.Count
            local is_crafted = lib.toolcheck(x.ID)
            if is_crafted == 1 then
                -- print("original count is:", x.Count)
                l_count = 1
            end
            -- print("batch: ",x.ItemID, " ", x.RecName, " ", x.ID, " ", l_count)
            table.insert(batch_insert_array,
                x.ItemID .. "," .. x.RecName .. "," .. l_count .. "," ..
                x.ID)
        end

        dbw:close()

        batch_recipe_data = batch_insert_array

        -- Set Calc and remove tool dups

        -- for c = 1, #batch_recipe_data do print(batch_recipe_data[c]) end
        -- os.exit()

        table.sort(batch_recipe_bank_data)

        -- for c = 1,#batch_recipe_bank_data do print(batch_recipe_bank_data[c]) end

        local sorted_bank_data = lib.return_sorted_counts_array(
            batch_recipe_bank_data)

        -- Set Tools and Trophies to 1
        for c = 1, #sorted_bank_data do
            local l_sorted_id = lib.return_number(sorted_bank_data[c], 2)
            local is_crafted = lib.toolcheck_id(l_sorted_id)
            -- Only concern is lamintor roller x 2 (no batch currently calls for this)
            if is_crafted == 1 then
                local l_tool_string = lib.return_string(sorted_bank_data[c], 1)
                sorted_bank_data[c] = l_tool_string .. "," .. l_sorted_id ..
                    ",1"

                -- Grab 2 laminator rollers
                if mq.TLO.FindItemBankCount(l_sorted_id)() > 1 and l_sorted_id ==
                    96489 then
                    sorted_bank_data[c] =
                        l_tool_string .. "," .. l_sorted_id .. ",2"
                end
            end
            -- Set all trophies to 1
            local is_trophy = lib.trophycheck_id(l_sorted_id)
            if is_trophy == 1 then
                local l_trophy_string =
                    lib.return_string(sorted_bank_data[c], 1)
                sorted_bank_data[c] = l_trophy_string .. "," .. l_sorted_id ..
                    ",1"
            end
            -- Set all bought tools to 1
            local is_bought_tool = lib.return_tool_buy(l_sorted_id)
            if is_bought_tool == 1 then
                local l_bought_tool_string = lib.return_string(
                    sorted_bank_data[c], 1)
                sorted_bank_data[c] =
                    l_bought_tool_string .. "," .. l_sorted_id .. ",1"
            end

            -- print(sorted_bank_data[c])
        end
        -- End Set Tools And Trophies to 1

        -- Print recipe ID and count
        local count_checker = 0
        if count_checker == 1 then
            for max_iter = 1, #p_batch_array do
                local p_id = p_batch_array[max_iter].BatchItemRecipe
                local p_mc = p_batch_array[max_iter].BatchItemMake
                print(p_id, " ", p_mc)
            end
            os.exit()
        end

        -- Go Bank shopping (RUN BATCH LIST)
        if GLOBAL_BANK_FLAG == 1 then
            if sorted_bank_data[1] ~= nil then
                GLOBAL_TEXT = "Bank Shopping"
                shop.go_bank_shopping(sorted_bank_data)
            end
        end

        -- Go Depot Shopping (RUN BATCH LIST)
        if GLOBAL_BANK_FLAG == 1 and mq.TLO.TradeskillDepot.Enabled() and
            l_depot_data[1] ~= nil then
            local temp_depot_data = {}

            -- try to grab all we have not what we want..
            for c = 1, #l_depot_data do
                local tsd_check_current_count =
                    mq.TLO.TradeskillDepot.FindItemCount(l_depot_data[c].ID)()

                local tsd_want = l_depot_data[c].Quantity

                -- Set count to most we can get!
                if tsd_want >= tsd_check_current_count then
                    tsd_want = tsd_check_current_count
                else
                    -- Do nothing
                end

                local item = {
                    Name = l_depot_data[c].Name,
                    Quantity = tsd_want,
                    ID = l_depot_data[c].ID
                }
                table.insert(temp_depot_data, item)
            end

            l_depot_data = temp_depot_data

            for c = 1, #l_depot_data do
                -- print(l_depot_data[c].Name, " ", l_depot_data[c].Quantity)
            end

            temp_depot_data = {}

            GLOBAL_TEXT = "Depot Shopping"
            print(msg, "Batch Depot Shopping")
            shop.go_depot_shopping(l_depot_data)
        end

        -- Create batch shopping list
        local final_shop_array = shopping_data -- shop.create_shopping_list(batch_recipe_data)

        final_shop_array = shop.create_shopping_list(batch_recipe_data)

        -- for c = 1, #final_shop_array do print(final_shop_array[c]) end

        -- If array is not nil then shop
        if final_shop_array[1] ~= nil then
            if GLOBAL_SHOP_FLAG == 1 then
                -- Use the boat to get out of halas
                if mq.TLO.Zone.ID() == 29 then
                    movement.leave_halas()

                    mq.cmd('/squelch /travelto poknowledge')
                    while true do
                        if mq.TLO.Zone.ID() == 202 then
                            break
                        end
                        mq.delay(1)
                    end
                end

                -- if we are in CR go to 1st floor
                if mq.TLO.Zone.ID() == 394 then
                    movement.crescent_reach_floor_1()

                    mq.cmd('/squelch /travelto poknowledge')
                    while true do
                        if mq.TLO.Zone.ID() == 202 then
                            break
                        end
                        mq.delay(1)
                    end
                end

                if mq.TLO.Zone.ID() == 54 and mq.TLO.Me.Z() > 10 then
                    mq.cmd('/nav locyx -443 92 |log=off')
                    while mq.TLO.Nav.Active() do
                        mq.delay(1000)
                    end
                    mq.cmd('/keypress forward hold')
                    mq.delay(6000)
                    mq.cmd('/keypress forward')
                    mq.delay(2000)

                    mq.cmd('/squelch /travelto poknowledge')
                    while true do
                        if mq.TLO.Zone.ID() == 202 then
                            break
                        end
                        mq.delay(1)
                    end
                end

                -- Go shopping
                shop.go_shopping(final_shop_array)
            end
        end
    end

    -- Run the batch
    for max_iter = 1, #p_batch_array do
        local p_id = p_batch_array[max_iter].BatchItemRecipe
        local p_mc = p_batch_array[max_iter].BatchItemMake
        -- print("Feeder Batch Count: ",p_id," ",p_mc)
        while true do
            -- Set to perform proper make count calculation in batch crafting routine
            GLOBAL_STANDARD_ID = p_id
            local batch_loop = tcn_req.batch_crafting_routine(p_id, p_mc)

            -- JB321
            -- should be depot shopping in the batch_crafting_routine.. or at least checking ahead of time..
            -- so before we shop, well how do we know we got it all.. need to scan bank depot and we know shopping.. so scan those 2 before even trying?

            if batch_loop == 0 then break end

            -- is GLOBAL_STANDARD_ID set for standard routine?

            -- Change?
            --  local p_iid = p_batch_array[max_iter].BatchItemID

            local p_item_id = tcn_req.recipe_id(p_id)
            local p_item_inv = mq.TLO.FindItemCount(p_item_id)()
            -- Batch Continue
            if GLOBAL_BATCH_CONTINUE == 0 then
                print(msg, "Batch Continue: OFF")
                break
            else
                print(msg, "Batch Continue: ON")
            end
            -- We have count - BREAK
            if p_item_inv >= p_mc then break end
            -- BATCH
            local ignore_data, ignore_data, ignore_data, farmed_data =
                crunch.items(p_id, 1, 0)
            -- We have farmed - BREAK

            if farmed_data[1] ~= nil or #farmed_data > 0 then
                print(msg, "Unable to make Recipe ID: ", p_id)
                break
            end
            mq.delay(1)
        end
        mq.delay(1)
    end
    -- GLOBAL_BATCH_CONTINUE = 0
    GLOBAL_TEXT = "Batch Execution Complete"

    -- turn into array

    -- Zones with banks
    if mq.TLO.Zone.ID() == 737 or mq.TLO.Zone.ID() == 738 or mq.TLO.Zone.ID() ==
        751 or mq.TLO.Zone.ID() == 202 or mq.TLO.Zone.ID() == 203 or
        mq.TLO.Zone.ID() == 344 or mq.TLO.Zone.ID() == 345 or mq.TLO.Zone.ID() ==
        712 or mq.TLO.Zone.ID() == 49 or mq.TLO.Zone.ID() == 29 or
        mq.TLO.Zone.ID() == 394 then
        -- In a bank zone.
    else
        -- If in Gfaydark jump down to the ground
        if mq.TLO.Zone.ID() == 54 and mq.TLO.Me.Z() > 10 then
            mq.cmd('/nav locyx -443 92 |log=off')
            while mq.TLO.Nav.Active() do mq.delay(1000) end
            mq.cmd('/keypress forward hold')
            mq.delay(6000)
            mq.cmd('/keypress forward')
            mq.delay(2000)
        end

        if mq.TLO.Zone.ID() == 394 then movement.crescent_reach_floor_1() end
        -- Go to POK
        mq.cmd('/squelch /travelto poknowledge')
        while true do
            if mq.TLO.Zone.ID() == 202 then break end
            mq.delay(1)
        end
        mq.delay(3000)
    end

    shop.return_bank_shopping()
    shop.return_depot()

    -- Retains if you switch tabs
    -- GLOBAL_STANDARD_ID = 0

    mq.delay(1)
    return
end

-- End Run Batch List

-- Generate Batch List Data
function tcn_req.generate_batch_list(p_batch_array)
    rip.create_toon_inventory()

    local temp_batch_array = {}

    for c = 1, #p_batch_array do
        local l_single_recipe_information =
            lib.load_recipe_table(p_batch_array[c].BatchItemRecipe)
        if l_single_recipe_information[1].RecipeBugged ~= 1 then
            table.insert(temp_batch_array, p_batch_array[c])
        end
    end

    p_batch_array = temp_batch_array

    if GLOBAL_ABORT_FLAG == 1 then return end

    local batch_recipe_data = {}

    local batch_component_data = {}

    local batch_bank_data = {}

    local test_e_array = {}

    local rec_data, tools_data, bank_data, component_data, e_tool_array

    for max_iter = 1, #p_batch_array do
        local b_recipe_id = p_batch_array[max_iter].BatchItemRecipe
        local b_item_count = p_batch_array[max_iter].BatchItemMake

        if mq.TLO.FindItemCount(p_batch_array[max_iter].BatchItemID)() > 0 then
            -- Used to calc proper amount to buy
            b_item_count = b_item_count -
                mq.TLO
                .FindItemCount(
                    p_batch_array[max_iter].BatchItemID)()
        end

        if b_item_count > 0 then
            -- BATCH
            GLOBAL_TEXT = "Processing Batch Recipe ID: " .. b_recipe_id
            rec_data, tools_data, bank_data, component_data, e_tool_array =
                m_crunch.items(b_recipe_id, b_item_count, 0, 0)

            for c = 1, #e_tool_array do
                table.insert(test_e_array, e_tool_array[c])
                --   print("\ao", e_tool_array[c])
            end

            for c = 1, #rec_data do
                table.insert(batch_recipe_data, rec_data[c])
            end

            for c = 1, #bank_data do
                table.insert(batch_bank_data, bank_data[c])
            end

            for c = 1, #component_data do
                table.insert(batch_component_data, component_data[c])
            end
        end
    end

    local special_gnome = {}

    -- Add special tools
    if test_e_array ~= nil then
        -- Open SQL Memory for tool additions
        local db_test_sort = sqlite3.open(":memory:")
        -- Create Table
        db_test_sort:exec(
            [[DROP TABLE IF EXISTS TTA;CREATE TEMP TABLE TTA (ItemName,RecipeID,ItemCount);]])
        local insert = table.concat(test_e_array, ", ")
        -- Insert Data into SQL Table
        db_test_sort:exec(string.format(
            "INSERT INTO TTA ('ItemName','RecipeID','ItemCount') VALUES %s;",
            insert))
        -- SQL String
        local sql_string =
        "SELECT Distinct ItemName,RecipeID,ItemCount FROM TTA ORDER BY ItemName DESC"

        -- SIM wipe out all components from array to show just tool components
        -- component_max_table = {}

        local myrace = mq.TLO.Me.Race()

        for r in db_test_sort:nrows(sql_string) do
            --  print("\agData: ", r.ItemName, " ", r.RecipeID, " ", r.ItemCount)

            -- Muramite Needle
            if r.RecipeID == 63767 then
                local c_string = "Bone Chips,13073,4"
                table.insert(batch_component_data, c_string)
                c_string = "Muramite Residue,60178,1"
                table.insert(batch_component_data, c_string)
            end

            -- Non-Stick Frying Pan
            if r.RecipeID == 97063 then
                local c_string = "Frying Pan Mold,8158,1"
                table.insert(batch_component_data, c_string)
            end

            -- Race Specific (Gnome)

            -- Gem Cutter
            if r.RecipeID == 101251 and myrace == "Gnome" then
                local c_string = "Diamond Dust,16884,1"
                table.insert(batch_component_data, c_string)
            end

            -- Dihydrous Oxide Glaciator
            if r.RecipeID == 11298 and myrace == "Gnome" then
                local c_string = "Dark Matter,58242,1"
                table.insert(batch_component_data, c_string)
                c_string = "Vial of Viscous Mana,10250,1"
                table.insert(batch_component_data, c_string)
                c_string = "Ice of Velious,11789,1"
                table.insert(batch_component_data, c_string)
                c_string = "Bundle of Super Conductive Wires,9426,1"
                table.insert(batch_component_data, c_string)
                c_string = "Rune of Frost,11780,1"
                table.insert(batch_component_data, c_string)
                c_string = "Vial of Distilled Mana,10253,1"
                table.insert(batch_component_data, c_string)
                c_string = "Brick of Electrified Copper,29539,1"
                table.insert(batch_component_data, c_string)
            end

            -- Geerlok Laminating Device
            if r.RecipeID == 35563 and myrace == "Gnome" then
                local c_string = "Belt of Leathery Fungus Flesh,7481,1"
                table.insert(batch_component_data, c_string)
                c_string = "Pinion,9178,1"
                table.insert(batch_component_data, c_string)
                c_string = "Steel Ball Bearing,9184,1"
                table.insert(batch_component_data, c_string)
                c_string = "Steel Casing,9194,1"
                table.insert(batch_component_data, c_string)
            end

            -- Corking Device
            if r.RecipeID == 101062 and myrace == "Gnome" then
                local c_string = "Branch of Sylvan Oak,19140,1"
                table.insert(batch_component_data, c_string)
            end

            -- Crab Cracker
            if r.RecipeID == 101063 and myrace == "Gnome" then
                local c_string = "Knuckle Joint,29789,1"
                table.insert(batch_component_data, c_string)
            end

            -- Wok
            if r.RecipeID == 101838 and myrace == "Gnome" then
                local c_string = "Clockwork Carapace,29761,1"
                table.insert(batch_component_data, c_string)
            end

            -- No Gnome Tool Logic
            if r.RecipeID == 101251 and myrace ~= "Gnome" then
                table.insert(special_gnome,
                    "We are not able to make the Gem Cutter because we need the services of a Mechanist")
            end
            if r.RecipeID == 11298 and myrace ~= "Gnome" then
                table.insert(special_gnome,
                    "We are not able to make the Dihydrous Oxide Glaciator because we need the services of a Mechanist")
            end
            if r.RecipeID == 35563 and myrace ~= "Gnome" then
                table.insert(special_gnome,
                    "We are not able to make the Geerlok Laminating Device because we need the services of a Mechanist")
            end
            if r.RecipeID == 101062 and myrace ~= "Gnome" then
                table.insert(special_gnome,
                    "We are not able to make the Corking Device because we need the services of a Mechanist")
            end
            if r.RecipeID == 101063 and myrace ~= "Gnome" then
                table.insert(special_gnome,
                    "We are not able to make the Crab Cracker because we need the services of a Mechanist")
            end
            if r.RecipeID == 101838 and myrace ~= "Gnome" then
                table.insert(special_gnome,
                    "We are not able to make the Wok because we need the services of a Mechanist")
            end
        end

        -- for c = 1, #component_max_table do print(component_max_table[c]) end
        -- os.exit()

        db_test_sort:close()
        -- end SQL Tool Section
    end

    local c_data = lib.return_sorted_counts_array(batch_component_data)

    print(msg, "\ap[\aoSorting Batch Data List\ap]")

    local c_farm_table = {}
    local c_vend_table = {}
    local batch_depot_table = {}

    print(msg, "\ap[\aoGenerating Batch Farm List\ap]")

    for c = 1, #c_data do
        local z_id = lib.return_number(c_data[c], 2)
        local z_count = lib.return_number(c_data[c], 3)
        local z_name = lib.return_string(c_data[c], 1)

        -- Coldain Smithing Hammer
        if z_id == 30140 then z_count = 1 end

        local l_inv_count = mq.TLO.FindItemCount(z_id)()
        local l_bnk_count = mq.TLO.FindItemBankCount(z_id)()

        local l_tot_count = l_inv_count + l_bnk_count

        -- Full Bank
        if l_bnk_count > 0 and l_inv_count < 1 and l_tot_count >= z_count then
            local c_string = z_name .. "," .. z_id .. "," .. z_count
            table.insert(batch_bank_data, c_string)
        end

        -- Partial Bank
        if l_bnk_count > 0 and l_inv_count < 1 and l_tot_count < z_count then
            local c_string = z_name .. "," .. z_id .. "," .. l_bnk_count
            table.insert(batch_bank_data, c_string)
        end

        -- Half and Halfish
        if l_bnk_count > 0 and l_inv_count > 0 and l_tot_count >= z_count and
            l_inv_count < z_count then
            local calc = z_count - l_inv_count
            local c_string = z_name .. "," .. z_id .. "," .. calc
            table.insert(batch_bank_data, c_string)
        end

        local ven = lib.vendor_has_item(z_id)

        -- Generate Batch Farm Table Data
        if ven == 0 then
            if l_tot_count < z_count then
                -- local farm_action, farm_zone = lib.return_item_source(z_id)
                -- local c_string =
                --  z_name .. "," .. z_id .. "," .. z_count .. "," ..
                --    farm_action .. "," .. farm_zone

                local c_string = z_name .. "," .. z_id .. "," .. z_count

                if mq.TLO.TradeskillDepot.Enabled() then
                    local tsd_count = mq.TLO.TradeskillDepot
                        .FindItemCount(z_id)()

                    local l_d_calc = 0

                    -- Bank and inventory have something and depot has more than both
                    if l_tot_count > 0 and tsd_count > l_tot_count and tsd_count +
                        l_tot_count >= z_count then
                        -- l_d_calc = tsd_count - l_tot_count
                        l_d_calc = z_count - l_tot_count
                    end

                    -- Bank and inventory have something and depot has less than both
                    if l_tot_count > 0 and tsd_count < l_tot_count and tsd_count +
                        l_tot_count >= z_count then
                        l_d_calc = z_count - l_tot_count
                    end

                    -- Bank and inventory have something and depot has an equal amount
                    if l_tot_count > 0 and tsd_count == l_tot_count and
                        tsd_count + l_tot_count >= z_count then
                        l_d_calc = math.ceil(z_count / 2)
                    end

                    -- Nothing in Bank or Inventory, but we meet or exceed needed count
                    if l_tot_count < 1 and tsd_count >= z_count then
                        l_d_calc = z_count
                    end

                    -- Set to max amount we have (batch)
                    if tsd_count < z_count and tsd_count > 0 then
                        l_d_calc = tsd_count
                        table.insert(c_farm_table, c_string)
                    end

                    if l_d_calc > 0 then
                        local depot_item = {
                            Name = z_name,
                            ID = z_id,
                            Quantity = l_d_calc
                        }

                        -- Add to batch depot table
                        table.insert(batch_depot_table, depot_item)
                        -- print("calc ", batch_depot_table[1].Quantity)
                    else
                        -- Add to farm table
                        table.insert(c_farm_table, c_string)
                    end
                else
                    -- No Tradeskill Depot, Add to farm table
                    table.insert(c_farm_table, c_string)
                end
            end
        end

        -- Vendor to Depot (Batch Mass)
        if mq.TLO.TradeskillDepot.Enabled() and z_count > 0 and ven == 1 then
            local tsd_count = mq.TLO.TradeskillDepot.FindItemCount(z_id)()
            local l_d_calc = 0
            local depot_item = { Name = z_name, ID = z_id, Quantity = l_d_calc }
            -- (Vendor) Nothing in Bank or Inv
            if tsd_count > 0 and l_tot_count < 1 then
                -- Full
                if tsd_count >= z_count then l_d_calc = z_count end
                -- Partial
                if tsd_count < z_count then l_d_calc = tsd_count end
            end
            if tsd_count > 0 and l_tot_count > 0 and tsd_count + l_tot_count >=
                z_count then
                -- (Vendor) Bank and inventory have something and depot has more than both
                if tsd_count > l_tot_count then
                    l_d_calc = z_count - l_tot_count
                end
                -- (Vendor) Bank and inventory have something and depot has less than both
                if tsd_count < l_tot_count then
                    l_d_calc = z_count - l_tot_count
                end
                -- (Vendor) Bank and inventory have something and depot has an equal amount
                if tsd_count == l_tot_count then
                    l_d_calc = math.ceil(z_count / 2)
                end
            end
            if l_d_calc > 0 then
                depot_item = { Name = z_name, ID = z_id, Quantity = l_d_calc }
                table.insert(batch_depot_table, depot_item)
            end
        end

        -- Vendor Table to shop
        if ven == 1 then
            local l_vendor_name = nil
            local faction_check = 1

            -- Faction check for vendor
            if z_id == 28021 or z_id == 10425 or z_id == 22564 or z_id == 22098 or
                z_id == 21625 then
                l_vendor_name = lib.return_vendor_name(z_id)
            end

            if l_vendor_name == "Ping Fuzzlecutter" or l_vendor_name ==
                "Nimren Stonecutter" or l_vendor_name == "Talem Tucter" or
                l_vendor_name == "Meg Tucter" then
                faction_check = lib.faction_check(l_vendor_name)
            end

            if faction_check == 0 then
                -- Total Inventory Count < Need Count = Add to farm table
                if l_tot_count < z_count then
                    local c_string = z_name .. "," .. z_id .. "," .. z_count
                    table.insert(c_farm_table, c_string)
                end
            else
                -- No Faction/Faction Good =  Add To Vendor Table
                local c_string = z_name .. "," .. z_id .. "," .. z_count
                table.insert(c_vend_table, c_string)
            end
        end
    end

    print(msg, "\ap[\aoGenerating Batch Shopping List\ap]")

    -- Create Shopping List Section
    local MAX_SHOP_LIST, MAX_ZONE_LIST = {}, {}

    local max_sl = {}

    for c = 1, #c_vend_table do
        local vi = lib.return_number(c_vend_table[c], 2)
        local vic = lib.return_number(c_vend_table[c], 3)
        local s_data_string = lib.return_vendor_data(vi, vic)
        table.insert(max_sl, s_data_string)
    end

    table.sort(max_sl)

    MAX_SHOP_LIST = max_sl

    local zone_array = {}

    -- Extract Zone ID
    for c = 1, #max_sl do
        local zone_id = lib.return_number(max_sl[c], 1)
        local zone_name = mq.TLO.Zone(zone_id)()
        table.insert(zone_array, zone_name)
    end

    -- Remove Duplicate Zone ID
    zone_array = removeDuplicates(zone_array)

    table.insert(zone_array, 1, "ALL")

    MAX_ZONE_LIST = zone_array

    MAX_SHOP_LIST = tcn_req.cleanse_purchased_tools(MAX_SHOP_LIST)
    -- End Shopping List Section

    print(msg, "\ap[\aoGenerating Mass Bank Shopping List\ap]")

    local temp_bank_batch_table = {}

    for c = 1, #batch_bank_data do
        local id = lib.return_number(batch_bank_data[c], 2)
        local count = lib.return_number(batch_bank_data[c], 3)
        local name = lib.return_string(batch_bank_data[c], 1)
        table.insert(temp_bank_batch_table, string.format('("%s", %d, %d)',
            name:gsub("'", "''"),
            id, count))
    end

    if batch_bank_data[1] ~= nil then
        batch_bank_data = lib.SQL_Bank_Array(temp_bank_batch_table)
    end

    GLOBAL_TEXT = "Processing Data..."

    local temp_global_array = lib.SQL_Sort_Array(c_farm_table)

    ---os.exit()
    c_farm_table = temp_global_array
    temp_global_array = {}

    -- Don't do recipe IDs for batch data
    local do_not = 0
    if do_not == 1 then
        local batch_c_table = {}
        -- test table for sql
        for x = 1, #batch_recipe_data do
            -- print(batch_recipe_data[x]) os.exit()
            local ItemID = lib.return_number(batch_recipe_data[x], 1)
            local RecipeName = lib.return_string(batch_recipe_data[x], 2)
            local Set_counts = lib.return_number(batch_recipe_data[x], 3)
            local Recipe_ID = lib.return_number(batch_recipe_data[x], 4)
            table.insert(batch_c_table, string.format('(%d,"%s",%d, %d)',
                ItemID, RecipeName,
                Recipe_ID, Set_counts))
        end
        --  for c = 1,#batch_c_table do print("test ",batch_c_table[c]) end os.exit()

        local dbw = sqlite3.open(":memory:")
        dbw:exec(
            "DROP TABLE IF EXISTS BATCHCALC;CREATE TEMP TABLE BATCHCALC (ItemID,RecName,ID,Count);")
        -- mq.delay(1)
        local batch_insert_array = {}
        local insert = table.concat(batch_c_table, ", ")
        -- for c  =1 ,#batch_c_table do print(batch_c_table[c]) end
        dbw:exec(string.format(
            "INSERT INTO BATCHCALC ('ItemID','RecName','ID', 'Count') VALUES %s;",
            insert))
        for x in dbw:nrows(
            "SELECT RecName,ItemID,ID,SUM(Count) AS Count FROM BATCHCALC GROUP BY ID") do
            local l_count = x.Count
            local is_crafted = lib.toolcheck(x.ID)
            if is_crafted == 1 then
                -- print("original count is:", x.Count)
                l_count = 1
            end
            --         print(x.ItemID, " ", x.RecName, " ", x.ID, " ", l_count)
            table.insert(batch_insert_array,
                x.ItemID .. "," .. x.RecName .. "," .. l_count .. "," ..
                x.ID)
        end

        dbw:close()

        batch_recipe_data = batch_insert_array
    end

    if special_gnome[1] ~= nil then
        print(msg,
            "\arIf this is a quest we will not be able to complete it based on:")
        for c = 1, #special_gnome do
            print(msg, "\ay" .. special_gnome[c])
        end
    end

    if MAX_SHOP_LIST[1] == nil then
        print(msg, "\ap[\agNo Items to shop for\ap]")
    end

    -- Convert to ID, NAME, QUANTITY FORMAT
    local converted_batch_shopping_data = convert_shopping_data(MAX_SHOP_LIST)

    local converted_batch_farm_data = convert_farm_data(c_farm_table)

    print(msg, "\ap[\aoLists Complete\ap]")
    GLOBAL_TEXT = "Data Processed..."

    return c_farm_table, MAX_SHOP_LIST, MAX_ZONE_LIST, batch_bank_data,
        converted_batch_shopping_data, converted_batch_farm_data,
        batch_depot_table
end

--  local final_batch_shopping_list =
--  tcn_req.cleanse_purchased_tools(batch_shopping_data)

-- Only needs farm data currently.
-- Generate Quest List Farm Data
function tcn_req.generate_mass_quest_list(p_quest_array)
    rip.create_toon_inventory()

    local temp_quest_array = {}

    -- Don't add bugged recipes (pretty sure doesn't apply for most quests)
    for c = 1, #p_quest_array do
        local l_single_recipe_information =
            lib.load_recipe_table(p_quest_array[c].RID)
        if l_single_recipe_information[1].RecipeBugged ~= 1 then
            table.insert(temp_quest_array, p_quest_array[c])
        end
    end

    p_quest_array = temp_quest_array

    if GLOBAL_ABORT_FLAG == 1 then return end

    local quest_recipe_data = {}

    local quest_component_data = {}

    local quest_bank_data = {}

    local test_e_array = {}

    local rec_data, tools_data, bank_data, component_data, e_tool_array

    for max_iter = 1, #p_quest_array do
        local b_recipe_id = p_quest_array[max_iter].RID
        local b_item_count = p_quest_array[max_iter].QTY

        -- Count is derived from Quest Journal
        if mq.TLO.FindItemCount(p_quest_array[max_iter].ID)() > 0 then
            -- Used to calc proper amount to buy
            --  b_item_count = b_item_count -
            --      mq.TLO
            --    .FindItemCount(p_quest_array[max_iter].ID)()
        end

        -- count - count = need count and it will only affect the mass list?
        -- wahat about the bcount
        -- request facility batch add recipes to request?

        -- b_item_coint will be uh craps

        if b_item_count > 0 then
            -- QUEST
            GLOBAL_TEXT = "Processing Quest Recipe ID: " .. b_recipe_id
            rec_data, tools_data, bank_data, component_data, e_tool_array =
                m_crunch.items(b_recipe_id, b_item_count, 0, 0)

            for c = 1, #e_tool_array do
                table.insert(test_e_array, e_tool_array[c])
                --   print("\ao", e_tool_array[c])
            end

            for c = 1, #rec_data do
                table.insert(quest_recipe_data, rec_data[c])
            end

            for c = 1, #bank_data do
                table.insert(quest_bank_data, bank_data[c])
            end

            for c = 1, #component_data do
                table.insert(quest_component_data, component_data[c])
            end
        end
    end

    local special_gnome = {}

    -- Add special tools
    if test_e_array ~= nil then
        -- Open SQL Memory for tool additions
        local db_test_sort = sqlite3.open(":memory:")
        -- Create Table
        db_test_sort:exec(
            [[DROP TABLE IF EXISTS TTA;CREATE TEMP TABLE TTA (ItemName,RecipeID,ItemCount);]])
        local insert = table.concat(test_e_array, ", ")
        -- Insert Data into SQL Table
        db_test_sort:exec(string.format(
            "INSERT INTO TTA ('ItemName','RecipeID','ItemCount') VALUES %s;",
            insert))
        -- SQL String
        local sql_string =
        "SELECT Distinct ItemName,RecipeID,ItemCount FROM TTA ORDER BY ItemName DESC"

        -- SIM wipe out all components from array to show just tool components
        -- component_max_table = {}

        local myrace = mq.TLO.Me.Race()

        for r in db_test_sort:nrows(sql_string) do
            --  print("\agData: ", r.ItemName, " ", r.RecipeID, " ", r.ItemCount)

            -- Muramite Needle
            if r.RecipeID == 63767 then
                local c_string = "Bone Chips,13073,4"
                table.insert(quest_component_data, c_string)
                c_string = "Muramite Residue,60178,1"
                table.insert(quest_component_data, c_string)
            end

            -- Non-Stick Frying Pan
            if r.RecipeID == 97063 then
                local c_string = "Frying Pan Mold,8158,1"
                table.insert(quest_component_data, c_string)
            end

            -- Race Specific (Gnome)

            -- Gem Cutter
            if r.RecipeID == 101251 and myrace == "Gnome" then
                local c_string = "Diamond Dust,16884,1"
                table.insert(quest_component_data, c_string)
            end

            -- Dihydrous Oxide Glaciator
            if r.RecipeID == 11298 and myrace == "Gnome" then
                local c_string = "Dark Matter,58242,1"
                table.insert(quest_component_data, c_string)
                c_string = "Vial of Viscous Mana,10250,1"
                table.insert(quest_component_data, c_string)
                c_string = "Ice of Velious,11789,1"
                table.insert(quest_component_data, c_string)
                c_string = "Bundle of Super Conductive Wires,9426,1"
                table.insert(quest_component_data, c_string)
                c_string = "Rune of Frost,11780,1"
                table.insert(quest_component_data, c_string)
                c_string = "Vial of Distilled Mana,10253,1"
                table.insert(quest_component_data, c_string)
                c_string = "Brick of Electrified Copper,29539,1"
                table.insert(quest_component_data, c_string)
            end

            -- Geerlok Laminating Device
            if r.RecipeID == 35563 and myrace == "Gnome" then
                local c_string = "Belt of Leathery Fungus Flesh,7481,1"
                table.insert(quest_component_data, c_string)
                c_string = "Pinion,9178,1"
                table.insert(quest_component_data, c_string)
                c_string = "Steel Ball Bearing,9184,1"
                table.insert(quest_component_data, c_string)
                c_string = "Steel Casing,9194,1"
                table.insert(quest_component_data, c_string)
            end

            -- Corking Device
            if r.RecipeID == 101062 and myrace == "Gnome" then
                local c_string = "Branch of Sylvan Oak,19140,1"
                table.insert(quest_component_data, c_string)
            end

            -- Crab Cracker
            if r.RecipeID == 101063 and myrace == "Gnome" then
                local c_string = "Knuckle Joint,29789,1"
                table.insert(quest_component_data, c_string)
            end

            -- Wok
            if r.RecipeID == 101838 and myrace == "Gnome" then
                local c_string = "Clockwork Carapace,29761,1"
                table.insert(quest_component_data, c_string)
            end

            -- No Gnome Tool Logic
            if r.RecipeID == 101251 and myrace ~= "Gnome" then
                table.insert(special_gnome,
                    "We are not able to make the Gem Cutter because we need the services of a Mechanist")
            end
            if r.RecipeID == 11298 and myrace ~= "Gnome" then
                table.insert(special_gnome,
                    "We are not able to make the Dihydrous Oxide Glaciator because we need the services of a Mechanist")
            end
            if r.RecipeID == 35563 and myrace ~= "Gnome" then
                table.insert(special_gnome,
                    "We are not able to make the Geerlok Laminating Device because we need the services of a Mechanist")
            end
            if r.RecipeID == 101062 and myrace ~= "Gnome" then
                table.insert(special_gnome,
                    "We are not able to make the Corking Device because we need the services of a Mechanist")
            end
            if r.RecipeID == 101063 and myrace ~= "Gnome" then
                table.insert(special_gnome,
                    "We are not able to make the Crab Cracker because we need the services of a Mechanist")
            end
            if r.RecipeID == 101838 and myrace ~= "Gnome" then
                table.insert(special_gnome,
                    "We are not able to make the Wok because we need the services of a Mechanist")
            end
        end

        -- for c = 1, #component_max_table do print(component_max_table[c]) end
        -- os.exit()

        db_test_sort:close()
        -- end SQL Tool Section
    end

    -- Sort and Return Component Data
    local c_data = lib.return_sorted_counts_array(quest_component_data)

    print(msg, "\ap[\aoSorting Quest Data List\ap]")

    local c_farm_table = {}
    local c_vend_table = {}

    -- Not used for now, it is a small list for quest
    local q_depot_table = {}

    print(msg, "\ap[\aoGenerating Quest Farm List\ap]")

    for c = 1, #c_data do
        local z_id = lib.return_number(c_data[c], 2)
        local z_count = lib.return_number(c_data[c], 3)
        local z_name = lib.return_string(c_data[c], 1)

        -- Coldain Smithing Hammer
        if z_id == 30140 then z_count = 1 end

        local l_inv_count = mq.TLO.FindItemCount(z_id)()
        local l_bnk_count = mq.TLO.FindItemBankCount(z_id)()

        local l_tot_count = l_inv_count + l_bnk_count

        -- Full Bank
        if l_bnk_count > 0 and l_inv_count < 1 and l_tot_count >= z_count then
            local c_string = z_name .. "," .. z_id .. "," .. z_count
            table.insert(quest_bank_data, c_string)
        end

        -- Partial Bank
        if l_bnk_count > 0 and l_inv_count < 1 and l_tot_count < z_count then
            local c_string = z_name .. "," .. z_id .. "," .. l_bnk_count
            table.insert(quest_bank_data, c_string)
        end

        -- Half and Halfish
        if l_bnk_count > 0 and l_inv_count > 0 and l_tot_count >= z_count and
            l_inv_count < z_count then
            local calc = z_count - l_inv_count
            local c_string = z_name .. "," .. z_id .. "," .. calc
            table.insert(quest_bank_data, c_string)
        end

        local ven = lib.vendor_has_item(z_id)

        -- Generate Quest Farm Table Data
        if ven == 0 then
            if l_tot_count < z_count then
                local c_string = z_name .. "," .. z_id .. "," .. z_count

                -- Skip depot
                local ign_depot = 0

                if mq.TLO.TradeskillDepot.Enabled() and ign_depot == 0 then
                    local tsd_count = mq.TLO.TradeskillDepot
                        .FindItemCount(z_id)()

                    local l_d_calc = 0

                    -- Bank and inventory have something and depot has more than both
                    if l_tot_count > 0 and tsd_count > l_tot_count and tsd_count +
                        l_tot_count >= z_count then
                        -- l_d_calc = tsd_count - l_tot_count
                        l_d_calc = z_count - l_tot_count
                    end

                    -- Bank and inventory have something and depot has less than both
                    if l_tot_count > 0 and tsd_count < l_tot_count and tsd_count +
                        l_tot_count >= z_count then
                        l_d_calc = z_count - l_tot_count
                    end

                    -- Bank and inventory have something and depot has an equal amount
                    if l_tot_count > 0 and tsd_count == l_tot_count and
                        tsd_count + l_tot_count >= z_count then
                        l_d_calc = math.ceil(z_count / 2)
                    end

                    -- Nothing in Bank or Inventory, but we meet or exceed needed count
                    if l_tot_count < 1 and tsd_count >= z_count then
                        l_d_calc = z_count
                    end

                    -- Only add if we have enough for quests
                    if l_d_calc >= z_count then
                        local depot_item = {
                            Name = z_name,
                            ID = z_id,
                            Quantity = l_d_calc
                        }

                        -- print("feeder depot calc need: ",z_count," ", depot_item.Name," ",depot_item.ID," ",depot_item.Quantity)
                        -- Add to quest depot table
                        table.insert(q_depot_table, depot_item)
                    else
                        -- Add to farm table
                        table.insert(c_farm_table, c_string)
                    end
                else
                    -- No Tradeskill Depot, Add to farm table
                    table.insert(c_farm_table, c_string)
                end
            end
        end

        -- Vendor Table to shop
        if ven == 1 then
            local l_vendor_name = nil
            local faction_check = 1

            -- Faction check for vendor
            if z_id == 28021 or z_id == 10425 or z_id == 22564 or z_id == 22098 or
                z_id == 21625 then
                l_vendor_name = lib.return_vendor_name(z_id)
            end

            if l_vendor_name == "Ping Fuzzlecutter" or l_vendor_name ==
                "Nimren Stonecutter" or l_vendor_name == "Talem Tucter" or
                l_vendor_name == "Meg Tucter" then
                faction_check = lib.faction_check(l_vendor_name)
            end

            if faction_check == 0 then
                -- Total Inventory Count < Need Count = Add to farm table
                if l_tot_count < z_count then
                    local c_string = z_name .. "," .. z_id .. "," .. z_count
                    table.insert(c_farm_table, c_string)
                end
            else
                -- No Faction/Faction Good =  Add To Vendor Table
                local c_string = z_name .. "," .. z_id .. "," .. z_count
                table.insert(c_vend_table, c_string)
            end
        end
    end

    print(msg, "\ap[\aoGenerating Quest Shopping List\ap]")

    -- Create Shopping List Section
    local MAX_SHOP_LIST, MAX_ZONE_LIST = {}, {}

    local max_sl = {}

    for c = 1, #c_vend_table do
        local vi = lib.return_number(c_vend_table[c], 2)
        local vic = lib.return_number(c_vend_table[c], 3)
        local s_data_string = lib.return_vendor_data(vi, vic)
        table.insert(max_sl, s_data_string)
    end

    table.sort(max_sl)

    MAX_SHOP_LIST = max_sl

    local zone_array = {}

    -- Extract Zone ID
    for c = 1, #max_sl do
        local zone_id = lib.return_number(max_sl[c], 1)
        local zone_name = mq.TLO.Zone(zone_id)()
        table.insert(zone_array, zone_name)
    end

    -- Remove Duplicate Zone ID
    zone_array = removeDuplicates(zone_array)

    table.insert(zone_array, 1, "ALL")

    MAX_ZONE_LIST = zone_array

    MAX_SHOP_LIST = tcn_req.cleanse_purchased_tools(MAX_SHOP_LIST)
    -- End Shopping List Section

    print(msg, "\ap[\aoGenerating Mass Quest Shopping List\ap]")

    local temp_bank_quest_table = {}

    for c = 1, #quest_bank_data do
        local id = lib.return_number(quest_bank_data[c], 2)
        local count = lib.return_number(quest_bank_data[c], 3)
        local name = lib.return_string(quest_bank_data[c], 1)
        table.insert(temp_bank_quest_table, string.format('("%s", %d, %d)',
            name:gsub("'", "''"),
            id, count))
    end

    if quest_bank_data[1] ~= nil then
        quest_bank_data = lib.SQL_Bank_Array(temp_bank_quest_table)
    end

    GLOBAL_TEXT = "Processing Data..."

    local temp_global_array = lib.SQL_Sort_Array(c_farm_table)

    --- os.exit()

    c_farm_table = temp_global_array
    temp_global_array = {}

    -- Don't do recipe IDs for batch data
    local do_not = 0
    if do_not == 1 then
        local quest_c_table = {}
        -- test table for sql
        for x = 1, #quest_recipe_data do
            -- print(batch_recipe_data[x]) os.exit()
            local ItemID = lib.return_number(quest_recipe_data[x], 1)
            local RecipeName = lib.return_string(quest_recipe_data[x], 2)
            local Set_counts = lib.return_number(quest_recipe_data[x], 3)
            local Recipe_ID = lib.return_number(quest_recipe_data[x], 4)
            table.insert(quest_c_table, string.format('(%d,"%s",%d, %d)',
                ItemID, RecipeName,
                Recipe_ID, Set_counts))
        end
        --  for c = 1,#batch_c_table do print("test ",batch_c_table[c]) end os.exit()

        local dbw = sqlite3.open(":memory:")
        dbw:exec(
            "DROP TABLE IF EXISTS QUESTCALC;CREATE TEMP TABLE QUESTCALC (ItemID,RecName,ID,Count);")
        -- mq.delay(1)
        local quest_insert_array = {}
        local insert = table.concat(quest_c_table, ", ")
        -- for c  =1 ,#batch_c_table do print(batch_c_table[c]) end
        dbw:exec(string.format(
            "INSERT INTO QUESTCALC ('ItemID','RecName','ID', 'Count') VALUES %s;",
            insert))
        for x in dbw:nrows(
            "SELECT RecName,ItemID,ID,SUM(Count) AS Count FROM QUESTCALC GROUP BY ID") do
            local l_count = x.Count
            local is_crafted = lib.toolcheck(x.ID)
            if is_crafted == 1 then
                -- print("original count is:", x.Count)
                l_count = 1
            end
            --         print(x.ItemID, " ", x.RecName, " ", x.ID, " ", l_count)
            table.insert(quest_insert_array,
                x.ItemID .. "," .. x.RecName .. "," .. l_count .. "," ..
                x.ID)
        end

        dbw:close()

        quest_recipe_data = quest_insert_array
    end

    if special_gnome[1] ~= nil then
        print(msg,
            "\arIf this is a quest we will not be able to complete it based on:")
        for c = 1, #special_gnome do
            print(msg, "\ay" .. special_gnome[c])
        end
    end

    if MAX_SHOP_LIST[1] == nil then
        print(msg, "\ap[\agNo Items to shop for\ap]")
    end

    -- Convert to ID, NAME, QUANTITY FORMAT
    local converted_quest_shopping_data = convert_shopping_data(MAX_SHOP_LIST)

    local converted_quest_farm_data = convert_farm_data(c_farm_table)

    print(msg, "Processing Complete")

    -- for c = 1 ,#c_farm_table do print(c_farm_table[c]) end os.exit()

    return c_farm_table, MAX_SHOP_LIST, MAX_ZONE_LIST, quest_bank_data,
        converted_quest_shopping_data, converted_quest_farm_data
end

-- Determine if prize.db is proper size
function tcn_req.prize_data_check()
    local count = 0
    local path = mq.luaDir .. "\\TCN\\prize.db"
    for line in io.lines(path) do count = count + 1 end
    if count < 1 then
        print(msg,
            "Please extract prize.zip and overwrite existing prize.db file in: " ..
            mq.luaDir .. "\\TCN\\")
        mq.exit()
    end
    return
end

function tcn_req.run_max_list(p_max_array)
    if GLOBAL_ABORT_FLAG == 1 then return end

    local end_tick

    local start_tick = GLOBAL_MAX_START

    if GLOBAL_MAX_GEN ~= 0 then
        end_tick = GLOBAL_MAX_GEN + start_tick
    else
        end_tick = #p_max_array
    end

    if end_tick > #p_max_array then end_tick = #p_max_array end

    if start_tick < 1 then start_tick = 1 end
    if start_tick >= end_tick then start_tick = end_tick end

    for max_iter = start_tick, end_tick do
        -- for max_iter = 1, 3 do
        if GLOBAL_ABORT_FLAG == 1 then break end
        GLOBAL_MAX_RECIPE_COUNT = max_iter

        -- Meteorlogical Rocket
        -- local sub_id = 2223
        -- sub_id = 63767
        -- tcn_req.max_crafting_routine(sub_id)
        -- os.exit()

        if GLOBAL_MAX_CRAFT_ROUTINE == 1 then
            tcn_req.max_crafting_routine(p_max_array[max_iter])
        else
            tcn_req.full_max_crafting_routine(p_max_array[max_iter])
        end

        GLOBAL_MAX_RECIPE = "Nothing"
        mq.delay(1)
        -- if GLOBAL_MAX_TIMER > 0 then mq.delay(GLOBAL_MAX_TIMER * 1000) end
        -- Break after 1 recipe
        -- local tt = 1 if tt == 1 then break end
    end

    GLOBAL_TEXT = "Finished Maxin' and Relaxin'"

    lib.swap_ammo_slot_back(GLOBAL_AMMO_SLOT)
    --   ammo_swap_slot(GLOBAL_AMMO_SLOT)
    -- Fishing
    lib.return_primary_item()

    shop.return_bank_shopping()

    shop.return_depot()

    -- Return stuff to bank, return perishable ts from list?
    GLOBAL_MAX_CRAFTING = 0

    if GLOBAL_ABORT_FLAG == 1 then return end
    return
end

-- Shrink using ability or ROA?
function tcn_req.shrink_methods()
    local l_race = { "Ogre", "Werewolf", "Troll", "Sarnak", "Iksar" }
    local me_race = mq.TLO.Me.Race()
    local l_race_match
    for u = 1, #l_race do if l_race[u] == me_race then l_race_match = 1 end end
    -- Attempt to shrink
    if l_race_match == 1 then
        if mq.TLO.Me.AltAbilityReady('Shrink')() then
            print(" \agUsing: \ayShrink")
            mq.cmd('/target ' .. mq.TLO.Me())
            mq.delay(1000)
            mq.cmd('/alt act 675')
            mq.delay(500)
        else
            -- Use ROA to shrink
            if mq.TLO.FindItemCount(67098)() > 0 then
                if mq.TLO.FindItem(67098).TimerReady() == 0 then
                    print(" \agUsing: \ayRing of the Ancients")
                    mq.cmd('/target ' .. mq.TLO.Me())
                    mq.delay(1000)
                    local str = "Ring of the Ancients"
                    mq.cmd('/useitem ', str)
                    mq.delay(500)
                end
            end
        end
    end
    return
end

function tcn_req.deposit_tools_trophies()
    movement.bank()

    while mq.TLO.Nav.Active() do mq.delay(1) end
    mq.delay(1000)

    if not mq.TLO.Window('BigBankWnd').Open() then
        mq.cmd('/nomodkey /click right target')
        mq.delay(1000)
    end

    shop.return_bank_shopping()

    shop.return_depot()

    return
end

function tcn_req.Load_Artisan_Array()
    local ts_artisan_quests = {
        "Baking Supplies", "Brewing Supplies", "Tailoring Supplies",
        "Smithing Supplies", "Fletching Supplies", "Fishing Supplies",
        "Jewelcrafting Supplies", "Pottery Supplies", "Poisoncrafting Supplies",
        "Tinkering Supplies", "Research Supplies", "Alchemy Supplies"
    }

    local artisan_array = {}
    for c = 1, #ts_artisan_quests do
        --   print (ts_artisan_name[c])
        if mq.TLO.Task(ts_artisan_quests[c]).ID() ~= nil then
            --    print(mq.TLO.Task(ts_artisan_name[c]).ID())
            local ts_id = mq.TLO.Task(ts_artisan_quests[c]).ID()
            local ts_name = mq.TLO.Task(ts_artisan_quests[c]).Title()
            table.insert(artisan_array, ts_name)
            --  print(mq.TLO.Task(ts_artisan_name[c]).Title())
        end
        -- print (mq.TLO.Task("Fishing Supplies").ID())
    end
    return artisan_array
end

function tcn_req.Load_Alliance_Array()
    local ts_alliance_quest = { "The New Tanaan Merchant Alliance" }

    local alliance_array = {}
    for c = 1, #ts_alliance_quest do
        --   print (ts_artisan_name[c])
        if mq.TLO.Task(ts_alliance_quest[c]).ID() ~= nil then
            --    print(mq.TLO.Task(ts_artisan_name[c]).ID())
            local ts_id = mq.TLO.Task(ts_alliance_quest[c]).ID()
            local ts_name = mq.TLO.Task(ts_alliance_quest[c]).Title()
            table.insert(alliance_array, ts_name)
            --  print(mq.TLO.Task(ts_alliance_quest[c]).Title())
        end
        -- print (mq.TLO.Task("The New Tanaan Merchant Alliance").ID())
    end
    return alliance_array
end

function tcn_req.deliver_artisan(p_quest_name)
    local p_quest_id = mq.TLO.Task(p_quest_name).ID()

    if p_quest_id == nil or p_quest_id == 0 then
        GLOBAL_TEXT = "We don't have that quest, try again"
    end

    lib.Turn_In(p_quest_id, p_quest_name)
    mq.delay(1)
    return
end

-- script status
function tcn_req.script_status(p_script_name)
    mq.delay(1500)
    p_script_name = 'tcn/tcn_quests'
    -- print(mq.TLO.Lua.Script(string.upper(p_script_name)).Status())
    while mq.TLO.Lua.Script(string.upper(p_script_name)).Status() == "RUNNING" do
        mq.delay(100)
    end
    mq.delay(1000)
    -- print(GLOBAL_AMMO_SLOT)
    lib.swap_ammo_slot_back(GLOBAL_AMMO_SLOT)
    --    ammo_swap_slot(GLOBAL_AMMO_SLOT)
    -- Fishing
    lib.return_primary_item()
    mq.delay(1000)
    shop.return_bank_shopping()
    shop.return_depot()
    mq.delay(1000)
    return
end

-- Return recipe name to TCG call
function tcn_req.recipe_name(p_id)
    local l_rec_name = lib.return_recipe_name(p_id)
    return l_rec_name
end

-- Return recipe ID to TCG call
function tcn_req.recipe_id(p_id)
    local l_rec_id = lib.return_recipe_item_id(p_id)
    return l_rec_id
end

-- Mass bank shopping added 3/30/2022 JB321
function tcn_req.mass_bank_shop(p_array)
    local temp_array = {}

    for c = 1, #p_array do table.insert(temp_array, p_array[c]) end

    local n_array = {}

    for c = 1, #temp_array do
        local item_name = temp_array[c].Name
        local item_count = temp_array[c].Quantity
        local item_id = temp_array[c].ID

        if string.find(item_name, "@") then
            item_name = item_name:gsub('@', ',')
        end

        local bank_item_count = mq.TLO.FindItemBankCount(item_id)()
        local bank_item_stack_size = mq.TLO.FindItemBank(item_id).StackSize()
        local bank_item_type = mq.TLO.FindItemBank(item_id).Type()

        -- print(bank_item_type)

        local consume_flag = 0

        if bank_item_type == "Drink" or bank_item_type == "Food" then
            consume_flag = 1
        end
        -- Set grab size
        if bank_item_count < bank_item_stack_size and item_count > 1 then
            item_count = bank_item_count
        end
        -- Set by stack size if not food or drink
        if bank_item_count >= bank_item_stack_size and item_count > 1 and
            consume_flag == 0 then
            item_count = bank_item_stack_size
        end

        -- If we have 2 laminator rollers we grab em
        if bank_item_count > 1 and item_id == 96489 then item_count = 2 end

        local bank_shop_string = item_name .. "," .. item_id .. "," ..
            item_count

        table.insert(n_array, bank_shop_string)
    end

    -- MASS
    -- for c = 1, #n_array do print(n_array[c]) end
    shop.go_bank_shopping(n_array)

    return
end

-- Read shopping list directory and return array
function tcn_req.scandir()
    local directory = mq.luaDir .. "\\TCN\\ShoppingLists"
    local i, t, popen = 0, {}, io.popen
    local pfile = popen('dir "' .. directory .. '" /d')
    for filename in pfile:lines() do
        if string.find(filename, ".csv") and string.find(filename, "_MSL") then
            i = i + 1
            t[i] = filename
        end
    end
    pfile:close()
    return t
end

-- Scan files with batch_
function tcn_req.b_scandir()
    local directory = mq.luaDir .. "\\TCN\\Batch"
    local i, t, popen = 0, {}, io.popen
    local pfile = popen('dir "' .. directory .. '" /b')

    for filename in pfile:lines() do
        if string.find(filename, ".csv") and string.find(filename, "batch_") then
            i = i + 1
            t[i] = filename
        end
    end
    pfile:close()
    return t
end

-- JB321 Added 3/31/2022
-- Load Shopping list data from file
function tcn_req.LOAD_MSL(p_data)
    local l_array = lib.LOAD_SL(p_data)
    local z_array = {}

    -- Extract Zone ID
    for c = 1, #l_array do
        local zone_name = l_array[c].VendorItemZone
        table.insert(z_array, zone_name)
    end

    -- Remove Duplicate Zone ID
    z_array = removeDuplicates(z_array)

    -- Insert ALL into Zone Table
    table.insert(z_array, 1, "ALL")

    return l_array, z_array
end

-- Grab from Guild Hall
function tcn_req.GUILD_HALL_BANKING(p_need_array)
    -- Move to GH
    movement.ngh()
    mq.delay(1)
    -- Move/Target/Open GH Banker
    movement.gh_banker()
    mq.delay(1)
    -- Generate GH Inventory
    local gh_inv = gh_inventory()

    -- Simulated need
    -- local item = {Name = "Crystallized Sulfur", Count = 21}
    -- table.insert(p_need_array, item)
    -- item = {Name = "Fine Feathers", Count = 1}
    -- table.insert(p_need_array, item)

    local gh_grab_table = {}

    for c = 1, #p_need_array do
        --  print(p_gh_array[c].Name, " ", p_gh_array[c].Count)
        for d = 1, #gh_inv do
            --  print(gh_inv[d].Name, " ", gh_inv[d].Count)
            if p_need_array[c].Name == gh_inv[d].Name and gh_inv[d].Count > 0 then
                local need_count = p_need_array[c].Count
                local l_inv_count = mq.TLO.FindItemCount('=' ..
                    p_need_array[c]
                    .Name)()

                if l_inv_count > 0 then
                    need_count = need_count - l_inv_count
                end

                local have_count = gh_inv[d].Count
                local set_count = 0

                if need_count > 0 then
                    if have_count <= need_count then
                        set_count = have_count
                    else
                        if have_count > need_count then
                            set_count = need_count
                        end
                    end
                end

                local array_item = {
                    Name = p_need_array[c].Name,
                    Count = set_count
                }
                if set_count > 0 then
                    table.insert(gh_grab_table, array_item)
                end
            end
        end
    end

    for c = 1, #gh_grab_table do
        print(msg, "\ap[\agGrabbing\ap] \ap[(\ay", gh_grab_table[c].Count,
            "\ap)] \ap[\aw", gh_grab_table[c].Name,
            "\ap] \ap[\ayGuild Bank\ap]")
        GLOBAL_TEXT = "Grabbing " .. gh_grab_table[c].Name .. " From Guild Bank"
        lib.GrabGuildItemName(gh_grab_table[c].Name, gh_grab_table[c].Count)
        lib.ClearCursor()
        mq.delay(300)
    end

    -- Clear Array and Remove Button
    MASS_gh_bank_array = {}

    mq.delay(1000)

    mq.cmd('/cleanup')

    GLOBAL_TEXT = "Idle"

    return
end

function tcn_req.ccr(passed_id)
    local result = lib.check_container_requirement(passed_id)
    return result
end

-- convert array to SQL max farm list
function tcn_req.sql_convert_max(p_array)
    local sql_data = lib.return_max_farm_list_sql(p_array)
    return sql_data
end

-- Grab from Dragon Hoard
function tcn_req.DRAGON_HOARD_BANKING(p_need_array)
    movement.bank()

    mq.delay(1)
    -- Open Bank Window
    if not mq.TLO.Window('BigBankWnd').Open() then
        mq.cmd('/nomodkey /click right target')
        mq.delay(1000)
    end

    -- Click Dragon Hoard
    if not mq.TLO.Window('DragonHoardWnd').Open() and mq.TLO.MacroQuest.Server() ==
        "rizlona" then
        mq.cmd('/notify BankWnd BW_DragonHoard leftmouseup')
        mq.delay(1000)
    else
        if not mq.TLO.Window('DragonHoardWnd').Open() then
            mq.cmd('/notify BigBankWnd BIGB_DragonHoard leftmouseup')
            mq.delay(1000)
        end
    end

    mq.delay(1)
    -- Generate Dragon Hoard Inventory
    local dh_inv = hoard_inventory()
    -- Simulated need
    -- local item = {Name = "Cup of Flour", Count = 2321}
    -- table.insert(p_need_array, item)
    -- item = {Name = "Fine Feathers", Count = 1}
    -- table.insert(p_need_array, item)

    local dh_grab_table = {}

    for c = 1, #p_need_array do
        --  print(dh_grab_table[c].Name, " ", dh_grab_table[c].Count)
        for d = 1, #dh_inv do
            --  print(dh_inv[d].Name, " ", dh_inv[d].Count)
            if p_need_array[c].Name == dh_inv[d].Name and dh_inv[d].Count > 0 then
                local need_count = p_need_array[c].Count
                local l_inv_count = mq.TLO.FindItemCount('=' ..
                    p_need_array[c]
                    .Name)()

                if l_inv_count > 0 then
                    need_count = need_count - l_inv_count
                end

                local have_count = dh_inv[d].Count
                local set_count = 0

                if need_count > 0 then
                    if have_count <= need_count then
                        set_count = have_count
                    else
                        if have_count > need_count then
                            set_count = need_count
                        end
                    end
                end

                local array_item = {
                    Name = p_need_array[c].Name,
                    Count = set_count
                }
                if set_count > 0 then
                    table.insert(dh_grab_table, array_item)
                end
            end
        end
    end

    for c = 1, #dh_grab_table do
        print(msg, "\ap[\agGrabbing\ap] \ap[(\ay", dh_grab_table[c].Count,
            "\ap)] \ap[\aw", dh_grab_table[c].Name,
            "\ap] \ap[\ayDragon Hoard\ap]")
        GLOBAL_TEXT = "Grabbing " .. dh_grab_table[c].Name ..
            " From Dragon Hoard"
        lib.GrabHoardItemName(dh_grab_table[c].Name, dh_grab_table[c].Count)
        lib.ClearCursor()
        mq.delay(300)
    end

    -- Clear Array and Remove Button
    MASS_dh_bank_array = {}

    mq.delay(1000)

    mq.cmd('/cleanup')

    GLOBAL_TEXT = "Idle"

    return
end

-- Sell all items in SellTable from Artisan.DB
function tcn_req.SellEverything()
    -- Open the Sell.db SQLite database located in the TCN folder under the MQ Lua directory
    local dbs = sqlite3.open(mq.luaDir .. '\\TCN\\Sell.db')

    -- SQL query to select all sellable items:
    --  - ItemNoSale < 1 means the item is allowed to be sold
    --  - ItemID != 0 ensures the item has a valid ID
    --  - Ordered alphabetically by ItemName for display purposes
    local sql_string =
    "SELECT * FROM SellTable WHERE ItemNoSale < 1 AND ItemID !=0 ORDER BY ItemName ASC"

    -- Table to hold the list of items we actually have in inventory and will sell
    local m_table = {}

    -- Inform the user that we are starting the list creation process
    print(msg, "Creating list of items to sell")

    -- Iterate over each row returned by the SQL query
    for r in dbs:nrows(sql_string) do
        -- Get the count of this item in the player's inventory
        local count = mq.TLO.FindItemCount(r.ItemID)()
        -- Only proceed if we have at least one of this item
        if count > 0 then
            -- Store the count in a local variable (kept for clarity)
            local ItemCount = count
            -- Create a table (record) representing this item
            local item = {
                ItemName = r.ItemName, -- Name of the item
                ItemID = r.ItemID,     -- Unique item ID
                ItemCount = ItemCount  -- Quantity in inventory
            }
            -- Append this item record to m_table
            table.insert(m_table, item)
        end
    end

    -- Debug loop (currently commented out) to print raw item data
    for c = 1, #m_table do
        -- print("f: ", m_table[c].ItemID, " ", m_table[c].ItemCount, " n: ",
        --       m_table[c].ItemName)
    end

    -- Another debug print (commented out) to show how many items are in m_table
    -- print(#m_table)

    -- Loop through the table and print each item in a formatted, color-coded way
    for c = 1, #m_table do
        print(msg, "\atID: \ao(\ag", m_table[c].ItemID, "\ao) \ag(",
            m_table[c].ItemCount, ") \at", m_table[c].ItemName)
    end

    -- Print the total number of items we are about to sell
    print(msg, "We have \ap\ag[" .. #m_table .. "\ap]\aw items to sell.")

    -- os.exit() -- commented out; would terminate the script here if uncommented

    -- Iterate through each item and send it to the vendor
    for d = 1, #m_table do
        -- Call the shop API to sell the item by ID, specifying the quantity and vendor slot (1)
        shop.sell_item_ID_to_vendor(m_table[d].ItemID, m_table[d].ItemCount, 1)
        -- Small delay between sales to avoid overwhelming the game/vendor
        mq.delay(300)
    end

    -- Wait 1 second before cleanup
    mq.delay(1000)
    -- Run the /cleanup command to tidy up inventory (likely removes empty bags, stacks items, etc.)
    mq.cmd('/cleanup')
    -- Wait 2 seconds to allow cleanup to finish
    mq.delay(2000)

    -- Final confirmation message to the user
    print(msg, "Mass Selling Process Complete")

    -- Close the database connection to free the file handle
    dbs:close()
end

return tcn_req
