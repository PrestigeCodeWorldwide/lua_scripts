-- tcn_alliance_movement.lua
-- description - does initial hail steps for merchant alliance quest
-- date 10/18/2022
-- upd
-- creator: jb321
local mq = require('mq')
local movement = require('tcn_movement')

local function Alliance_Movement_Steps()
    movement.npc("Kerst")
    movement.moving()
    mq.cmd('/keypress hail')
    mq.delay(1000)
    movement.npc("Jeann")
    movement.moving()
    mq.cmd('/keypress hail')
    mq.delay(1000)
    movement.npc("Morgyn")
    movement.moving()
    mq.cmd('/keypress hail')
    mq.delay(1000)
    movement.npc("Kerst")
    movement.moving()
    mq.cmd('/keypress hail')
    mq.delay(1000)
    return
end

Alliance_Movement_Steps()
