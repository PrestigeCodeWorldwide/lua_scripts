-- tcn_trophy_quest_engine
-- date 10/26/2021
-- upd 2/23/2023
-- v0.6b
-- creator jb321
local mq = require('mq')
local lib = require('tcn_library')
local movement = require('tcn_movement')

local function trophy_stuff(p_args, p_deposit)

    -- Run trophy quest

    -- Get associated skill based on task
    local fv_tskill = lib.return_skill(p_args)

    local msg = "\at[\aoTCSNe\agX\aot\at]\aw "

    -- Do the freebie
    if mq.TLO.Me.Skill(fv_tskill)() < 50 then

        local quest_num = tonumber(lib.return_god_quest_number(fv_tskill))

        print(msg,
              "Our skill is too low to get the trophy quest, let's fix that")
           
        if quest_num ~= nil then
            -- Run the GOD freebie
            
              -- print(fv_tskill," ", quest_num)

            mq.cmd('/squelch /lua run tcn/tcn_god ', quest_num)
        else
            if fv_tskill == "Research" and mq.TLO.Me.Skill('Research')() > 0 then
                -- Run the TSS Research freebie
                if mq.TLO.Me.Skill('Research')() ~= nil then
                    mq.cmd('/lua run tcn/tcn_tss 11')
                end
            end
        end

        while mq.TLO.Lua.Script('tcn/tcn_tss').Status() == "RUNNING" do
            -- wait for script to end
            mq.delay(100)
        end

          while mq.TLO.Lua.Script('tcn/tcn_god').Status() == "RUNNING" do
            -- wait for script to end
            mq.delay(100)
        end
        
        movement.pok()

    end

    local fv_have_task = lib.match_task(p_args)

    if fv_have_task == nil then
        --  print(msg, "\ayDon't have: \aw", task_result, " Task")
        if lib.match_task(p_args) == nil then
            --   print(msg, "We were unable to get: ", task_result)
        end
    end

    local p_task_result = p_args

    print(msg, "\ag[Attempting] \ap[\aw", p_task_result, "\ap]")

    -- Task is already running end it or ignore?

    mq.cmd('/lua run tcn/tcn_quests ',
           "'" .. p_task_result .. "'," .. p_deposit)
    mq.delay(1)
    return
end

local args = ...

local s1 = lib.return_string(args, 1)
local n1 = lib.return_number(args, 2)

s1 = s1:gsub('"', '')

-- print("passed ", args)

trophy_stuff(s1, n1)

