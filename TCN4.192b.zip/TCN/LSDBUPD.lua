-- DB Update for New Everquest Expansion - Laurion's Song
-- Update Vendor Tables in regular DB.. because reasons.
-- Created (Template): 9/10/2022
-- Updated: 12/17/2024
-- Author: jb321
-- Version 2.2b
--
-- Note: Artisan.DB cannot be in use, exit out of TCSNeXt prior.
local mq = require('mq')

local PackageMan = require('mq/PackageMan')
local sqlite3 = PackageMan.Require('lsqlite3')

-- local sqlite3 = require('lsqlite3')

local db = sqlite3.open(mq.luaDir .. '\\TCN\\Artisan.db')
local dbls = sqlite3.open(mq.luaDir .. '\\LSUPD.db')

local msg = "\ap[\atTCSNe\auX\att\ap]\aw "

local status
-- Clear screen
-- mq.cmd('/mqclear')

print(msg, "Laurion's Song Recipe Database Update")

mq.delay(100)

-- Delete existing entries in Artisan.DB for updates/changes/fixes

-- Delete all occurences from Master Recipe Table based on expansion
status = db:exec("DELETE FROM MasterRecipeTable WHERE Expansion = 'LSO'")

-- Array of LS Recipe IDs
local recipe_array = {
    39095, 39096, 39097, 39098, 39099, 39100, 39101, 39102, 39103, 39104, 39105,
    39106, 39107, 39108, 39109, 39110, 39111, 39112, 39113, 39114, 39115, 39116,
    39117, 39118, 39119, 39120, 39121, 39122, 39123, 39124, 39125, 39126, 39127,
    39128, 39129, 39130, 39131, 39132, 39133, 39134, 39135, 39136, 39137, 39138,
    39139, 39140, 39141, 39142, 39143, 39144, 39145, 39146, 39147, 39148, 39149,
    39150, 39151, 39152, 39153, 39154, 39155, 39156, 39157, 39158, 39159, 39160,
    39161, 39162, 39163, 39164, 39165, 39166, 39167, 39168, 39169, 39170, 39171,
    39172, 39173, 39174, 39175, 39176, 39177, 39178, 39179, 39180, 39181, 39182,
    39183, 39184, 39185, 39186, 39187, 39188, 39189, 39191, 39192, 39193, 39194,
    39195, 39196, 39197, 39198, 39199, 39200, 39201, 39202, 39203, 39204, 39205,
    39206, 39207, 39208, 39209, 39210, 39211, 39212, 39213, 39214, 39215, 39569,
    39570, 39571, 39572, 39573, 39574, 39575, 39576, 39577, 39578, 39579, 39580,
    39581, 39582, 39583, 39584, 39585, 39586, 39587, 39588, 39589, 39590, 39591,
    39592, 39593, 39594, 39595, 39596, 39597, 39598, 39599, 39600, 39601, 39602,
    39603, 39604, 39605, 39606, 39607, 39608, 39609, 39610, 39611, 39612, 39613,
    39614, 39615, 39616, 39617, 39618, 39619, 39620, 39621, 39622, 39623, 39624,
    39625, 39626, 39627, 39628, 39629, 39630, 39631, 39632, 39633, 39642,
    5138123, 5138124, 117001, 117002, 117003, 117004, 117005, 117006, 23828,
    23829, 23830, 23831, 25739, 25738, 25743, 25740, 25737, 25742, 25747, 25744,
    25745, 25741, 25746, 23832, 25750, 25749, 25754, 25751, 25748, 25753, 25758,
    23835, 25755, 25756, 23833, 23834, 25752, 25757, 39190, 39643
}

-- Testing for regular Artisan DB with no LSO/NOS
-- 43998 Recipes
-- 192315 Components

-- Delete all occurences from Master Component Table matching the RecipeID
local dbCommand = string.format(
                      "DELETE FROM MasterCompTable WHERE RecipeID IN (%s)",
                      table.concat(recipe_array, ", "))

status = db:exec(dbCommand)

print(msg, "Removing previous Laurion's Song Recipe Database Entries")

-- Remove -- to clear data and not add to DB
 -- db:close() mq.exit()

print(msg, "Updating Master Recipe Table")

mq.delay(100)

local master_recipe_entry = {}
for z in dbls:nrows("SELECT * FROM MasterRecipeTable") do
    local a = z.RecipeID
    local b = z.ItemID
    local c = z.RecipeName
    local d = z.Trivial
    local e = z.Yield
    local f = z.Container
    local g = z.Skill
    local h = z.Bugged
    local i = z.ReqSkill
    local j = z.ReqRace
    local k = z.ReqClass
    local l = z.KDSB
    local m = z.Requirement
    local n = z.Notes
    local o = z.Action
    local p = z.What
    local q = z.Who
    local r = z.Where
    local s = z.Expansion

    if h == nil then h = 0 end
    if i == nil then i = 0 end
    if j == nil then j = "NA" end
    if k == nil then k = "NA" end
    if l == nil then l = "NA" end
    if m == nil then m = "NA" end
    if n == nil then n = "NA" end
    if o == nil then o = "NA" end
    if p == nil then p = "NA" end
    if q == nil then q = "NA" end
    if r == nil then r = "NA" end

    c = '"' .. c .. '"'
    f = '"' .. f .. '"'
    g = '"' .. g .. '"'

    j = '"' .. j .. '"'
    k = '"' .. k .. '"'
    l = '"' .. l .. '"'
    m = '"' .. m .. '"'
    n = '"' .. n .. '"'
    o = '"' .. o .. '"'
    p = '"' .. p .. '"'
    q = '"' .. q .. '"'
    r = '"' .. r .. '"'
    s = '"' .. s .. '"'

    local sql_format_string = "(" .. a .. "," .. b .. "," .. c .. "," .. d ..
                                  "," .. e .. "," .. f .. "," .. g .. "," .. h ..
                                  "," .. i .. "," .. j .. "," .. k .. ", " .. l ..
                                  ", " .. m .. "," .. n .. "," .. o .. ", " .. p ..
                                  "," .. q .. "," .. r .. "," .. s .. ")"

    -- print("\ag", sql_format_string)

    table.insert(master_recipe_entry, sql_format_string)

end

-- local sql_format_string =
-- "(31227, 159832, 'Luclin Toast', 466, 1, 'Oven', 'Baking', 0, 0, 'NA', 'NA', 'NA','NA', 'NA', 'NA', 'NA', 'NA','NA','LSO')"

mq.delay(1)

local insert = table.concat(master_recipe_entry, ", ")

mq.delay(1)

-- Insert Recipe Information Into Master Recipe Table
status = db:exec(string.format(
                     "INSERT INTO MasterRecipeTable ('RecipeID','ItemID','RecipeName','Trivial','Yield','Container','Skill','Bugged','ReqSkill','ReqRace','ReqClass','KDSB','Requirement','Notes','Action','What','Who','Where','Expansion') VALUES %s;",
                     insert))

if status == 0 then print(msg, "Master Recipe Table Updated: \agSuccessful") end

mq.delay(100)

print(msg, "Added: \ag(", #master_recipe_entry, "\aw) New Recipes")

-- Update Component Table
print(msg, "Updating Master Component Table")
mq.delay(100)
local component_entry = {}
for z in dbls:nrows("SELECT * FROM MasterCompTable") do
    local a = z.RecipeID
    local b = z.ItemName
    local c = z.ItemID
    local d = z.SubRecipeID
    local e = z.ItemCount
    local f = z.CRecipeName

    b = '"' .. b .. '"'
    f = '"' .. f .. '"'

    local sql_format_string = "(" .. a .. "," .. b .. "," .. c .. "," .. d ..
                                  "," .. e .. "," .. f .. ")"
    -- print("\ay",sql_format_string)
    table.insert(component_entry, sql_format_string)
end

insert = table.concat(component_entry, ", ")

status = db:exec(string.format(
                     "INSERT INTO MasterCompTable ('RecipeID','ItemName','ItemID','SubRecipeID','ItemCount','CRecipeName') VALUES %s;",
                     insert))

if status == 0 then print(msg, "Master Component Table Updated: \agSuccessful") end

print(msg, "Added: \ag(", #component_entry, "\aw) Components")

print(msg, "Finished")
db:close()
dbls:close()
