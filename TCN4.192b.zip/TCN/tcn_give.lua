-- tcn_give 1.3b
-- author jb321
-- date 10/14/2021
-- updated 11/29/2023

local mq = require('mq')
local lib = require('tcn_library')

local function return_number(str, int)
    local counter = 0
    for number in string.gmatch(str, '([^,]+)') do
        counter = counter + 1
        if counter == int then return tonumber(number) end
    end
    return
end

mq.delay(1000)

local args = ...
args = string.gsub(args, '"', '')
-- print(args)
local item_id = return_number(args, 1)
local item_qty = return_number(args, 2)
local pc_id = return_number(args, 3)

-- Close Depot Window
if mq.TLO.Window('TradeskillDepotWnd').Open() then
    mq.TLO.Window('TradeskillDepotWnd').DoClose()
    mq.delay(1000)
end

-- Close Bank window
if mq.TLO.Window('BigBankWnd').Open() then
    mq.delay(1000)
    mq.TLO.Window('BigBankWnd').DoClose()
    -- mq.cmd('/notify BigBankWnd BIGB_DoneButton leftmouseup')
    mq.delay(1000)
end

-- Close Find Item Window
if mq.TLO.Window('FindItemWnd').Open() then
    -- Reset
    mq.cmd('/notify FindItemWnd FIW_Default leftmouseup')
    mq.delay(1000)
    mq.TLO.Window('FindItemWnd').DoClose()
    mq.delay(1000)
end

-- Close Inventory
if mq.TLO.Window('InventoryWindow').Open() then
    mq.TLO.Window('InventoryWindow').DoClose()
    mq.delay(1000)
end

mq.delay(1000)

-- Run to requester
mq.cmd('/squelch /nav spawn id ' .. pc_id .. ' | dist=20')
while mq.TLO.Nav.Active() do mq.delay(1) end
mq.delay(500)
-- Target the requester
mq.cmd('/target ='.. mq.TLO.Spawn(pc_id)())
mq.delay(500)
-- Pick up requested item and quantity
lib.GrabItemID(item_id, item_qty)
mq.delay(500)

--Re-target
--mq.cmd('/target ' .. mq.TLO.Spawn(pc_id)())
--mq.delay(500)

-- Open Give Window
if not mq.TLO.Window('GiveWnd').Open() then
    mq.cmd('/doevents')
    mq.cmd('/click left target')
    mq.delay(1000)
end
mq.delay(1500)
-- Click Trade
mq.cmd('/notify TradeWnd TRDW_Trade_Button leftmouseup')
mq.delay(500)
return
