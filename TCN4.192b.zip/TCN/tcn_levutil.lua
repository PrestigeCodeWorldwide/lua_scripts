-- lev tool - keeps you unlev'd
local mq = require('mq')

local function drop_levitation_buffs()
    for i = 1, 42 do
        if mq.TLO.Me.Buff(i)() ~= nil then
            -- print(mq.TLO.Me.Buff(i).HasSPA(57)(), " ", mq.TLO.Me.Buff(i))
            if mq.TLO.Me.Buff(i).HasSPA(57)() then
                -- mq.cmd('/removebuff ', mq.TLO.Me.Buff(i))
                mq.cmd('/removelev')
            end
            mq.delay(1)
        end
    end

    for i = 1, 30 do
        if mq.TLO.Me.Song(i)() ~= nil then
            -- print(mq.TLO.Me.Song(i).HasSPA(57)(), " ", mq.TLO.Me.Song(i))
            if mq.TLO.Me.Song(i).HasSPA(57)() then
                -- mq.cmd('/removebuff ', mq.TLO.Me.Song(i))
                mq.cmd('/removelev')
            end
            mq.delay(1)
        end
    end
end

local end_time = 0
local start_time = os.time()

-- Check and drop levitation every five seconds
while true do
    end_time = os.time()
    local elapsed_time = os.difftime(end_time, start_time)
    if elapsed_time == 5 then
        drop_levitation_buffs()
        start_time = os.time()
    end
    if not (mq.TLO.Lua.Script('tcn').Status() == "RUNNING" or
        mq.TLO.Lua.Script('tcn').Status() == "PAUSED") then break end
end
