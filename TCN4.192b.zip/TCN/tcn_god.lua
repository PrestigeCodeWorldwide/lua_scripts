-- name: TCN_God.lua
-- version 1.31b
-- start date: 9/10/21
-- updated: 8/18/24
-- creator: jb321
local mq = require('mq')

local lib = require('TCN_Library')
local shop = require('TCN_Shoplist')
local craft = require('TCN_Craft')
local mv = require('TCN_Movement')

-- declarations
local msg = "\ap[\atTCSNe\auX\att\ap]\aw "

-- event I will give you the recipes after you have helped us enough.. means we messed up!

-- Set trophy swap to auto
GLOBAL_TROPHY_FLAG = 1

-- Local Functions--

local function start_god_engine(p_id)

    local TS_NPC, TS_Text, TS_WIN, TS_QuestName, TS_NAV, TS_Bag, TS_Bag_Price,
          TS_Bag_ID = lib.return_quest_info(p_id)
    local legacy_quest_id = p_id

    if mq.TLO.Zone.ID() ~= 279 then
        print("\at[TCSNe\awx\att] \aw[Travelling To] \ag[Abysmal Sea]")
        mv.abysmal()
    end

    TS_QuestName = string.gsub(TS_QuestName, '\\a', '\a')

    print(msg, "\awStarting ", TS_QuestName)

    -- goto GODLoop -- Testing Purposes

    -- Requirement check and container purchase
    if TS_Bag == "nil" then
        --  No requirements

        if string.find(TS_QuestName, "Pottery") then
            -- Avoid the KILN!
            mq.cmd('/squelch /nav locyxz -250 292 117 |log = off')
            mv.moving()
            mq.cmd('/squelch /nav locyxz -337 274 101 |log = off')
            mv.moving()
        else
            mq.cmd('/squelch /nav locyxz ', TS_NAV, " |log = off")
            mv.moving()
        end

        if string.find(TS_QuestName, "Brewing") then
            -- Because: Ogres
            mq.cmd('/squelch /nav locyxz -137 223 117 |log=off')
            mv.moving()
            mq.cmd('/squelch /nav locyxz -124 173 117 |log=off')
            mv.moving()
        end

        if string.find(TS_QuestName, "Baking") then
            -- Because: Ogres
            mq.cmd('/squelch /nav locyxz -137 223 117 |log=off')
            mv.moving()
        end

    else

        print("\ao[\atTCSNeXt\ao]: \atChecking Requirements:")

        if not string.find(TS_QuestName, "Baking") then
            -- Alternate Container Checking
            local result = lib.return_available_container(TS_Bag)
            if result ~= nil then TS_Bag = result end
        end

        local real_bag_name = mq.TLO.FindItem(TS_Bag).Name()

        if mq.TLO.FindItemCount(TS_Bag)() > 0 then
            TS_Bag = real_bag_name
            print(msg, "Have: \at", TS_Bag, "\ap]")
            -- bag_have = 1
        end

        if mq.TLO.FindItemCount(TS_Bag)() == 0 then
            print("\ao[\atTCSNeXt\ao]: \ay[\aoNeed \at", TS_Bag, "\ay]")

            local money_need = TS_Bag_Price
            if string.find(TS_NPC, "Ordin") then money_need = 2 end

            if mq.TLO.Me.Platinum() < money_need then

                if mq.TLO.Me.PlatinumBank() < money_need and
                    mq.TLO.Me.PlatinumShared() < money_need then
                    mq.delay(500)
                    return
                end

                mv.bank()
                lib.bank_withdrawal(money_need)

                if mq.TLO.Me.Platinum() < money_need then
                    print("\ao[\atTCSNeXt\ao]: \ay[\ayNot Enough Platinum For ",
                          TS_Bag, "\ay]")
                    return
                end

                local npc_no_return = {
                    "Imildu Woodstreak", "Skelontorim Orrthemech"
                }

                local no_return = 1
                for x = 1, #npc_no_return do
                    if string.find(TS_NPC, npc_no_return[x]) then
                        no_return = 0
                    end
                end

                -- Return from bank
                if no_return == 1 then
                    mq.cmd('/squelch /nav locyxz ', -344, 164, 100,
                           " |log = off")
                    mv.moving()
                end

            end

            if string.find(TS_QuestName, "Baking") then
                -- Because: Ogres
                mq.cmd('/squelch /nav locyxz -137 223 117 |log =off')
                mv.moving()
            else
                mq.cmd('/squelch /nav locyxz ', TS_NAV, " |log = off")
                mv.moving()
            end

            mv.npc(TS_NPC)

            print(
                "\ao[\atTCSNeXt\ao]: \ay[\awPurchasing:\ay]  \ap[\ag1\ap] \ap[\ay",
                TS_Bag, "\ap] \agfrom: \ay[\ay", TS_NPC, "\ay]")
            if not mq.TLO.Merchant.Open() then
                mq.cmd('/nomodkey /click right target')
            end
            mq.delay(1500)

            while mq.TLO.Merchant.ItemsReceived() ~= true do
                mq.delay(1000)
            end

            mq.delay(500)
            shop.buy_item(1, TS_Bag_ID)
            mq.delay(1000)

            if string.find(TS_NPC, "Ordin") and mq.TLO.FindItemCount(17947)() <
                1 then
                print(
                    "\ao[\atTCSNeXt\ao]: \ay[\awPurchasing:\ay] \ap[\ag1\ap] \ap[\aySpit\ap] \agfrom: \ay[\ay",
                    TS_NPC, "\ay]")
                if not mq.TLO.Merchant.Open() then
                    mq.cmd('/nomodkey /click right target')
                end
                mq.delay(1000)
                mq.delay(60000,
                         function()
                    return mq.TLO.Merchant.ItemsReceived()
                end)
                shop.buy_item(1, 17947)
            end

            if mq.TLO.FindItemCount(TS_Bag)() == 0 then
                print("\ao[\atTCSNeXt\ao]: \ay[\ayMissing: \ao", TS_Bag, "\ay]")
                return
            end

        end
        mq.cmd('/cleanup')
    end

    -- ::GODLoop::

    while true do
        -- Crafting

        local legacy_quest_recipe_array =
            lib.return_god_quest_recipe_array(legacy_quest_id)

        for god_cycle = 0, #legacy_quest_recipe_array do

            local l_recipe_id = legacy_quest_recipe_array[god_cycle]

            --  print( legacy_quest_recipe_array[god_cycle])

            local result = lib.recipe_check(l_recipe_id)

            if result == 1 then

                lib.trophy_selector(l_recipe_id)

                craft.main(l_recipe_id, 20, 0, 0)

                EXP_FLAG = 0
                local l_container = lib.return_container_name(l_recipe_id)

                if l_container == "Kiln" then
                    mq.cmd('/nav locyxz -337 274 100 |log=off')
                    mv.moving()
                end

                if l_container == "Forge" then
                    -- Because: Ogres
                    mq.cmd('/nav locyxz 41 216 116 |log=off')
                    mv.moving()
                end
            end

        end

        -- Move to NPC
        mv.npc(TS_NPC)

        -- Cycle through all recipes for the quest

        legacy_quest_recipe_array = lib.return_god_quest_recipe_array(
                                        legacy_quest_id)

        for god_cycle = 0, #legacy_quest_recipe_array do

            local l_recipe_id = legacy_quest_recipe_array[god_cycle]

            local god_item_id, god_recipe_name, hc =
                lib.return_recipe_info(l_recipe_id)
            mq.delay(500)

            if hc > 0 then

                -- Don't turn in unfired GOD items..
                if not (god_item_id == 58160 or god_item_id == 58161) then
                    lib.restack_items(god_item_id)
                    mq.delay(500)
                    lib.give_item_id(god_item_id)
                    mq.delay(300)
                    lib.ClearCursor()
                end
            end

        end
        -- Destroy left overs
        lib.legacy_destroy(legacy_quest_id)

        mq.cmd('/doevents flush')

        mq.delay(1)

        mq.cmd('/say ' .. TS_Text)
        -- Testing was 3000
        mq.delay(1000)
        lib.ClearCursor()
        lib.ClearCursor()
        lib.ClearCursor()
        --  mq.delay(1)
        lib.ClearCursor()
        --  mq.delay(1)
        lib.ClearCursor()
        -- 3000
        mq.delay(3000)

        -- Quest Completion
        local winning = lib.legacy_quest_complete(legacy_quest_id)

        if winning == 1 then
            mq.cmd('/doevents flush')
            mq.cmd('/say recipes')

            local break_counter = 0

            -- Capture events

            while true do
                mq.delay(1)
                mq.doevents()
                break_counter = break_counter + 1
                if break_counter == 20 then break end
            end

            mq.delay(1000)
            mq.cmd('/beep')
            print(msg, "\awFinished: ", TS_QuestName)
            break
        end
    end
    return
end

-- End Local Functions

-- CODE START--

local function GatesOfDiscord(p_id)

    local passed_arg = p_id

    local num_arg = tonumber(passed_arg)

    local god_quest_values = {
        2323, 2326, 2329, 2330, 2325, 2324, 2327, 2328, 2332, 2331, 2322
    }

    -- error checking here.
    if num_arg < 1 or num_arg > 11 then

        print(msg, "\ayInvalid Quest Number.. \agPlease Try Again")
        print " "
        print(msg, "\atValid Quests:")

        for x = 1, #god_quest_values do

            local TS_NPC, TS_Text, TS_WIN, TS_QuestName, TS_NAV, TS_Bag,
                  TS_Bag_Price, TS_Bag_ID =
                lib.return_quest_info(god_quest_values[x])

            TS_QuestName = string.gsub(TS_QuestName, '\\a', '\a')

            print("\ao", x, " - [", TS_QuestName, "\ao]")
        end

        print " "
        print(msg, "Usage:  /GOD number")
        return
    end

    for x = 1, #god_quest_values do
        if num_arg == x then
            num_arg = god_quest_values[x]
            break
        end
    end

    mq.cmd('/cleanup')
    lib.CloseInventoryWindow()
    mq.delay(1000)
    lib.ClearCursor()
    mq.delay(1000)

    -- Run solo quest
    if num_arg ~= 2322 then

        local legacy_quest_id = lib.return_god_quest_id(num_arg)

        local TS_NPC, TS_Text, TS_WIN, TS_QuestName, TS_NAV, TS_Bag,
              TS_Bag_Price, TS_Bag_ID = lib.return_quest_info(legacy_quest_id)

        if legacy_quest_id == 2328 and mq.TLO.Me.Race() == "Gnome" then
            start_god_engine(legacy_quest_id)
        else
            if legacy_quest_id == 2328 then
                print "\at[TCSNeXt] \ayTinkering Freebie Race requirement not met"
            end
        end
        if legacy_quest_id == 2332 and mq.TLO.Me.Class() == "Shaman" and
            mq.TLO.Me.Level() > 24 then
            start_god_engine(legacy_quest_id)
            mq.cmd('/squelch /nav locyxz ', TS_NAV, " |log = off")
            mv.moving()
        else
            if legacy_quest_id == 2332 then
                print "\at[TCSNe\awX\att]\ay[Alchemy Freebie, level or class requirements not met]"
            end
        end
        if legacy_quest_id == 2331 and mq.TLO.Me.Class() == "Rogue" and
            mq.TLO.Me.Level() > 19 then
            start_god_engine(legacy_quest_id)
            mq.cmd('/squelch /nav locyxz ', TS_NAV, " |log = off")
            mv.moving()
        else
            if legacy_quest_id == 2331 then
                print "\ayPoison Freebie, level or class requirements not met"
            end
        end

        if not (legacy_quest_id == 2331 or legacy_quest_id == 2332 or
            legacy_quest_id == 2328) then
            start_god_engine(legacy_quest_id)
            mq.cmd('/squelch /nav locyxz ', TS_NAV, " |log = off")
            mv.moving()
        end

    else
        -- Run the chain

        local legacy_quest_recipe_array_dump =
            lib.return_god_quest_id_array_dump()

        for god_cycle = 0, #legacy_quest_recipe_array_dump do

            local legacy_quest_id = legacy_quest_recipe_array_dump[god_cycle]

            local TS_NPC, TS_Text, TS_WIN, TS_QuestName, TS_NAV, TS_Bag,
                  TS_Bag_Price, TS_Bag_ID =
                lib.return_quest_info(legacy_quest_id)

            if legacy_quest_id == 2328 and mq.TLO.Me.Race() == "Gnome" then
                mq.cmd('/squelch /nav locyxz -137 223 117 |log = off')
                mv.moving()
                mq.cmd('/squelch /nav locyxz 204 225 112 |log = off')
                mv.moving()
                start_god_engine(legacy_quest_id)
            else
                if legacy_quest_id == 2328 then
                    print "\at[TCSNeXt] \ayTinkering Freebie Race requirement not met"
                end
            end
            if legacy_quest_id == 2332 and mq.TLO.Me.Class() == "Shaman" and
                mq.TLO.Me.Level() > 24 then

                start_god_engine(legacy_quest_id)
            else
                if legacy_quest_id == 2332 then
                    print "\at[TCSNe\awX\att]\ay[Alchemy Freebie, level or class requirements not met]"
                end
            end
            if legacy_quest_id == 2331 and mq.TLO.Me.Class() == "Rogue" and
                mq.TLO.Me.Level() > 19 then

                start_god_engine(legacy_quest_id)
            else
                if legacy_quest_id == 2331 then
                    print "\ayPoison Freebie, level or class requirements not met"
                end
            end

            if not (legacy_quest_id == 2331 or legacy_quest_id == 2332 or
                legacy_quest_id == 2328) then
                -- Special NAV
                -- Ogres!
                if legacy_quest_id == 2329 then
                    mq.cmd('/squelch /nav locyxz -217 180 117 |log = off')
                    mv.moving()
                    mq.cmd('/squelch /nav locyxz -210 216 117 |log = off')
                    mv.moving()
                end
                -- Ogres!
                if legacy_quest_id == 2325 then
                    mq.cmd('/squelch /nav locyxz 41 202 117 |log = off')
                    mv.moving()
                end
                -- Ogres!
                if legacy_quest_id == 2327 then
                    mq.cmd('/squelch /nav locyxz -6 180 100 |log = off')
                    mv.moving()
                end
                -- Ogres!
                if legacy_quest_id == 2324 then
                    mq.cmd('/squelch /nav locyxz -6 180 100 |log = off')
                    mv.moving()
                    mq.cmd('/squelch /nav locyxz -204 225 112 |log = off')
                    mv.moving()
                    mq.cmd('/squelch /nav locyxz -137 223 117 |log = off')
                    mv.moving()
                end

                -- work on time to get minutes and hours or minutes and seconds..
                local startTime = os.time()
                -- Start GOD Quest
                start_god_engine(legacy_quest_id)
                local endTime = os.time()
                local elapsedTime = os.difftime(endTime, startTime)
                if elapsedTime < 60 then
                    print(elapsedTime, " seconds")
                end
                if elapsedTime < 3600 and elapsedTime > 59 then
                    print(math.floor(elapsedTime / 60), " minutes")
                end
                if elapsedTime > 3599 then
                    print(math.floor(elapsedTime / 3600), " hours")
                end

                -- Pathing Assist
                if legacy_quest_id == 2324 then
                    mq.cmd('/squelch /nav locyxz -137 223 117 |log = off')
                    mv.moving()
                    mq.cmd('/squelch /nav locyxz -204 225 112 |log = off')
                    mv.moving()
                end
            end
        end

    end
    return
end

BUY_MULT = 1
USE_MULT = false

-- Code
local args = ...

-- print(USE_MULT)
-- revisit

GatesOfDiscord(args)

-- Return Trophies
lib.swap_ammo_slot_back(GLOBAL_AMMO_SLOT)

-- Fishing
lib.return_primary_item()

-- will return to POK no matter what if we do one quest for now

-- if tonumber(args) == 11 then 

mv.pok()
-- end
-- add in get trophy quests
return
