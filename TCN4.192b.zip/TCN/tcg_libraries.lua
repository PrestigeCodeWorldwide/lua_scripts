-- tcg_libraries.lua
-- description - functions primarily specific to init.lua
-- date 10/17/2022
-- upd: 09/11/2025
-- ver 1.43a
-- creator: jb321
local mq = require('mq')

local sqlite3 = require('lsqlite3')

local TCG = {}

-- Check for sell.db and extract if it doesn't exist
function TCG.SellDB_Check()
    local function file_exists()
        local p_name = mq.luaDir .. "\\TCN\\sell.db"
        local f = io.open(p_name, "r")
        return f ~= nil and io.close(f)
    end

    if not file_exists() then
        local cmd = "PowerShell Expand-Archive " .. mq.luaDir ..
            "\\TCN\\Sell.zip " .. mq.luaDir .. "\\TCN\\"
        -- print(cmd)
        local rc = os.execute(cmd)
    end
end

function TCG.check_and_update_db(expansion)
    local expansions = {
        NOS = {
            script  = 'NOSDBUPD.lua',
            db      = 'NOSUPD.db',
            update  = "\agUpdating NoS DB for you",
            missing = "\atNight of Shadow Database update not purchased or files are missing"
        },
        LSO = {
            script  = 'LSDBUPD.lua',
            db      = 'LSUPD.db',
            update  = "\agUpdating LSO DB for you",
            missing = "\atLaurion's Song Database update not purchased or files are missing"
        },
        TOB = {
            script  = 'TOBUPD.lua',
            db      = 'TOBUPD.db',
            update  = "\agUpdating ToB DB for you",
            missing = "\atThe Outer Brood Database update not purchased or files are missing"
        }
    }

    local info = expansions[expansion]
    if not info then
        print("\\arUnknown expansion code: " .. tostring(expansion))
        return
    end

    local dbn = sqlite3.open(mq.luaDir .. '\\TCN\\Artisan.db')
    local has_data = false
    for _ in dbn:nrows(("SELECT 1 FROM MasterRecipeTable WHERE Expansion = '%s' LIMIT 1"):format(expansion)) do
        has_data = true
        break
    end
    if has_data then return end

    local msg_prefix = "\ap[\atTCSNe\auX\att\ap]\aw "

    local function file_exists(path)
        local f = io.open(path, "r")
        if f then
            io.close(f)
            return true
        end
        return false
    end

    if file_exists(mq.luaDir .. "\\" .. info.script) and file_exists(mq.luaDir .. "\\" .. info.db) then
        print(msg_prefix .. info.update) -- concatenate so MQ sees color code immediately
        mq.cmd(('/lua run %s'):format(info.script))
        mq.delay(3000)
    else
        print(msg_prefix .. info.missing) -- same here
    end
end

function TCG.settings_exist(p_name)
    p_name = mq.luaDir .. "\\TCN\\Settings\\" .. p_name
    local f = io.open(p_name, "r")
    return f ~= nil and io.close(f)
end

function TCG.favorites_exist(p_name)
    p_name = mq.luaDir .. "\\TCN\\Favorites\\" .. p_name
    local f = io.open(p_name, "r")
    return f ~= nil and io.close(f)
end

function TCG.writeshoppinglist(p_filename, data)
    local file = io.open(mq.luaDir .. "\\TCN\\ShoppingLists\\" .. p_filename ..
        ".csv", "a")
    file:write(data, "\n")
    file:close()
    return
end

function TCG.read_settings(p_file)
    local array = {}
    -- how to get rid of this?
    -- just add lines?
    local count = 0
    local path = mq.luaDir .. "\\TCN\\Settings"
    local p_data = path .. "\\" .. p_file
    -- print(p_data)
    for line in io.lines(p_data) do
        --    print(line)
        array[count] = line
        count = count + 1
    end
    return array
end

function TCG.read_favorites(p_file)
    local array = {}
    -- how to get rid of this?
    -- just add lines?

    local path = mq.luaDir .. "\\TCN\\Favorites"
    local p_data = path .. "\\" .. p_file
    -- print(p_data)
    for line in io.lines(p_data) do
        --    print(line)
        table.insert(array, line)
    end
    return array
end

function TCG.write_favorites(p_file_name, p_data)
    local file = io.open(mq.luaDir .. "\\TCN\\Favorites\\" .. p_file_name ..
        ".csv", "w")
    for c = 1, #p_data do
        local data_element = tonumber(p_data[c])
        file:write(data_element, "\n")
    end
    file:close()
end

-- load favorites
function TCG.favorites()
    local m = {}
    local s_file = "TCS_FAV_" .. mq.TLO.Me() .. "_" ..
        mq.TLO.MacroQuest.Server() .. ".csv"
    local file_exist_bool = TCG.favorites_exist(s_file)
    if file_exist_bool then
        local msg = "\at[\aoTCSNe\agX\aot\at]\aw "
        print(msg, "Loading Favorites")
        local read_data = TCG.read_favorites(s_file)
        for c = 1, #read_data do table.insert(m, tonumber(read_data[c])) end
    end
    return m
end

function TCG.return_string(str, int)
    local counter = 0
    for word in string.gmatch(str, '([^,]+)') do
        counter = counter + 1
        if counter == int then return word end
    end
end

function TCG.return_number(str, int)
    if int == nil or str == nil then
        print(str, " ", int, " TCG Return_number error")
        return 0
    end

    local counter = 0
    for number in string.gmatch(str, '([^,]+)') do
        counter = counter + 1
        if counter == int then return tonumber(number) end
    end
    --  return 0
end

-- Read batch file for crafting
function TCG.read_batch_file(p_file)
    local array = {}
    local path = mq.luaDir .. "\\TCN\\Batch"
    local p_data = path .. "\\" .. p_file

    -- Open File Dialog?
    -- Concat? turn line into array?

    for line in io.lines(p_data) do
        local a_BID = TCG.return_number(line, 1)
        local a_BIN = TCG.return_string(line, 2)
        local a_BIM = TCG.return_number(line, 3)
        local a_BIR = TCG.return_number(line, 4)

        local batch_load_array = {
            BatchItemID = a_BID,
            BatchItemName = a_BIN,
            BatchItemMake = a_BIM,
            BatchItemRecipe = a_BIR
        }

        table.insert(array, batch_load_array)
    end
    return array
end

-- file locked?
function TCG.is_file_locked(p_name)
    local full_path = mq.luaDir .. "\\TCN\\ShoppingLists\\" .. p_name

    -- Try to open the file for writing
    local f = io.open(full_path, "r+")
    if f then
        f:close()
        return false -- Not locked
    else
        return true  -- Locked or inaccessible
    end
end

-- shopping file exists
function TCG.file_exists(p_name)
    p_name = mq.luaDir .. "\\TCN\\ShoppingLists\\" .. p_name
    local f = io.open(p_name, "r")
    return f ~= nil and io.close(f)
end

function TCG.batch_file_exists(p_name)
    p_name = mq.luaDir .. "\\TCN\\Batch\\" .. p_name
    local f = io.open(p_name, "r")
    return f ~= nil and io.close(f)
end

function TCG.writefile(p_filename, data)
    local file = io.open(mq.luaDir .. "\\TCN\\Settings\\" .. p_filename, "w")
    file:write(data, "\n")
    file:close()
    return
end

function TCG.writebatchfile(p_filename, data)
    local file = io.open(mq.luaDir .. "\\TCN\\Batch\\" .. p_filename, "a")
    file:write(data, "\n")
    file:close()
    return
end

function TCG.check_skill(p_skill_selected, p_skill_req)
    p_skill_req = tonumber(p_skill_req)
    local l_my_skill_ability = mq.TLO.Me.Skill(p_skill_selected)()
    if p_skill_req == nil or p_skill_req == 0 then return nil end
    if l_my_skill_ability >= p_skill_req then return nil end
    return "Skill Level Required: " .. p_skill_req
end

-- Return status of Lua script
function TCG.check_script_status(p_skill_selected, p_skill_req) return end

-- Race Class Requirement Check based on skill
function TCG.check_requirement(p_skill_selected)
    -- set no go flag for craft button
    if p_skill_selected == "Alchemy" and mq.TLO.Me.Class() ~= "Shaman" then
        -- ImGui.Text("Class Requirement: Shaman")
        return 'Class Requirement: Shaman'
    end

    if p_skill_selected == "Make Poison" and mq.TLO.Me.Class() ~= "Rogue" then
        --  ImGui.Text("Class Requirement: Rogue")
        return 'Class Requirement: Rogue'
    end

    if p_skill_selected == "Tinkering" and mq.TLO.Me.Race() ~= "Gnome" then
        --   ImGui.Text("Race Requirement: Gnome")
        return 'Race Requirement: Gnome'
    end
    return nil
end

-- retool this
function TCG.script_status(p_script_name, p_squelch)
    -- print("passed: ", p_script_name)

    local pid_array = mq.TLO.Lua.PIDs()
    local delimiter = ","
    local pid_table = {};
    for match in (pid_array .. delimiter):gmatch("(.-)" .. delimiter) do
        if match ~= nil then table.insert(pid_table, match); end
    end

    local flag = 0
    local get_pid_name

    if pid_table[1] ~= nil then
        for c = 1, #pid_table do
            get_pid_name = mq.TLO.Lua.Script(pid_table[c]).Name()
            if get_pid_name ~= nil then
                if get_pid_name == p_script_name then
                    flag = 1
                    break
                end
            end
        end
    else
        return nil, nil, nil
    end

    if flag == 1 and mq.TLO.Lua.Script(get_pid_name).ReturnCount() == 0 then
        return mq.TLO.Lua.Script(get_pid_name).PID(),
            mq.TLO.Lua.Script(get_pid_name).ReturnCount(),
            mq.TLO.Lua.Script(get_pid_name).Status()
    end
    return nil, nil, nil
end

-- dunno
function TCG.save(pfad, s_array)
    local file = io.open(pfad, "w")
    for i = 1, #s_array do file:write(tostring(s_array[i]) .. "|") end
    file:close()
    return
end

function TCG.check_faction()
    local l_faction_index = mq.TLO.Window('FactionWnd/FAC_FactionList').Items()
    mq.delay(1000)
    -- l_faction_index = 0

    if l_faction_index == 0 then
        local msg = "\at[\aoTCSNe\agX\aot\at]\aw "
        print(msg, "Initializing Faction")
        mq.TLO.Window('FactionWnd').DoOpen()

        mq.delay(300)
        while l_faction_index == 0 do
            -- print(l_faction_index)
            -- l_faction_index = mq.TLO.Window('FactionWnd/FAC_FactionList')
            --   .Items()
            l_faction_index = mq.TLO.Window('FactionWnd').Child(
                'FAC_FactionList').Items()

            mq.delay(100)
        end
        mq.delay(300)
    end

    mq.delay(1)

    if mq.TLO.Window('FactionWnd')() then
        mq.TLO.Window('FactionWnd').DoClose()
    end
    mq.delay(300)
end

-- Initialize TSD
function TCG.depot_init()
    if mq.TLO.TradeskillDepot.Enabled() then
        if not mq.TLO.TradeskillDepot.ItemsReceived() then
            local msg = "\at[\aoTCSNe\agX\aot\at]\aw "
            print(msg, "Initializing Tradeskill Depot")
            if not mq.TLO.Window('TradeskillDepotWnd').Open() then
                mq.TLO.Window('TradeskillDepotWnd').DoOpen()
                mq.delay(500)
            end
            -- Wait for list to populate
            while not mq.TLO.TradeskillDepot.ItemsReceived() do
                mq.delay(300)
            end
            if mq.TLO.Window('TradeskillDepotWnd').Open() then
                mq.TLO.Window('TradeskillDepotWnd').DoClose()
                mq.delay(500)
            end
        end
    end
end

-- Initialize Trophy Tribute
function TCG.trophytribute_init()
    mq.delay(1000)

    local msg = "\at[\aoTCSNe\agX\aot\at]\aw "

    print(msg, "Initializing Trophy Tribute Benefits")

    if not mq.TLO.Window('TributeBenefitWnd').Open() then
        mq.TLO.Window('TributeBenefitWnd').DoOpen()
        mq.delay(1000)
    end

    mq.TLO.Window('TributeBenefitWnd').Child('TBW_Subwindows').SetCurrentTab(
        'Trophy')()
    mq.TLO.Window('TributeBenefitWnd').Child('TBW_Subwindows').Select()
    mq.delay(1000)

    local act_cost = -- tonumber(mq.TLO.Window('TBW_TrophyPage').Child(
    --           'TBWT_CostLabel').Text())
        tonumber(mq.TLO.Window(
                'TributeBenefitWnd/TBW_Subwindows/TBW_TrophyPage/TBWT_CostLabel')
            .Text())

    mq.delay(1000)

    if act_cost == nil then
        print(msg, "Not Activating Trophy Tribute Benefits, NIL Cost")
        if mq.TLO.Window('TributeBenefitWnd').Open() then
            mq.TLO.Window('TributeBenefitWnd').DoClose()
        end
        return
    end

    -- Cost - Abort
    if act_cost > 0 then
        mq.TLO.Window('TributeBenefitWnd').DoClose()
        print(msg, "Not Activating Trophy Tribute Benefits, There is a cost!")
        mq.delay(1000)
        return
    end

    local btn_text = mq.TLO.Window('TributeBenefitWnd/TBWT_ActivateButton')
        .Text()
    local activ = 0
    if btn_text == "Deactivate" then activ = 1 end
    if activ == 0 then
        print(msg, "Activating Trophy Tribute Benefits")
        mq.TLO.Window('TributeBenefitWnd/TBWT_ActivateButton').LeftMouseUp()
        mq.delay(1000)
    end

    if mq.TLO.Window('TributeBenefitWnd').Open() then
        mq.TLO.Window('TributeBenefitWnd').DoClose()
    end

    mq.delay(2000)
end

-- determining the path and lua and settings/fav/batch
-- either make a flag to state what kind of file is being checked for
-- or parse the file string to determine what kind
-- or send the whole thing with csv and all
-- Change to send filename and full path to check for existence, to remove redundancies

return TCG
