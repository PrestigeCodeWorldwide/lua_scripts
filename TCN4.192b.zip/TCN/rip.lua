-- rip 4/3/2022
-- updated 7/22/2023
-- ver 1.2b
-- creator jb321
-- 1.1b -- Added Tradeskill Depot Support
-- Corrected issue with inventory generation with SQL.. items with " in the name caused issues
-- 1.2b -- Added Tradeskill Depot detection for unchecking TSD in FIW
local mq = require 'mq'
require 'ImGui'

-- Create SQL Inventory cumulative bank + local + TSD

-- local PackageMan = require('mq/PackageMan')
local sql = require('lsqlite3')

-- local csv = require 'ftcsv'

local dbrip = sql.open(mq.luaDir .. '\\TCN\\Work.db')

local function CreateToonInventory()
    -- local dbrip = sql.open(mq.luaDir .. '\\TCN\\Artisan.db')

    -- JB321 CODE Start (Substitute for Outputfile Inventory)
    -- dump inventory

    -- Doesn't update after each use (on change?)
    -- if mq.TLO.Window('FindItemWnd').Child('FIW_ItemList')
    -- .Items() == 0 then end

    -- Not needed.. there is a short cut key
    --   if not mq.TLO.Window('InventoryWindow').Open() then
    --  mq.cmd('/keypress i')

    --  mq.delay(1)
    -- end

    -- TODO
    -- dump bank inv array from rip
    -- when adding to bank check skills and lookup required trophy and add it to list..

    -- Open Finditem window
    if not mq.TLO.Window('FindItemWnd').Open() then
        mq.TLO.Window('InventoryWindow').DoOpen()
        -- mq.cmd('/keypress Shift+Alt+F')
        mq.delay(500)
        mq.cmd('/notify InventoryWindow IW_FindItemButton leftmouseup')
        mq.delay(300)
    end

    mq.cmd('/notify FindItemWnd FIW_Default leftmouseup')
    mq.delay(300)

    -- Tradeskill Depot Check Box in FindItemWnd
    if mq.TLO.TradeskillDepot.Enabled() then
        if not mq.TLO.Window('FindItemWnd').Child('FIW_SearchDepotButton')
            .Checked() then
            mq.cmd('/notify FindItemWnd FIW_SearchDepotButton leftmouseup')
            mq.delay(500)
        end
    end

    -- Execute Search
    mq.cmd('/notify FindItemWnd FIW_QueryButton leftmouseup')
    mq.delay(300)

    local l_items_index = mq.TLO.Window('FindItemWnd').Child('FIW_ItemList')
                              .Items()

    -- Print index
    -- print(mq.TLO.Window('FindItemWnd').Child('FIW_ItemList')
    -- .Items())

    local working_id_local_table = {}

    local tester = 0

    if tester == 1 then
        for x = 1, l_items_index do
            local l_item_location = mq.TLO.Window('FindItemWnd').Child(
                                        'FIW_ItemList').List(x, 4)()

            -- print(l_item_location)

            if string.find(l_item_location, "Bank") or
                string.find(l_item_location, "General") or
                string.find(l_item_location, "Shared") -- watch
            or string.find(l_item_location, "Personal") then
                local l_items_name = mq.TLO.Window('FindItemWnd').Child(
                                         'FIW_ItemList').List(x, 2)()
                local l_qty = mq.TLO.Window('FindItemWnd').Child('FIW_ItemList')
                                  .List(x, 3)()
                local b_item_id = mq.TLO.FindItemBank('=' .. l_items_name).ID()
                local l_item_id = mq.TLO.FindItem('=' .. l_items_name).ID()

                local t_item_id = nil

                if mq.TLO.TradeskillDepot.Enabled() then
                    t_item_id = mq.TLO.TradeskillDepot.FindItem('=' ..
                                                                    l_items_name)
                                    .ID()
                end

                l_qty = tonumber(l_qty)

                local l_location
                if string.find(l_item_location, "Bank") or
                    string.find(l_item_location, "Shared") then
                    l_location = "Bank"
                end
                if string.find(l_item_location, "General") then
                    l_location = "General"
                end
                if string.find(l_item_location, "Personal") then
                    l_location = "Depot"
                end

                if b_item_id ~= nil then
                    local t_type = mq.TLO.FindItemBank('=' .. l_items_name)
                                       .Tradeskills()
                    local l_type = mq.TLO.FindItemBank('=' .. l_items_name)
                                       .Type()
                    local item = {
                        ItemName = l_items_name,
                        ItemID = b_item_id,
                        ItemCount = l_qty,
                        ItemLocation = l_location,
                        ItemType = l_type
                    }
                    if t_type and l_type ~= "BackPack" then
                        table.insert(working_id_local_table, item)
                    end
                else
                    if l_item_id ~= nil then
                        local l_type = mq.TLO.FindItem('=' .. l_items_name)
                                           .Type()
                        local t_type = mq.TLO.FindItem('=' .. l_items_name)
                                           .Tradeskills()

                        local item = {
                            ItemName = l_items_name,
                            ItemID = l_item_id,
                            ItemCount = l_qty,
                            ItemLocation = l_location,
                            ItemType = l_type
                        }
                        if t_type and l_type ~= "BackPack" then
                            table.insert(working_id_local_table, item)
                        end

                    else
                        if t_item_id ~= nil then
                            local l_type =
                                mq.TLO.TradeskillDepot.FindItem('=' ..
                                                                    l_items_name)
                                    .Type()
                            local t_type =
                                mq.TLO.TradeskillDepot.FindItem('=' ..
                                                                    l_items_name)
                                    .Tradeskills()

                            local item = {
                                ItemName = l_items_name,
                                ItemID = t_item_id,
                                ItemCount = l_qty,
                                ItemLocation = l_location,
                                ItemType = l_type
                            }

                            table.insert(working_id_local_table, item)

                        end
                    end
                end
            end
        end
    end

    -- Working routine!
    if tester == 0 then
        for x = 1, l_items_index do
            local l_items_name = mq.TLO.Window('FindItemWnd').Child(
                                     'FIW_ItemList').List(x, 2)()
            local l_qty = mq.TLO.Window('FindItemWnd').Child('FIW_ItemList')
                              .List(x, 3)()

            l_qty = tonumber(l_qty)

            local b_item_id = mq.TLO.FindItemBank('=' .. l_items_name).ID()
            local l_item_id = mq.TLO.FindItem('=' .. l_items_name).ID()

            local t_item_id = nil

            if mq.TLO.TradeskillDepot.Enabled() then
                t_item_id = mq.TLO.TradeskillDepot.FindItem('=' .. l_items_name)
                                .ID()
            end

            -- if l_qty > 0 then print(l_qty, " ",l_items_name) end

            local l_location = "none"

            if b_item_id ~= nil then
                local t_type = mq.TLO.FindItemBank('=' .. l_items_name)
                                   .Tradeskills()
                local l_type = mq.TLO.FindItemBank('=' .. l_items_name).Type()

                local item = {
                    ItemName = l_items_name,
                    ItemID = b_item_id,
                    ItemCount = l_qty,
                    ItemLocation = l_location,
                    ItemType = l_type
                }

                table.insert(working_id_local_table, item)
            else
                if l_item_id ~= nil then

                    local item = {
                        ItemName = l_items_name,
                        ItemID = l_item_id,
                        ItemCount = l_qty,
                        ItemLocation = l_location
                    }

                    table.insert(working_id_local_table, item)
                else
                    if t_item_id ~= nil then
                        local item = {
                            ItemName = l_items_name,
                            ItemID = t_item_id,
                            ItemCount = l_qty,
                            ItemLocation = l_location
                        }
                        table.insert(working_id_local_table, item)
                    end
                end
            end
        end
    end

    -- Check for TSD to uncheck box
    if mq.TLO.TradeskillDepot.Enabled() then
        -- Uncheck TSD
        if mq.TLO.Window('FindItemWnd').Child('FIW_SearchDepotButton').Checked() then
            mq.cmd('/notify FindItemWnd FIW_SearchDepotButton leftmouseup')
            mq.delay(500)
        end
    end

    -- Close Find Item Window
    if mq.TLO.Window('FindItemWnd').Open() then
        mq.TLO.Window('FindItemWnd').DoClose()
        mq.delay(500)
    end

    -- Close Inventory
    if mq.TLO.Window('InventoryWindow').Open() then
        mq.TLO.Window('InventoryWindow').DoClose()
        mq.delay(500)
    end

    local final_local_inventory_array = working_id_local_table

    local inv_table = {}

    for c = 1, #final_local_inventory_array do
        local id = tonumber(final_local_inventory_array[c].ItemID)
        local count = tonumber(final_local_inventory_array[c].ItemCount)
        local name = tostring(final_local_inventory_array[c].ItemName)

        -- Non TS Items (collectibles) No TS item has " in it..
        if string.find(name, '"') then count = nil end

        local location = tostring(final_local_inventory_array[c].ItemLocation)
        if count ~= nil then
            table.insert(inv_table, string.format('(%d, "%s", %d, "%s")', id,
                                                  name:gsub("'", "''"), count,
                                                  location))
        end
    end

    local insert = table.concat(inv_table, ", ")

    local t_table = "Temp_Toon"

    local sql_string = 'DROP TABLE IF EXISTS ' .. t_table ..
                           ';CREATE TEMP TABLE ' .. t_table ..
                           ' (ID, Name, Count,Location);'

    dbrip:exec(sql_string)

    mq.delay(1)

    dbrip:exec(string.format("INSERT INTO " .. t_table ..
                                 " ('ID', 'Name','Count','Location') VALUES %s;",
                             insert))
    mq.delay(1)

    local s_table = mq.TLO.MacroQuest.Server() .. "_" .. mq.TLO.Me.Name() ..
                        "_Inventory"

    sql_string = 'DROP TABLE IF EXISTS ' .. s_table .. ';CREATE TABLE ' ..
                     s_table .. ' (ID, Name, Count);'

    dbrip:exec(sql_string)
    mq.delay(1)

    dbrip:exec("INSERT INTO " .. s_table ..
                   " SELECT ID,Name,SUM(Count) AS Count FROM " .. t_table ..
                   " GROUP BY Name")

    mq.delay(1)

    -- dbrip:close()
    return
end

local rip = {}

function rip.create_toon_inventory()
    local msg = "\ap[\atTCSNe\auX\att\ap]\aw "
    local start_time = os.time()
    CreateToonInventory()
    local end_time = os.time()
    print(msg, "\atInventory Generation \ap(\ay" .. end_time - start_time ..
              "\at) \agSeconds")

    return
end

return rip
