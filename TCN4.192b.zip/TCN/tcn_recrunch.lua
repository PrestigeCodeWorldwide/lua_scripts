-- created: 9/7/2021
-- updated: 1/3/22
-- creator: jb321
-- version: 1.7b
-- name: recrunch
-- notes check maths for calculating... from bank
local mq = require('mq')

--local PackageMan = require('mq/PackageMan')
 --local sqlite3 = PackageMan.Require('lsqlite3')
 local sqlite3 = require('lsqlite3')

local db = sqlite3.open(mq.luaDir .. '\\tcn\\Artisan.db')
local lib = require('tcn_Library')
-- local recrunch = require('//tcn//tcn_recrunch')

local data_array = {}
local temp_bank_array = {}
local temp_banked_components = {}

-- used for components 
local t_component_array = {}

local temp_banked_recipes = {}

-- local pottery_tools = {}
-- local fletching_tools = {}
-- local convertible_tool_array = {}

local tool_array = {}
local tool_counter = 0

local pass_var2 = 0
local pass_var3 = 0
local pass_var4 = 0
local pass_var5 = 0
local pass_var6 = 0
local pass_var7 = 0
local pass_var8 = 0
local pass_var9 = 0
local pass_var10 = 0
local pass_var11 = 0

local banked_tools_array = {}

local tool_array_inv = {}

-- Sour Recipe Global?
local soiled = {}

local compare_soiled = {}

local msg = "\ap[\atTCSNe\auX\att\ap]\aw "

local function c_return_toon_item_inv_count(p_id)

    local r_value = 0
    local r_name = nil
    local r_flag = 0
    local linv_count = mq.TLO.FindItemCount(p_id)()
    local binv_count = mq.TLO.FindItemBankCount(p_id)()
    local tinv_count = linv_count + binv_count

    -- None in inventory return nothing
    if tinv_count < 1 then return 0, nil end

    for c = 1, #GLOBAL_CRUNCH_ARRAY do
        if GLOBAL_CRUNCH_ARRAY[c].ItemID == p_id then
            r_value = GLOBAL_CRUNCH_ARRAY[c].ItemCount
            r_name = GLOBAL_CRUNCH_ARRAY[c].ItemName
            r_flag = 1
            break
        end
    end

    if r_flag == 1 then return r_value, r_name end

    -- Not In Array/Add It
    local l_item_name = lib.return_item_name(p_id)
    local array_item = {
        ItemID = p_id,
        ItemCount = tinv_count,
        ItemName = l_item_name
    }

    table.insert(GLOBAL_CRUNCH_ARRAY, array_item)
    local array_size = #GLOBAL_CRUNCH_ARRAY

    return GLOBAL_CRUNCH_ARRAY[array_size].ItemCount,
           GLOBAL_CRUNCH_ARRAY[array_size].ItemName
end

local function c_update_toon_item_inv_count(p_id, p_count)
    p_id = tonumber(p_id)
    for c = 1, #GLOBAL_CRUNCH_ARRAY do
        local c_id = GLOBAL_CRUNCH_ARRAY[c].ItemID
        if c_id == p_id then
            GLOBAL_CRUNCH_ARRAY[c].ItemCount = p_count
            break
        end
    end
    return
end

local function return_tool(p_id)

    local zz = 0
    if zz == 1 then return 0 end

    -- tool_array_inv = {}
    -- tool_array_dynamic = {}

    -- if p_id or s_id = anyone of the 4 recipes then set to 2 for roller

    local r_flag = 0
    -- local linv_count = mq.TLO.FindItemCount(p_id)()
    -- local binv_count = mq.TLO.FindItemBankCount(p_id)()
    -- local tinv_count = linv_count + binv_count

    -- None in inventory return nothing
    -- if tinv_count > 0 then return end

    for c = 1, #tool_array_inv do
        if tool_array_inv[c].ItemID == p_id then
            r_flag = 1
            break
        end
    end

    -- don't add again
    if r_flag == 1 then return 1 end

    -- Not In Array/Add It
    -- local l_item_name = lib.return_item_name(p_id)

    -- print("Return Tool Adding: ", p_id) -- ) l_item_name)

    local array_item = {ItemID = p_id} -- , ItemName = l_item_name}

    table.insert(tool_array_inv, array_item)

    return 0
end

-- Static Item IDs for all purchased tools
local function crunch_purchased_tools(p_id)
    local purchased_tool_id_array = {
        37803, 8086, 7052, 10489, 152401, 17947, 17906, 17882, 21625, 34914,
        95826, 8893, 10425, 81673, 81671, 81670, 81677, 81679, 10477, 10479,
        11397, 81669, 10478, 81676, 98305, 81672, 81678, 81674, 81675, 81661,
        65255, 65189, 81666, 81668, 81663, 65167, 81665, 98304, 81660, 65145,
        81667, 65233, 65211, 81664, 10064, 152402, 152403, 152404, 152405,
        152406, 152407, 152408, 38511, 38512, 38513, 38514, 38515, 12056, 37804,
        95827, 95828, 95829, 95830, 95831, 95832, 29546, 16361, 8085, 29820,
        29816, 29824
    }

    local value = 0
    for c = 1, #purchased_tool_id_array do
        if purchased_tool_id_array[c] == p_id then
            value = 1
            break
        end
    end
    return value
end

-- Static recipe Item IDs for all crafted tools
local function crunch_toolcheck_id(p_id)
    local crafted_tool_id_array = {
        12011, 13439, 9727, 13432, 8174, 13438, 13438, 13430, 37804, 95829,
        95832, 95828, 95831, 95827, 95826, 95830, 37805, 95833, 13432, 9753,
        37803, 12090, 16883, 10064, 33646, 96488, 96492, 96489, 9777, 21565,
        29778, 29760, 29779, 13437, 13437, 65260, 9724, 13436, 13433, 13434,
        14592, 14593, 14594, 13435, 14591, 13436, 13433, 13434, 14592, 14593,
        14594, 13435, 14591, 65259, 13440, 60316, 60187
    }

    local value = 0
    for c = 1, #crafted_tool_id_array do
        if crafted_tool_id_array[c] == p_id then
            value = 1
            break
        end
    end
    return value
end

-- Static recipe IDs for all crafted tools
local function crunch_toolcheck(p_id)
    local crafted_tool_array = {
        94960, 108028, 93131, 9913432, 97063, 98043, 108286, 108961, 88214,
        88534, 88655, 88747, 88776, 88931, 89129, 89306, 89307, 34653, 108293,
        94961, 1234, 98773, 101251, 9910064, 11298, 35559, 35563, 35560, 101062,
        99296, 101063, 101838, 93048, 97036, 108278, 94170, 94183, 92429, 92755,
        95644, 95815, 98848, 99568, 100420, 100468, 108004, 108016, 108127,
        108133, 108958, 109101, 109111, 109229, 95874, 93008, 817, 63767, 99565,
        108968
    }

    local value = 0
    for c = 1, #crafted_tool_array do
        if crafted_tool_array[c] == p_id then
            value = 1
            break
        end
    end
    return value
end

-- move to library for testing?
local function preload_vendors()
    local m = {}
    -- how to access learned recipes info?   local aam = {}
    local string_loader
    for row in db:nrows(
                   "SELECT DISTINCT * FROM VendorLocations ORDER BY VendorZoneID ASC") do

        if row.VendorFaction == nil then row.VendorFaction = "None" end
        if row.VendorFactionRequired == nil then
            row.VendorFactionRequired = "None"
        end

        string_loader = row.VendorName .. "," .. row.VendorZoneID .. "," ..
                            row.VendorFaction .. "," ..
                            row.VendorFactionRequired
        table.insert(m, string_loader)
    end
    return m
end

-- Preload vendor names and factions
-- local preload_v = preload_vendors()

-- use r.SubRecipeID
-- revisit or scrap
local function print_multi_options(p_id, p_silent)
    local a = 0
    if a == 0 then return end
end

-- calc buy  count ---------
----------------------------
local function calc_buy_count(p_id, s_id, p_sets_wanted)

    if p_id == nil then
        print("err calc_buy_count ", p_id, " ", s_id)
        os.exit()
    end

    if s_id == nil then
        print("err calc_buy_count ", s_id, " ", p_id)
        os.exit()
    end

    if p_sets_wanted == nil then
        print("err calc_buy_count ", p_id)
        os.exit()
    end

    local set_count = 0

    local item_row_count = lib.Return_Calling_Recipe_Row_Count(p_id, s_id)

    if item_row_count == nil then
        print(msg, p_id, " ", s_id,
              " Broked, NIL calling row count TCN Cruncher")
        os.exit()
    end

    local tool_check1 = crunch_toolcheck(s_id)

    local rt = return_tool(35560)

    -- Disable for TCN_Quests - makes tools
    if GLOBAL_OPTION_FLAG == 1 then tool_check1 = 0 end

    -- Zero out banked or local tools
    if tool_check1 == 1 then
        local l_item_id = lib.return_item_ID(s_id)
        local tot_tools = mq.TLO.FindItemCount(l_item_id)() +
                              mq.TLO.FindItemBankCount(l_item_id)()
        if tot_tools >= item_row_count then return 0 end
    end


    local tool_check = crunch_toolcheck(p_id)

    rt = return_tool(35560)


    -- Disable for TCN_Quests - allows you to make unlimited tools if it is required to satisfy trophy req
    if GLOBAL_OPTION_FLAG == 1 then tool_check = 0 end

    -- Zero out banked or local tools
    if tool_check == 1 then
        local l_item_id = lib.return_item_ID(p_id)
        local tot_tools = mq.TLO.FindItemCount(l_item_id)() +
                              mq.TLO.FindItemBankCount(l_item_id)()
        if tot_tools >= item_row_count then return 0 end
    end

    local l_yield = lib.return_recipe_yield(s_id)

    if l_yield == nil then
        print(msg, "\ayError: \ag", s_id,
              " Recipe not in table, check component table for ID")
        os.exit()
    end

    local l_sub_item_id = lib.return_item_ID(s_id)

    local l_desired_count = item_row_count * p_sets_wanted

    if l_desired_count < 1 then return 0 end

    -- Read Dynamic Array Table
    local toon_inv_count, toon_item_name =
        c_return_toon_item_inv_count(l_sub_item_id)

    if toon_item_name ~= nil then
        -- Have recipe counts
        if toon_inv_count >= l_desired_count then
            toon_inv_count = toon_inv_count - l_desired_count
            c_update_toon_item_inv_count(l_sub_item_id, toon_inv_count)
            local comp_string = toon_item_name .. "," .. l_sub_item_id .. "," ..
                                    l_desired_count
            table.insert(t_component_array, comp_string)
            l_desired_count = 0
        else
            -- Partial recipe counts
            if toon_inv_count > 0 and toon_inv_count < l_desired_count then
                l_desired_count = l_desired_count - toon_inv_count
                local comp_string = toon_item_name .. "," .. l_sub_item_id ..
                                        "," .. toon_inv_count
                table.insert(t_component_array, comp_string)
                c_update_toon_item_inv_count(l_sub_item_id, 0)
                toon_inv_count = 0
            end
        end
    end

    set_count = lib.set_amount(l_desired_count, l_yield)

    return set_count
end

local function make_data(p_id, s_id, p_bc, p_mc)

    -- Primary ID, Secondary ID, Buy Count
    local primary_id = p_id
    local secondary_id = s_id
    local fv_buy_count = p_bc

    local fv_secondary_item_id = lib.return_item_ID(s_id)
    local fv_secondary_item_name = lib.return_recipe_name(s_id)
    local fv_yield = lib.return_recipe_yield(secondary_id)

    -- print("\agmake_data cruncher string ", fv_secondary_item_name)

    if fv_yield == nil then
        print(msg, "Error: NIL YIELD BUY CALC")
        os.exit()
    end

    -- watch make count

    local fv_mc = math.ceil(fv_buy_count * fv_yield)

    -- fv_mc = p_mc

    -- For the 2 pottery items
    if string.find(fv_secondary_item_name, ",") then
        fv_secondary_item_name = fv_secondary_item_name:gsub(',', '@')
    end

    -- print("make data_ cruncher: make count ", fv_mc, " second sid: ",
    --  fv_secondary_item_id, " sid ", s_id)

    local data = fv_secondary_item_id .. "," .. fv_secondary_item_name .. "," ..
                     fv_buy_count .. "," .. secondary_id .. "," .. fv_mc
    --   .. "," ..       fv_count
    --  print("\aw",data)
    return data
end


-- need to add in inventory control array here but since it is only tools don't need this at all?

local function multi_option_check(p_id, p_count, p_silent)
    local swap_id, swap_count, conversion_status =
        lib.multi_component_check(p_id, p_count, p_silent)

    local data_string
    local l_item_name

    -- if we have 1 lb then why are we checking and selecting..??
    -- print("cruncher testing multi ",p_id," ",conversion_status)

    --- 0 bypass multi option non conversions
    if swap_id ~= 0 and conversion_status == 99 then

        for x = 0, #data_array do
            local l_recipe_id = lib.return_number(data_array[x], 4)
            if p_id == l_recipe_id then
                l_item_name = lib.return_string(data_array[x], 2)
                print(msg, "\ap[\atRemoving: \ap] \ap[\ag", l_item_name, "\ap]")
                --     table.remove(data_array, l_item_name)
                -- Only remove 1 occurrence -- watch this
                break
            end
        end

        table.remove(data_array, l_item_name)

        data_string = make_data(p_id, swap_id, swap_count)

        for x = 1, #soiled do
            local l_get_soiled_name = lib.return_string(soiled[x], 2)
            if string.find(l_item_name, l_get_soiled_name) then
                --  print(msg, "\atRemoving Soiled: \aw", l_get_soiled_name)
                -- table.remove(soiled, l_item_name)
                break
            end
        end

        table.remove(soiled, l_item_name)

        data_string = make_data(p_id, swap_id, swap_count)
        table.insert(data_array, data_string)

        -- fix
  
        print(msg, "Experimental TCN Cruncher")

        -- second time we run it doesnt reset data or? is it the array and placement?

        for mini in db:nrows("SELECT * FROM MasterCompTable where recipeid=" ..
                                 swap_id) do
            if mini.SubRecipeID > 0 and mq.TLO.FindItemCount(mini.ItemID)() <
                mini.ItemCount then
                print(msg, "\ap[\agAdding Recipe: \ap]\ap [\aw", mini.ItemName,
                      "\ap]")
                -- will counts work?
                -- swap_id?
                data_string = make_data(p_id, mini.SubRecipeID, swap_count)
                -- do single rec check?

                print(msg, "Second Try: MINI Crunch ", data_string)

                table.insert(data_array, data_string)
            end
        end

        -- for x = 0, #data_array do print(data_array[x]) end -- os.exit()
        return 0
    end

    -- Food conversion lbs to lbs
    if swap_id ~= 0 and conversion_status == 1 then
        data_string = make_data(p_id, swap_id, swap_count)
        table.insert(data_array, data_string)
        return 0
    end

    return 1
end

-- Add items to soiled array - checks inventory, bank, and vendor
local function soiled_area(p_item_id, p_hc, p_recipe_id, p_need_count, p_silent,
                           p_rcc, p_type, p_item_name, p_mid)

    local l_item_name = p_item_name -- lib.return_item_name(p_item_id)

    if l_item_name == nil then
        print(msg, "\ayError: \agNo item name found in either table")
        os.exit()
    end

    if (p_hc >= p_need_count and p_hc ~= 0) then
        --   print("\ag[x] Item ID:\ag",p_item_id," ",l_item_name," \ay[Have:]\aw[",p_hc,"]\ao[In Inventory]")
        -- return
    end

    -- print("\ag",l_item_name," Item ID: ",p_mitem, " Want: ",p_cr)
    local tv_nc = math.ceil(p_need_count)
    -- p_hc)
    -- if p_hc > p_cr then tv_nc = 0 end

    local reason_flag = 0

    local faction_check = nil

    -- Used for skill level
    local recipe_flag_id = 0

    local tv_vc
    -- Check vendor if the item is not a recipe

    -- Add bought tools to potential grab list from bank
    local bank_have_item = mq.TLO.FindItemBankCount(p_item_id)()
    local purchase_tools_check = crunch_purchased_tools(p_item_id)

    -- Don't add the main recipe as a banked component
    if p_item_id ~= p_mid then

        -- FIX!

        -- crutch for tools and stuff for cruncher
        local comp_string = l_item_name .. "," .. p_item_id .. "," .. tv_nc
        table.insert(t_component_array, comp_string)

        if bank_have_item > 0 and p_hc < 1 and purchase_tools_check == 1 then
            -- print("Adding Buy Tool: ", lib.return_item_name(p_item_id), " ",
            --      p_item_id)
            local bank_tool_string = l_item_name .. "," .. p_item_id .. ",1"
            table.insert(banked_tools_array, bank_tool_string)
        end

        local toolcheck_id = crunch_toolcheck_id(p_item_id)

        local total_have = bank_have_item + p_hc

        -- Add banked component that is not a tool
        if p_hc < tv_nc and total_have >= tv_nc and toolcheck_id == 0 and
            purchase_tools_check == 0 then
            -- print("should have added: ", p_item_id, " ", l_item_name," ",tv_nc)
            table.insert(temp_banked_components,
                         l_item_name .. "," .. p_item_id .. "," .. tv_nc)
        end

      end

    -- print("items in soil area ",lib.return_item_name(p_item_id))

    --   print(lib.return_item_name(p_item_id))
    if p_type == 0 then tv_vc = lib.vendor_has_item(p_item_id) end

    -- Faction Check
    if p_type == 0 and tv_vc == 1 then
        local l_vendor_name = nil
        if p_item_id == 28021 or p_item_id == 10425 or p_item_id == 22564 or
            p_item_id == 22098 or p_item_id == 21625 then
            l_vendor_name = lib.return_vendor_name(p_item_id)
        end
        -- Faction check for vendor
        if l_vendor_name == "Ping Fuzzlecutter" or l_vendor_name ==
            "Nimren Stonecutter" or l_vendor_name == "Talem Tucter" or
            l_vendor_name == "Meg Tucter" then
            faction_check = lib.faction_check(l_vendor_name)
            -- print(faction_check)
            -- flag it if it is not purchasable
        end
    end

    -- print("\atMain ID: ",p_recipe_id, " need: ",tv_nc, " yield ",l_recipe_yield)

    -- If there is a vendor for a purchased tool and it isn't in the DB, this is a fall back to buy_tools table
    purchase_tools_check = crunch_purchased_tools(p_item_id)

    if purchase_tools_check == 1 then tv_nc = 1 end

    if tv_vc == 0 or faction_check == 0 then
        local soiled_string = p_item_id .. "," .. l_item_name .. "," ..
                                  p_recipe_id .. ",0," .. tv_nc .. "," ..
                                  reason_flag .. "," .. recipe_flag_id

        local compare_soiled_string = l_item_name .. "," .. p_item_id .. "," ..
                                          tv_nc

        -- print("Cruncher Soiling: ", soiled_string)

        -- Make sure no jewel tools are added or knots..
        --  if not (string.find(soiled_string, "Cut Tool") or
        --   string.find(soiled_string, "Setting Tool")) then
        table.insert(soiled, soiled_string)
        table.insert(compare_soiled, compare_soiled_string)
        --  end
    end
    return
end

local function calc_and_soil(p_item_id, p_item_count, p_main_id, p_silent,
                             p_tv_rv, p_item_name, p_mid)
    -- Get inventory count of component
    local tv_hc = mq.TLO.FindItemCount(p_item_id)()

    p_item_count = tonumber(p_item_count)

    -- Error checking
    if p_item_count == nil then
        print("cruncher error NIL passed ItemCount tv_ic", p_main_id, " ",
              p_item_count)
        os.exit()
    end
    -- Calculate buy count * Item count in row
    local l_tv_cr = p_tv_rv * p_item_count
    -- Add item if missing

    -- print("calc and soil ", p_item_id)

    soiled_area(p_item_id, tv_hc, p_main_id, l_tv_cr, p_silent, 0, 0,
                p_item_name, p_mid)
    return
end

local function recipe_calc(p_main_id, p_sub_id, p_pass_var, p_silent,
                           p_row_item_count, p_mitem_id)

    -- Determine how many sets to buy
    local l_sets_wanted = calc_buy_count(p_main_id, p_sub_id, p_pass_var)

    local rt = return_tool(p_sub_id)
    if rt == 1 then l_sets_wanted = 0 end

    -- print("\ayCRUNCHER sets wanted: ",  l_sets_wanted ," main ", p_main_id, " sub ",p_sub_id, " pass: ",p_pass_var)

    -- Buy set count
    local l_tv_rv = l_sets_wanted

    -- print ("set count : ",l_tv_rv, " passvr ",p_pass_var)

    -- Fix
    -- Check if there is another option for the recipe to be completed

    -- Sets buy count to 0 if multi_option available this needs work
    if l_tv_rv == 999999999 then
        -- if l_tv_rv ~= 0 then
        local answer = multi_option_check(p_main_id, p_pass_var, p_silent)
        -- it has been doing conversions
        --  print ("here ", p_main_id)
        -- if it the primary id it will never pick the sub?
        if answer == 0 then l_tv_rv = 0 end
    end
    -- Recipe count is satisifed	
    if l_tv_rv == 0 then
        -- list_row1.SubRecipeID = 0
        -- print(msg, "Returning ", p_sub_id)
        return 0
        -- Recipe count not satisified
    else
        -- Add recipe to array
        local data_string = make_data(p_main_id, p_sub_id, l_tv_rv, p_pass_var)
        table.insert(data_array, data_string)

        --  print("recrunch data_string ", data_string)
        return l_tv_rv
    end
end

-- Start the crunch
local recrunch = {}
-- p _ option 1 means make tools based on the quest 
function recrunch.items(main_id, want_count, p_silent)

    tool_array_inv = {}

    t_component_array = {}

    -- GLOBAL_TEXT = "State: Processing Recipe.."

    -- All Recipes Start Unsoiled
    soiled = {}

    compare_soiled = {}

    temp_bank_array = {}
    temp_banked_components = {}
    temp_banked_recipes = {}

    local tv_rv = 0

    -- testing
    -- main_id = 90812
    -- want_count = 500

    local silent = p_silent

    data_array = {}

    -- Overall want count of item
    local tv_pnc = want_count

    local tv_rn = lib.return_recipe_name(main_id)

    if silent == 1 then
        print("\aw[Master Recipe:] \at", tv_rn, " \ag[Recipe ID:] \at[",
              main_id, "]")
    end

    local tv_mid = lib.return_item_ID(main_id)
    local tv_hc = mq.TLO.FindItemCount(tv_mid)()

    -- Main Recipe Checking 

    -- ROW 0 Main Recipe
    local tv_yc = lib.return_recipe_yield(main_id)

    if tv_yc == nil then
        print(msg, "\ayError: \ag Invalid Recipe ID: ", main_id)
        os.exit()
    end

    if (tv_pnc - tv_hc) <= tv_yc then
        tv_rv = 1

    else
        tv_rv = math.ceil(tv_pnc - tv_hc) / tv_yc
    end

    -- Verify count correct because it is the main recipe?

    -- tv_rv = math.ceil(tv_pnc - tv_hc) / tv_yc

    local result = crunch_toolcheck(main_id)

    -- If first recipe is a tool, it will add to the tool array if we don't have it
    -- This area needs work for the tools..

    -- Works for tools currently, not multi, will add

    -- Add tool
    if result == 1 then
        local l_item_id = lib.return_item_ID(main_id)
        local lv_inv = mq.TLO.FindItemCount(l_item_id)()
        local lv_b_inv = mq.TLO.FindItemBankCount(l_item_id)()
        --  local l_item_name = lib.return_item_name(l_item_id)
        if lv_inv >= 1 or lv_b_inv >= 1 then
            -- We have the count so don't add to the tool array
        else
            local tool_string = main_id .. ",1"

            -- table.insert(tool_array, tool_string)
        end
    end

    -- Disable for TCN_Quests - Will make whatever amount of tools the quest requests
    if GLOBAL_OPTION_FLAG == 1 then result = 0 end

    -- skip tool counts for quests?
    if result == 1 then
        local lv_inv = mq.TLO.FindItemCount(main_id)()
        if lv_inv > 0 then
            tv_rv = 0
        else
            -- fix this up
            tv_rv = 1
        end
    end

    local fv_mc = tv_pnc
    -- * yield

    -- print("CRUNCHER want ", tv_pnc, " have: ", tv_hc, " buy: ", tv_rv, " make: ",
    --   fv_mc, " main id ",main_id)

    local main_yield = tv_yc -- lib.return_recipe_yield(main_id)

    tv_rv = tv_pnc / main_yield

    if main_yield >= tv_pnc then tv_rv = 1 end

    -- print("buy ", tv_rv, " want ", tv_pnc, " make ", fv_mc)

    local pass_var1 = tv_rv

    local l_item_id = lib.return_recipe_item_id(main_id)
    local l_recipe_skill = lib.return_recipe_skill(main_id)
    local l_can_make = lib.check_requirements(l_recipe_skill, main_id)
    local l_recipe_item_name = lib.return_recipe_name(main_id)

    -- this is the 1st recipe
    soiled_area(l_item_id, tv_hc, main_id, 1, silent, l_can_make, 1,
                l_recipe_item_name, tv_mid)

    -- Convert anyuthing with a , in the name to an @ 
    if string.find(tv_rn, ",") then tv_rn = tv_rn:gsub(',', '@') end

    local data_string =
        tv_mid .. "," .. tv_rn .. "," .. math.ceil(tv_rv) .. "," .. main_id ..
            "," .. fv_mc

    -- print("1st recruncher ", data_string)
    -- if the recipe is a tool don't add it twice.. or don't add tool because it doesn't matter?
    -- if result == 1 then table.insert(dta_array, data_string) end

    table.insert(data_array, data_string)

    -- Start Recipe Interrogation

    -- ROW 1

    for list_row1 in db:nrows("SELECT * FROM MasterCompTable where RecipeID=" ..
                                  main_id .. " ORDER BY SubRecipeID ASC") do

        tv_rv = pass_var1
        pass_var1 = tv_rv

        -- print("\atwhat ", tv_rv, " ", pass_var1, " ItemId ", list_row1.ItemName,
        --    " ItemCount ", list_row1.ItemCount, " s ", list_row1.SubRecipeID)
        --  print("\agCruncher Row 1 ", list_row1.SubRecipeID, " ",
        -- list_row1.ItemName, " Recipe ID: ", list_row1.RecipeID,
        -- " ItemCount: ", list_row1.ItemCount)

        -- slow down
        mq.delay(1)
        if list_row1.SubRecipeID > 0 then
            local r_tv_rv = recipe_calc(main_id, list_row1.SubRecipeID,
                                        pass_var1, silent, list_row1.ItemCount,
                                        list_row1.ItemID)

            --   print(tv_rv," ", list_row1.ItemName)

            tv_rv = r_tv_rv

            pass_var2 = tv_rv

            ---   print ("row 1 ",list_row1.ItemName," ",  list_row1.SubRecipeID, " ",tv_rv )

            if tv_rv == 0 then list_row1.SubRecipeID = 0 end
        else

            calc_and_soil(list_row1.ItemID, list_row1.ItemCount, main_id,
                          silent, tv_rv, list_row1.ItemName, tv_mid)

        end

        -- ROW 1 END

        -- ROW 2--

        for list_row2 in db:nrows(
                             "SELECT * FROM MasterCompTable where recipeid=" ..
                                 list_row1.SubRecipeID ..
                                 " ORDER BY SubRecipeID ASC") do
            mq.delay(1)

            --  print("\atrow 2 start ",list_row2.ItemName)

            --   print("\ayROW 2 ", list_row2.ItemName, " ID:", list_row2.SubRecipeID)

            if list_row1.SubRecipeID == 0 then break end

            if list_row1.SubRecipeID ~= 0 then

                if list_row2.SubRecipeID > 0 then
                    local r_tv_rv = recipe_calc(list_row1.SubRecipeID,
                                                list_row2.SubRecipeID,
                                                pass_var2, silent,
                                                list_row2.ItemCount,
                                                list_row2.ItemID)
                    tv_rv = r_tv_rv
                    pass_var3 = tv_rv
                    if tv_rv == 0 then
                        list_row2.SubRecipeID = 0
                    end
                end

                if list_row2.SubRecipeID == 0 then

                    --  print(list_row2.ItemID, " ", list_row2.ItemCount, " ",
                    --      list_row1.SubRecipeID, " ", tv_rv)

                    --    print("\atrow 2 cas ",list_row2.ItemName)

                    calc_and_soil(list_row2.ItemID, list_row2.ItemCount,
                                  list_row1.SubRecipeID, silent, tv_rv,
                                  list_row2.ItemName, tv_mid)

                end

            end
            -- ROW 2 END--

            -- ROW 3 Start --
            for list_row3 in db:nrows(
                                 "SELECT * FROM MasterCompTable where recipeid=" ..
                                     list_row2.SubRecipeID ..
                                     " ORDER BY SubRecipeID ASC") do
                mq.delay(1)

                --    print("\atrow 3 start ",list_row3.ItemName)

                --  print("\ayrow 3 ", list_row3.ItemName," ",list_row3.SubRecipeID," row 2 sub id ",list_row2.SubRecipeID)

                if list_row2.SubRecipeID == 0 then break end

                if list_row2.SubRecipeID ~= 0 then

                    -- print(pass_var2, " ROW 3 pass-var")
                    -- switch around so we check for soured items first.. itemid = 0?
                    if list_row3.SubRecipeID > 0 then
                        local r_tv_rv = recipe_calc(list_row2.SubRecipeID,
                                                    list_row3.SubRecipeID,
                                                    pass_var3, silent,
                                                    list_row3.ItemCount,
                                                    list_row3.ItemID)
                        tv_rv = r_tv_rv
                        pass_var4 = tv_rv
                        if tv_rv == 0 then
                            list_row3.SubRecipeID = 0
                        end
                    else

                        --  print("\atrow 3 cas ",list_row3.ItemName)

                        calc_and_soil(list_row3.ItemID, list_row3.ItemCount,
                                      list_row2.SubRecipeID, silent, tv_rv,
                                      list_row3.ItemName, tv_mid)
                    end

                end
                -- ROW 3 END--

                -- ROW 4 --
                for list_row4 in db:nrows(
                                     "SELECT * FROM MasterCompTable where recipeid=" ..
                                         list_row3.SubRecipeID ..
                                         " ORDER BY SubRecipeID ASC") do

                    mq.delay(1)

                    if list_row3.SubRecipeID == 0 then break end

                    if list_row3.SubRecipeID ~= 0 then

                        if list_row4.SubRecipeID > 0 then
                            local r_tv_rv =
                                recipe_calc(list_row3.SubRecipeID,
                                            list_row4.SubRecipeID, pass_var4,
                                            silent, list_row4.ItemCount,
                                            list_row4.ItemID)
                            tv_rv = r_tv_rv
                            pass_var5 = tv_rv
                            if tv_rv == 0 then
                                list_row4.SubRecipeIDemID = 0
                            end
                        else
                            calc_and_soil(list_row4.ItemID, list_row4.ItemCount,
                                          list_row3.SubRecipeID, silent, tv_rv,
                                          list_row4.ItemName, tv_mid)
                        end

                    end
                    -- ROW 4 END--

                    -- ROW 5--

                    for list_row5 in db:nrows(
                                         "SELECT * FROM MasterCompTable where recipeid=" ..
                                             list_row4.SubRecipeID ..
                                             " ORDER BY SubRecipeID ASC") do
                        mq.delay(1)

                        if list_row4.SubRecipeID == 0 then
                            break
                        end

                        if list_row4.SubRecipeID ~= 0 then

                            if list_row5.SubRecipeID > 0 then
                                local r_tv_rv = recipe_calc(
                                                    list_row4.SubRecipeID,
                                                    list_row5.SubRecipeID,
                                                    pass_var5, silent,
                                                    list_row5.ItemCount,
                                                    list_row5.ItemID)
                                tv_rv = r_tv_rv
                                pass_var6 = tv_rv
                                if tv_rv == 0 then
                                    list_row5.SubRecipeID = 0
                                end
                            else
                                calc_and_soil(list_row5.ItemID,
                                              list_row5.ItemCount,
                                              list_row4.SubRecipeID, silent,
                                              tv_rv, list_row5.ItemName, tv_mid)
                            end
                        end

                        -- ROW 6
                        for list_row6 in db:nrows(
                                             "SELECT * FROM MasterCompTable where recipeid=" ..
                                                 list_row5.SubRecipeID ..
                                                 " ORDER BY SubRecipeID ASC") do
                            --  print("\ag[6] Item ID:\aw",list_row6.ItemID,"",list_row6.ItemName)
                            mq.delay(1)

                            if list_row5.SubRecipeID == 0 then
                                break
                            end

                            if list_row5.SubRecipeID ~= 0 then

                                if list_row6.SubRecipeID > 0 then
                                    local r_tv_rv = recipe_calc(
                                                        list_row5.SubRecipeID,
                                                        list_row6.SubRecipeID,
                                                        pass_var6, silent,
                                                        list_row6.ItemCount,
                                                        list_row6.ItemID)
                                    tv_rv = r_tv_rv
                                    pass_var7 = tv_rv
                                    if tv_rv == 0 then
                                        list_row6.SubRecipeID = 0
                                    end
                                else
                                    calc_and_soil(list_row6.ItemID,
                                                  list_row6.ItemCount,
                                                  list_row5.SubRecipeID, silent,
                                                  tv_rv, list_row6.ItemName,
                                                  tv_mid)
                                end

                            end

                            -- ROW 7
                            for list_row7 in db:nrows(
                                                 "SELECT * FROM MasterCompTable where recipeid=" ..
                                                     list_row6.SubRecipeID ..
                                                     " ORDER BY SubRecipeID ASC") do
                                mq.delay(1)

                                if list_row6.SubRecipeID == 0 then
                                    break
                                end

                                if list_row6.SubRecipeID ~= 0 then

                                    if list_row7.SubRecipeID > 0 then
                                        local r_tv_rv = recipe_calc(
                                                            list_row6.SubRecipeID,
                                                            list_row7.SubRecipeID,
                                                            pass_var7, silent,
                                                            list_row7.ItemCount,
                                                            list_row7.ItemID)
                                        tv_rv = r_tv_rv
                                        pass_var8 = tv_rv
                                        if tv_rv == 0 then
                                            list_row7.SubRecipeID = 0
                                        end
                                    else
                                        calc_and_soil(list_row7.ItemID,
                                                      list_row7.ItemCount,
                                                      list_row6.SubRecipeID,
                                                      silent, tv_rv,
                                                      list_row7.ItemName, tv_mid)
                                    end
                                end

                                -- ROW 8
                                for list_row8 in db:nrows(
                                                     "SELECT * FROM MasterCompTable where recipeid=" ..
                                                         list_row7.SubRecipeID ..
                                                         " ORDER BY SubRecipeID ASC") do
                                    mq.delay(1)

                                    if list_row7.SubRecipeID == 0 then
                                        break
                                    end

                                    if list_row7.SubRecipeID ~= 0 then

                                        if list_row8.SubRecipeID > 0 then
                                            local r_tv_rv = recipe_calc(
                                                                list_row7.SubRecipeID,
                                                                list_row8.SubRecipeID,
                                                                pass_var8,
                                                                silent,
                                                                list_row8.ItemCount,
                                                                list_row8.ItemID)
                                            tv_rv = r_tv_rv
                                            pass_var9 = tv_rv
                                            if tv_rv == 0 then
                                                list_row8.SubRecipeID = 0
                                            end
                                        else
                                            calc_and_soil(list_row8.ItemID,
                                                          list_row8.ItemCount,
                                                          list_row7.SubRecipeID,
                                                          silent, tv_rv,
                                                          list_row8.ItemName,
                                                          tv_mid)
                                        end
                                    end

                                    -- ROW 9
                                    for list_row9 in db:nrows(
                                                         "SELECT * FROM MasterCompTable where recipeid=" ..
                                                             list_row8.SubRecipeID ..
                                                             " ORDER BY SubRecipeID ASC") do
                                        mq.delay(1)

                                        if list_row8.SubRecipeID == 0 then
                                            break
                                        end

                                        if list_row8.SubRecipeID ~= 0 then

                                            if list_row9.SubRecipeID > 0 then
                                                local r_tv_rv = recipe_calc(
                                                                    list_row8.SubRecipeID,
                                                                    list_row9.SubRecipeID,
                                                                    pass_var9,
                                                                    silent,
                                                                    list_row9.ItemCount,
                                                                    list_row9.ItemID)
                                                tv_rv = r_tv_rv
                                                pass_var10 = tv_rv
                                                if tv_rv == 0 then
                                                    list_row9.SubRecipeID = 0
                                                end
                                            else
                                                calc_and_soil(list_row9.ItemID,
                                                              list_row9.ItemCount,
                                                              list_row8.SubRecipeID,
                                                              silent, tv_rv,
                                                              list_row9.ItemName,
                                                              tv_mid)
                                            end
                                        end

                                        -- ROW 10
                                        for list_row10 in db:nrows(
                                                              "SELECT * FROM MasterCompTable where recipeid=" ..
                                                                  list_row9.SubRecipeID ..
                                                                  " ORDER BY SubRecipeID ASC") do
                                            mq.delay(1)

                                            if list_row9.SubRecipeID == 0 then
                                                break
                                            end

                                            if list_row9.SubRecipeID ~= 0 then

                                                if list_row10.SubRecipeID > 0 then
                                                    local r_tv_rv = recipe_calc(
                                                                        list_row10.SubRecipeID,
                                                                        list_row9.SubRecipeID,
                                                                        pass_var10,
                                                                        silent,
                                                                        list_row10.ItemCount,
                                                                        list_row10.ItemID)
                                                    tv_rv = r_tv_rv
                                                    pass_var11 = tv_rv
                                                    if tv_rv == 0 then
                                                        list_row10.SubRecipeID =
                                                            0
                                                    end
                                                else
                                                    calc_and_soil(
                                                        list_row10.ItemID,
                                                        list_row10.ItemCount,
                                                        list_row9.SubRecipeID,
                                                        silent, tv_rv,
                                                        list_row10.ItemName,
                                                        tv_mid)
                                                end
                                            end

                                            -- ROW 11
                                            for list_row11 in db:nrows(
                                                                  "SELECT * FROM MasterCompTable where recipeid=" ..
                                                                      list_row10.SubRecipeID ..
                                                                      " ORDER BY SubRecipeID ASC") do
                                                mq.delay(1)

                                                if list_row10.SubRecipeID == 0 then
                                                    break
                                                end

                                                if list_row10.SubRecipeID ~= 0 then

                                                    if list_row11.SubRecipeID >
                                                        0 then
                                                        local r_tv_rv =
                                                            recipe_calc(
                                                                list_row11.SubRecipeID,
                                                                list_row10.SubRecipeID,
                                                                pass_var11,
                                                                silent,
                                                                list_row11.ItemCount,
                                                                list_row11.ItemID)
                                                        tv_rv = r_tv_rv
                                                        -- rownot implmented
                                                        --   pass_var12 = tv_rv
                                                        if tv_rv == 0 then
                                                            list_row11.SubRecipeID =
                                                                0
                                                        end
                                                    else
                                                        calc_and_soil(
                                                            list_row11.ItemID,
                                                            list_row11.ItemCount,
                                                            list_row10.SubRecipeID,
                                                            silent, tv_rv,
                                                            list_row11.ItemName,
                                                            tv_mid)
                                                    end
                                                end

                                            end
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
            end
        end
        -- print ("\ay**********************************************************")
    end

    local recipe_array = data_array

    --  print "recruncher"
    --  for c = 1, #recipe_array do print(recipe_array[c]) end

    local temp_tool_array = {}
    local last_tool_id = 0

    -- Check if there are any tools that we don't have in the recipe

    -- I think this can go..

    if tool_array[1] ~= nil then
        table.sort(tool_array)
        -- Remove Duplicate Tools
        for x = 1, #tool_array do
            if last_tool_id ~= tool_array[x] then
                -- print("\agRecrunch Tool: ", tool_array[x])
                table.insert(temp_tool_array, tool_array[x])
            end
            last_tool_id = tool_array[x]
        end
        -- Reset main tool array
        tool_array = {}
        -- Remove Tools if have count..
        for x = 1, #temp_tool_array do
            local l_recipe_id = lib.return_number(temp_tool_array[x], 1)
            l_item_id = lib.return_item_ID(l_recipe_id)
            --  print("\ayCruncher: Temp Tools: ", temp_re_tool_array[x])
            if mq.TLO.FindItemCount(l_item_id)() < 1 then
                table.insert(tool_array, temp_tool_array[x])
            end
        end
    end

    -- if have generate flag then don't add tools but do a tool list with just the recipe ID?

    -- This is used for making tools not for banking lists
    -- for c = 1, #tool_array do print("Cruncher Final Tools: ", tool_array[c]) end

    local tools = tool_array
    tool_array = {}

    -- Used to compare to final craft recipe list to make sure no re-crunching needed.
    -- print(msg, lib.return_recipe_name(main_id))
    -- print "check reverse order TCN Cruncher"

    for x = #recipe_array, 1, -1 do
        -- print("\aw TCN Re-CRUNCHER \agReverse Order: \at", recipe_array[x])
    end

    -- Sort Soiled Table
    table.sort(soiled)

    -- for x = 1, #soiled do print("\awSorted Soiled: \ay", soiled[x]) end

    -- Add missing items to bank array and squash counts

    local last_id = 0
    local TotalCount = 0
    local var_ItemName
    local temp_bank_array2 = {}
    local final_missing_array = {}
    local go_flag = 1

    -- extra arrays
    -- last chance shopping here..

    -- just go through table instead of this? the table?
    -- Add banked trophies
    local trophy_temp = {}
    local l_trophy_id
    local flag = 1

    for k = 1, #recipe_array do
        --  print(recipe_array[k])
        --  print("\aw",lib.return_number(recipe_array[k], 4))
    end

    for k = 1, #recipe_array do
        local l_recipe_id = lib.return_number(recipe_array[k], 4)

        l_recipe_skill = lib.return_recipe_skill(l_recipe_id)

        local l_have_trophy = lib.have_trophy(l_recipe_skill)

        -- Trophy in bank add to list
        if mq.TLO.FindItemCount(l_have_trophy)() < 1 and l_have_trophy ~= nil then
            if trophy_temp[1] == nil then
                l_trophy_id = mq.TLO.FindItemBank(l_have_trophy).ID()
                table.insert(trophy_temp,
                             l_have_trophy .. "," .. l_trophy_id .. ",1")
            end

            flag = 1
            for z = 1, #trophy_temp do
                l_trophy_id = mq.TLO.FindItemBank(l_have_trophy).ID()

                if l_trophy_id == lib.return_number(trophy_temp[z], 2) then
                    flag = 0
                end

                if flag == 1 then
                    l_trophy_id = mq.TLO.FindItemBank(l_have_trophy).ID()
                    table.insert(trophy_temp,
                                 l_have_trophy .. "," .. l_trophy_id .. ",1")
                    flag = 0
                end
            end
        end
    end

    --   for x = 1, #temp_bank_array do print("\aw",temp_bank_array[x]) end
    --   for x = 1, #trophy_temp do print("Trophies: ", trophy_temp[x]) end

    -- Sort trophies
    table.sort(trophy_temp)

    -- How bout every trophy is value of 1?

    -- Squash trophies
    local last_trophy = 0
    local trophy_temp2 = {}
    for x = 1, #trophy_temp do

        -- stopped from adding trophies 1/3/22

        if last_trophy ~= trophy_temp[x] then
            --  table.insert(trophy_temp2, trophy_temp[x])
        end
        last_trophy = trophy_temp[x]
    end

    -- for x = 1, #trophy_temp2 do print("\atFinal Trophies: ", trophy_temp2[x]) end

    -- stopped from adding trophies 1/3/22

    -- Add trophies to bank shopping list
    for j = 1, #trophy_temp2 do
        --  table.insert(temp_bank_array2, trophy_temp2[j])
    end

    -- for x = 1 , #recipe_array do print (recipe_array[x]) end
    -- note add a recipe to do a conversion or recplace/add to do a sub replace?

    for x = 1, #banked_tools_array do
        --     print("\atcruncher banked tools ", banked_tools_array[x])
    end

    -- Add tools from bank

    -- Sort Banked Tools
    table.sort(banked_tools_array)

    --- Squash Banked Tools

    local last_tool = 0
    local tool_temp2 = {}
    for x = 1, #banked_tools_array do
        if last_tool ~= banked_tools_array[x] then
            table.insert(tool_temp2, banked_tools_array[x])
        end
        last_tool = banked_tools_array[x]
    end

    banked_tools_array = {}

    -- Add to banked array
    for x = 1, #tool_temp2 do table.insert(temp_bank_array2, tool_temp2[x]) end

    -- final list of tools, trophies, and whatever
    -- for x = 1, #temp_bank_array2 do print("\agfinal final banked tools: ",temp_bank_array2[x]) end

    tool_temp2 = {}
    temp_bank_array = temp_bank_array2
    temp_bank_array2 = {}
    trophy_temp = {}
    trophy_temp2 = {}

    for x = 1, #temp_bank_array do
        --      print("\agcruncher temp bank array ", temp_bank_array[x])
    end

    -- it thinks it can make the item when it gets here but now let's add up all the counts - Components

    -- Sort and Count temp_banked_components
    if temp_banked_components[1] ~= nil then
        local temp_array = temp_banked_components
        --    lib.return_sorted_counts_array(temp_banked_components)
        temp_banked_components = temp_array
        temp_array = {}

        local final_banked_components = {}

        -- Determine if we can really make the item based on count
        for c = 1, #temp_banked_components do
            --  print("\atCruncher temp banked components",
            --     temp_banked_components[c])

            l_item_id = lib.return_number(temp_banked_components[c], 2)

            local final_inv_component_check = mq.TLO.FindItemCount(l_item_id)()
            local final_bank_inv_component_check =
                mq.TLO.FindItemBankCount(l_item_id)()
            local final_combined_inv = final_inv_component_check +
                                           final_bank_inv_component_check
            local f_need_count = lib.return_number(temp_banked_components[c], 3)
            local f_item_name = lib.return_string(temp_banked_components[c], 1)

            local f_get_count = 0

            -- Our total bank+inv meets or exceeds the need count

            if final_combined_inv >= f_need_count then
                if final_inv_component_check > 0 then
                    f_get_count = f_need_count - final_inv_component_check
                else
                    f_get_count = f_need_count
                end

                local final_comp_string =
                    f_item_name .. "," .. l_item_id .. "," .. f_get_count

                table.insert(final_banked_components, final_comp_string)
                --    print("cruncher need: ", f_need_count, " get: ", f_get_count,
                --       " what: ", f_item_name)

            else
                -- We bit off more than we could chew, and vendor can't save us
                local vendor_item_query = lib.vendor_has_item(l_item_id)
                if vendor_item_query == 0 then
                    go_flag = 0
                    break
                end
            end
        end

        --  print("wipe out tables,go_flag ",go_flag)

        -- Wipe out tables
        if go_flag == 0 then
            final_banked_components = {}
            temp_banked_components = {}
        end

        -- Add banked components to temp bank shopping list
        if final_banked_components[1] ~= nil then
            for x = 1, #final_banked_components do
                --  print("\aoadding final components: ", final_banked_components[x])
                table.insert(temp_bank_array, final_banked_components[x])
            end
        end

        final_banked_components = {}
        temp_banked_components = {}
    end

    --  for z = 1, #temp_bank_array do print("current bank array after squashed and counted components ", temp_bank_array[z]) end

    -- Format for temp_banked_recipes ItemName, ItemID, ItemCountNeeded

    -- Sort and Count temp_banked_recipes
    if temp_banked_recipes[1] ~= nil then
        local temp_array = temp_banked_recipes
        --     lib.return_sorted_counts_array(temp_banked_recipes)
        temp_banked_recipes = temp_array
        temp_array = {}

        local final_banked_recipes = {}

        -- Determine if we can really make the item based on count
        for c = 1, #temp_banked_recipes do
            --  print("\atCruncher temp banked components",temp_banked_components[c])

            l_item_id = lib.return_number(temp_banked_recipes[c], 2)

            local final_inv_component_check = mq.TLO.FindItemCount(l_item_id)()
            local final_bank_inv_component_check =
                mq.TLO.FindItemBankCount(l_item_id)()
            local final_combined_inv = final_inv_component_check +
                                           final_bank_inv_component_check
            local f_need_count = lib.return_number(temp_banked_recipes[c], 3)
            local f_item_name = lib.return_string(temp_banked_recipes[c], 1)

            local f_get_count = 0

            -- Our total bank+inv meets or exceeds the need count
            if final_combined_inv >= f_need_count then

                if final_inv_component_check > 0 then
                    f_get_count = f_need_count - final_inv_component_check
                else
                    f_get_count = f_need_count
                end

                local final_comp_string =
                    f_item_name .. "," .. l_item_id .. "," .. f_get_count

                table.insert(final_banked_recipes, final_comp_string)
                --    print("cruncher need: ", f_need_count, " get: ", f_get_count)

            else
                go_flag = 0
            end
        end

        -- Wipe out banked recipe tables
        if go_flag == 0 then
            final_banked_recipes = {}
            temp_banked_recipes = {}
        end

        -- If tables survived add to temp bank shopping list
        if final_banked_recipes[1] ~= nil then
            for x = 1, #final_banked_recipes do
                --  print("adding final components: ",final_banked_components[x])
                table.insert(temp_bank_array, final_banked_recipes[x])
            end
        end

        -- for c =1 , #final_banked_recipes do print("Final Banked Recipes List: ",final_banked_recipes[c]) end

        final_banked_recipes = {}
        temp_banked_recipes = {}
    end

    for c = 1, #temp_bank_array do
        --   print("\atTemp Banked Array after all processing List: ",
        --     temp_bank_array[c])
    end

    -- Sort and Count soiled comparison array
    if compare_soiled[1] ~= nil then
        local temp_array = compare_soiled
        -- lib.return_sorted_counts_array(compare_soiled)
        compare_soiled = temp_array
        temp_array = {}
    end

    local final_compare_soiled_array = {}

    -- Determine if we have enough of what is missing in bank and inventory
    for z = 1, #compare_soiled do
        local l_compare_item_id = lib.return_number(compare_soiled[z], 2)

        local final_soiled_comp_check = mq.TLO
                                            .FindItemCount(l_compare_item_id)()
        local final_soiled_bankcomp_check =
            mq.TLO.FindItemBankCount(l_compare_item_id)()
        local total_soiled_comp_check = final_soiled_comp_check +
                                            final_soiled_bankcomp_check

        local l_soiled_need_count = lib.return_number(compare_soiled[z], 3)

  
        if l_soiled_need_count > total_soiled_comp_check then
            local l_soiled_item_name = lib.return_string(compare_soiled[z], 1)

            go_flag = 0

            local l_missing_count = l_soiled_need_count
            -- Removed calculation of inventory so we would have total accurate need count
            -- -                                        total_soiled_comp_check

            --   print(msg, "\ayMissing Items: \ap[\ag", l_soiled_item_name,
            -- "\ap] \ay Need: ", l_missing_count, " Have: ",
            --  total_soiled_comp_check)

            local farm_action, farm_zone =
                lib.return_item_source(l_compare_item_id)

            local final_missing_string =
                l_soiled_item_name .. "," .. l_compare_item_id .. "," ..
                    l_missing_count .. "," .. farm_action .. "," .. farm_zone
            table.insert(final_compare_soiled_array, final_missing_string)
        end

    end

    temp_banked_recipes = {}
    temp_banked_components = {}

    -- print("cruncher go flag ", go_flag)
    -- 
    -- Erase Soiled Array When We can make the whole recipe based on count
    if go_flag == 1 then
        soiled = {}
    else
        -- Wipe out bank shopping array because we can't make the item..
        temp_bank_array = {}
    end

    -- for x = 1, #soiled do print("\agTCN Cruncher \atSoiled ", soiled[x]) end

    -- if soiled[1] ~= nil then m = {} end

    -- print("\aySoiled: ",soiled[1])

    -- for c = 1  , #recipe_array do print(recipe_array[c]) end

    -- Tools to add for generation list.
    -- for c = 1, #tools do print(tools[c]) end

    GLOBAL_TEXT = "Recipe processed..."

    -- t_component_array = lib.return_sorted_counts_array(t_component_array)

    return recipe_array, soiled, tools, temp_bank_array,
           final_compare_soiled_array, t_component_array
end

return recrunch
