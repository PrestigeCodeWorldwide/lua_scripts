-- name: TCG/init.lua
-- created: 10/25/2021
-- creator:jb321
-- updated: 09/15/2025
---@type mq
---- @class mq
local mq = require('mq')

local PackageMan = require('mq/PackageMan')
PackageMan.Require('lsqlite3')

---@type ImGui
---- @class ImGui
require 'ImGui'

local tcglib = require('tcg_libraries')

require('tcn_events')

tcglib.SellDB_Check()

-- Check for docking
--local io = ImGui.GetIO()
--if bit32.band(io.ConfigFlags, ImGuiConfigFlags_DockingEnable) ~= 0 then
-- print("Docking is enabled in this ImGui build.")
--else
--print("Docking is NOT enabled in this ImGui build.")
--end

-- Crash testing
-- mq.cmd('/mqoverlay resume')

-- mq.cmd('/mqoverlay reload')

-- local TEXT_BASE_WIDTH, _ = ImGui.CalcTextSize("A")
local TEXT_BASE_HEIGHT = ImGui.GetTextLineHeightWithSpacing();

-- TOP

local msg = "\at[\aoTCSNe\agX\aot\at]\aw "

-- global vars for recipe lookup
RecipeToShow = nil
PendingRecipe = nil

print(msg, "Starting Tradeskill Construction Set NeXt")

-- Disable/Stop Plugins Section

-- Stop auto-forage
if mq.TLO.Plugin('mq2autoforage')() then
    --   print(msg, "\awDisabling: \agAuto-Forage")
    mq.cmd('/squelch /stopforage')
end

GLOBAL_MQ2TSTrophy_Plugin = 0

mq.delay(1)

-- Dannet Bounce/Load
if not mq.TLO.Plugin('MQ2DanNet')() then
    print(msg, "\ap[\awLoading: \agMQ2DanNet \awplugin\ap]")
    mq.cmd('/squelch /plugin MQ2DanNet load')
else
    print(msg, "\ap[\awBouncing: \agMQ2DanNet \awplugin\ap]")
    mq.cmd('/squelch /plugin MQ2DanNet unload')
    mq.delay(2000)
    mq.cmd('/squelch /plugin MQ2DanNet load')
end

mq.delay(1000)
print(msg, "\ap[\agMQ2DanNet \awis now loaded\ap]")

mq.delay(1)

-- Unload MQ2TSTrophy Plugin
if mq.TLO.Plugin('MQ2TSTrophy')() then
    print(msg, "\ap[\awUnloading: \agMQ2TSTrophy \awplugin\ap]")
    mq.cmd('/squelch /plugin MQ2TSTrophy unload')
    GLOBAL_MQ2TSTrophy_Plugin = 1
end

mq.delay(1)

-- mq.cmd('/squelch /plugin MQ2TSTrophy load')

-- List of expansions to check
do
    local expansions = { "NOS", "LSO", "TOB" }
    for _, code in ipairs(expansions) do
        tcglib.check_and_update_db(code)
    end
end

-- Remove levitation effects
print(msg, "Removing Levitation")
mq.cmd('/squelch /removelev')

print(msg, "Removing Visible Familiar")
-- Remove visible familiar
mq.cmd('/removebuff "summon familiar"')
mq.delay(1000)

-- print(msg, "Removing Illusion")
-- Remove Illusion
-- mq.cmd('/squelch /removebuff "illusion"')
-- mq.delay(1000)
-- mq.cmd('/squelch /removebuff "illusion"')

-- Clean up
-- print("unrem /cleanup tcn")
-- mq.cmd('/cleanup')

-- auto inv

-- Lua Version
--print(_VERSION)

-- Use new cruncher method for mass generation
local new_engine_bool = true

-- Temp to close info window for batch
BW_OPEN = false

-- Global var for stopping at 350 for artisan prize
GLOBAL_THREEFITTY = false

-- Array for batch depot data
local ret_batch_depot_data = {}

-- Array for max/artisan depot data
local ret_max_depot_data = {}

-- artisan max farm list
local art_max_farm_list = {}

-- Text Input Search Var
GLOBAL_TXT_INPUT = ""

-- GLOBAL_TXT_INPUT = string.rep("\0", 100)

-- for server events
GL_SWITCH = 0

-- Flag for not experienced break for Artisan
EXP_FLAG = 0

GLOBAL_DEPOT_FULL = false

-- bam
GLOBAL_ENGINE_FLAG = true

-- loose search vars for text search
local search_type_text = 0
local cb_search_type = false

-- Known/Unkown Artisan Recipe List Arrays
MAX_UNKNOWN_ARRAY = {}
MAX_KNOWN_ARRAY = {}

-- Fish Swap vars
FISH_SCALE_SWAP = false
FISH_SWAP = false

-- Purchase Multiplier Vars
BUY_MULT = 1
BUY_MULT_selection = 1

USE_MULT = false

-- Favorite Array for holding favorites
local fav_array = {}

-- Artisan Generate Recipe List Variables
GEN_selection = 1
GEN_selection_index = 0
GEN_array = { "10", "20", "30", "40", "50", "75", "100" }

-- Guild Hall Banking Array
-- GH vars
MASS_gh_bank_array = {}
GO_GUILD_HALL = 0

-- Dragon Hoard vars
MASS_dh_bank_array = {}
GO_DRAGON_HOARD = 0

-- Cultural testing switch -- set to 0 for off
GLOBAL_CULT_TESTING = 0

-- Batch File Op Vars
-- Batch variables
local batch_continue_cb = false

GLOBAL_BATCH_CONTINUE = 0
BATCH_OPS_WINDOW_GUI = false
BATCH_FILE_SELECT = 0
B_dir_results = ""

-- Variables for collapsing recipes and counts
GLOBAL_COLLAPSE_FLAG = 0
GLOBAL_COLLAPSE_CB = false

-- Global ReCrunch INV Array
GLOBAL_CRUNCH_ARRAY = {}

-- Recipe variable to display name during max crafting
GLOBAL_MAX_RECIPE = "Nothing"

-- Configurable start for max 350/Artisan
GLOBAL_MAX_START = 1

-- For determing which zone to go to culturally
GLOBAL_REQ_RACE = nil

-- Ignore tools during crunch (1)
GLOBAL_TOOL_RECIPE = 0

-- Ability to toggle recrunching (currently defunct)
-- GLOBAL_NO_RECRUNCH = 0

-- Turn off text spam unless crafting 350
GLOBAL_MISSING_SPAM = 0

-- Allows the user to go to the NGH or use POK
GLOBAL_CRAFTING_ZONE = 0

-- Set array for mass shopping zone selection
local mass_zone_select = 1
local mass_zone_array = {}
local mass_bank_array = {}
local mass_shop_array = {}

BANK_ARRAY = {}

GLOBAL_SOILED_ARRAY = {}

-- Set Auto-Deposit to on
GLOBAL_DEPOSIT_FLAG = 1

-- Set Auto-Depot to off
GLOBAL_DEPOT_FLAG = 0

-- Set add tool recipes to on
-- GLOBAL_GENERATE_FLAG = 0

local t_quest_selection = nil

local request_array_list = {}

local t_max_selection = nil

local animItems = mq.FindTextureAnimation('A_DragItem')

-- Make visible at runtime
mq.cmd('/squelch /makemevisible')

local feeder = require('\\tcn\\tcn_feeder')

-- Batch crafting vars
-- local batch_rec_id = nil
local batch_array = {}
local go_batch = 0
local batch_window_openGUI = false

-- craftbutton bool
local craft_button_bool

-- Artisan Seal Bool Button
local art_button_bool

-- shopping window data
-- local l_shopping_select = 0
-- local l_shopping_index = 0

-- local standard buttons
local standard_button_pause_bool = false

-- set starting button color for craft
local scw_r_col, scw_g_col, scw_b_col = 1, 1, 1

local max_recipe_array = {}

-- Load database count
-- local db_count = feeder.db_count()
-- currently 43769

local destroy_max_bool = false
local sell_max_bool = false
local bank_max_bool = false

local continue_max_bool = false
local cheap_max_bool = false

-- 0 is cheap
-- 1 is full

GLOBAL_MAX_CRAFT_ROUTINE = 0

GLOBAL_MAX_CONT = 0

-- was false
-- Make it always generate a report when doing an Artisan Run
-- local report_max_bool = true

local go_shop = 0
local go_ask = 0
local go_block = 0

-- set limit to 30
local max_generate_cb = true

-- Ignore making and counting missing components for tools
-- local ignore_tool_cb = true

-- global settings globals

-- Set Array for single recipe missing list
-- local single_recipe_farmlist = {}
-- local override_goal_count = 0

local go_craft = 0
local can_craft = 4

local go_max = 0

local go_quest = 0
local go_deposit = 0

-- local max_counter = 0

PCT_DONE = 0

local go_no_go_skill_select
local go_no_go_skillreq

-- What's in Ammo slot?
GLOBAL_AMMO_SLOT = mq.TLO.Me.Inventory(22).ID()

-- What's in Primary slot?
GLOBAL_PRIMARY_SLOT = mq.TLO.Me.Inventory(13).ID()

-- Option Globals for Cruncher (Make 1 tool)
GLOBAL_OPTION_FLAG = 0

-- craft max globals

-- local recipe_search_button_toggle = "Hide Recipe Search Results"

-- shopping list stuff
-- local ignore_array = {}
local trim_soiled = {}
local recipe_disposition_data = {}
local recipe_shopping_data = {}
local max_recipe_shopping_data = {}
local recipe_stack_data = {}

-- work on this
local script_status_text = nil

-- Depot array
local l_depot_array = {}

-- farm list for quests
local quest_farm_list = {}
local artisan_farm_list = {}
local merchant_farm_list = {}

-- Set array for 350 farm list
local max_farm_list = {}

local l_make_amount = 1

-- local b_make_amount = 1

local lab = "Execute Query"

-- TSS Data

local tss_quests = {
    "Pottery", "Brewing", "Blacksmithing", "Tailoring", "Jewelry Making",
    "Baking", "Fletching", "Tinkering", "Alchemy", "Poison Making", "Research",
    "All"
}

local tss_selection = 1

-- local tss_selection_index = 0

-- local tss_bool_button = false
-- local tss_bool_button_label = "Go"

-- just add number and it will work for food and 2x brew
local alphabet = {
    "#", "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N",
    "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z"
}

-- God Data
local god_quests = {
    "Pottery", "Brewing", "Blacksmithing", "Tailoring", "Jewelry Making",
    "Baking", "Fletching", "Tinkering", "Alchemy", "Poison Making", "All"
}

-- max variable array area

local max_array = {
    "Alchemy", "Baking", "Blacksmithing", "Brewing", "Fishing", "Fletching",
    "Jewelry Making", "Make Poison", "Pottery", "Research", "Tailoring",
    "Tinkering"
}

-- Seals
local art_selection = 1

-- Artisan Prize Window
local l_max_selection = 1
local l_max_index = 0

-- local l_max_farm_selection = 0
-- end

-- artisan tab vars

local artisan_button_pause_bool = false
-- local artisan_pause_toggler = 0

local set_artisan_text_color_r = 1
local set_artisan_text_color_g = 1
local set_artisan_text_color_b = 0.9

-- recipe search vars
-- local show_recipe_search_results = 0
-- local show_shopping_results = 0

-- trophy vars
-- local trophy_index = 0

local trophy_selection = 1
local trophy_button_bool = false

local trophy_button_action_bool = false

local trophy_action = "Stop"

-- god vars

local god_selection = 1
-- local god_selection_index = 0

-- local god_button_go_bool = false
local god_button_pause_bool = false
-- local god_button_stop_bool = false

local god_bool_button = false

local god_button_label = "Pause"

local god_action_button = "Go"

local god_go = 0

-- crunch go

local crunch_go = 0

----
-- local peer_go = 0

-- some button
local click_value

-- search result variables

GLOBAL_item_id = 0

local id_select = 0
local l_item_id = 0
local name_select = nil
-- local container_select = nil
local skill_select = nil
local skill_req = 0
-- local trivial_select = nil

-- ID Select
local small_button_click_value

-- variables

local s_combo_box_index = 1
local s_combo_box_selected = 1
local s_combo_box_selected_skill = 1
local s_combo_box_index_skill = 1

local s_combo_box_selected_exp = 1
local s_combo_box_index_exp = 1

-- test
local current_item = 0

local openGUI = true
local shouldDrawGUI = true

-- various gui setting

-- local openMaxFarmWindowGUI = false
-- local openShoppingListGUI = false

-- Open Standard Recipes Window With Tabs

OPENInfoWindow = false

-- local openRecipeRequirementsGUI = false
-- local openFarmWindowGUI = false
-- local openRecipeListGUI = false

OPENToonShoppingListGUI = false

-- bool for Artisan Known Unknown List
local info_max_bool = false
GLOBAL_INFO_MAX = 0

tcglib.check_faction()

-- Batch List Vars

BATCH_FARM_LIST = {}
BATCH_SHOPPING_DATA = {}
BATCH_ZONE_ARRAY = {}
BATCH_BANK_ARRAY = {}
BATCH_ZONE_SELECT = 1

local levitate_cb_bool = false

local recipe_search_results = {}
local recipe_batch_results = {}

local trophy_quest_array = feeder.trophy_quests()

local trophy_flag = 0

local monitor_trophy_flag = 0

-- global vars defined

GLOBAL_TASK_UPDATE = 0

GLOBAL_TROPHY_FLAG = 0
GLOBAL_BANK_FLAG = 0

GLOBAL_BANK_WITHDRAW_FLAG = 1

GLOBAL_SHOP_FLAG = 0

GLOBAL_PLATINUM = 5000

local autoshop_cb_bool = true
local autoguild_cb_bool = false
local autobank_cb_bool = true
local autodeposit_cb_bool = true
local autodepot_cb_bool = false
local autotoon_cb_bool = false
local autotrophy_cb_bool = true
local autoplatinum_cb_bool = false

-- override bool checkbox var
local override_cb_bool = false

-- Load favorites into memory
fav_array = tcglib.favorites()

tcglib.trophytribute_init()

tcglib.depot_init()

-- Testing
-- fav_array = {92742, 1014, 1577, 34819}
local fav_btn_bool = false

-- Global destroy if file missing create
if not tcglib.settings_exist("Global_Destroy.csv") then
    print(msg, "Creating Global Destroy File")
    tcglib.writefile("Global_Destroy.csv", "")
    mq.delay(100)
end

if not tcglib.settings_exist("NoArtisan_Destroy.csv") then
    print(msg, "Creating Artisan Non-Destruction File")
    tcglib.writefile("NoArtisan_Destroy.csv", "")
    mq.delay(100)
end

-- Create depot items to not return file
if not tcglib.settings_exist("Depot_Ignore.csv") then
    print(msg, "Creating Depot Skip File")
    tcglib.writefile("Depot_Ignore.csv", "")
    mq.delay(100)
end

-- Load Global Settings

-- local s_file =
--   "Artisan_GS_" .. mq.TLO.Me() .. "_" .. mq.TLO.MacroQuest.Server() .. ".csv"
-- local file_exist_bool = tcglib.settings_exist(s_file)

local file_exist_bool = tcglib.settings_exist(
    "Artisan_GS_" .. mq.TLO.Me() .. "_" ..
    mq.TLO.MacroQuest.Server() .. ".csv")

if file_exist_bool then
    --  local read_data = tcglib.read_settings(s_file)
    local read_data = tcglib.read_settings(
        "Artisan_GS_" .. mq.TLO.Me() .. "_" ..
        mq.TLO.MacroQuest.Server() .. ".csv")
    --  print(read_data[0])
    local ass = tcglib.return_number(read_data[0], 1)
    local ags = tcglib.return_number(read_data[0], 2)
    local ats = tcglib.return_number(read_data[0], 3)
    local abs = tcglib.return_number(read_data[0], 4)
    local ads = tcglib.return_number(read_data[0], 5)
    local adt = tcglib.return_number(read_data[0], 6)
    local aps = tcglib.return_number(read_data[0], 7)

    -- Account for new auto-depot with existing settings
    if aps == nil then
        aps = adt
        adt = 0
        autodepot_cb_bool = false
    end

    GLOBAL_PLATINUM = aps
    if ass == 1 then
        autoshop_cb_bool = true
        GLOBAL_SHOP_FLAG = 1
    else
        autoshop_cb_bool = false
        GLOBAL_SHOP_FLAG = 0
    end
    if ags == 1 then
        autoguild_cb_bool = true
        GLOBAL_CRAFTING_ZONE = 1
    else
        autoguild_cb_bool = false
        GLOBAL_CRAFTING_ZONE = 0
    end
    if ats == 1 then
        autotrophy_cb_bool = true
        GLOBAL_TROPHY_FLAG = 1
    else
        autotrophy_cb_bool = false
        GLOBAL_TROPHY_FLAG = 0
    end
    if abs == 1 then
        autobank_cb_bool = true
        GLOBAL_BANK_FLAG = 1
    else
        autobank_cb_bool = false
        GLOBAL_BANK_FLAG = 0
    end
    if ads == 1 then
        autodeposit_cb_bool = true
        GLOBAL_DEPOSIT_FLAG = 1
    else
        autodeposit_cb_bool = false
        GLOBAL_DEPOSIT_FLAG = 0
    end
    if adt == 1 then
        autodepot_cb_bool = true
        GLOBAL_DEPOT_FLAG = 1
    else
        autodepot_cb_bool = false
        GLOBAL_DEPOT_FLAG = 0
    end
end

local skill_types = {
    "Alchemy", "Baking", "Blacksmithing", "Brewing", "Fishing", "Fletching",
    "Jewelry Making", "Make Poison", "Pottery", "Research", "Tailoring",
    "Tinkering"
}

-- Steps
-- Add new expansion here
-- and then add expansion and abbreviation in tcn_feeder
-- and also under return_logo function to get the logo for the expansion

local expansion_names = {
    "The Outer Brood", "Laurion's Song", "Night of Shadows", "Terror of Luclin",
    "Claws of Veeshan", "Torment of Velious", "The Burning Lands",
    "Ring of Scale", "Empires of Kunark", "The Darkened Sea",
    "Call of the Forsaken", "Rain of Fear", "Veil of Alaris", "House of Thule",
    "Underfoot", "Seeds of Destruction", "Secrets of Faydwer", "The Buried Sea",
    "The Serpent's Spine", "Prophecy of Ro", "Depths of Darkhollow",
    "Dragons of Norrath", "Omens of War", "Gates of Discord",
    "Lost Dungeons of Norrath", "Legacy of Ykesha", "Planes of Power",
    "Shadows of Luclin", "Scars of Velious", "Ruins of Kunark", "Everquest"
}

-- Functions

local ColumnID_ID = 0
local ColumnID_Name = 1
local ColumnID_Quantity = 2
local ColumnID_Vendor = 3
local ColumnID_Price = 4
local ColumnID_ZoneName = 5
local ColumnID_Action = 6
local ColumnID_Inventory = 7
local ColumnID_RID = 8

local ColumnID_Button = 9
local ColumnID_EXP = 11
local ColumnID_Trivial = 13
local ColumnID_Yield = 14
local ColumnID_Container = 15

local current_sort_specs = nil

-- sorting arrays for windows
local converted_shopping_data = {}
local converted_farm_data = {}
local converted_recipe_data = {}

local converted_batch_shopping_data = {}
local converted_batch_farm_data = {}

local converted_mass_shopping_data = {}
local converted_mass_farm_data = {}

-- MAX globals

-- used to display when generating list

-- Used to determine how many recipes to use for generating max 350 list
GLOBAL_MAX_GEN = 0

-- Global to set used flag for 350 tradeskill items
GLOBAL_MAX_USED = 0

GLOBAL_MAX_RECIPE_COUNT = 0

-- Used to toggle banking 350 tradeskill items after each craft for main recipe only.. for now
GLOBAL_MAX_BANK_FLAG = 0

-- make it an option

-- should we put destroy and sell as a global for both?

GLOBAL_MAX_DESTROY_FLAG = 0

-- do a search for each variable when we are all done and see if they are used especially globals

GLOBAL_MAX_LEARNED_FLAG = 0
GLOBAL_MAX_FAILED_FLAG = 0

GLOBAL_MAX_RECIPE_COUNTER = 0

GLOBAL_MAX_RECIPE_ID = 0
GLOBAL_MAX_ITEM_ID = 0

-- Display report from Max Run
-- GLOBAL_MAX_REPORT_FLAG = 0

GLOBAL_MAX_RECIPE_NAME = nil

GLOBAL_MAX_DESTROY_ID = 0
GLOBAL_MAX_SELL_ID = 0
GLOBAL_MAX_SELL_THRESHOLD = 0
GLOBAL_MAX_SELL_FLAG = 0

GLOBAL_TEXT = nil

GLOBAL_MAX_KNOWN = 0
GLOBAL_MAX_HOWMANY = 0
GLOBAL_MAX_PCT = 0

-- Used for item icons
GLOBAL_CRAFT_ID = 0
GLOBAL_PURCHASE_ID = 0

-- Standard Crafting Settings

GLOBAL_STANDARD_CRAFTING_STATUS_MSG = nil

GLOBAL_STANDARD_SKILL_ID = 0
GLOBAL_STANDARD_DESTROY_ID = 0
GLOBAL_STANDARD_SELL_ID = 0

GLOBAL_ABORT_FLAG = 0

-- Was 30 set to 0 (Sets delay after each final craft attempt in Artisan Run)
GLOBAL_MAX_TIMER = 0

GLOBAL_STANDARD_SELL_THRESHOLD = 0

GLOBAL_STANDARD_AUTOCONTINUE = 0
GLOBAL_STANDARD_UI = 0

GLOBAL_STANDARD_ID = 0

-- Flag for lore combines
GLOBAL_LORE_FLAG = 0

-- Max 350 Crafting Settings

GLOBAL_MAX_CRAFTING = 0

-- GLOBAL_STANDARD_CRAFTING = 0

local standard_destroy_cb = false
local standard_sell_cb = false
local standard_skill_cb = false
local standard_continue_cb = false
local standard_ui_cb = false
local standard_info_cb = false

local go_sell = 0
local go_destroy = 0
local go_continue = 0

BATCH_TEXT_INPUT = ""

-- try to make them local if possible if not returned from another lua

-- Item Lookup Variables
ITEM_RECIPE_RESULTS = {}
ITEM_RECIPE_RESULTS_LOOKUP = {}

local text_input = ""

-- ToonShoppingListWindow Data
local pass_array = {}
local pass_shop_array = {}
local pass_zone_array = {}
local pass_zone_select = 1

-- Buddy vars
local dir_results = {}
local f_select = 0
local go_buddy = 0

-- Preload recipe results with Alchemy and A
-- recipe_search_results = feeder.recipe_search_results("A","Alchemy")

-- Local Functions
local function CompareWithSortSpecs(a, b)
    for n = 1, current_sort_specs.SpecsCount, 1 do
        -- Here we identify columns using the ColumnUserID value that we ourselves passed to TableSetupColumn()
        -- We could also choose to identify columns based on their index (sort_spec.ColumnIndex), which is simpler!
        local sort_spec = current_sort_specs:Specs(n)
        local delta = 0

        if sort_spec.ColumnUserID == ColumnID_ID then
            delta = a.ID - b.ID
        elseif sort_spec.ColumnUserID == ColumnID_Name then
            if a.Name < b.Name then
                delta = -1
            elseif b.Name < a.Name then
                delta = 1
            else
                delta = 0
            end
        elseif sort_spec.ColumnUserID == ColumnID_Quantity then
            delta = a.Quantity - b.Quantity
        elseif sort_spec.ColumnUserID == ColumnID_Vendor then
            if a.Vendor < b.Vendor then
                delta = -1
            elseif b.Vendor < a.Vendor then
                delta = 1
            else
                delta = 0
            end
        elseif sort_spec.ColumnUserID == ColumnID_ZoneName then
            if a.ZoneName < b.ZoneName then
                delta = -1
            elseif b.ZoneName < a.ZoneName then
                delta = 1
            else
                delta = 0
            end
        elseif sort_spec.ColumnUserID == ColumnID_Action then
            if a.Action < b.Action then
                delta = -1
            elseif b.Action < a.Action then
                delta = 1
            else
                delta = 0
            end
        elseif sort_spec.ColumnUserID == ColumnID_RID then
            if a.RID < b.RID then
                delta = -1
            elseif b.RID < a.RID then
                delta = 1
            else
                delta = 0
            end
        elseif sort_spec.ColumnUserID == ColumnID_Price then
            if a.Price < b.Price then
                delta = -1
            elseif b.Price < a.Price then
                delta = 1
            else
                delta = 0
            end
        elseif sort_spec.ColumnUserID == ColumnID_Trivial then
            if a.Trivial < b.Trivial then
                delta = -1
            elseif b.Trivial < a.Trivial then
                delta = 1
            else
                delta = 0
            end
        elseif sort_spec.ColumnUserID == ColumnID_Yield then
            if a.Yield < b.Yield then
                delta = -1
            elseif b.Yield < a.Yield then
                delta = 1
            else
                delta = 0
            end
        elseif sort_spec.ColumnUserID == ColumnID_Container then
            if a.Container < b.Container then
                delta = -1
            elseif b.Container < a.Container then
                delta = 1
            else
                delta = 0
            end

            -- maybe because of nil/null fields
            --  blows up!
            --   elseif sort_spec.ColumnUserID == ColumnID_EXP then
            --   if a.Expansion < b.Expansion then
            --      delta = -1
            --  elseif b.Expansion < a.Expansion then
            --      delta = 1
            --  else
            --      delta = 0
            --   end
        end

        if delta ~= 0 then
            if sort_spec.SortDirection == ImGuiSortDirection.Ascending then
                return delta < 0
            end
            return delta > 0
        end
    end

    -- Always return a way to differentiate items.
    -- Your own compare function may want to avoid fallback on implicit sort specs e.g. a Name compare if it wasn't already part of the sort specs.
    return a.ID - b.ID < 0
end

-- Help Marker '?''
local function HelpMarker(desc)
    ImGui.TextDisabled('?')
    if ImGui.IsItemHovered() then
        ImGui.BeginTooltip()
        ImGui.PushTextWrapPos(ImGui.GetFontSize() * 35.0)
        ImGui.Text(desc)
        ImGui.PopTextWrapPos()
        ImGui.EndTooltip()
    end
end

-- Global Item Request Variables
Request_search_results = {}
R_amount = 1

-- Request Single Items
local function ItemRequest()
    ImGui.Text('Qty:')
    ImGui.SameLine()
    ImGui.SetNextItemWidth(100)

    R_amount, _ = ImGui.SliderInt('##SliderInt ', R_amount, 1, 1000, "%d")
    ImGui.SameLine()
    ImGui.SetNextItemWidth(1)

    R_amount, _ = ImGui.InputInt('##inputint###inputstandard', R_amount, 1,
        10000, ImGuiInputTextFlags.None)

    ImGui.SameLine()
    if ImGui.Button("+1000") then R_amount = R_amount + 1000 end

    if R_amount < 1 then R_amount = 1 end
    if R_amount > 10000 then R_amount = 10000 end

    ImGui.SetNextItemWidth(100)
    ImGui.SameLine()
    text_input, _ = ImGui.InputText("##itemrequest##edit", text_input, 128)
    local l_text_length = tonumber(string.len(text_input))

    -- Trigger search on Enter
    local enterPressed = ImGui.IsItemDeactivatedAfterEdit()
        or ImGui.IsKeyPressed(ImGuiKey.Enter)

    ImGui.SameLine()
    if (ImGui.Button("Text Search") or enterPressed) and l_text_length > 0 then
        --   Request_search_results = feeder.component_search_results(text_input)
        Request_search_results = feeder.item_recipe_search(text_input, "like")
    end

    ImGui.SameLine()
    if ImGui.Button('Clear Results') then
        Request_search_results = {}
        R_amount = 1
        text_input = ""
    end
    -- Show item list
    if Request_search_results[1] ~= nil then RequestTableWindow() end
end

-- Trophies Window
local function TrophiesWindow()
    -- opengui false if we have trophies or don't show tab

    -- Not needed!
    if trophy_quest_array[1] == nil then
        print(msg, "Congratulations, you have all the trophies.")
        ImGui.Text("Congratulations, you have all the trophies.")
        --  GLOBAL_TEXT = "Congrabulations, You have all the trophies."
        return
    end

    -- add refresh to nil out
    -- remd  ImGui.SetCursorPosX(4)

    if ImGui.Button('Refresh') then
        -- trophy_quest_array = {}
        trophy_flag = 1
        trophy_quest_array = {}
    end

    ImGui.SameLine()

    -- load the quests
    if trophy_quest_array[1] == nil then trophy_flag = 1 end

    if trophy_quest_array[1] ~= nil then
        ImGui.SetNextItemWidth(200)
        trophy_selection, _ = ImGui.Combo("##trophy_list", trophy_selection,
            trophy_quest_array,
            #trophy_quest_array,
            #trophy_quest_array)
    end

    -- Trophies
    ImGui.SameLine()
    if ImGui.SmallButton("Generate Farm List") then
        quest_farm_list = {}

        max_farm_list = {}
        GLOBAL_SOILED_ARRAY = {}

        -- Select Trophy Quest
        t_quest_selection = trophy_quest_array[trophy_selection]
        if mq.TLO.Task(t_quest_selection).ID() ~= nil then
            go_quest = 1
        else
            GLOBAL_TEXT = "We don't have " .. t_quest_selection .. " Task"
        end
    end

    ImGui.SameLine()
    trophy_button_bool, _ = ImGui.SmallButton("Go")
    if trophy_button_bool then
        GLOBAL_TEXT = "Starting " .. trophy_quest_array[trophy_selection]
        monitor_trophy_flag = 1

        mq.cmd('/lua run tcn/tcn_trophy_quests ', '"' ..
            trophy_quest_array[trophy_selection] .. '",' ..
            GLOBAL_DEPOSIT_FLAG)
    end

    ImGui.SameLine()
    trophy_button_action_bool, _ = ImGui.SmallButton(trophy_action)

    if trophy_button_action_bool then
        monitor_trophy_flag = 0

        GLOBAL_TEXT = "Stopping " .. trophy_quest_array[trophy_selection]

        mq.cmd('/squelch /lua stop tcn\\tcn_god')
        mq.cmd('/squelch /lua stop tcn\\tcn_tss')

        -- will now be stopped how? --global_abort flag?
        mq.cmd('/squelch /lua stop tcn\\tcn_quests')

        -- will now be stopped how? --global_abort flag?
        mq.cmd('/squelch /lua stop tcn\\tcn_trophy_quests')

        if mq.TLO.Nav.Active() then mq.cmd('/squelch /nav stop') end
    end

    ImGui.SameLine()

    if ImGui.Button('Exit') then
        -- print(GLOBAL_MQ2TSTrophy_Plugin)

        if GLOBAL_MQ2TSTrophy_Plugin == 1 then
            --  print(msg, "\ap[\awLoading: \agMQ2TSTrophy \awplugin\ap]")
            mq.cmd('/squelch /plugin MQ2TSTrophy load')
        end

        if mq.TLO.Nav.Active() then mq.cmd('/squelch /nav stop') end

        mq.exit()
        -- mq.cmd('/lua stop tcxx')
    end

    ImGui.Separator()

    if trophy_quest_array[1] ~= nil then
        script_status_text = mq.TLO.Lua.Script('tcn').Status()

        if script_status_text ~= nil and trophy_quest_array[1] ~= nil and
            monitor_trophy_flag == 1 then
            ImGui.Text("Gates of Discord Quest " .. script_status_text)
        else
            ImGui.Text("Gates of Discord Quest Inactive")
        end

        script_status_text = mq.TLO.Lua.Script('tcn/tcn_quests').Status()

        ImGui.SameLine()
        if script_status_text ~= nil and trophy_quest_array[1] ~= nil and
            monitor_trophy_flag == 1 then
            ImGui.Text(trophy_quest_array[trophy_selection] .. " " ..
                script_status_text)
        else
            ImGui.Text(trophy_quest_array[trophy_selection] .. " Inactive")
        end

        ImGui.SameLine()
        local tcg_status = mq.TLO.Lua.Script('tcn').Status()
        ImGui.Text("TCSNeXt Status: " .. tcg_status)
    end

    local function Trophy_Step_Window()
        local p_quest_title = trophy_quest_array[trophy_selection]
        local l_objective_count = mq.TLO.Window('TaskWND').Child(
            'Task_TaskElementList').Items()
        ImGui.Separator()
        ImGui.Text("Complete Steps:")
        for c = 1, l_objective_count do
            -- print(mq.TLO.Task(p_quest_title).Objective(c).Status()," name ",p_quest_title)
            local obj_status = mq.TLO.Task(p_quest_title).Objective(c).Status()
            if obj_status == "Done" then
                -- ImGui.TextColored(0, 1, 0, 1, farm_item_name)
                ImGui.TextColored(0, 1, 0, 1,
                    mq.TLO.Task(p_quest_title).Objective(c)())
                -- print("Done: ", mq.TLO.Task(p_quest_title).Objective(c)())
            end
        end
        ImGui.Separator()
        ImGui.Text("Incomplete Steps:")
        for c = 1, l_objective_count do
            local obj_status = mq.TLO.Task(p_quest_title).Objective(c).Status()
            if obj_status ~= "Done" and obj_status ~= nil then
                ImGui.TextColored(.6, .6, 0, 1,
                    mq.TLO.Task(p_quest_title).Objective(c)())
                -- print("Incomplete: ", mq.TLO.Task(p_quest_title).Objective(c)())
            end
        end
    end

    if quest_farm_list[1] ~= nil then
        QuestFarmTableWindow()
    else
        Trophy_Step_Window()
    end
end

-- Merchant Alliance Widow
local function MAWindow()
    -- remd  ImGui.SetCursorPosX(4)

    -- remd 2/13/2023
    -- ImGui.PishItemWidth(200)

    local alliance_array = feeder.Load_Alliance_Array()

    if alliance_array[1] == nil then
        ImGui.Text("We don't have the New Tanaan Merchant Alliance Quest")
        return
    end

    local p_quest_title = "The New Tanaan Merchant Alliance"
    local l_objective_count = mq.TLO.Window('TaskWND').Child(
        'Task_TaskElementList').Items()

    -- ImGui.TextColored(0, 1, 0, 1, "The New Tanaan Merchant Alliance Quest")
    local rcol, gcol, bcol

    rcol = .5
    gcol = 0
    bcol = 0

    if mq.TLO.Task(p_quest_title).Step.Index() < 5 then
        rcol = 0
        gcol = .5
        bcol = 0
    end

    ImGui.PushStyleColor(ImGuiCol.Button, rcol, gcol, bcol, .75)

    if ImGui.SmallButton("Perform Initial Hails") then
        if mq.TLO.Task(p_quest_title).Step.Index() < 5 then
            mq.cmd('/lua run tcn/tcn_alliance_movement')
        end
    end

    ImGui.PopStyleColor()

    ImGui.SameLine()
    HelpMarker(
        "Do this before trying other options, calculations will be off if hails are not perfomed.")
    ImGui.SameLine()

    rcol = 0
    gcol = .5
    bcol = 0

    if mq.TLO.Task(p_quest_title).Step.Index() < 5 then
        rcol = .5
        gcol = .5
        bcol = 0
    end

    ImGui.PushStyleColor(ImGuiCol.Button, rcol, gcol, bcol, .75)

    art_button_bool, _ = ImGui.SmallButton("Start Merchant Alliance Quest")
    if art_button_bool then
        GLOBAL_TEXT = "Starting New Tanaan Merchant Alliance Quest"
        if mq.TLO.Task(p_quest_title).Step.Index() > 4 then
            mq.cmd(
                '/lua run tcn/tcn_quests "The New Tanaan Merchant Alliance",' ..
                GLOBAL_DEPOSIT_FLAG)
        end
    end

    ImGui.PopStyleColor()

    local quest_script_status = mq.TLO.Lua.Script('tcn/tcn_quests').Status()
    --  GLOBAL_TEXT = quest_script_status

    if quest_script_status == "RUNNING" then
        GLOBAL_TEXT = "Running New Tanaan Merchant Alliance Quest"
    else
        if quest_script_status == "EXITED" then
            -- GLOBAL_TEXT = "Ending " .. art_array[art_selection + 1]
        end
    end

    rcol = 0
    gcol = .5
    bcol = 0

    if mq.TLO.Task(p_quest_title).Step.Index() < 5 then
        rcol = .5
        gcol = 0
        bcol = 0
    end

    ImGui.PushStyleColor(ImGuiCol.Button, rcol, gcol, bcol, .75)

    ImGui.SameLine()
    if ImGui.SmallButton("Generate Farm List") and
        mq.TLO.Task(p_quest_title).Step.Index() > 4 then
        t_quest_selection = "The New Tanaan Merchant Alliance"
        merchant_farm_list = {}
        go_quest = 1812
    end
    ImGui.PopStyleColor()

    ImGui.SameLine()
    HelpMarker(
        "Generates farm list only if button is green, if not please press 'perform initial hails' button")

    ImGui.SameLine()
    if ImGui.SmallButton("Stop") then
        GLOBAL_TEXT = "Stopping New Tanaan Merchant Alliance Quest"
        if mq.TLO.Nav.Active() then mq.cmd('/squelch /nav stop') end
        mq.cmd('/squelch /lua stop tcn\\tcn_quests')
        GLOBAL_TEXT = "Aborting New Tanaan Merchant Alliance Quest"
    end

    ImGui.SameLine()
    if ImGui.SmallButton('Exit') then
        if GLOBAL_MQ2TSTrophy_Plugin == 1 then
            --  print(msg, "\ap[\awLoading: \agMQ2TSTrophy \awplugin\ap]")
            mq.cmd('/squelch /plugin MQ2TSTrophy load')
        end

        if mq.TLO.Nav.Active() then mq.cmd('/squelch /nav stop') end

        mq.exit()
        -- mq.cmd('/lua stop tcxx')
    end

    local function StepsMAWindow()
        -- if ImGui.Button("Travel to Halas") then mq.cmd('/travelto halas') end

        ImGui.Separator()
        ImGui.Text("Complete Steps:")
        for c = 5, l_objective_count do
            local obj_status = mq.TLO.Task(p_quest_title).Objective(c).Status()
            if obj_status == "Done" then
                -- ImGui.TextColored(0, 1, 0, 1, farm_item_name)
                ImGui.TextColored(0, 1, 0, 1,
                    mq.TLO.Task(p_quest_title).Objective(c)())
                -- print("Done: ", mq.TLO.Task(p_quest_title).Objective(c)())
            end
        end
        ImGui.Separator()
        ImGui.Text("Incomplete Steps:")
        for c = 5, l_objective_count do
            local obj_status = mq.TLO.Task(p_quest_title).Objective(c).Status()
            if obj_status ~= "Done" and obj_status ~= nil then
                ImGui.TextColored(.6, .6, 0, 1,
                    mq.TLO.Task(p_quest_title).Objective(c)())
                -- print("Incomplete: ", mq.TLO.Task(p_quest_title).Objective(c)())
            end
        end
        ImGui.Separator()
        ImGui.Text("Current Step:")
        ImGui.Text(mq.TLO.Task(p_quest_title).Step())
    end

    if merchant_farm_list[1] ~= nil then
        MerchantQuestFarmTableWindow()
    else
        StepsMAWindow()
    end
end

local function SealsWindow()
    -- add refresh to nil out
    -- remd  ImGui.SetCursorPosX(4)
    -- ImGui.SetNextItemWidth(200)

    local art_array = feeder.Load_Artisan_Array()

    if art_array[1] == nil then
        ImGui.Text("We don't have any Artisan Seal Quests")
        return
    end

    ImGui.Text("Available Artisan Seal Quests: ")
    ImGui.SameLine()
    ImGui.SetNextItemWidth(200)
    art_selection, _ = ImGui.Combo("##art_list", art_selection, art_array,
        #art_array, #art_array)

    ImGui.SameLine()
    art_button_bool, _ = ImGui.SmallButton("Start")
    if art_button_bool then
        GLOBAL_TEXT = "Starting " .. art_array[art_selection]
        mq.cmd('/lua run tcn/tcn_quests ',
            '"' .. art_array[art_selection] .. '",' .. GLOBAL_DEPOSIT_FLAG)

        go_quest = 99
    end

    -- Artisan
    ImGui.SameLine()
    if ImGui.SmallButton("Generate Farm List") then
        artisan_farm_list = {}
        max_farm_list = {}
        GLOBAL_SOILED_ARRAY = {}
        -- Select Artisan Quest
        t_quest_selection = art_array[art_selection]
        go_quest = 1492
    end

    local quest_script_status = mq.TLO.Lua.Script('tcn/tcn_quests').Status()
    --   GLOBAL_TEXT = quest_script_status

    if quest_script_status == "RUNNING" then
        GLOBAL_TEXT = "Running " .. art_array[art_selection]
        -- print(GLOBAL_TEXT)
    else
        if quest_script_status == "EXITED" then
            -- GLOBAL_TEXT = "Ending " .. art_array[art_selection + 1]
        end
    end

    ImGui.SameLine()

    if ImGui.Button('Exit') then
        if GLOBAL_MQ2TSTrophy_Plugin == 1 then
            --  print(msg, "\ap[\awLoading: \agMQ2TSTrophy \awplugin\ap]")
            mq.cmd('/squelch /plugin MQ2TSTrophy load')
        end

        if mq.TLO.Nav.Active() then mq.cmd('/squelch /nav stop') end

        mq.exit()

        -- mq.cmd('/lua stop tcxx')
    end

    ImGui.Separator()

    local function ArtisanStepsWindow()
        local barfoo = ""
        local bartimer = "Current Game Time is: " .. mq.TLO.GameTime.Time12()
        local fourtimer = "24 Hour Game Time is: " .. mq.TLO.GameTime.Time24()
        local nightimer = ""

        if mq.TLO.GameTime.Night() then
            nightimer = "Night"
        else
            nightimer = "Day"
        end

        if mq.TLO.GameTime.Hour() > 4 and mq.TLO.GameTime.Hour() < 19 then
            barfoo =
            "Lebounde ab Dolmen is accepting deliveries but will go to sleep at 7 pm"
        else
            barfoo = "Lebounde ab Dolmen is sawing logs and wakes up at 5 am"
        end

        ImGui.Text(barfoo)
        ImGui.Text(bartimer .. " " .. nightimer .. "time")
        ImGui.SameLine()
        ImGui.Text(fourtimer)

        if ImGui.Button("Travel to Halas") then mq.cmd('/travelto halas') end
        ImGui.SameLine()
        HelpMarker("Travel to Halas Zone Line Entry.")

        ImGui.SameLine()
        if ImGui.Button("NAV to Lebounde") then
            mq.cmd('/nav spawn lebounde')
        end
        ImGui.SameLine()
        HelpMarker("Navigate to Lebounde once you have crossed the water.")

        local p_quest_title = art_array[art_selection]
        local l_objective_count = mq.TLO.Window('TaskWND').Child(
            'Task_TaskElementList').Items()

        -- Turn in items
        ImGui.SameLine()
        if ImGui.Button("Turn In") then
            t_quest_selection = art_array[art_selection]
            go_quest = 2
        end

        ImGui.SameLine()
        HelpMarker(
            "When you get to Lebounde, be in range and target them, this will do the rest!")

        ImGui.SameLine()
        if ImGui.Button("Stop") then
            if mq.TLO.Nav.Active() then mq.cmd('/squelch /nav stop') end
            mq.cmd('/squelch /lua stop tcn\\tcn_quests')
            GLOBAL_TEXT = "Aborting " .. art_array[art_selection]
        end

        ImGui.Separator()
        ImGui.Text("Complete Steps:")
        for c = 1, l_objective_count do
            local obj_status = mq.TLO.Task(p_quest_title).Objective(c).Status()
            if obj_status == "Done" then
                -- ImGui.TextColored(0, 1, 0, 1, farm_item_name)
                ImGui.TextColored(0, 1, 0, 1,
                    mq.TLO.Task(p_quest_title).Objective(c)())
                --   print("Done: ", mq.TLO.Task(p_quest_title).Objective(c)())
            end
        end

        ImGui.Separator()
        ImGui.Text("Incomplete Steps:")
        for c = 1, l_objective_count do
            local obj_status = mq.TLO.Task(p_quest_title).Objective(c).Status()
            if obj_status ~= "Done" and obj_status ~= nil then
                ImGui.TextColored(.6, .6, 0, 1,
                    mq.TLO.Task(p_quest_title).Objective(c)())
                --  print("Incomplete: ", mq.TLO.Task(p_quest_title).Objective(c)())
            end
        end
    end

    if artisan_farm_list[1] ~= nil then
        ArtisanQuestFarmTableWindow()
    else
        ArtisanStepsWindow()
    end
end

local function DashboardWindow()
    -- Update periodically
    local db_count = 43769
    db_count = feeder.db_count()

    -- remd  ImGui.SetCursorPosX(4)

    ImGui.TextColored(0, 1, 1, 1,
        "Welcome to TCSNext Recipe Database Online: (" .. db_count ..
        ")")

    ImGui.Separator()

    -- remd  ImGui.SetCursorPosX(4)
    ImGui.SetNextItemWidth(150)
    ImGui.Text(
        "Level " .. mq.TLO.Me.Level() .. " [" .. mq.TLO.Me.Race() .. " " ..
        mq.TLO.Me.Class() .. "] Free Inventory Slots: " ..
        mq.TLO.Me.FreeInventory())
    -- remd  ImGui.SetCursorPosX(4)
    ImGui.Text("Platinum: [" .. mq.TLO.Me.Platinum() .. "] [Bank (" ..
        mq.TLO.Me.PlatinumBank() .. ") [Shared: (" ..
        mq.TLO.Me.PlatinumShared() .. ")]")

    ImGui.Separator()

    -- remd  ImGui.SetCursorPosX(4)
    ImGui.Text("Zone: [" .. mq.TLO.Zone() .. "] Zone ID: " .. mq.TLO.Zone.ID())

    ImGui.Separator()

    -- ImGui.Text("Blacksmithing: " .. mq.TLO.Me.Skill('Blacksmithing')())
    -- ImGui.Text("Brewing:              " .. mq.TLO.Me.Skill('Brewing')())
    -- ImGui.Text("Baking:                " .. mq.TLO.Me.Skill('Baking')())
    -- ImGui.Text("Tailoring:             " .. mq.TLO.Me.Skill('Tailoring')())
    -- ImGui.Text("Jewelcrafting:   " .. mq.TLO.Me.Skill('Jewelry Making')())
    -- ImGui.Text("Fletching:            " .. mq.TLO.Me.Skill('Fletching')())
    -- ImGui.Text("Pottery:               " .. mq.TLO.Me.Skill('Pottery')())
    -- ImGui.Text("Fishing:               " .. mq.TLO.Me.Skill('Fishing')())
    -- ImGui.Text("Research:           " .. mq.TLO.Me.Skill('Research')())

    ImGui.Text("Baking: " .. mq.TLO.Me.Skill('Baking')() .. " /" ..
        mq.TLO.Me.SkillCap('Baking')())
    ImGui.Text(
        "Blacksmithing: " .. mq.TLO.Me.Skill('Blacksmithing')() .. " /" ..
        mq.TLO.Me.SkillCap('Blacksmithing')())
    ImGui.Text("Brewing: " .. mq.TLO.Me.Skill('Brewing')() .. " /" ..
        mq.TLO.Me.SkillCap('Brewing')())
    ImGui.Text("Fishing: " .. mq.TLO.Me.Skill('Fishing')() .. " /" ..
        mq.TLO.Me.SkillCap('Fishing')())
    ImGui.Text("Fletching: " .. mq.TLO.Me.Skill('Fletching')() .. " /" ..
        mq.TLO.Me.SkillCap('Fletching')())
    ImGui.Text(
        "Jewelry Making: " .. mq.TLO.Me.Skill('Jewelry Making')() .. " /" ..
        mq.TLO.Me.SkillCap('Jewelry Making')())

    ImGui.Text("Pottery: " .. mq.TLO.Me.Skill('Pottery')() .. " /" ..
        mq.TLO.Me.SkillCap('Pottery')())
    ImGui.Text("Research: " .. mq.TLO.Me.Skill('Research')() .. " /" ..
        mq.TLO.Me.SkillCap('Research')())
    ImGui.Text("Tailoring: " .. mq.TLO.Me.Skill('Tailoring')() .. " /" ..
        mq.TLO.Me.SkillCap('Tailoring')())

    if mq.TLO.Me.Class() == "Rogue" then
        ImGui.TextColored(1, .7, 0, 1,
            "Make Poison:          " ..
            mq.TLO.Me.Skill('Make Poison')() .. " /" ..
            mq.TLO.Me.SkillCap('Make Poison')())
        --     ImGui.Text(
        --     "Make Poison: " .. mq.TLO.Me.Skill('Make Poison')() .. " /" ..
        --    mq.TLO.Me.SkillCap('Make Poison')())
    end
    if mq.TLO.Me.Class() == "Shaman" then
        ImGui.TextColored(1, .5, 1, 1,
            "Alchemy:              " ..
            mq.TLO.Me.Skill('Alchemy')() .. " /" ..
            mq.TLO.Me.SkillCap('Alchemy')())
        --  ImGui.Text("Alchemy: " .. mq.TLO.Me.Skill('Alchemy')() .. " /" ..
        --   mq.TLO.Me.SkillCap('Alchemy')())
    end
    if mq.TLO.Me.Race() == "Gnome" then
        ImGui.TextColored(.7, .7, 0, 1,
            "Tinkering: " .. mq.TLO.Me.Skill('Tinkering')() ..
            " /" .. mq.TLO.Me.SkillCap('Tinkering')())
        --   ImGui.Text("Tinkering: " .. mq.TLO.Me.Skill('Tinkering')() .. " /" ..
        --  mq.TLO.Me.SkillCap('Tinkering')())
    end

    ImGui.Separator()

    if ImGui.Button('Exit') then
        if GLOBAL_MQ2TSTrophy_Plugin == 1 then
            --  print(msg, "\ap[\awLoading: \agMQ2TSTrophy \awplugin\ap]")
            mq.cmd('/squelch /plugin MQ2TSTrophy load')
        end

        if mq.TLO.Nav.Active() then mq.cmd('/squelch /nav stop') end
        mq.cmd('/squelch /lua stop tcn\\tcn_quests')
        mq.cmd('/squelch /lua stop tcn\\tcn_god')
        -- mq.cmd('/lua stop tcxx')
        mq.exit()
        -- Kill all or just kill the scrips
    end

    ImGui.Separator()
end

local function StandardFishWindow()
    local fish_ids = {
        "Overthere Threadfin", "152460", "Timorous Deep Toothfish", "152461",
        "Velious Arrowhead", "166007", "Velious Bluefish", "166008",
        "Velious Angel Fish", "163659", "Velious Spiked Pleco", "163660",
        "Primordial Clown Fish", "160765", "Primordial Lion Fish", "160764",
        "Luclin Flame Angel", "166194", "Luclin Dragon Blood Cichlid", "166195",
        "Luclin Ghost Angelfish", "159706", "Luclin Silver Arowana", "159707",
        "Serene Tiger Botia", "154763", "Serene Walleye Perch", "154764",
        "Razorfang Viperfish", "87350", "Void Maw Angler", "87351"
    }

    local fishy_array = {}

    for j = 1, #fish_ids, 2 do
        local item = {
            ItemID = fish_ids[j + 1],
            ItemName = fish_ids[j],
            ItemInv = mq.TLO.FindItemCount(fish_ids[j + 1])(),
            ItemBank = mq.TLO.FindItemBankCount(fish_ids[j + 1])()
        }
        table.insert(fishy_array, item)
    end

    for c = 1, #fishy_array do
        --   print("\at", fishy_array[c].ItemName, " ", fishy_array[c].ItemID, " ",
        --        fishy_array[c].ItemInv, " ", fishy_array[c].ItemBank)
    end

    -- os.exit()

    ImGui.Text("TCSNeXt Fishventory")

    ImGui.Text(
        "The fish that is highlighted in green will be used for swapping based on the Fish checkbox being checked.")

    -- ImGui.SetWindowSize(480, 280)
    -- ImGui.SetWindowFontScale(1)
    -- remd  ImGui.SetCursorPosX(4)

    local flags = bit32.bor(ImGuiTableFlags.Resizable,
        ImGuiTableFlags.Reorderable,
        ImGuiTableFlags.Hideable,
        ImGuiTableFlags.MultiSortable,
        ImGuiTableFlags.Sortable, ImGuiTableFlags.RowBg,

        ImGuiTableFlags.Borders, ImGuiTableFlags.ScrollY)

    if ImGui.BeginTable('##fish_table', 4, flags, 0, TEXT_BASE_HEIGHT * 18, 0.0) then
        local ColumnID_ItemUID = 0
        local ColumnID_ItemUName = 1
        local ColumnID_ItemUInv = 2
        local ColumnID_ItemUBank = 3

        ImGui.TableSetupColumn('Item ID', ImGuiTableColumnFlags.WidthAuto, -1.0,
            ColumnID_ItemUID)
        ImGui.TableSetupColumn('Name', ImGuiTableColumnFlags.WidthStretch, -1.0,
            ColumnID_ItemUName)
        ImGui.TableSetupColumn('Inventory', ImGuiTableColumnFlags.WidthAuto,
            -1.0, ColumnID_ItemUInv)
        ImGui.TableSetupColumn('Bank', ImGuiTableColumnFlags.WidthAuto, -1.0,
            ColumnID_ItemUBank)

        ImGui.TableSetupScrollFreeze(0, 1) -- Make row always visible
        -- Display data
        ImGui.TableHeadersRow()

        local clipper = ImGuiListClipper.new()

        clipper:Begin(#fishy_array)
        while clipper:Step() do
            for row_n = clipper.DisplayStart, clipper.DisplayEnd - 1, 1 do
                local r_col, g_col, b_col = .3, 1, 1
                local item_u_id = fishy_array[row_n + 1].ItemID
                local item_u_name = fishy_array[row_n + 1].ItemName
                local item_u_inv = fishy_array[row_n + 1].ItemInv
                local item_u_bank = fishy_array[row_n + 1].ItemBank

                ImGui.PushID('F_SCALE')
                ImGui.TableNextRow()
                ImGui.TableNextColumn()
                ImGui.TextColored(r_col, g_col, b_col, 1, item_u_id)
                ImGui.TableNextColumn()

                if (row_n % 2) == 0 and not FISH_SWAP then
                    --  r_col, g_col, b_col = 1, .3, 1
                    --   ImGui.TextColored(r_col, g_col, b_col, 1, item_u_name)
                else
                    if (row_n % 2) == 0 and FISH_SWAP then
                        --  r_col, g_col, b_col = .3, .3, 1
                        --  ImGui.TextColored(r_col, g_col, b_col, 1, item_u_name)
                    end
                end

                if (row_n % 2) == 0 and not FISH_SWAP then
                    -- green
                    r_col, g_col, b_col = .3, 1, .3
                    ImGui.TextColored(r_col, g_col, b_col, 1, item_u_name)
                end

                if (row_n % 2) == 0 and FISH_SWAP then
                    r_col, g_col, b_col = .6, .3, 0
                    ImGui.TextColored(r_col, g_col, b_col, 1, item_u_name)
                end

                if (row_n % 2) == 1 and FISH_SWAP then
                    -- green
                    r_col, g_col, b_col = .3, 1, .3
                    ImGui.TextColored(r_col, g_col, b_col, 1, item_u_name)
                end

                if (row_n % 2) == 1 and not FISH_SWAP then
                    r_col, g_col, b_col = .6, .3, 0
                    ImGui.TextColored(r_col, g_col, b_col, 1, item_u_name)
                end

                -- print((row_n % 2))

                ImGui.TableNextColumn()
                ImGui.Text(string.format(item_u_inv))
                ImGui.TableNextColumn()
                ImGui.Text(string.format(item_u_bank))

                ImGui.PopID()
            end
        end
        ImGui.EndTable('fish_table')
    end

    -- ImGui.TreePop()

    --  ImGui.End()
end

local function StandardShoppingListWindow()
    if recipe_shopping_data[1] == nil then
        ImGui.Text("No Data")
        return
    end

    -- if not openShoppingListGUI then return end

    -- ImGui.SetWindowFontScale(1)

    -- -- remd  ImGui.SetCursorPosX(4)

    if name_select ~= nil then
        ImGui.Text(name_select .. " Recipe ID: " .. id_select)
        ImGui.SameLine()
        ImGui.Text("Legend")
        ImGui.SameLine()
        ImGui.TextColored(.3, 1, 1, 1, "Buy From Vendor")
        ImGui.SameLine()
        ImGui.TextColored(0, 1, 0, 1, "Local Inventory")
    end

    local amount_total = 0

    local flags = bit32.bor(ImGuiTableFlags.Resizable,
        ImGuiTableFlags.Reorderable,
        ImGuiTableFlags.Hideable,
        ImGuiTableFlags.MultiSortable,
        ImGuiTableFlags.Sortable, ImGuiTableFlags.RowBg,
        ImGuiTableFlags.Borders, ImGuiTableFlags.ScrollY)

    local aflags = bit32.bor(ImGuiTableFlags.Resizable,
        ImGuiTableFlags.Reorderable,
        ImGuiTableFlags.Hideable,
        ImGuiTableFlags.MultiSortable,
        ImGuiTableFlags.Sortable, ImGuiTableFlags.RowBg,
        ImGuiTableFlags.BordersOuter,
        ImGuiTableFlags.BordersV,
        ImGuiTableFlags.NoBordersInBody,
        ImGuiTableFlags.ScrollY)

    if ImGui.BeginTable('##single_recipe_shopping_table', 7, flags, 0,
            TEXT_BASE_HEIGHT * 25, 0.0) then
        local ColumnID_RequestItem = 10

        -- Recipe Name / Item Name
        ImGui.TableSetupColumn('Name', ImGuiTableColumnFlags.WidthAuto, -1.0,
            ColumnID_Name)
        -- Item Price
        ImGui.TableSetupColumn('Price', ImGuiTableColumnFlags.WidthAuto, -1.0,
            ColumnID_Price)
        -- Count / Quantity / Needed
        ImGui.TableSetupColumn('Count', ImGuiTableColumnFlags.WidthAuto, -1.0,
            ColumnID_Quantity)
        -- Item ID
        ImGui.TableSetupColumn('ID', ImGuiTableColumnFlags.WidthFixed, -1.0,
            ColumnID_ID)
        -- Vendor Name
        ImGui.TableSetupColumn('Vendor', ImGuiTableColumnFlags.WidthAuto, -1.0,
            ColumnID_Vendor)
        -- Zone Name
        ImGui.TableSetupColumn('Zone', ImGuiTableColumnFlags.WidthAuto, -1.0,
            ColumnID_ZoneName)

        ImGui.TableSetupColumn('Request', ImGuiTableColumnFlags.WidthFixed,
            -1.0, ColumnID_RequestItem)

        ImGui.TableSetupScrollFreeze(0, 1) -- Make row always visible

        local sort_specs = ImGui.TableGetSortSpecs()

        if sort_specs then
            if sort_specs.SpecsDirty then
                if #converted_shopping_data > 1 then
                    current_sort_specs = sort_specs
                    table.sort(converted_shopping_data, CompareWithSortSpecs)
                    current_sort_specs = nil
                end
                sort_specs.SpecsDirty = false
            end
        end

        -- Display data
        ImGui.TableHeadersRow()

        for iter = 1, #recipe_shopping_data do
            amount_total = amount_total +
                tcglib.return_number(recipe_shopping_data[iter],
                    6)
        end

        local clipper = ImGuiListClipper.new()

        clipper:Begin(#converted_shopping_data)
        while clipper:Step() do
            for row_n = clipper.DisplayStart, clipper.DisplayEnd - 1, 1 do
                local r_col, g_col, b_col = .3, 1, 1
                local convert_item = converted_shopping_data[row_n + 1]
                ImGui.PushID(convert_item)

                if mq.TLO.FindItemCount(convert_item.ID)() >=
                    convert_item.Quantity then
                    r_col = 0
                    g_col = 1
                    b_col = 0
                end

                ImGui.TableNextRow()
                ImGui.TableNextColumn()
                ImGui.TextColored(r_col, g_col, b_col, 1, convert_item.Name)
                ImGui.TableNextColumn()
                --   ImGui.Text(string.format("%6d", convert_item.Price))
                ImGui.Text(convert_item.Price)
                ImGui.TableNextColumn()
                ImGui.Text(string.format("%6d", convert_item.Quantity))
                ImGui.TableNextColumn()
                ImGui.Text(string.format("%6d", convert_item.ID))
                ImGui.TableNextColumn()
                ImGui.Text(string.format(convert_item.Vendor))
                ImGui.TableNextColumn()

                if convert_item.ZoneID ~= 202 then
                    r_col = 0
                    g_col = 1
                    b_col = 1
                else
                    r_col = 1
                    g_col = 1
                    b_col = 1
                end

                ImGui.TextColored(r_col, g_col, b_col, 1, convert_item.ZoneName)

                ImGui.TableNextColumn()
                if ImGui.Button("Request") then
                    GLOBAL_TEXT =
                    "Requesting Standard Single Missing Vendored Items via DanNet"
                    request_array_list = {}
                    local have_count = mq.TLO.FindItemCount(convert_item.ID)()
                    local current_qty = convert_item.Quantity
                    if have_count > 0 then
                        current_qty = current_qty - have_count
                    end
                    -- add condition checks in here
                    local request_string = convert_item.ID .. "," .. current_qty
                    if current_qty > 0 then
                        table.insert(request_array_list, request_string)
                    end
                    if request_array_list[1] ~= nil then
                        go_ask = 1
                    else
                        GLOBAL_TEXT = "Nothing to request via DanNet"
                    end
                end

                ImGui.PopID()
            end
        end

        ImGui.EndTable()
    end

    if ImGui.Button("Request Vendored Items") then
        GLOBAL_TEXT = "Requesting Vendor Components via DanNet"
        request_array_list = {}
        for x = 1, #recipe_shopping_data do
            local request_item_id = tcglib.return_number(
                recipe_shopping_data[x], 3)
            local request_item_count = tcglib.return_number(
                recipe_shopping_data[x], 4)
            local have_count = mq.TLO.FindItemCount(request_item_id)()
            if have_count > 0 then
                request_item_count = request_item_count - have_count
            end

            -- add condition checks in here
            local request_string = request_item_id .. "," .. request_item_count

            if request_item_count > 0 then
                table.insert(request_array_list, request_string)
            end
        end
        --   for x = 1, #request_array_list do print(request_array_list[x]) end
        if request_array_list[1] ~= nil then
            go_ask = 1
        else
            GLOBAL_TEXT = "Nothing to request via DanNet"
        end
    end
    ImGui.SameLine()
    HelpMarker(
        "Queries other characters in zone for vendor items, and delivers from inventory or bank.")

    ImGui.SameLine()
    if ImGui.Button("Shop Recipe") then
        if trim_soiled[1] ~= nil or recipe_disposition_data[1] ~= nil then
            go_shop = 0
            GLOBAL_TEXT = "Unable to shop, please check info."
        else
            go_shop = 1
        end
    end

    ImGui.SameLine()

    local modifier = .001

    -- need , or numerics

    if amount_total >= 100000000 then
        --  modifier = .01
    end

    ImGui.Text("Est. Total Platinum: " .. amount_total * modifier)
    amount_total = 0

    ImGui.SameLine()
    ImGui.Text("[Item Count: (" .. #recipe_shopping_data .. ")]")

    -- ImGui.End()

    -- end

    --  ImGui.EndChild()
end

local function StandardDepotTableWindow()
    if not mq.TLO.TradeskillDepot.Enabled() then
        ImGui.Text("Expansion: Night of Shadows not enabled")
        return
    end

    if l_depot_array[1] == nil then
        ImGui.Text("No Data")
        return
    end

    -- ImGui.SetWindowSize(700, 280)
    -- ImGui.SetWindowFontScale(1)

    -- ImGui.Text(name_select .. " Recipe ID: " .. id_select)

    ---- remd  ImGui.SetCursorPosX(4)

    -- ImGui.Text("Items Returned: (" .. #trim_soiled .. ")")

    local flags = bit32.bor(ImGuiTableFlags.Resizable,
        ImGuiTableFlags.Reorderable,
        ImGuiTableFlags.Hideable,
        ImGuiTableFlags.MultiSortable,
        ImGuiTableFlags.Sortable, ImGuiTableFlags.RowBg,

        ImGuiTableFlags.Borders, ImGuiTableFlags.ScrollY)

    if ImGui.BeginTable('##single_recipe_depot_table', 4, flags, 0,
            TEXT_BASE_HEIGHT * 25, 0.0) then
        local ColumnID_RequestItem = 10

        ImGui.TableSetupColumn('Item', ImGuiTableColumnFlags.WidthStretch, -1.0,
            ColumnID_Name)

        ImGui.TableSetupColumn('Depot', ImGuiTableColumnFlags.WidthFixed, -1.0,
            ColumnID_Quantity)

        ImGui.TableSetupColumn('Inv', ImGuiTableColumnFlags.WidthFixed, -1.0,
            ColumnID_Inventory)

        ImGui.TableSetupColumn('ID', ImGuiTableColumnFlags.WidthAuto, -1.0,
            ColumnID_ID)

        ImGui.TableSetupScrollFreeze(0, 1) -- Make row always visible

        local sort_specs = ImGui.TableGetSortSpecs()

        if sort_specs then
            if sort_specs.SpecsDirty then
                if #l_depot_array > 1 then
                    current_sort_specs = sort_specs
                    table.sort(l_depot_array, CompareWithSortSpecs)
                    current_sort_specs = nil
                end
                sort_specs.SpecsDirty = false
            end
        end

        ImGui.TableHeadersRow()

        local clipper = ImGuiListClipper.new()

        clipper:Begin(#l_depot_array)

        while clipper:Step() do
            for row_n = clipper.DisplayStart, clipper.DisplayEnd - 1, 1 do
                local convert_item = l_depot_array[row_n + 1]
                ImGui.PushID(convert_item)

                ImGui.TableNextRow()
                ImGui.TableNextColumn()

                if mq.TLO.FindItemCount(convert_item.ID)() >=
                    convert_item.Quantity then
                    ImGui.TextColored(0, 1, 0, 1, convert_item.Name)
                else
                    ImGui.TextColored(1, .65, 0, 1, convert_item.Name)
                end

                ImGui.TableNextColumn()
                ImGui.Text(string.format("%6d", convert_item.Quantity))
                ImGui.TableNextColumn()
                ImGui.Text(mq.TLO.FindItemCount(convert_item.ID)())

                ImGui.TableNextColumn()
                ImGui.Text(string.format("%6d", convert_item.ID))

                ImGui.PopID()
            end
        end
        ImGui.EndTable()
    end

    -- ImGui.TreePop()

    -- ImGui.SameLine()
    -- revisit
    if ImGui.Button("Depot Shop") then go_shop = 1149 end

    ImGui.SameLine()

    HelpMarker("Goes to your tradeskill depot and grabs items.")

    -- ImGui.End()
end

local function StandardFarmTableWindow()
    if trim_soiled[1] == nil then
        ImGui.Text("No Data")
        return
    end

    local flag = 1
    for x = 1, #trim_soiled do
        local farm_item_id = tcglib.return_number(trim_soiled[x], 2)
        local farm_item_count = tcglib.return_number(trim_soiled[x], 3)
        if mq.TLO.FindItemCount(farm_item_id)() < farm_item_count then
            flag = 0
        end
    end

    if flag == 1 then
        trim_soiled = {}
        if recipe_disposition_data[1] == nil then
            GLOBAL_TEXT = "Ready to make recipe!"
            can_craft = 1
        end
        return
    end

    -- if not openFarmWindowGUI then return end

    -- ImGui.SetWindowSize(700, 280)
    -- ImGui.SetWindowFontScale(1)

    ImGui.Text(name_select .. " Recipe ID: " .. id_select)

    ---- remd  ImGui.SetCursorPosX(4)

    -- ImGui.Text("Items Returned: (" .. #trim_soiled .. ")")

    local flags = bit32.bor(ImGuiTableFlags.Resizable,
        ImGuiTableFlags.Reorderable,
        ImGuiTableFlags.Hideable,
        ImGuiTableFlags.MultiSortable,
        ImGuiTableFlags.Sortable, ImGuiTableFlags.RowBg,

        ImGuiTableFlags.Borders, ImGuiTableFlags.ScrollY)

    if ImGui.BeginTable('##single_recipe_farm_table', 9, flags, 0,
            TEXT_BASE_HEIGHT * 25, 0.0) then
        local ColumnID_RequestItem = 10

        -- request individual?
        -- ImGui.TableSetupColumn('Request', ImGuiTableColumnFlags.WidthAuto, -1.0,
        --       ColumnID_ItemRequest)

        ImGui.TableSetupColumn('Item', ImGuiTableColumnFlags.WidthStretch, -1.0,
            ColumnID_Name)

        ImGui.TableSetupColumn('Need', ImGuiTableColumnFlags.WidthFixed, -1.0,
            ColumnID_Quantity)

        ImGui.TableSetupColumn('Inv', ImGuiTableColumnFlags.WidthFixed, -1.0,
            ColumnID_Inventory)

        local ColumnID_Bnk = 2113

        ImGui.TableSetupColumn('Bnk', ImGuiTableColumnFlags.WidthAuto, -1.0,
            ColumnID_Bnk)

        local ColumnID_Depot = 2112

        ImGui.TableSetupColumn('Depot', ImGuiTableColumnFlags.WidthAuto, -1.0,
            ColumnID_Depot)

        ImGui.TableSetupColumn('Action', ImGuiTableColumnFlags.WidthFixed, -1.0,
            ColumnID_Action)

        ImGui.TableSetupColumn('Zone', ImGuiTableColumnFlags.WidthStretch, -1.0,
            ColumnID_ZoneName)

        ImGui.TableSetupColumn('ID', ImGuiTableColumnFlags.WidthAuto, -1.0,
            ColumnID_ID)

        ImGui.TableSetupColumn('Request', ImGuiTableColumnFlags.WidthFixed,
            -1.0, ColumnID_RequestItem)

        ImGui.TableSetupScrollFreeze(0, 1) -- Make row always visible

        local sort_specs = ImGui.TableGetSortSpecs()

        if sort_specs then
            if sort_specs.SpecsDirty then
                if #converted_farm_data > 1 then
                    current_sort_specs = sort_specs
                    table.sort(converted_farm_data, CompareWithSortSpecs)
                    current_sort_specs = nil
                end
                sort_specs.SpecsDirty = false
            end
        end

        ImGui.TableHeadersRow()

        local clipper = ImGuiListClipper.new()

        clipper:Begin(#converted_farm_data)

        while clipper:Step() do
            for row_n = clipper.DisplayStart, clipper.DisplayEnd - 1, 1 do
                local convert_item = converted_farm_data[row_n + 1]
                ImGui.PushID(convert_item)

                ImGui.TableNextRow()
                ImGui.TableNextColumn()

                if mq.TLO.FindItemCount(convert_item.ID)() >=
                    convert_item.Quantity then
                    ImGui.TextColored(0, 1, 0, 1, convert_item.Name)
                else
                    ImGui.TextColored(1, .65, 0, 1, convert_item.Name)
                end

                ImGui.TableNextColumn()
                ImGui.Text(string.format("%6d", convert_item.Quantity))

                ImGui.TableNextColumn()
                ImGui.Text(mq.TLO.FindItemCount(convert_item.ID)())

                ImGui.TableNextColumn()
                ImGui.Text(mq.TLO.FindItemBankCount(convert_item.ID)())

                ImGui.TableNextColumn()
                if mq.TLO.TradeskillDepot.Enabled() then
                    if mq.TLO.TradeskillDepot.FindItemCount(convert_item.ID)() >
                        0 then
                        ImGui.Text(mq.TLO.TradeskillDepot.FindItemCount(
                            convert_item.ID)())
                    else
                        ImGui.Text("0")
                    end
                else
                    ImGui.Text("-")
                end

                ImGui.TableNextColumn()

                local r_col, g_col, b_col = 0, .5, 0

                -- make color return routine.. R G B
                -- r_col , g_col, b_col = return_rgb(convert_item.Action)

                if convert_item.Action == "Faction" then
                    r_col, g_col, b_col = .3, 1, .7
                end

                if convert_item.Action == "Farm" then
                    r_col, g_col, b_col = 1, .5, 0
                end

                if convert_item.Action == "Fish" then
                    r_col, g_col, b_col = 0, .5, 1
                end

                if convert_item.Action == "Forage" then
                    r_col, g_col, b_col = .9, .1, .9
                end

                if convert_item.Action == "Vendor" then
                    r_col, g_col, b_col = .7, .9, .2
                end

                if convert_item.Action == "Enchanter" then
                    r_col, g_col, b_col = .9, .7, .1
                end

                -- Add quested

                ImGui.TextColored(r_col, g_col, b_col, 1, convert_item.Action)
                ImGui.TableNextColumn()
                ImGui.Text(convert_item.ZoneName)
                ImGui.TableNextColumn()
                ImGui.Text(string.format("%6d", convert_item.ID))

                ImGui.TableNextColumn()
                if ImGui.Button("Request") then
                    GLOBAL_TEXT =
                    "Requesting Standard Single Missing Component via DanNet"
                    request_array_list = {}
                    local have_count = mq.TLO.FindItemCount(convert_item.ID)()
                    local current_qty = convert_item.Quantity
                    if have_count > 0 then
                        current_qty = current_qty - have_count
                    end
                    -- add condition checks in here
                    local request_string = convert_item.ID .. "," .. current_qty
                    if current_qty > 0 then
                        table.insert(request_array_list, request_string)
                    end
                    if request_array_list[1] ~= nil then
                        go_ask = 1
                    else
                        GLOBAL_TEXT = "Nothing to request via DanNet"
                    end
                end

                ImGui.PopID()
            end
        end
        ImGui.EndTable()
    end

    -- ImGui.TreePop()

    if ImGui.Button("Request Missing Components") then
        -- would be better served to make a function that passes the array?

        GLOBAL_TEXT = "Requesting Missing Components via DanNet"
        -- load dannet
        request_array_list = {}
        for x = 1, #trim_soiled do
            local request_item_id = tcglib.return_number(trim_soiled[x], 2)
            local request_item_count = tcglib.return_number(trim_soiled[x], 3)
            local have_count = mq.TLO.FindItemCount(request_item_id)()
            if have_count > 0 then
                request_item_count = request_item_count - have_count
            end
            -- add condition checks in here
            local request_string = request_item_id .. "," .. request_item_count

            if request_item_count > 0 then
                table.insert(request_array_list, request_string)
            end
        end
        --   for x = 1, #request_array_list do print(request_array_list[x]) end
        if request_array_list[1] ~= nil then
            go_ask = 1
        else
            GLOBAL_TEXT = "Nothing to request via DanNet"
        end
    end

    ImGui.SameLine()

    HelpMarker(
        "Queries other characters in zone for missing items, and delivers from inventory or bank.")

    -- ImGui.End()
end

local function StandardRecipeStackWindow()
    if recipe_stack_data[1] == nil then
        ImGui.Text("No Data")
        return
    end

    -- if not openShoppingListGUI then return end

    -- ImGui.SetWindowSize(700, 250)
    -- ImGui.SetWindowFontScale(1)
    ---- remd  ImGui.SetCursorPosX(4)

    -- if name_select ~= nil then
    --   ImGui.Text(name_select .. " Recipe ID: " .. id_select)
    -- end

    local flags = bit32.bor(ImGuiTableFlags.Resizable,
        ImGuiTableFlags.Reorderable,
        ImGuiTableFlags.Hideable,
        ImGuiTableFlags.MultiSortable,
        ImGuiTableFlags.Sortable, ImGuiTableFlags.RowBg,
        ImGuiTableFlags.Borders, ImGuiTableFlags.ScrollY)

    if ImGui.BeginTable('##single_recipe_stack_table', 5, flags, 0,
            TEXT_BASE_HEIGHT * 25, 0.0) then
        local ColumnID_Request = 10

        ImGui.TableSetupColumn('Recipe ID', ImGuiTableColumnFlags.WidthFixed,
            -1.0, ColumnID_RID)

        ImGui.TableSetupColumn('Item ID', ImGuiTableColumnFlags.WidthFixed,
            -1.0, ColumnID_ID)

        ImGui.TableSetupColumn('Recipe Name',
            ImGuiTableColumnFlags.WidthStretch, -1.0,
            ColumnID_Name)

        ImGui.TableSetupColumn('Sets', ImGuiTableColumnFlags.WidthFixed, -1.0,
            ColumnID_Quantity)

        ImGui.TableSetupColumn('Request', ImGuiTableColumnFlags.WidthFixed,
            -1.0, ColumnID_Request)

        ImGui.TableSetupScrollFreeze(0, 1) -- Make row always visible

        local sort_specs = ImGui.TableGetSortSpecs()

        if sort_specs then
            if sort_specs.SpecsDirty then
                if #converted_recipe_data > 1 then
                    current_sort_specs = sort_specs
                    table.sort(converted_recipe_data, CompareWithSortSpecs)
                    current_sort_specs = nil
                end
                sort_specs.SpecsDirty = false
            end
        end

        -- Display data
        ImGui.TableHeadersRow()

        local clipper = ImGuiListClipper.new()
        clipper:Begin(#converted_recipe_data)
        while clipper:Step() do
            for row_n = clipper.DisplayStart, clipper.DisplayEnd - 1, 1 do
                local r_col, g_col, b_col = 0, 1, 0
                local convert_item = converted_recipe_data[row_n + 1]
                ImGui.PushID(convert_item)
                ImGui.TableNextRow()
                ImGui.TableNextColumn()
                ImGui.TextColored(r_col, g_col, b_col, 1, convert_item.RID)
                ImGui.TableNextColumn()
                ImGui.Text(convert_item.ID)
                ImGui.TableNextColumn()
                ImGui.Text(convert_item.Name)
                ImGui.TableNextColumn()
                ImGui.TextColored(r_col, g_col, b_col, 1, convert_item.Quantity)
                ImGui.TableNextColumn()

                if ImGui.Button("Request") then
                    GLOBAL_TEXT =
                    "Requesting Standard Single Recipe Item via DanNet"
                    request_array_list = {}
                    local have_count = mq.TLO.FindItemCount(convert_item.ID)()
                    local current_qty = convert_item.Quantity
                    if have_count > 0 then
                        current_qty = current_qty - have_count
                    end
                    -- add condition checks in here
                    local request_string = convert_item.ID .. "," .. current_qty
                    if current_qty > 0 then
                        table.insert(request_array_list, request_string)
                    end
                    if request_array_list[1] ~= nil then
                        go_ask = 1
                    else
                        GLOBAL_TEXT = "Nothing to request via DanNet"
                    end
                end

                ImGui.PopID()
            end
        end
        ImGui.EndTable()
    end

    -- ImGui.TreePop()

    if ImGui.Button("Request Recipes (Experimental)") then
        -- Add in change color to green for recipes we have the proper counts for.
        -- Need to re-calculate aftwards, otherwise it will buy vendored items to make recipes.

        GLOBAL_TEXT = "Requesting Missing Recipes via DanNet"
        -- load dannet
        request_array_list = {}
        for x = 1, #recipe_stack_data do
            local request_item_id =
                tcglib.return_number(recipe_stack_data[x], 1)
            -- divide or multiply by yield?
            local request_item_count = tcglib.return_number(
                recipe_stack_data[x], 3)
            local have_count = mq.TLO.FindItemCount(request_item_id)()
            if have_count > 0 then
                request_item_count = request_item_count - have_count
            end
            -- add condition checks in here
            local request_string = request_item_id .. "," .. request_item_count

            if request_item_count > 0 then
                table.insert(request_array_list, request_string)
            end
        end
        --   for x = 1, #request_array_list do print(request_array_list[x]) end
        if request_array_list[1] ~= nil then
            go_ask = 1
        else
            GLOBAL_TEXT = "Nothing to request via DanNet"
        end
    end

    ImGui.SameLine()
    HelpMarker(
        "Queries other characters in zone for missing recipes, and delivers from inventory or bank.")

    ImGui.SameLine()

    ImGui.Text("Recipe Count: " .. #recipe_stack_data)

    --  ImGui.End()

    -- for c = 1 ,#recipe_stack_data do print(recipe_stack_data[c]) end
end

local function StandardRequirementsWindow()
    if recipe_disposition_data[1] == nil then
        ImGui.Text("No Data")
        return
    end

    -- if not openRecipeRequirementsGUI then return end

    ImGui.Separator()

    -- ImGui.SetWindowSize(700, 240)
    -- ImGui.SetWindowFontScale(1)

    ImGui.Text(name_select .. " ID: " .. id_select)

    ---- remd  ImGui.SetCursorPosX(4)

    -- ImGui.Text("Items Returned: (" .. #recipe_disposition_data .. ")")
    local flags = bit32.bor(ImGuiTableFlags.Resizable,
        ImGuiTableFlags.Reorderable,
        ImGuiTableFlags.Hideable,
        ImGuiTableFlags.MultiSortable,
        ImGuiTableFlags.Sortable, ImGuiTableFlags.RowBg,

        ImGuiTableFlags.Borders, ImGuiTableFlags.ScrollY)

    -- Recipe disposition table
    if ImGui.BeginTable('##single_recipe_farm_table_disposition', 5, flags, 0,
            TEXT_BASE_HEIGHT * 25, 0.0) then
        local ColumnID_RecipeName = 0
        local ColumnID_SkillRequired = 1
        local ColumnID_SkillLevel = 2
        local ColumnID_Race = 3
        local ColumnID_RecipeID = 4

        ImGui.TableSetupColumn('Recipe Name', ImGuiTableColumnFlags.WidthAuto,
            -1.0, ColumnID_RecipeName)
        ImGui.TableSetupColumn('Skill Required',
            ImGuiTableColumnFlags.WidthFixed, -1.0,
            ColumnID_SkillRequired)
        ImGui.TableSetupColumn('Skill Level',
            ImGuiTableColumnFlags.WidthStretch, -1.0,
            ColumnID_SkillLevel)
        ImGui.TableSetupColumn('Race', ImGuiTableColumnFlags.WidthStretch, -1.0,
            ColumnID_Race)
        ImGui.TableSetupColumn('Recipe ID', ImGuiTableColumnFlags.WidthStretch,
            -1.0, ColumnID_RecipeID)

        ImGui.TableSetupScrollFreeze(0, 1) -- Make row always visible
        -- Display data
        ImGui.TableHeadersRow()

        local clipper = ImGuiListClipper.new()
        clipper:Begin(#recipe_disposition_data)
        while clipper:Step() do
            for row_n = clipper.DisplayStart, clipper.DisplayEnd - 1, 1 do
                local farm_recipe_name =
                    recipe_disposition_data[row_n + 1].RecipeName
                local farm_item_skill = recipe_disposition_data[row_n + 1]
                    .RecipeSkillUsed
                local farm_item_skill_level =
                    recipe_disposition_data[row_n + 1].RecipeSkillLevel

                local farm_item_race = recipe_disposition_data[row_n + 1]
                    .RecipeRace

                if farm_item_race == nil then
                    farm_item_race = "None"
                end

                local farm_recipe_id = recipe_disposition_data[row_n + 1]
                    .RecipeID

                -- ImGui.PushStyleColor(ImGuiCol.Text, 0.16, 0.98, 0.38, .75)

                ImGui.PushID('recipe_disposition')

                -- ImGui.TableSetBgColor(ImGuiTableBgTarget.CellBg, 0.26, 0.98, 0.98, 0.35)

                local r_col, g_col, b_col = 0, .5, 0

                ImGui.TableNextRow()
                ImGui.TableNextColumn()
                --  ImGui.TableSetBgColor(ImGuiTableBgTarget.CellBg, 0.3, 0.9, 0.6, 0.35)

                if string.find(farm_recipe_name, "@") then
                    farm_recipe_name = farm_recipe_name:gsub('@', ',')
                end
                ImGui.TextColored(r_col, g_col, b_col, 1, farm_recipe_name)
                --   ImGui.Text(farm_recipe_name)
                ImGui.TableNextColumn()
                r_col, g_col, b_col = 1, 1, 1
                if farm_item_skill == "Make Poison" then
                    r_col = 1
                    g_col = .65
                    b_col = 0
                end
                if farm_item_skill == "Alchemy" then
                    r_col = 1
                    g_col = .5
                    b_col = 1
                end
                if farm_item_skill == "Tinkering" then
                    r_col = 1
                    g_col = 1
                    b_col = 0
                end

                ImGui.TextColored(r_col, g_col, b_col, 1, farm_item_skill)

                --   ImGui.Text(farm_item_skill)

                ImGui.TableNextColumn()
                if farm_item_skill_level == 0 then
                    farm_item_skill_level = "NONE"
                end

                if farm_item_skill_level == 999 then
                    farm_item_skill_level = "0, See GM/Freebies"
                end

                ImGui.Text(farm_item_skill_level)

                ImGui.TableNextColumn()
                ImGui.Text(farm_item_race)

                ImGui.TableNextColumn()
                ImGui.Text(farm_recipe_id)

                ImGui.PopID('recipe_disposition')
                --    ImGui.PopStyleColor(1)
            end
        end
        ImGui.EndTable()
    end
    -- ImGui.TreePop()
    -- ImGui.End()
end

local function StandardBankWindow()
    if BANK_ARRAY[1] == nil then
        ImGui.Text("No Data")
        return
    end

    -- ImGui.SetWindowSize(700, 280)
    -- ImGui.SetWindowFontScale(1)
    ---- remd  ImGui.SetCursorPosX(4)

    local flags = bit32.bor(ImGuiTableFlags.Resizable,
        ImGuiTableFlags.Reorderable,
        ImGuiTableFlags.Hideable,
        ImGuiTableFlags.MultiSortable,
        ImGuiTableFlags.Sortable, ImGuiTableFlags.RowBg,

        ImGuiTableFlags.Borders, ImGuiTableFlags.ScrollY)

    if ImGui.BeginTable('##bank_shopping_table', 3, flags, 0,
            TEXT_BASE_HEIGHT * 25, 0.0) then
        ImGui.TableSetupColumn('Name', ImGuiTableColumnFlags.WidthStretch, -1.0,
            ColumnID_Name)
        ImGui.TableSetupColumn('ID', ImGuiTableColumnFlags.WidthAuto, -1.0,
            ColumnID_ID)
        ImGui.TableSetupColumn('Count', ImGuiTableColumnFlags.WidthAuto, -1.0,
            ColumnID_Quantity)

        ImGui.TableSetupScrollFreeze(0, 1) -- Make row always visible

        local sort_specs = ImGui.TableGetSortSpecs()

        if sort_specs then
            if sort_specs.SpecsDirty then
                if #BANK_ARRAY > 1 then
                    current_sort_specs = sort_specs
                    table.sort(BANK_ARRAY, CompareWithSortSpecs)
                    current_sort_specs = nil
                end
                sort_specs.SpecsDirty = false
            end
        end

        -- Display data
        ImGui.TableHeadersRow()

        local clipper = ImGuiListClipper.new()
        clipper:Begin(#BANK_ARRAY)
        while clipper:Step() do
            for row_n = clipper.DisplayStart, clipper.DisplayEnd - 1, 1 do
                local r_col, g_col, b_col = .3, 1, 1
                local convert_item = BANK_ARRAY[row_n + 1]
                ImGui.PushID(convert_item)
                if string.find(convert_item.Name, "@") then
                    convert_item.Name = convert_item.Name:gsub('@', ',')
                end
                ImGui.TableNextRow()
                ImGui.TableNextColumn()
                ImGui.TextColored(r_col, g_col, b_col, 1, convert_item.Name)
                ImGui.TableNextColumn()
                ImGui.Text(string.format(convert_item.ID))
                ImGui.TableNextColumn()
                ImGui.Text(convert_item.Quantity)
                ImGui.PopID()
            end
        end
        ImGui.EndTable()
    end

    local ign_code = 0

    -- For later maybe?
    if ign_code == 1 then
        ImGui.Text("Options")
        ImGui.SameLine()
        -- revisit
        if ImGui.Button("Bank Shop") then go_shop = 49 end

        ImGui.SameLine()
        -- Write artisan bank shopping list to disk

        -- remove
        if ImGui.Button("Save") then
            local skill_used = max_array[l_max_selection]

            local file = "Artisan_BSL_" .. skill_used .. "_" .. mq.TLO.Me() ..
                "_" .. mq.TLO.MacroQuest.Server() .. ".csv"

            local file_exist_bool = tcglib.file_exists(file)

            if file_exist_bool then
                local command =
                    'del ' .. mq.luaDir .. '\\TCN\\ShoppingLists\\' .. file
                os.execute(command)
            end

            tcglib.writeshoppinglist("Artisan_BSL_" .. skill_used .. "_" ..
                mq.TLO.Me() .. "_" ..
                mq.TLO.MacroQuest.Server(),
                "Item,ID,Count")

            for sl = 1, #mass_bank_array do
                local item_id = mass_bank_array[sl].ID
                local item_count = mass_bank_array[sl].Quantity
                local item_name = mass_bank_array[sl].Name

                -- print(item_id, " ",item_count, " ",item_name)

                if string.find(item_name, ",") then
                    item_name = item_name:gsub(',', '|')
                end

                local l_shop_string = item_name .. "," .. item_id .. "," ..
                    item_count
                tcglib.writeshoppinglist(
                    "Artisan_BSL_" .. skill_used .. "_" .. mq.TLO.Me() .. "_" ..
                    mq.TLO.MacroQuest.Server(), l_shop_string)
            end
        end

        ImGui.SameLine()
        HelpMarker("Saves Bank Shopping Data to " .. mq.luaDir ..
            "\\TCN\\ShoppingLists\\ " .. " Directory")

        local skill_used = max_array[l_max_selection]

        local file =
            "Artisan_BSL_" .. skill_used .. "_" .. mq.TLO.Me() .. "_" ..
            mq.TLO.MacroQuest.Server() .. ".csv"

        local file_exist_bool = tcglib.file_exists(file)

        if file_exist_bool then
            ImGui.SameLine()
            ImGui.TextColored(0, 1, 0, 1, "File Exists")
        else
            ImGui.SameLine()
            ImGui.TextColored(1, 1, 0, 1, "File Not Created")
        end

        ImGui.SameLine()
        if ImGui.Button("Open Folder") then
            -- Open Windows Directory
            os.execute("start " .. mq.luaDir .. "\\TCN\\ShoppingLists")
        end

        ImGui.SameLine()
        HelpMarker("Open Folder " .. mq.luaDir .. "\\TCN\\ShoppingLists\\ ")
    end
    -- end IGN CODE

    -- ImGui.SameLine()
    -- if ImGui.Button("Close Window") then
    --  BANK_ARRAY = {}
    --  GLOBAL_TEXT = "Idle"
    -- end

    -- ImGui.End()
end

local function ShowResults()
    -- Stable ID for the tab bar
    if ImGui.BeginTabBar("Results##results_tabbar", ImGuiTabBarFlags.Reorderable) then
        -- Helper to draw a tab with conditional coloring
        local function DrawTab(label, id_suffix, data_array, draw_func)
            local col1, col2, col3
            if data_array[1] == nil then
                col1, col2, col3 = 0.5, 0, 0
            else
                col1, col2, col3 = 0, 0.5, 0
            end

            ImGui.PushStyleColor(ImGuiCol.TabActive, col1, col2, col3, 1)
            ImGui.PushStyleColor(ImGuiCol.Tab, col1, col2, col3, 1)

            ImGui.PushID(id_suffix)
            if ImGui.BeginTabItem(label .. "##" .. id_suffix) then
                draw_func()
                ImGui.EndTabItem()
            end
            ImGui.PopID()

            ImGui.PopStyleColor(2)
        end

        -- Tabs
        DrawTab("Shopping", "results_shopping", recipe_shopping_data, StandardShoppingListWindow)
        DrawTab("Missing", "results_missing", trim_soiled, StandardFarmTableWindow)
        DrawTab("Recipes", "results_recipes", recipe_stack_data, StandardRecipeStackWindow)
        DrawTab("Requirements", "results_requirements", recipe_disposition_data, StandardRequirementsWindow)
        DrawTab("Bank", "results_bank", BANK_ARRAY, StandardBankWindow)
        DrawTab("Depot", "results_depot", l_depot_array, StandardDepotTableWindow)
        DrawTab("Fish", "results_fish", { true }, StandardFishWindow) -- always enabled

        ImGui.EndTabBar()
    end
end


function MerchantQuestFarmTableWindow()
    if merchant_farm_list[1] == nil then return end

    -- ImGui.SetWindowSize(700, 480)
    -- ImGui.SetWindowFontScale(1)

    -- remd-- remd  ImGui.SetCursorPosX(4)

    -- ImGui.Text("Items Returned: (" .. #quest_farm_list .. ")")
    local flags = bit32.bor(ImGuiTableFlags.Resizable,
        ImGuiTableFlags.Reorderable,
        ImGuiTableFlags.Hideable, ImGuiTableFlags.Sortable,
        ImGuiTableFlags.MultiSortable,
        ImGuiTableFlags.RowBg, ImGuiTableFlags.BordersOuter,
        ImGuiTableFlags.BordersV,
        ImGuiTableFlags.NoBordersInBody,
        ImGuiTableFlags.ScrollY)
    if ImGui.BeginTable('##merchant_recipe_farm_table', 6, flags, 0,
            TEXT_BASE_HEIGHT * 20, 0.0) then
        local ColumnID_ItemName = 0
        local ColumnID_ItemCount = 1
        local ColumnID_ItemHave = 2
        local ColumnID_ItemAction = 3
        local ColumnID_ItemZone = 4
        local ColumnID_ItemID = 5

        ImGui.TableSetupColumn('Missing Item',
            ImGuiTableColumnFlags.WidthStretch, -1.0,
            ColumnID_ItemName)

        ImGui.TableSetupColumn('Count', ImGuiTableColumnFlags.WidthFixed, -1.0,
            ColumnID_ItemCount)

        ImGui.TableSetupColumn('Inv', ImGuiTableColumnFlags.WidthFixed, -1.0,
            ColumnID_ItemHave)

        ImGui.TableSetupColumn('Action', ImGuiTableColumnFlags.WidthFixed, -1.0,
            ColumnID_ItemAction)

        ImGui.TableSetupColumn('Zone', ImGuiTableColumnFlags.WidthStretch, -1.0,
            ColumnID_ItemZone)

        ImGui.TableSetupColumn('Item ID', ImGuiTableColumnFlags.WidthFixed,
            -1.0, ColumnID_ItemID)
        ImGui.TableSetupScrollFreeze(0, 1) -- Make row always visible
        -- Display data
        ImGui.TableHeadersRow()

        local clipper = ImGuiListClipper.new()
        clipper:Begin(#merchant_farm_list)
        while clipper:Step() do
            for row_n = clipper.DisplayStart, clipper.DisplayEnd - 1, 1 do
                local farm_item_name = tcglib.return_string(
                    merchant_farm_list[row_n + 1], 1)

                local farm_item_id = tcglib.return_number(
                    merchant_farm_list[row_n + 1], 2)
                local farm_item_count = tcglib.return_number(
                    merchant_farm_list[row_n + 1], 3)

                local farm_item_action =
                    tcglib.return_string(
                        merchant_farm_list[row_n + 1], 4)

                local farm_item_zone = tcglib.return_string(
                    merchant_farm_list[row_n + 1], 5)

                --  ImGui.PushID()
                ImGui.TableNextRow()
                ImGui.TableNextColumn()

                if mq.TLO.FindItemCount(farm_item_id)() >= farm_item_count then
                    ImGui.TextColored(0, 1, 0, 1, farm_item_name)
                else
                    ImGui.TextColored(1, 1, 1, 1, farm_item_name)
                end
                -- ImGui.Text(farm_item_name)

                ImGui.TableNextColumn()
                ImGui.Text(farm_item_count)
                ImGui.TableNextColumn()
                ImGui.Text(mq.TLO.FindItemCount(farm_item_id)())

                ImGui.TableNextColumn()

                local r_col, g_col, b_col = 0, .5, 0

                if farm_item_action == "Faction" then
                    r_col, g_col, b_col = .3, 1, .7
                end

                if farm_item_action == "Farm" then
                    r_col, g_col, b_col = 1, .5, 0
                end

                if farm_item_action == "Fish" then
                    r_col, g_col, b_col = 0, .5, 1
                end

                if farm_item_action == "Forage" then
                    r_col, g_col, b_col = .9, .1, .9
                end

                if farm_item_action == "Vendor" then
                    r_col, g_col, b_col = .7, .9, .2
                end

                if farm_item_action == "Enchanter" then
                    r_col, g_col, b_col = .9, .7, .1
                end

                -- Add quested

                -- add count > mqtlo finditemcount

                ImGui.TextColored(r_col, g_col, b_col, 1, farm_item_action)

                --     ImGui.Text(farm_item_action)

                ImGui.TableNextColumn()

                if string.find(farm_item_zone, "@") then
                    farm_item_zone = farm_item_zone:gsub('@', ',')
                end
                ImGui.Text(farm_item_zone)

                ImGui.TableNextColumn()
                ImGui.Text(string.format(farm_item_id))
                --  ImGui.PopID()
            end
        end
        ImGui.EndTable()

        if ImGui.Button("Request Missing Components") then
            GLOBAL_TEXT = "Requesting Missing Quest Components via DanNet"
            -- load dannet
            request_array_list = {}
            for x = 1, #merchant_farm_list do
                local request_item_id = tcglib.return_number(
                    merchant_farm_list[x], 2)
                local request_item_count =
                    tcglib.return_number(merchant_farm_list[x], 3)
                local have_count = mq.TLO.FindItemCount(request_item_id)()
                if have_count > 0 then
                    request_item_count = request_item_count - have_count
                end
                -- add condition checks in here
                local request_string = request_item_id .. "," ..
                    request_item_count

                if request_item_count > 0 then
                    table.insert(request_array_list, request_string)
                end
            end
            --   for x = 1, #request_array_list do print(request_array_list[x]) end
            if request_array_list[1] ~= nil then
                go_ask = 1
            else
                GLOBAL_TEXT = "Nothing to request via DanNet"
            end
        end

        ImGui.SameLine()
        HelpMarker(
            "Queries other characters in zone for missing items, and delivers from inventory or bank.")

        ImGui.SameLine()
        -- Write artisan farm shopping list to disk

        -- Quest Farm don't use this.
        local no_use = 0
        if no_use == 1 then
            if ImGui.Button("Save Data") then
                --  show date for file when we try to read it?

                local skill_used = max_array[l_max_selection]

                local file =
                    "Artisan_QL_" .. skill_used .. "_" .. mq.TLO.Me() .. "_" ..
                    mq.TLO.MacroQuest.Server() .. ".csv"

                local file_exist_bool = tcglib.file_exists(file)

                if file_exist_bool then
                    local command = 'del ' .. mq.luaDir ..
                        '\\TCN\\ShoppingLists\\' .. file
                    --   os.execute(command)
                end

                --   writeshoppinglist(
                --    "Artisan_QL_" .. skill_used .. "_" .. mq.TLO.Me() .. "_" ..
                --     mq.TLO.MacroQuest.Server(), "Item,Count,ID")

                for sl = 1, #merchant_farm_list do
                    local item_name = tcglib.return_string(
                        merchant_farm_list[sl], 1)
                    local item_id = tcglib.return_number(merchant_farm_list[sl],
                        2)
                    local item_count = tcglib.return_number(
                        merchant_farm_list[sl], 3)
                    -- local item_zone = tcglib.return_string(max_farm_list[sl], 4)
                    -- local item_action = tcglib.return_string(max_farm_list[sl], 5)

                    local l_farm_string =
                        item_name .. "," .. item_count .. "," .. item_id
                    --   writeshoppinglist("Artisan_QL_" .. skill_used .. "_" ..
                    --                       mq.TLO.Me() .. "_" ..
                    --                      mq.TLO.MacroQuest.Server(), l_farm_string)
                end
            end
        end

        ImGui.SameLine()
        if ImGui.Button("Close Merchant Alliance Quest Farm Window") then
            merchant_farm_list = {}
            -- GLOBAL_MAX_REPORT_FLAG = 0
            --  report_max_bool = false
            GLOBAL_TEXT = "Idle"
        end
    end

    -- ImGui.End()
end

function ArtisanQuestFarmTableWindow()
    if artisan_farm_list[1] == nil then return end

    -- ImGui.SetWindowSize(700, 480)
    -- ImGui.SetWindowFontScale(1)

    -- remd-- remd  ImGui.SetCursorPosX(4)

    -- ImGui.Text("Items Returned: (" .. #quest_farm_list .. ")")
    local flags = bit32.bor(ImGuiTableFlags.Resizable,
        ImGuiTableFlags.Reorderable,
        ImGuiTableFlags.Hideable, ImGuiTableFlags.Sortable,
        ImGuiTableFlags.MultiSortable,
        ImGuiTableFlags.RowBg, ImGuiTableFlags.BordersOuter,
        ImGuiTableFlags.BordersV,
        ImGuiTableFlags.NoBordersInBody,
        ImGuiTableFlags.ScrollY)
    if ImGui.BeginTable('##artisan_recipe_farm_table', 6, flags, 0,
            TEXT_BASE_HEIGHT * 20, 0.0) then
        local ColumnID_ItemName = 0
        local ColumnID_ItemCount = 1
        local ColumnID_ItemHave = 2
        local ColumnID_ItemAction = 3
        local ColumnID_ItemZone = 4
        local ColumnID_ItemID = 5

        ImGui.TableSetupColumn('Missing Item',
            ImGuiTableColumnFlags.WidthStretch, -1.0,
            ColumnID_ItemName)

        ImGui.TableSetupColumn('Count', ImGuiTableColumnFlags.WidthFixed, -1.0,
            ColumnID_ItemCount)

        ImGui.TableSetupColumn('Inv', ImGuiTableColumnFlags.WidthFixed, -1.0,
            ColumnID_ItemHave)

        ImGui.TableSetupColumn('Action', ImGuiTableColumnFlags.WidthFixed, -1.0,
            ColumnID_ItemAction)

        ImGui.TableSetupColumn('Zone', ImGuiTableColumnFlags.WidthStretch, -1.0,
            ColumnID_ItemZone)

        ImGui.TableSetupColumn('Item ID', ImGuiTableColumnFlags.WidthFixed,
            -1.0, ColumnID_ItemID)
        ImGui.TableSetupScrollFreeze(0, 1) -- Make row always visible
        -- Display data
        ImGui.TableHeadersRow()

        local clipper = ImGuiListClipper.new()
        clipper:Begin(#artisan_farm_list)
        while clipper:Step() do
            for row_n = clipper.DisplayStart, clipper.DisplayEnd - 1, 1 do
                local farm_item_name = tcglib.return_string(
                    artisan_farm_list[row_n + 1], 1)

                local farm_item_id = tcglib.return_number(
                    artisan_farm_list[row_n + 1], 2)
                local farm_item_count = tcglib.return_number(
                    artisan_farm_list[row_n + 1], 3)

                local farm_item_action =
                    tcglib.return_string(
                        artisan_farm_list[row_n + 1], 4)

                local farm_item_zone = tcglib.return_string(
                    artisan_farm_list[row_n + 1], 5)

                --  ImGui.PushID()
                ImGui.TableNextRow()
                ImGui.TableNextColumn()

                if mq.TLO.FindItemCount(farm_item_id)() >= farm_item_count then
                    ImGui.TextColored(0, 1, 0, 1, farm_item_name)
                else
                    ImGui.TextColored(1, 1, 1, 1, farm_item_name)
                end
                -- ImGui.Text(farm_item_name)

                ImGui.TableNextColumn()
                ImGui.Text(farm_item_count)
                ImGui.TableNextColumn()
                ImGui.Text(mq.TLO.FindItemCount(farm_item_id)())

                ImGui.TableNextColumn()

                local r_col, g_col, b_col = 0, .5, 0

                if farm_item_action == "Faction" then
                    r_col, g_col, b_col = .3, 1, .7
                end

                if farm_item_action == "Farm" then
                    r_col, g_col, b_col = 1, .5, 0
                end

                if farm_item_action == "Fish" then
                    r_col, g_col, b_col = 0, .5, 1
                end

                if farm_item_action == "Forage" then
                    r_col, g_col, b_col = .9, .1, .9
                end

                if farm_item_action == "Vendor" then
                    r_col, g_col, b_col = .7, .9, .2
                end

                if farm_item_action == "Enchanter" then
                    r_col, g_col, b_col = .9, .7, .1
                end

                -- Add quested

                -- add count > mqtlo finditemcount

                ImGui.TextColored(r_col, g_col, b_col, 1, farm_item_action)

                --     ImGui.Text(farm_item_action)

                ImGui.TableNextColumn()

                if string.find(farm_item_zone, "@") then
                    farm_item_zone = farm_item_zone:gsub('@', ',')
                end
                ImGui.Text(farm_item_zone)

                ImGui.TableNextColumn()
                ImGui.Text(string.format(farm_item_id))
                --  ImGui.PopID()
            end
        end
        ImGui.EndTable()

        -- Ignore code for now
        local itsd = 0

        if mq.TLO.TradeskillDepot.Enabled() and itsd == 1 then
            if ImGui.Button("Request Components from Depot") then
                local depot_data = feeder.return_depot_convert_data(
                    artisan_farm_list)

                local count = 0

                -- need and local inventory

                for c = 1, #depot_data do
                    if mq.TLO.TradeskillDepot.FindItemCount(depot_data[c].ID)() >
                        0 then
                        count = 1
                    end
                end

                if count == 1 then
                    GLOBAL_TEXT = "Shopping from Depot"

                    -- for c = 1 ,#depot_data do print(depot_data[c].Name," ",depot_data[c].ID," ",depot_data[c].Quantity) end

                    -- feeder.window_go_depot_shopping(depot_data)
                    -- Verify list is complete before wiping?
                    depot_data = {}
                else
                    GLOBAL_TEXT = "None of these items are in the depot"
                end
            end

            ImGui.SameLine()
            HelpMarker("Checks depot for missing items and grabs them.")
            ImGui.SameLine()
        end

        if ImGui.Button("Request Missing Components") then
            GLOBAL_TEXT = "Requesting Missing Quest Components via DanNet"
            -- load dannet
            request_array_list = {}
            for x = 1, #artisan_farm_list do
                local request_item_id = tcglib.return_number(
                    artisan_farm_list[x], 2)
                local request_item_count =
                    tcglib.return_number(artisan_farm_list[x], 3)
                local have_count = mq.TLO.FindItemCount(request_item_id)()
                if have_count > 0 then
                    request_item_count = request_item_count - have_count
                end
                -- add condition checks in here
                local request_string = request_item_id .. "," ..
                    request_item_count

                if request_item_count > 0 then
                    table.insert(request_array_list, request_string)
                end
            end
            --   for x = 1, #request_array_list do print(request_array_list[x]) end
            if request_array_list[1] ~= nil then
                go_ask = 1
            else
                GLOBAL_TEXT = "Nothing to request via DanNet"
            end
        end

        ImGui.SameLine()
        HelpMarker(
            "Queries other characters in zone for missing items, and delivers from inventory or bank.")

        ImGui.SameLine()
        -- Write artisan farm shopping list to disk

        -- Quest Farm don't use this.
        local no_use = 0
        if no_use == 1 then
            if ImGui.Button("Save Data") then
                --  show date for file when we try to read it?

                local skill_used = max_array[l_max_selection]

                local file =
                    "Artisan_QL_" .. skill_used .. "_" .. mq.TLO.Me() .. "_" ..
                    mq.TLO.MacroQuest.Server() .. ".csv"

                local file_exist_bool = tcglib.file_exists(file)

                if file_exist_bool then
                    local command = 'del ' .. mq.luaDir ..
                        '\\TCN\\ShoppingLists\\' .. file
                    --   os.execute(command)
                end

                --   writeshoppinglist(
                --    "Artisan_QL_" .. skill_used .. "_" .. mq.TLO.Me() .. "_" ..
                --     mq.TLO.MacroQuest.Server(), "Item,Count,ID")

                for sl = 1, #artisan_farm_list do
                    local item_name = tcglib.return_string(
                        artisan_farm_list[sl], 1)
                    local item_id = tcglib.return_number(artisan_farm_list[sl],
                        2)
                    local item_count = tcglib.return_number(
                        artisan_farm_list[sl], 3)
                    -- local item_zone = tcglib.return_string(max_farm_list[sl], 4)
                    -- local item_action = tcglib.return_string(max_farm_list[sl], 5)

                    local l_farm_string =
                        item_name .. "," .. item_count .. "," .. item_id
                    --   writeshoppinglist("Artisan_QL_" .. skill_used .. "_" ..
                    --                       mq.TLO.Me() .. "_" ..
                    --                      mq.TLO.MacroQuest.Server(), l_farm_string)
                end
            end
        end

        ImGui.SameLine()
        if ImGui.Button("Close Artisan Seals Quest Farm Window") then
            artisan_farm_list = {}
            -- GLOBAL_MAX_REPORT_FLAG = 0
            --  report_max_bool = false
            GLOBAL_TEXT = "Idle"
        end
    end

    -- ImGui.End()
end

function QuestFarmTableWindow()
    if quest_farm_list[1] == nil then return end

    -- ImGui.SetWindowSize(700, 480)
    -- ImGui.SetWindowFontScale(1)

    -- remd-- remd  ImGui.SetCursorPosX(4)

    -- ImGui.Text("Items Returned: (" .. #quest_farm_list .. ")")
    local flags = bit32.bor(ImGuiTableFlags.Resizable,
        ImGuiTableFlags.Reorderable,
        ImGuiTableFlags.Hideable, ImGuiTableFlags.Sortable,
        ImGuiTableFlags.MultiSortable,
        ImGuiTableFlags.RowBg, ImGuiTableFlags.BordersOuter,
        ImGuiTableFlags.BordersV,
        ImGuiTableFlags.NoBordersInBody,
        ImGuiTableFlags.ScrollY)
    if ImGui.BeginTable('##quest_recipe_farm_table', 8, flags, 0,
            TEXT_BASE_HEIGHT * 20, 0.0) then
        local ColumnID_ItemName = 0
        local ColumnID_ItemCount = 1
        local ColumnID_ItemHave = 2
        local ColumnID_ItemAction = 3
        local ColumnID_ItemZone = 4
        local ColumnID_ItemID = 5

        local ColumnID_Bnk = 66
        local ColumnID_Dpt = 77

        ImGui.TableSetupColumn('Missing Item',
            ImGuiTableColumnFlags.WidthStretch, -1.0,
            ColumnID_ItemName)

        ImGui.TableSetupColumn('Need', ImGuiTableColumnFlags.WidthFixed, -1.0,
            ColumnID_ItemCount)

        ImGui.TableSetupColumn('Inv', ImGuiTableColumnFlags.WidthAuto, -1.0,
            ColumnID_ItemHave)

        ImGui.TableSetupColumn('Bnk', ImGuiTableColumnFlags.WidthAuto, -1.0,
            ColumnID_Bnk)

        ImGui.TableSetupColumn('Depot', ImGuiTableColumnFlags.WidthAuto, -1.0,
            ColumnID_Dpt)

        ImGui.TableSetupColumn('Action', ImGuiTableColumnFlags.WidthFixed, -1.0,
            ColumnID_ItemAction)

        ImGui.TableSetupColumn('Zone', ImGuiTableColumnFlags.WidthStretch, -1.0,
            ColumnID_ItemZone)

        ImGui.TableSetupColumn('Item ID', ImGuiTableColumnFlags.WidthFixed,
            -1.0, ColumnID_ItemID)
        ImGui.TableSetupScrollFreeze(0, 1) -- Make row always visible
        -- Display data
        ImGui.TableHeadersRow()

        local clipper = ImGuiListClipper.new()
        clipper:Begin(#quest_farm_list)
        while clipper:Step() do
            for row_n = clipper.DisplayStart, clipper.DisplayEnd - 1, 1 do
                local farm_item_name = tcglib.return_string(
                    quest_farm_list[row_n + 1], 1)

                local farm_item_id = tcglib.return_number(
                    quest_farm_list[row_n + 1], 2)
                local farm_item_count = tcglib.return_number(
                    quest_farm_list[row_n + 1], 3)

                local farm_item_action =
                    tcglib.return_string(
                        quest_farm_list[row_n + 1], 4)

                local farm_item_zone = tcglib.return_string(
                    quest_farm_list[row_n + 1], 5)

                ImGui.PushID('quest_max_farm_list')
                ImGui.TableNextRow()
                ImGui.TableNextColumn()

                if mq.TLO.FindItemCount(farm_item_id)() >= farm_item_count then
                    ImGui.TextColored(0, 1, 0, 1, farm_item_name)
                else
                    ImGui.TextColored(1, 1, 1, 1, farm_item_name)
                end
                -- ImGui.Text(farm_item_name)

                ImGui.TableNextColumn()
                ImGui.Text(farm_item_count)

                ImGui.TableNextColumn()
                ImGui.Text(mq.TLO.FindItemCount(farm_item_id)())

                ImGui.TableNextColumn()
                ImGui.Text(mq.TLO.FindItemBankCount(farm_item_id)())

                ImGui.TableNextColumn()
                if mq.TLO.TradeskillDepot.Enabled() then
                    if mq.TLO.TradeskillDepot.FindItemCount(farm_item_id)() > 0 then
                        ImGui.Text(mq.TLO.TradeskillDepot.FindItemCount(
                            farm_item_id)())
                    else
                        ImGui.Text("0")
                    end
                else
                    ImGui.Text("-")
                end

                ImGui.TableNextColumn()

                local r_col, g_col, b_col = 0, .5, 0

                if farm_item_action == "Faction" then
                    r_col, g_col, b_col = .3, 1, .7
                end

                if farm_item_action == "Farm" then
                    r_col, g_col, b_col = 1, .5, 0
                end

                if farm_item_action == "Fish" then
                    r_col, g_col, b_col = 0, .5, 1
                end

                if farm_item_action == "Forage" then
                    r_col, g_col, b_col = .9, .1, .9
                end

                if farm_item_action == "Vendor" then
                    r_col, g_col, b_col = .7, .9, .2
                end

                if farm_item_action == "Enchanter" then
                    r_col, g_col, b_col = .9, .7, .1
                end

                -- Add quested

                -- add count > mqtlo finditemcount

                ImGui.TextColored(r_col, g_col, b_col, 1, farm_item_action)

                --     ImGui.Text(farm_item_action)

                ImGui.TableNextColumn()

                if string.find(farm_item_zone, "@") then
                    farm_item_zone = farm_item_zone:gsub('@', ',')
                end
                ImGui.Text(farm_item_zone)

                ImGui.TableNextColumn()
                ImGui.Text(string.format(farm_item_id))
                ImGui.PopID()
            end
        end
        ImGui.EndTable()

        if ImGui.Button("Request Missing Components") then
            GLOBAL_TEXT = "Requesting Missing Quest Components via DanNet"

            -- load dannet

            request_array_list = {}

            for x = 1, #quest_farm_list do
                local request_item_id = tcglib.return_number(quest_farm_list[x],
                    2)

                local request_item_count =
                    tcglib.return_number(quest_farm_list[x], 3)

                local have_count = mq.TLO.FindItemCount(request_item_id)()

                if have_count > 0 then
                    request_item_count = request_item_count - have_count
                end

                -- add condition checks in here
                local request_string = request_item_id .. "," ..
                    request_item_count

                -- print("have: ",have_count," \ag", request_item_id, " \at", request_item_count)

                if request_item_count > 0 then
                    table.insert(request_array_list, request_string)
                end
            end
            --   for x = 1, #request_array_list do print(request_array_list[x]) end
            if request_array_list[1] ~= nil then
                go_ask = 1
            else
                GLOBAL_TEXT = "Nothing to request via DanNet"
            end
        end

        ImGui.SameLine()
        HelpMarker(
            "Queries other characters in zone for missing items, and delivers from inventory or bank.")

        ImGui.SameLine()
        -- Write artisan farm shopping list to disk

        -- Quest Farm don't use this.
        local no_use = 0
        if no_use == 1 then
            if ImGui.Button("Save Data") then
                --  show date for file when we try to read it?

                local skill_used = max_array[l_max_selection]

                local file =
                    "Artisan_QL_" .. skill_used .. "_" .. mq.TLO.Me() .. "_" ..
                    mq.TLO.MacroQuest.Server() .. ".csv"

                local file_exist_bool = tcglib.file_exists(file)

                if file_exist_bool then
                    local command = 'del ' .. mq.luaDir ..
                        '\\TCN\\ShoppingLists\\' .. file
                    --   os.execute(command)
                end

                --   writeshoppinglist(
                --    "Artisan_QL_" .. skill_used .. "_" .. mq.TLO.Me() .. "_" ..
                --     mq.TLO.MacroQuest.Server(), "Item,Count,ID")

                for sl = 1, #quest_farm_list do
                    local item_name = tcglib.return_string(quest_farm_list[sl],
                        1)
                    local item_id = tcglib.return_number(quest_farm_list[sl], 2)
                    local item_count = tcglib.return_number(quest_farm_list[sl],
                        3)
                    -- local item_zone = tcglib.return_string(max_farm_list[sl], 4)
                    -- local item_action = tcglib.return_string(max_farm_list[sl], 5)

                    local l_farm_string =
                        item_name .. "," .. item_count .. "," .. item_id
                    --   writeshoppinglist("Artisan_QL_" .. skill_used .. "_" ..
                    --                       mq.TLO.Me() .. "_" ..
                    --                      mq.TLO.MacroQuest.Server(), l_farm_string)
                end
            end
        end

        ImGui.SameLine()
        if ImGui.Button("Close Farm Window") then
            quest_farm_list = {}
            -- GLOBAL_MAX_REPORT_FLAG = 0
            --  report_max_bool = false
            GLOBAL_TEXT = "Idle"
        end
    end

    -- ImGui.End()
end

function BatchGenerateWindow()
    if BATCH_FARM_LIST[1] == nil then
        ImGui.Text("No Data")
        return
    end

    -- ImGui.SetWindowSize(800, 480)
    -- ImGui.SetWindowPos(1024,0)
    -- ImGui.SetWindowFontScale(1)
    -- remd  ImGui.SetCursorPosX(4)

    -- ImGui.Text("Items Returned: (" .. #max_farm_list .. ")")
    local flags = bit32.bor(ImGuiTableFlags.Resizable,
        ImGuiTableFlags.Reorderable,
        ImGuiTableFlags.Hideable, ImGuiTableFlags.Sortable,
        ImGuiTableFlags.MultiSortable,
        ImGuiTableFlags.RowBg, ImGuiTableFlags.BordersOuter,
        ImGuiTableFlags.BordersV,
        ImGuiTableFlags.NoBordersInBody,
        ImGuiTableFlags.ScrollY)

    if ImGui.BeginTable('##batch_recipe_farm_table', 7, flags, 0,
            TEXT_BASE_HEIGHT * 16, 0.0) then
        local ColumnID_RequestItem = 10

        ImGui.TableSetupColumn('Missing Item',
            ImGuiTableColumnFlags.WidthStretch, -1.0,
            ColumnID_Name)

        ImGui.TableSetupColumn('Count', ImGuiTableColumnFlags.WidthFixed, -1.0,
            ColumnID_Quantity)

        ImGui.TableSetupColumn('Inv', ImGuiTableColumnFlags.WidthFixed, -1.0,
            ColumnID_Inventory)

        ImGui.TableSetupColumn('Action', ImGuiTableColumnFlags.WidthFixed, -1.0,
            ColumnID_Action)

        ImGui.TableSetupColumn('Zone', ImGuiTableColumnFlags.WidthStretch, -1.0,
            ColumnID_ZoneName)

        ImGui.TableSetupColumn('Item ID', ImGuiTableColumnFlags.WidthFixed,
            -1.0, ColumnID_ID)

        ImGui.TableSetupColumn('Request', ImGuiTableColumnFlags.WidthFixed,
            -1.0, ColumnID_RequestItem)

        ImGui.TableSetupScrollFreeze(0, 1) -- Make row always visible

        local sort_specs = ImGui.TableGetSortSpecs()

        if sort_specs then
            if sort_specs.SpecsDirty then
                if #converted_batch_farm_data > 1 then
                    current_sort_specs = sort_specs
                    table.sort(converted_batch_farm_data, CompareWithSortSpecs)
                    current_sort_specs = nil
                end
                sort_specs.SpecsDirty = false
            end
        end

        -- Display data
        ImGui.TableHeadersRow()

        local clipper = ImGuiListClipper.new()
        clipper:Begin(#converted_batch_farm_data)
        while clipper:Step() do
            for row_n = clipper.DisplayStart, clipper.DisplayEnd - 1, 1 do
                local convert_item = converted_batch_farm_data[row_n + 1]
                ImGui.PushID(convert_item)
                ImGui.TableNextRow()
                ImGui.TableNextColumn()
                if mq.TLO.FindItemCount(convert_item.ID)() >=
                    convert_item.Quantity then
                    ImGui.TextColored(0, 1, 0, 1, convert_item.Name)
                else
                    ImGui.TextColored(1, 1, 1, 1, convert_item.Name)
                end
                ImGui.TableNextColumn()

                -- Vah Shir Anvil and other items Should be caught by tools routine
                --  if convert_item.ID == 29816 or convert_item.ID == 29820 or
                --    convert_item.ID == 29824 then
                --    convert_item.Quantity = 1
                -- end

                ImGui.Text(convert_item.Quantity)
                ImGui.TableNextColumn()
                ImGui.Text(mq.TLO.FindItemCount(convert_item.ID)())
                ImGui.TableNextColumn()
                local r_col, g_col, b_col = 0, .5, 0
                if convert_item.Action == "Faction" then
                    r_col, g_col, b_col = .3, 1, .7
                end
                if convert_item.Action == "Farm" then
                    r_col, g_col, b_col = 1, .5, 0
                end
                if convert_item.Action == "Fish" then
                    r_col, g_col, b_col = 0, .5, 1
                end
                if convert_item.Action == "Forage" then
                    r_col, g_col, b_col = .9, .1, .9
                end
                if convert_item.Action == "Vendor" then
                    r_col, g_col, b_col = .7, .9, .2
                end
                if convert_item.Action == "Enchanter" then
                    r_col, g_col, b_col = .9, .7, .1
                end
                -- Add quested
                -- add count > mqtlo finditemcount
                ImGui.TextColored(r_col, g_col, b_col, 1, convert_item.Action)
                ImGui.TableNextColumn()

                -- if string.find(convert_item.ZoneName, "@") then
                --   convert_item.ZoneName = convert_item.ZoneName:gsub('@', ',')
                -- end

                ImGui.Text(convert_item.ZoneName)
                ImGui.TableNextColumn()
                ImGui.Text(string.format(convert_item.ID))
                ImGui.TableNextColumn()

                if ImGui.Button("Request") then
                    GLOBAL_TEXT =
                    "Requesting Batch Single Missing Component via DanNet"
                    request_array_list = {}
                    local have_count = mq.TLO.FindItemCount(convert_item.ID)()
                    local current_qty = convert_item.Quantity
                    if have_count > 0 then
                        current_qty = current_qty - have_count
                    end
                    -- add condition checks in here
                    local request_string = convert_item.ID .. "," .. current_qty
                    if current_qty > 0 then
                        table.insert(request_array_list, request_string)
                    end
                    if request_array_list[1] ~= nil then
                        go_ask = 1
                    else
                        GLOBAL_TEXT = "Nothing to request via DanNet"
                    end
                end

                ImGui.PopID()
            end
        end

        ImGui.EndTable()

        if ImGui.Button("Request Batch Missing Components") then
            GLOBAL_TEXT = "Requesting Batch Missing Components via DanNet"

            request_array_list = {}
            for x = 1, #BATCH_FARM_LIST do
                local request_item_id = tcglib.return_number(BATCH_FARM_LIST[x],
                    2)
                local request_item_count =
                    tcglib.return_number(BATCH_FARM_LIST[x], 3)
                local have_count = mq.TLO.FindItemCount(request_item_id)()
                if have_count > 0 then
                    request_item_count = request_item_count - have_count
                end
                -- add condition checks in here
                local request_string = request_item_id .. "," ..
                    request_item_count

                if request_item_count > 0 then
                    table.insert(request_array_list, request_string)
                end
            end
            --   for x = 1, #request_array_list do print(request_array_list[x]) end
            if request_array_list[1] ~= nil then
                go_ask = 1
            else
                GLOBAL_TEXT = "Nothing to request via DanNet"
            end
        end

        ImGui.SameLine()
        HelpMarker(
            "Queries other characters in zone for missing items, and delivers from inventory or bank.")

        local ign_section_batch_save = 0

        if ign_section_batch_save == 1 then
            ImGui.SameLine()
            -- Write artisan farm shopping list to disk
            if ImGui.Button("Save Data") then
                --  show date for file when we try to read it?

                local skill_used = max_array[l_max_selection]

                local file =
                    "Artisan_FL_" .. skill_used .. "_" .. mq.TLO.Me() .. "_" ..
                    mq.TLO.MacroQuest.Server() .. ".csv"

                local file_exist_bool = tcglib.file_exists(file)

                if file_exist_bool then
                    local command = 'del ' .. mq.luaDir ..
                        '\\TCN\\ShoppingLists\\' .. file
                    os.execute(command)
                end

                tcglib.writeshoppinglist(
                    "Artisan_FL_" .. skill_used .. "_" .. mq.TLO.Me() .. "_" ..
                    mq.TLO.MacroQuest.Server(), "Item,Count,ID,Action,Zone")

                for sl = 1, #max_farm_list do
                    local item_name = tcglib.return_string(max_farm_list[sl], 1)
                    local item_id = tcglib.return_number(max_farm_list[sl], 2)
                    local item_count =
                        tcglib.return_number(max_farm_list[sl], 3)
                    local item_action = tcglib.return_string(max_farm_list[sl],
                        4)
                    local item_zone = tcglib.return_string(max_farm_list[sl], 5)

                    if string.find(item_zone, ",") then
                        item_zone = item_zone:gsub(',', '|')
                    end

                    local l_farm_string =
                        item_name .. "," .. item_count .. "," .. item_id .. "," ..
                        item_action .. "," .. item_zone

                    tcglib.writeshoppinglist(
                        "Artisan_FL_" .. skill_used .. "_" .. mq.TLO.Me() .. "_" ..
                        mq.TLO.MacroQuest.Server(), l_farm_string)
                end
            end

            ImGui.SameLine()
            HelpMarker("Saves data to " .. mq.luaDir ..
                "\\TCN\\ShoppingLists\\ " .. " Directory")

            local skill_used = max_array[l_max_selection]

            local file = "Artisan_FL_" .. skill_used .. "_" .. mq.TLO.Me() ..
                "_" .. mq.TLO.MacroQuest.Server() .. ".csv"

            local file_exist_bool = tcglib.file_exists(file)

            if file_exist_bool then
                ImGui.SameLine()
                ImGui.TextColored(0, 1, 0, 1, "File Exists")
            else
                ImGui.SameLine()
                ImGui.TextColored(1, 1, 0, 1, "File Not Created")
            end
        end
        -- ign_section_batch_save

        ImGui.SameLine()
        if ImGui.Button("Open Folder") then
            -- Open Windows Directory
            os.execute("start " .. mq.luaDir .. "\\TCN\\ShoppingLists")
        end

        ImGui.SameLine()
        HelpMarker("Open Folder " .. mq.luaDir .. "\\TCN\\ShoppingLists\\ ")

        -- ImGui.SameLine()
        -- if ImGui.Button("Close Window") then
        --   BATCH_FARM_LIST = {}
        --   GLOBAL_TEXT = "Idle"
        -- end
    end

    -- ImGui.End()
end

function BatchShoppingWindow()
    if BATCH_SHOPPING_DATA[1] == nil then
        ImGui.Text("No Data")
        return
    end

    -- ImGui.SetWindowSize(800, 285)
    -- ImGui.SetWindowFontScale(1)
    -- remd  ImGui.SetCursorPosX(4)

    if name_select ~= nil then
        ImGui.TextColored(.3, 1, 1, 1, "Buy From Vendor")
        ImGui.SameLine()
        ImGui.TextColored(0, 1, 0, 1, "Local Inventory")
    end

    local amount_total = 0

    local ColumnID_RequestItem = 10

    local flags = bit32.bor(ImGuiTableFlags.Resizable,
        ImGuiTableFlags.Reorderable,
        ImGuiTableFlags.Hideable,
        ImGuiTableFlags.MultiSortable,
        ImGuiTableFlags.Sortable, ImGuiTableFlags.RowBg,
        ImGuiTableFlags.BordersOuter,
        ImGuiTableFlags.BordersV,
        ImGuiTableFlags.NoBordersInBody,
        ImGuiTableFlags.ScrollY)

    if ImGui.BeginTable('##batch_recipe_shopping_table', 7, flags, 0,
            TEXT_BASE_HEIGHT * 12, 0.0) then
        ImGui.TableSetupColumn('Name', ImGuiTableColumnFlags.WidthAuto, -1.0,
            ColumnID_Name)
        ImGui.TableSetupColumn('Price', ImGuiTableColumnFlags.WidthAuto, -1.0,
            ColumnID_Price)
        ImGui.TableSetupColumn('Count', ImGuiTableColumnFlags.WidthAuto, -1.0,
            ColumnID_Quantity)
        ImGui.TableSetupColumn('ID', ImGuiTableColumnFlags.WidthFixed, -1.0,
            ColumnID_ID)
        ImGui.TableSetupColumn('Vendor', ImGuiTableColumnFlags.WidthStretch,
            -1.0, ColumnID_Vendor)
        ImGui.TableSetupColumn('Zone', ImGuiTableColumnFlags.WidthAuto, -1.0,
            ColumnID_ZoneName)

        ImGui.TableSetupColumn('Request', ImGuiTableColumnFlags.WidthFixed,
            -1.0, ColumnID_RequestItem)

        ImGui.TableSetupScrollFreeze(0, 1) -- Make row always visible

        local sort_specs = ImGui.TableGetSortSpecs()

        if sort_specs then
            if sort_specs.SpecsDirty then
                if #converted_batch_shopping_data > 1 then
                    current_sort_specs = sort_specs
                    table.sort(converted_batch_shopping_data,
                        CompareWithSortSpecs)
                    current_sort_specs = nil
                end
                sort_specs.SpecsDirty = false
            end
        end

        -- Display data
        ImGui.TableHeadersRow()

        for iter = 1, #BATCH_SHOPPING_DATA do
            amount_total = amount_total +
                tcglib.return_number(BATCH_SHOPPING_DATA[iter], 6)
        end

        local clipper = ImGuiListClipper.new()
        clipper:Begin(#converted_batch_shopping_data)
        while clipper:Step() do
            for row_n = clipper.DisplayStart, clipper.DisplayEnd - 1, 1 do
                local r_col, g_col, b_col = .3, 1, 1
                local convert_item = converted_batch_shopping_data[row_n + 1]
                ImGui.PushID(convert_item)
                if string.find(convert_item.Name, "@") then
                    convert_item.Name = convert_item.Name:gsub('@', ',')
                end
                ImGui.TableNextRow()
                ImGui.TableNextColumn()
                if mq.TLO.FindItemCount(convert_item.ID)() >=
                    convert_item.Quantity then
                    r_col = 0
                    g_col = 1
                    b_col = 0
                end
                ImGui.TextColored(r_col, g_col, b_col, 1, convert_item.Name)
                ImGui.TableNextColumn()
                ImGui.Text(convert_item.Price)
                ImGui.TableNextColumn()
                ImGui.Text(convert_item.Quantity)
                ImGui.TableNextColumn()
                ImGui.Text(string.format(convert_item.ID))
                ImGui.TableNextColumn()
                ImGui.Text(convert_item.Vendor)
                ImGui.TableNextColumn()
                if convert_item.ZoneID ~= 202 then
                    r_col = 0
                    g_col = 1
                    b_col = 1
                else
                    r_col = 1
                    g_col = 1
                    b_col = 1
                end
                ImGui.TextColored(r_col, g_col, b_col, 1, convert_item.ZoneName)

                ImGui.TableNextColumn()

                if ImGui.Button("Request") then
                    GLOBAL_TEXT =
                    "Requesting Batch Single Missing Vendored Items via DanNet"
                    request_array_list = {}
                    local have_count = mq.TLO.FindItemCount(convert_item.ID)()
                    local current_qty = convert_item.Quantity
                    if have_count > 0 then
                        current_qty = current_qty - have_count
                    end
                    -- add condition checks in here
                    local request_string = convert_item.ID .. "," .. current_qty
                    if current_qty > 0 then
                        table.insert(request_array_list, request_string)
                    end
                    if request_array_list[1] ~= nil then
                        go_ask = 1
                    else
                        GLOBAL_TEXT = "Nothing to request via DanNet"
                    end
                end

                ImGui.PopID()
            end
        end
        ImGui.EndTable()
    end

    ---fix
    if ImGui.Button("Request Batch Vendored Items") then
        GLOBAL_TEXT = "Requesting Batch Vendor Components via DanNet"
        request_array_list = {}
        for x = 1, #BATCH_SHOPPING_DATA do
            local request_item_id = tcglib.return_number(BATCH_SHOPPING_DATA[x],
                3)
            local request_item_count = tcglib.return_number(
                BATCH_SHOPPING_DATA[x], 4)
            local have_count = mq.TLO.FindItemCount(request_item_id)()

            if have_count > 0 then
                request_item_count = request_item_count - have_count
            end

            -- Add condition checks in here
            local request_string = request_item_id .. "," .. request_item_count

            if request_item_count > 0 then
                table.insert(request_array_list, request_string)
            end
        end
        --   for x = 1, #request_array_list do print(request_array_list[x]) end
        if request_array_list[1] ~= nil then
            go_ask = 1
        else
            GLOBAL_TEXT = "Nothing to request via DanNet"
        end
    end
    ImGui.SameLine()
    HelpMarker(
        "Queries other characters in zone for vendor items, and delivers from inventory or bank.")

    ImGui.SameLine()
    if ImGui.Button("Shop") then
        local l_zone_lookup = mq.TLO.Zone(BATCH_ZONE_ARRAY[BATCH_ZONE_SELECT])
            .ID()
        local n_array = {}
        if l_zone_lookup == nil then
            mass_shop_array = BATCH_SHOPPING_DATA
        else
            for c = 1, #BATCH_SHOPPING_DATA do
                local zone_id = tcglib.return_number(BATCH_SHOPPING_DATA[c], 1)
                if zone_id == l_zone_lookup then
                    table.insert(n_array, BATCH_SHOPPING_DATA[c])
                end
            end
            mass_shop_array = n_array
        end
        -- for c = 1, #mass_shop_array do print(mass_shop_array[c]) end
        go_shop = 43
    end

    local ign_section_batch_save = 0
    if ign_section_batch_save == 1 then
        ImGui.SameLine()
        -- Write artisan farm shopping list to disk
        if ImGui.Button("Save") then
            local skill_used = max_array[l_max_selection]

            local file = "Artisan_MSL_" .. skill_used .. "_" .. mq.TLO.Me() ..
                "_" .. mq.TLO.MacroQuest.Server() .. ".csv"

            local file_exist_bool = tcglib.file_exists(file)

            if file_exist_bool then
                local command =
                    'del ' .. mq.luaDir .. '\\TCN\\ShoppingLists\\' .. file
                os.execute(command)
            end

            -- print(file)

            tcglib.writeshoppinglist("Artisan_MSL_" .. skill_used .. "_" ..
                mq.TLO.Me() .. "_" ..
                mq.TLO.MacroQuest.Server(),
                "Vendor,Item,Count,Unit Price,ID,Zone,ZoneID")

            for sl = 1, #BATCH_SHOPPING_DATA do
                local item_shop_item_zone_id =
                    tcglib.return_number(BATCH_SHOPPING_DATA[sl], 1)
                local vendor_name = tcglib.return_string(
                    BATCH_SHOPPING_DATA[sl], 2)
                local item_id = tcglib.return_number(BATCH_SHOPPING_DATA[sl], 3)
                local item_count = tcglib.return_number(BATCH_SHOPPING_DATA[sl],
                    4)
                local item_name = tcglib.return_string(BATCH_SHOPPING_DATA[sl],
                    5)
                local item_price = tcglib.return_number(BATCH_SHOPPING_DATA[sl],
                    6)

                local item_zone = mq.TLO.Zone(item_shop_item_zone_id)()

                if string.find(item_zone, ",") then
                    item_zone = item_zone:gsub(',', '|')
                end

                if string.find(item_name, ",") then
                    item_name = item_name:gsub(',', '|')
                end

                local l_shop_string = vendor_name .. "," .. item_name .. "," ..
                    item_count .. "," .. item_price .. "," ..
                    item_id .. "," .. item_zone .. "," ..
                    item_shop_item_zone_id
                tcglib.writeshoppinglist(
                    "Artisan_MSL_" .. skill_used .. "_" .. mq.TLO.Me() .. "_" ..
                    mq.TLO.MacroQuest.Server(), l_shop_string)
                -- print(l_shop_string)
            end
        end

        -- Load shopping list to buy method?

        ImGui.SameLine()
        HelpMarker("Saves Mass Shopping Data to " .. mq.luaDir ..
            "\\TCN\\ShoppingLists\\ " .. " Directory")

        local skill_used = max_array[l_max_selection]

        local file =
            "Artisan_MSL_" .. skill_used .. "_" .. mq.TLO.Me() .. "_" ..
            mq.TLO.MacroQuest.Server() .. ".csv"

        local file_exist_bool = tcglib.file_exists(file)

        if file_exist_bool then
            ImGui.SameLine()
            ImGui.TextColored(0, 1, 0, 1, "File Exists")
        else
            ImGui.SameLine()
            ImGui.TextColored(1, 1, 0, 1, "File Not Created")
        end
    end

    --  ign_section_batch_save

    ImGui.SameLine()
    if ImGui.Button("Open Folder") then
        -- Open Windows Directory
        os.execute("start " .. mq.luaDir .. "\\TCN\\ShoppingLists")
    end

    ImGui.SameLine()
    HelpMarker("Open Folder " .. mq.luaDir .. "\\TCN\\ShoppingLists\\ ")

    -- ImGui.SameLine()
    -- if ImGui.Button("Close Window") then
    --  BATCH_SHOPPING_DATA = {}
    -- GLOBAL_TEXT = "Idle"
    -- end

    ImGui.Text("Est. Total Platinum: " .. amount_total * .001)
    ImGui.SameLine()
    ImGui.Text("Est. Tradeskill Slots Needed: (" .. #BATCH_SHOPPING_DATA .. ")")
    amount_total = 0

    ImGui.Text("Select Vendor Zone To Shop:")
    ImGui.SameLine()
    ImGui.SetNextItemWidth(180)

    BATCH_ZONE_SELECT, _ = ImGui.Combo("##batch_zone_list", BATCH_ZONE_SELECT,
        BATCH_ZONE_ARRAY, #BATCH_ZONE_ARRAY,
        #BATCH_ZONE_ARRAY)

    ImGui.SameLine()
    HelpMarker("Will shop specific zone based on drop-down selection.")

    -- ImGui.End()
end

function BatchLoadWindow()
    -- ImGui.SetWindowSize(800, 480)
    -- ImGui.SetWindowFontScale(1)
    -- remd  ImGui.SetCursorPosX(4)

    -- ImGui.PushItemWidth(800)

    local function BatchSaveWindow()
        if batch_array[1] == nil then BATCH_OPS_WINDOW_GUI = false end

        -- Save Batch
        ImGui.Separator()
        ImGui.Text("Please enter filename: ")
        ImGui.SameLine()
        BATCH_TEXT_INPUT, _ = ImGui.InputText("##batchsave##edit",
            BATCH_TEXT_INPUT, 128)
        ImGui.SameLine()
        if ImGui.Button("Save") and BATCH_TEXT_INPUT ~= "" and batch_array[1] ~=
            nil then
            -- Set batch filename
            local batch_filename = "batch_" .. mq.TLO.Me() .. "_" ..
                mq.TLO.MacroQuest.Server() .. "_" ..
                BATCH_TEXT_INPUT .. ".csv"

            local batch_exist_bool = tcglib.batch_file_exists(batch_filename)
            if batch_exist_bool then
                local command = 'del ' .. mq.luaDir .. '\\TCN\\Batch\\' ..
                    batch_filename
                os.execute(command)
            end

            for c = 1, #batch_array do
                local batch_string = batch_array[c].BatchItemID .. "," ..
                    batch_array[c].BatchItemName .. "," ..
                    batch_array[c].BatchItemMake .. "," ..
                    batch_array[c].BatchItemRecipe

                tcglib.writebatchfile(batch_filename, batch_string)
            end
            GLOBAL_TEXT = "Batch file saved"
            BATCH_TEXT_INPUT = ""
            BATCH_OPS_WINDOW_GUI = false
        end
    end

    if #B_dir_results > 0 then
        BATCH_FILE_SELECT, _ = ImGui.ListBox("", BATCH_FILE_SELECT,
            B_dir_results, #B_dir_results,
            #B_dir_results)

        if ImGui.Button("Load File") and #B_dir_results > 0 then
            local read_batch_fn = B_dir_results[BATCH_FILE_SELECT]
            batch_window_openGUI = false
            batch_array = {}
            batch_array = tcglib.read_batch_file(read_batch_fn)
            -- for c = 1, #batch_array do print(batch_array[c]) end
            if batch_array[1] ~= nil then
                GLOBAL_TEXT = "Batch file loaded"
                B_dir_results = feeder.b_scandir()
                BATCH_OPS_WINDOW_GUI = false
            end
        end

        ImGui.SameLine()
        if ImGui.Button("Delete File") and #B_dir_results > 0 then
            local delete_batch_fn = B_dir_results[BATCH_FILE_SELECT]

            local batch_exist_bool = tcglib.batch_file_exists(delete_batch_fn)
            if batch_exist_bool then
                local command = 'del ' .. mq.luaDir .. '\\TCN\\Batch\\' ..
                    delete_batch_fn
                os.execute(command)
                GLOBAL_TEXT = "Batch File Deleted"
                B_dir_results = feeder.b_scandir()
                if #B_dir_results < 1 then
                    BATCH_OPS_WINDOW_GUI = false
                end
            else
                GLOBAL_TEXT = "No Batch File to delete"
            end
        end
    end

    if batch_array[1] ~= nil then BatchSaveWindow() end

    ImGui.Separator()

    ImGui.PushStyleColor(ImGuiCol.Button, 0, .6, .4, 1)

    if ImGui.Button("Exit Batch File Operations") then
        BATCH_OPS_WINDOW_GUI = false
    end

    ImGui.PopStyleColor()

    if batch_array[1] == nil and #B_dir_results < 1 then
        BATCH_OPS_WINDOW_GUI = false
    end
end

function BatchBankWindow()
    if BATCH_BANK_ARRAY[1] == nil then
        ImGui.Text("No Data")
        return
    end

    -- ImGui.SetWindowSize(800, 240)
    -- ImGui.SetWindowFontScale(1)
    -- remd  ImGui.SetCursorPosX(4)

    local flags = bit32.bor(ImGuiTableFlags.Resizable,
        ImGuiTableFlags.Reorderable,
        ImGuiTableFlags.Hideable,
        ImGuiTableFlags.MultiSortable,
        ImGuiTableFlags.Sortable, ImGuiTableFlags.RowBg,
        ImGuiTableFlags.BordersOuter,
        ImGuiTableFlags.BordersV,
        ImGuiTableFlags.NoBordersInBody,
        ImGuiTableFlags.ScrollY)

    if ImGui.BeginTable('##batch_bank_shopping_table', 3, flags, 0,
            TEXT_BASE_HEIGHT * 12, 0.0) then
        ImGui.TableSetupColumn('Name', ImGuiTableColumnFlags.WidthAuto, -1.0,
            ColumnID_Name)
        ImGui.TableSetupColumn('ID', ImGuiTableColumnFlags.WidthAuto, -1.0,
            ColumnID_ID)
        ImGui.TableSetupColumn('Count', ImGuiTableColumnFlags.WidthAuto, -1.0,
            ColumnID_Quantity)

        ImGui.TableSetupScrollFreeze(0, 1) -- Make row always visible

        local sort_specs = ImGui.TableGetSortSpecs()

        if sort_specs then
            if sort_specs.SpecsDirty then
                if #BATCH_BANK_ARRAY > 1 then
                    current_sort_specs = sort_specs
                    table.sort(BATCH_BANK_ARRAY, CompareWithSortSpecs)
                    current_sort_specs = nil
                end
                sort_specs.SpecsDirty = false
            end
        end

        -- Display data
        ImGui.TableHeadersRow()

        local clipper = ImGuiListClipper.new()
        clipper:Begin(#BATCH_BANK_ARRAY)
        while clipper:Step() do
            for row_n = clipper.DisplayStart, clipper.DisplayEnd - 1, 1 do
                local r_col, g_col, b_col = .3, 1, 1
                local convert_item = BATCH_BANK_ARRAY[row_n + 1]
                ImGui.PushID(convert_item)
                if string.find(convert_item.Name, "@") then
                    convert_item.Name = convert_item.Name:gsub('@', ',')
                end
                ImGui.TableNextRow()
                ImGui.TableNextColumn()
                ImGui.TextColored(r_col, g_col, b_col, 1, convert_item.Name)
                ImGui.TableNextColumn()
                ImGui.Text(string.format(convert_item.ID))
                ImGui.TableNextColumn()
                ImGui.Text(convert_item.Quantity)
                ImGui.PopID()
            end
        end

        ImGui.EndTable()
    end

    ImGui.Text("Options")
    ImGui.SameLine()
    -- fix
    if ImGui.Button("Bank Shop") then go_shop = 72 end

    local ign_section_batch_save = 0
    if ign_section_batch_save == 1 then
        ImGui.SameLine()
        -- Write artisan bank shopping list to disk
        if ImGui.Button("Save") then
            local skill_used = max_array[l_max_selection]

            local file = "Artisan_BSL_" .. skill_used .. "_" .. mq.TLO.Me() ..
                "_" .. mq.TLO.MacroQuest.Server() .. ".csv"

            local file_exist_bool = tcglib.file_exists(file)

            if file_exist_bool then
                local command =
                    'del ' .. mq.luaDir .. '\\TCN\\ShoppingLists\\' .. file
                os.execute(command)
            end

            tcglib.writeshoppinglist("Artisan_BSL_" .. skill_used .. "_" ..
                mq.TLO.Me() .. "_" ..
                mq.TLO.MacroQuest.Server(),
                "Item,ID,Count")

            for sl = 1, #mass_bank_array do
                local item_id = mass_bank_array[sl].ID
                local item_count = mass_bank_array[sl].Quantity
                local item_name = mass_bank_array[sl].Name

                -- print(item_id, " ",item_count, " ",item_name)

                if string.find(item_name, ",") then
                    item_name = item_name:gsub(',', '|')
                end

                local l_shop_string = item_name .. "," .. item_id .. "," ..
                    item_count
                tcglib.writeshoppinglist(
                    "Artisan_BSL_" .. skill_used .. "_" .. mq.TLO.Me() .. "_" ..
                    mq.TLO.MacroQuest.Server(), l_shop_string)
            end
        end

        ImGui.SameLine()
        HelpMarker("Saves Mass Bank Shopping Data to " .. mq.luaDir ..
            "\\TCN\\ShoppingLists\\ " .. " Directory")

        local skill_used = max_array[l_max_selection]

        local file =
            "Artisan_BSL_" .. skill_used .. "_" .. mq.TLO.Me() .. "_" ..
            mq.TLO.MacroQuest.Server() .. ".csv"

        local file_exist_bool = tcglib.file_exists(file)

        if file_exist_bool then
            ImGui.SameLine()
            ImGui.TextColored(0, 1, 0, 1, "File Exists")
        else
            ImGui.SameLine()
            ImGui.TextColored(1, 1, 0, 1, "File Not Created")
        end
    end
    -- ign_section_batch_save

    ImGui.SameLine()
    if ImGui.Button("Open Folder") then
        -- Open Windows Directory
        os.execute("start " .. mq.luaDir .. "\\TCN\\ShoppingLists")
    end

    ImGui.SameLine()
    HelpMarker("Open Folder " .. mq.luaDir .. "\\TCN\\ShoppingLists\\ ")

    -- ImGui.SameLine()
    -- if ImGui.Button("Close Window") then
    --   BATCH_BANK_ARRAY = {}
    --    GLOBAL_TEXT = "Idle"
    -- end

    -- ImGui.End()
end

function BatchDepotWindow()
    if not mq.TLO.TradeskillDepot.Enabled() then
        ImGui.Text("Expansion: Night of Shadows not enabled")
        return
    end

    if ret_batch_depot_data[1] == nil then
        ImGui.Text("No Data")
        return
    end

    local flags = bit32.bor(ImGuiTableFlags.Resizable,
        ImGuiTableFlags.Reorderable,
        ImGuiTableFlags.Hideable,
        ImGuiTableFlags.MultiSortable,
        ImGuiTableFlags.Sortable, ImGuiTableFlags.RowBg,
        ImGuiTableFlags.BordersOuter,
        ImGuiTableFlags.BordersV,
        ImGuiTableFlags.NoBordersInBody,
        ImGuiTableFlags.ScrollY)

    if ImGui.BeginTable('##batch_depot_shopping_table', 3, flags, 0,
            TEXT_BASE_HEIGHT * 12, 0.0) then
        ImGui.TableSetupColumn('Name', ImGuiTableColumnFlags.WidthAuto, -1.0,
            ColumnID_Name)
        ImGui.TableSetupColumn('ID', ImGuiTableColumnFlags.WidthAuto, -1.0,
            ColumnID_ID)
        ImGui.TableSetupColumn('Count', ImGuiTableColumnFlags.WidthAuto, -1.0,
            ColumnID_Quantity)

        ImGui.TableSetupScrollFreeze(0, 1) -- Make row always visible

        local sort_specs = ImGui.TableGetSortSpecs()

        if sort_specs then
            if sort_specs.SpecsDirty then
                if #ret_batch_depot_data > 1 then
                    current_sort_specs = sort_specs
                    table.sort(ret_batch_depot_data, CompareWithSortSpecs)
                    current_sort_specs = nil
                end
                sort_specs.SpecsDirty = false
            end
        end

        -- Display data
        ImGui.TableHeadersRow()

        local clipper = ImGuiListClipper.new()
        clipper:Begin(#ret_batch_depot_data)
        while clipper:Step() do
            for row_n = clipper.DisplayStart, clipper.DisplayEnd - 1, 1 do
                local r_col, g_col, b_col = .3, 1, 1
                local convert_item = ret_batch_depot_data[row_n + 1]
                ImGui.PushID(convert_item)
                if string.find(convert_item.Name, "@") then
                    convert_item.Name = convert_item.Name:gsub('@', ',')
                end
                ImGui.TableNextRow()
                ImGui.TableNextColumn()
                ImGui.TextColored(r_col, g_col, b_col, 1, convert_item.Name)
                ImGui.TableNextColumn()
                ImGui.Text(string.format(convert_item.ID))
                ImGui.TableNextColumn()
                ImGui.Text(convert_item.Quantity)
                ImGui.PopID()
            end
        end

        ImGui.EndTable()
    end

    if ImGui.Button("Depot Shop") then go_shop = 1150 end

    ImGui.SameLine()

    HelpMarker("Goes to your tradeskill depot and grabs items.")

    -- ImGui.SameLine()
    -- if ImGui.Button("Close Window") then
    --   BATCH_BANK_ARRAY = {}
    --    GLOBAL_TEXT = "Idle"
    -- end

    -- ImGui.End()
end

function UnknownMax()
    if MAX_UNKNOWN_ARRAY == nil then return end

    if MAX_UNKNOWN_ARRAY[1] == nil then
        ImGui.Text("No Data")
        return
    end

    ImGui.Text("Unknown Recipes: " .. #MAX_UNKNOWN_ARRAY)

    local flags = bit32.bor(ImGuiTableFlags.Resizable,
        ImGuiTableFlags.Reorderable,
        ImGuiTableFlags.Hideable,
        ImGuiTableFlags.MultiSortable,
        ImGuiTableFlags.Sortable, ImGuiTableFlags.RowBg,
        ImGuiTableFlags.BordersOuter,
        ImGuiTableFlags.BordersV,
        ImGuiTableFlags.NoBordersInBody,
        ImGuiTableFlags.ScrollY)

    if ImGui.BeginTable('##max_unknown_table', 2, flags, 0,
            TEXT_BASE_HEIGHT * 10, 0.0) then
        ImGui.TableSetupColumn('Recipe ID', ImGuiTableColumnFlags.WidthAuto,
            -1.0, ColumnID_ID)
        ImGui.TableSetupColumn('Name', ImGuiTableColumnFlags.WidthAuto, -1.0,
            ColumnID_Name)

        ImGui.TableSetupScrollFreeze(0, 1) -- Make row always visible

        local sort_specs = ImGui.TableGetSortSpecs()

        if sort_specs then
            if sort_specs.SpecsDirty then
                if #MAX_UNKNOWN_ARRAY > 1 then
                    current_sort_specs = sort_specs
                    table.sort(MAX_UNKNOWN_ARRAY, CompareWithSortSpecs)
                    current_sort_specs = nil
                end
                sort_specs.SpecsDirty = false
            end
        end

        -- Display data
        ImGui.TableHeadersRow()

        local clipper = ImGuiListClipper.new()

        clipper:Begin(#MAX_UNKNOWN_ARRAY)
        while clipper:Step() do
            for row_n = clipper.DisplayStart, clipper.DisplayEnd - 1, 1 do
                local r_col, g_col, b_col = .3, 1, 1
                local convert_item = MAX_UNKNOWN_ARRAY[row_n + 1]
                ImGui.PushID(convert_item)
                if string.find(convert_item.Name, "@") then
                    convert_item.Name = convert_item.Name:gsub('@', ',')
                end
                ImGui.TableNextRow()
                ImGui.TableNextColumn()
                ImGui.TextColored(r_col, g_col, b_col, 1, convert_item.ID)
                ImGui.TableNextColumn()
                ImGui.Text(string.format(convert_item.Name))
                ImGui.PopID()
            end
        end
        ImGui.EndTable()
    end
end

function KnownMax()
    if MAX_KNOWN_ARRAY == nil then return end

    if MAX_KNOWN_ARRAY[1] == nil then
        ImGui.Text("No Data")
        return
    end

    -- for c = 1, #MAX_KNOWN_ARRAY do
    --   if MAX_KNOWN_ARRAY[c].Name == nil then
    --      print(MAX_KNOWN_ARRAY[c].Name, " ", MAX_KNOWN_ARRAY[c].ID)
    --  end
    -- end

    -- os.exit()

    -- this window will only open on checkbox?

    -- ImGui.SetWindowSize(640, 480)
    -- ImGui.SetWindowFontScale(1)
    -- remd  ImGui.SetCursorPosX(4)

    ImGui.Text("Known Recipes: " .. #MAX_KNOWN_ARRAY)

    local flags = bit32.bor(ImGuiTableFlags.Resizable,
        ImGuiTableFlags.Reorderable,
        ImGuiTableFlags.Hideable,
        ImGuiTableFlags.MultiSortable,
        ImGuiTableFlags.Sortable, ImGuiTableFlags.RowBg,
        ImGuiTableFlags.BordersOuter,
        ImGuiTableFlags.BordersV,
        ImGuiTableFlags.NoBordersInBody,
        ImGuiTableFlags.ScrollY)

    if ImGui.BeginTable('##max_known_table', 2, flags, 0, TEXT_BASE_HEIGHT * 10,
            0.0) then
        -- local ColumnID_RecipeUID = 0
        -- local ColumnID_RecipeUName = 1

        ImGui.TableSetupColumn('Recipe ID', ImGuiTableColumnFlags.WidthAuto,
            -1.0, ColumnID_ID)
        ImGui.TableSetupColumn('Name', ImGuiTableColumnFlags.WidthAuto, -1.0,
            ColumnID_Name)

        ImGui.TableSetupScrollFreeze(0, 1) -- Make row always visible

        local sort_specs = ImGui.TableGetSortSpecs()

        if sort_specs then
            if sort_specs.SpecsDirty then
                if #MAX_KNOWN_ARRAY > 1 then
                    current_sort_specs = sort_specs
                    table.sort(MAX_KNOWN_ARRAY, CompareWithSortSpecs)
                    current_sort_specs = nil
                end
                sort_specs.SpecsDirty = false
            end
        end

        -- Display data
        ImGui.TableHeadersRow()

        local clipper = ImGuiListClipper.new()

        clipper:Begin(#MAX_KNOWN_ARRAY)
        while clipper:Step() do
            for row_n = clipper.DisplayStart, clipper.DisplayEnd - 1, 1 do
                local r_col, g_col, b_col = .3, 1, 1
                local convert_item = MAX_KNOWN_ARRAY[row_n + 1]
                ImGui.PushID(convert_item)
                if string.find(convert_item.Name, "@") then
                    convert_item.Name = convert_item.Name:gsub('@', ',')
                end
                ImGui.TableNextRow()
                ImGui.TableNextColumn()
                ImGui.TextColored(r_col, g_col, b_col, 1, convert_item.ID)
                ImGui.TableNextColumn()
                ImGui.Text(convert_item.Name)
                ImGui.PopID()
            end
        end
        ImGui.EndTable()
    end

    -- ImGui.TreePop()

    -- ImGui.Text("")
    -- ImGui.SameLine()
    -- ImGui.Text("Known Recipes: " .. #MAX_KNOWN_ARRAY)
    -- ImGui.SameLine()
    -- if ImGui.Button("Close Window") then
    --    MAX_KNOWN_ARRAY = {}
    --   GLOBAL_TEXT = "Idle"
    -- end

    -- ImGui.End()
end

local function ShowArtisanRecipeResults()
    if ImGui.BeginTabBar('KResults', ImGuiTabBarFlags.Reorderable) then
        ImGui.PushID('Known##kresults')
        if ImGui.BeginTabItem('Known##kresults') then
            KnownMax()
            ImGui.EndTabItem()
        end
        ImGui.PopID()

        ImGui.PushID('Unknown##kresults')
        if ImGui.BeginTabItem('Unknown##kresults') then
            UnknownMax()
            ImGui.EndTabItem()
        end
        ImGui.PopID()
        ImGui.EndTabBar()
    end
end

function MainArtisanInfoWindow()
    ImGui.Begin("TCSNeXt Artisan Recipe Information Window", OPENInfoWindow)

    ImGui.SetWindowSize(480, 320)

    ImGui.SetWindowFontScale(1)

    -- ImGui.PushStyleVar(ImGuiStyleVar.IndentSpacing, 0.0)

    ---- remd  ImGui.SetCursorPosX(4)

    ShowArtisanRecipeResults()

    ImGui.End()
end

function MaxFarmTableWindow()
    if art_max_farm_list[1] == nil then
        ImGui.Text("No Data")
        return
    end

    -- convincing..

    -- if not open_max_farm_list_GUI then return end

    -- ImGui.SetWindowSize(800, 480)
    -- ImGui.SetWindowFontScale(1)
    -- remd  ImGui.SetCursorPosX(4)

    -- ImGui.Text("Items Returned: (" .. #art_max_farm_list .. ")")
    local flags = bit32.bor(ImGuiTableFlags.Resizable,
        ImGuiTableFlags.Reorderable,
        ImGuiTableFlags.Hideable, ImGuiTableFlags.Sortable,
        ImGuiTableFlags.MultiSortable,
        ImGuiTableFlags.RowBg, ImGuiTableFlags.BordersOuter,
        ImGuiTableFlags.BordersV,
        ImGuiTableFlags.NoBordersInBody,
        ImGuiTableFlags.ScrollY)

    if ImGui.BeginTable('##max_recipe_farm_table', 9, flags, 0,
            TEXT_BASE_HEIGHT * 16, 0.0) then
        local ColumnID_RequestItem = 10

        ImGui.TableSetupColumn('Missing Item',
            ImGuiTableColumnFlags.WidthStretch, -1.0,
            ColumnID_Name)

        ImGui.TableSetupColumn('Need', ImGuiTableColumnFlags.WidthFixed, -1.0,
            ColumnID_Quantity)

        ImGui.TableSetupColumn('Inv', ImGuiTableColumnFlags.WidthAuto, -1.0,
            ColumnID_Inventory)

        local ColumnID_Bnk = 91929

        ImGui.TableSetupColumn('Bnk', ImGuiTableColumnFlags.WidthAuto, -1.0,
            ColumnID_Bnk)

        local ColumnID_Dpt = 91930

        ImGui.TableSetupColumn('Depot', ImGuiTableColumnFlags.WidthAuto, -1.0,
            ColumnID_Dpt)

        ImGui.TableSetupColumn('Action', ImGuiTableColumnFlags.WidthFixed, -1.0,
            ColumnID_Action)

        ImGui.TableSetupColumn('Zone', ImGuiTableColumnFlags.WidthStretch, -1.0,
            ColumnID_ZoneName)

        ImGui.TableSetupColumn('Item ID', ImGuiTableColumnFlags.WidthFixed,
            -1.0, ColumnID_ID)

        ImGui.TableSetupColumn('Request', ImGuiTableColumnFlags.WidthFixed,
            -1.0, ColumnID_RequestItem)
        ImGui.TableSetupScrollFreeze(0, 1) -- Make row always visible

        local sort_specs = ImGui.TableGetSortSpecs()

        if sort_specs then
            if sort_specs.SpecsDirty then
                if #converted_mass_farm_data > 1 then
                    current_sort_specs = sort_specs
                    table.sort(converted_mass_farm_data, CompareWithSortSpecs)
                    current_sort_specs = nil
                end
                sort_specs.SpecsDirty = false
            end
        end

        -- Display data
        ImGui.TableHeadersRow()

        local clipper = ImGuiListClipper.new()
        clipper:Begin(#converted_mass_farm_data)
        while clipper:Step() do
            for row_n = clipper.DisplayStart, clipper.DisplayEnd - 1, 1 do
                local convert_item = converted_mass_farm_data[row_n + 1]
                ImGui.PushID(convert_item)
                ImGui.TableNextRow()
                ImGui.TableNextColumn()
                if mq.TLO.FindItemCount(convert_item.ID)() >=
                    convert_item.Quantity then
                    ImGui.TextColored(0, 1, 0, 1, convert_item.Name)
                else
                    ImGui.TextColored(1, 1, 1, 1, convert_item.Name)
                end
                ImGui.TableNextColumn()

                -- Should be converted prior for shadowscream and anvils and stuff
                --  if convert_item.ID == 29816 or convert_item.ID == 29820 or
                --    convert_item.ID == 29824 then
                --   convert_item.Quantity = 1
                --                end

                ImGui.Text(convert_item.Quantity)
                ImGui.TableNextColumn()
                ImGui.Text(mq.TLO.FindItemCount(convert_item.ID)())

                ImGui.TableNextColumn()
                ImGui.Text(mq.TLO.FindItemBankCount(convert_item.ID)())

                ImGui.TableNextColumn()
                if mq.TLO.TradeskillDepot.Enabled() then
                    if mq.TLO.TradeskillDepot.FindItemCount(convert_item.ID)() >
                        0 then
                        ImGui.Text(mq.TLO.TradeskillDepot.FindItemCount(
                            convert_item.ID)())
                    else
                        ImGui.Text("0")
                    end
                else
                    ImGui.Text("-")
                end

                ImGui.TableNextColumn()
                local r_col, g_col, b_col = 0, .5, 0
                if convert_item.Action == "Faction" then
                    r_col, g_col, b_col = .3, 1, .7
                end
                if convert_item.Action == "Farm" then
                    r_col, g_col, b_col = 1, .5, 0
                end
                if convert_item.Action == "Fish" then
                    r_col, g_col, b_col = 0, .5, 1
                end
                if convert_item.Action == "Forage" then
                    r_col, g_col, b_col = .9, .1, .9
                end
                if convert_item.Action == "Vendor" then
                    r_col, g_col, b_col = .7, .9, .2
                end
                if convert_item.Action == "Enchanter" then
                    r_col, g_col, b_col = .9, .7, .1
                end
                -- Add quested
                -- add count > mqtlo finditemcount
                ImGui.TextColored(r_col, g_col, b_col, 1, convert_item.Action)
                -- should be converted prior to..
                ImGui.TableNextColumn()

                -- if string.find(convert_item.ZoneName, "@") then
                --  convert_item.ZoneName = convert_item.ZoneName:gsub('@', ',')
                -- end

                ImGui.Text(convert_item.ZoneName)
                ImGui.TableNextColumn()
                ImGui.Text(string.format(convert_item.ID))

                ImGui.TableNextColumn()
                if ImGui.Button("Request") then
                    GLOBAL_TEXT =
                    "Requesting Artisan Prize Single Missing Component via DanNet"
                    request_array_list = {}
                    local have_count = mq.TLO.FindItemCount(convert_item.ID)()
                    -- testing
                    -- have_count = 21
                    -- is this right.. for testing?
                    local current_qty = convert_item.Quantity
                    if have_count > 0 then
                        current_qty = current_qty - have_count
                    end
                    -- add condition checks in here
                    local request_string = convert_item.ID .. "," .. current_qty
                    if current_qty > 0 then
                        table.insert(request_array_list, request_string)
                    end
                    if request_array_list[1] ~= nil then
                        go_ask = 1
                    else
                        GLOBAL_TEXT = "Nothing to request via DanNet"
                    end
                end

                ImGui.PopID()
            end
        end

        ImGui.EndTable()

        if ImGui.Button("Request Missing Components") then
            GLOBAL_TEXT =
            "Requesting Artisan Prize Missing Components via DanNet"
            -- load dannet
            request_array_list = {}
            for x = 1, #art_max_farm_list do
                local request_item_id = tcglib.return_number(
                    art_max_farm_list[x], 2)
                local request_item_count =
                    tcglib.return_number(art_max_farm_list[x], 3)
                local have_count = mq.TLO.FindItemCount(request_item_id)()
                if have_count > 0 then
                    request_item_count = request_item_count - have_count
                end
                -- add condition checks in here
                local request_string = request_item_id .. "," ..
                    request_item_count

                if request_item_count > 0 then
                    table.insert(request_array_list, request_string)
                end
            end
            --   for x = 1, #request_array_list do print(request_array_list[x]) end
            if request_array_list[1] ~= nil then
                go_ask = 1
            else
                GLOBAL_TEXT = "Nothing to request via DanNet"
            end
        end

        ImGui.SameLine()

        HelpMarker(
            "Queries other characters in zone for missing items, and delivers from inventory or bank.")

        ImGui.SameLine()

        -- Write artisan farm shopping list to disk
        if ImGui.Button("Save Data") then
            --  show date for file when we try to read it?

            local skill_used = max_array[l_max_selection]

            local file = "Artisan_FL_" .. skill_used .. "_" .. mq.TLO.Me() ..
                "_" .. mq.TLO.MacroQuest.Server() .. ".csv"

            local file_exist_bool = tcglib.file_exists(file)

            if file_exist_bool then
                local command =
                    'del ' .. mq.luaDir .. '\\TCN\\ShoppingLists\\' .. file
                os.execute(command)
            end

            tcglib.writeshoppinglist("Artisan_FL_" .. skill_used .. "_" ..
                mq.TLO.Me() .. "_" ..
                mq.TLO.MacroQuest.Server(),
                "Item,Count,ID,Action,Zone")

            for sl = 1, #art_max_farm_list do
                local item_name = converted_mass_farm_data[sl].Name
                local item_id = converted_mass_farm_data[sl].ID
                local item_count = converted_mass_farm_data[sl].Quantity
                local item_action = converted_mass_farm_data[sl].Action
                local item_zone = converted_mass_farm_data[sl].ZoneName

                if string.find(item_zone, ",") then
                    item_zone = item_zone:gsub(',', '|')
                end

                local l_farm_string = item_name .. "," .. item_count .. "," ..
                    item_id .. "," .. item_action .. "," ..
                    item_zone
                tcglib.writeshoppinglist(
                    "Artisan_FL_" .. skill_used .. "_" .. mq.TLO.Me() .. "_" ..
                    mq.TLO.MacroQuest.Server(), l_farm_string)
            end
        end

        ImGui.SameLine()
        HelpMarker("Saves data to " .. mq.luaDir .. "\\TCN\\ShoppingLists\\ " ..
            " Directory")

        local skill_used = max_array[l_max_selection]

        local file = "Artisan_FL_" .. skill_used .. "_" .. mq.TLO.Me() .. "_" ..
            mq.TLO.MacroQuest.Server() .. ".csv"

        local file_exist_bool = tcglib.file_exists(file)

        if file_exist_bool then
            ImGui.SameLine()
            ImGui.TextColored(0, 1, 0, 1, "File Exists")
        else
            ImGui.SameLine()
            ImGui.TextColored(1, 1, 0, 1, "File Not Created")
        end

        ImGui.SameLine()
        if ImGui.Button("Open Folder") then
            -- Open Windows Directory
            os.execute("start " .. mq.luaDir .. "\\TCN\\ShoppingLists")
        end

        ImGui.SameLine()
        HelpMarker("Open Folder " .. mq.luaDir .. "\\TCN\\ShoppingLists\\ ")
    end

    -- ImGui.End()
end

local function ItemLookupResults()
    -- if not ITEM_LOOKUP_RESULTS_GUI then return end

    --  ImGui.SetWindowSize(800, 400)
    -- ImGui.SetWindowFontScale(1)
    -- remd  ImGui.SetCursorPosX(4)

    local flags = bit32.bor(ImGuiTableFlags.Resizable,
        ImGuiTableFlags.Reorderable,
        ImGuiTableFlags.Hideable,
        ImGuiTableFlags.MultiSortable,
        ImGuiTableFlags.Sortable, ImGuiTableFlags.RowBg,
        ImGuiTableFlags.BordersOuter,
        ImGuiTableFlags.BordersV,
        ImGuiTableFlags.NoBordersInBody,
        ImGuiTableFlags.ScrollY)

    if ImGui.BeginTable('##lookup_recipe_comp_table', 4, flags, 0,
            TEXT_BASE_HEIGHT * 6, 0.0) then
        -- local ColumnID_RecipeID = 0
        -- local ColumnID_RecipeName = 1
        -- local ColumnID_ItemID = 2
        local ColumnID_ItemName = 20

        ImGui.TableSetupColumn('Recipe Name', ImGuiTableColumnFlags.WidthAuto,
            -1.0, ColumnID_Name)

        ImGui.TableSetupColumn('Recipe ID', ImGuiTableColumnFlags.WidthAuto,
            -1.0, ColumnID_RID)

        ImGui.TableSetupColumn('Item Name', ImGuiTableColumnFlags.WidthAuto,
            -1.0, ColumnID_ItemName)

        ImGui.TableSetupColumn('Item ID', ImGuiTableColumnFlags.WidthStretch,
            -1.0, ColumnID_ID)

        ImGui.TableSetupScrollFreeze(0, 1) -- Make row always visible

        local sort_specs = ImGui.TableGetSortSpecs()

        if sort_specs then
            if sort_specs.SpecsDirty then
                if #ITEM_RECIPE_RESULTS_LOOKUP > 1 then
                    current_sort_specs = sort_specs
                    table.sort(ITEM_RECIPE_RESULTS_LOOKUP, CompareWithSortSpecs)
                    current_sort_specs = nil
                end
                sort_specs.SpecsDirty = false
            end
        end

        -- Display data
        ImGui.TableHeadersRow()

        local clipper = ImGuiListClipper.new()

        clipper:Begin(#ITEM_RECIPE_RESULTS_LOOKUP)

        while clipper:Step() do
            for row_n = clipper.DisplayStart, clipper.DisplayEnd - 1, 1 do
                local r_col, g_col, b_col = 0, 1, 0

                local l_item_lookup = ITEM_RECIPE_RESULTS_LOOKUP[row_n + 1]

                ImGui.PushID(l_item_lookup)

                -- Needed? lookup the pottery thing
                --  if string.find(l_item_lookup.Name, "@") then
                --   l_item_lookup.Name = l_item_lookup.Name:gsub('@', ',')
                --  end

                ImGui.TableNextRow()
                ImGui.TableNextColumn()
                ImGui.TextColored(r_col, g_col, b_col, 1, l_item_lookup.Name)
                ImGui.TableNextColumn()
                ImGui.Text(l_item_lookup.RID)
                ImGui.TableNextColumn()
                ImGui.Text(l_item_lookup.ItemName)
                ImGui.TableNextColumn()
                ImGui.TextColored(r_col, g_col, b_col, 1, l_item_lookup.ID)
                ImGui.PopID()
            end
        end

        ImGui.EndTable()
    end

    -- ImGui.EndChild()
    -- ImGui.End()
end

function ItemLookupWindow()
    -- if ITEM_RECIPE_RESULTS[1] == nil then return end

    -- ImGui.SameLine()

    ImGui.Text("Items Returned: (" .. #ITEM_RECIPE_RESULTS .. ")")

    local flags = bit32.bor(ImGuiTableFlags.Resizable,
        ImGuiTableFlags.Reorderable,
        ImGuiTableFlags.Hideable,
        ImGuiTableFlags.MultiSortable,
        ImGuiTableFlags.Sortable, ImGuiTableFlags.RowBg,
        ImGuiTableFlags.BordersOuter,
        ImGuiTableFlags.BordersV,
        ImGuiTableFlags.NoBordersInBody,
        ImGuiTableFlags.ScrollY)

    if ImGui.BeginTable('##lookup_table', 3, flags, 0, TEXT_BASE_HEIGHT * 15,
            0.0) then
        ImGui.TableSetupColumn('Select', ImGuiTableColumnFlags.WidthFixed, -1.0,
            ColumnID_Button)

        ImGui.TableSetupColumn('Name', ImGuiTableColumnFlags.WidthStretch, -1.0,
            ColumnID_Name)

        ImGui.TableSetupColumn('ID', ImGuiTableColumnFlags.WidthAuto, -1.0,
            ColumnID_ID)

        ImGui.TableSetupScrollFreeze(0, 1) -- Make row always visible

        local sort_specs = ImGui.TableGetSortSpecs()

        if sort_specs then
            if sort_specs.SpecsDirty then
                if #ITEM_RECIPE_RESULTS > 1 then
                    current_sort_specs = sort_specs
                    table.sort(ITEM_RECIPE_RESULTS, CompareWithSortSpecs)
                    current_sort_specs = nil
                end
                sort_specs.SpecsDirty = false
            end
        end

        -- Display data
        ImGui.TableHeadersRow()

        local clipper = ImGuiListClipper.new()

        clipper:Begin(#ITEM_RECIPE_RESULTS)

        while clipper:Step() do
            for row_n = clipper.DisplayStart, clipper.DisplayEnd - 1, 1 do
                -- remd  ImGui.SetCursorPosX(4)
                local lookup_items = ITEM_RECIPE_RESULTS[row_n + 1]
                ImGui.PushID(lookup_items)

                ImGui.TableNextRow()
                ImGui.TableNextColumn()

                small_button_click_value, _ = ImGui.SmallButton(
                    'Select###Select_ID2')

                if small_button_click_value then
                    GLOBAL_item_id = lookup_items.ID
                    -- Item Lookup Results trigger
                    go_craft = 8675309
                    --   scw_r_col, scw_g_col, scw_b_col = 1, .647, 0
                end

                ImGui.TableNextColumn()
                local r_col, g_col, b_col = 0, .7, 0
                ImGui.TextColored(r_col, g_col, b_col, 1, lookup_items.Name)

                ImGui.TableNextColumn()
                local r_col, g_col, b_col = 1, .7, 0
                ImGui.TextColored(r_col, g_col, b_col, 1, lookup_items.ID)
                ImGui.PopID()
            end
        end
        ImGui.EndTable()
    end

    -- ImGui.EndChild()
end

function BatchInfoWindow()
    if ImGui.BeginTabBar('BatchResults', ImGuiTabBarFlags.Reorderable) then
        local col1 = 1
        local col2 = 1
        local col3 = 1

        if BATCH_SHOPPING_DATA[1] == nil then
            col1 = .5
            col2 = 0
            col3 = 0
        else
            col1 = 0
            col2 = .5
            col3 = 0
        end

        ImGui.PushStyleColor(ImGuiCol.TabActive, col1, col2, col3, 1)
        ImGui.PushStyleColor(ImGuiCol.Tab, col1, col2, col3, 1)

        ImGui.PushID('Shopping##BatchResults')
        if ImGui.BeginTabItem('Shopping##BatchResults') then
            BatchShoppingWindow()
            ImGui.EndTabItem()
        end
        ImGui.PopID()

        ImGui.PopStyleColor()
        ImGui.PopStyleColor()

        if BATCH_BANK_ARRAY[1] == nil then
            col1 = .5
            col2 = 0
            col3 = 0
        else
            col1 = 0
            col2 = .5
            col3 = 0
        end

        ImGui.PushStyleColor(ImGuiCol.TabActive, col1, col2, col3, 1)
        ImGui.PushStyleColor(ImGuiCol.Tab, col1, col2, col3, 1)

        ImGui.PushID('Bank##BatchResults')
        if ImGui.BeginTabItem('Bank##BatchResults') then
            BatchBankWindow()
            ImGui.EndTabItem()
        end
        ImGui.PopID()

        ImGui.PopStyleColor()
        ImGui.PopStyleColor()

        if ret_batch_depot_data[1] == nil then
            col1 = .5
            col2 = 0
            col3 = 0
        else
            col1 = 0
            col2 = .5
            col3 = 0
        end

        ImGui.PushStyleColor(ImGuiCol.TabActive, col1, col2, col3, 1)
        ImGui.PushStyleColor(ImGuiCol.Tab, col1, col2, col3, 1)

        ImGui.PushID('Depot##DepotBatchResults')
        if ImGui.BeginTabItem('Depot##DepotBatchResults') then
            BatchDepotWindow()
            ImGui.EndTabItem()
        end
        ImGui.PopID()

        ImGui.PopStyleColor()
        ImGui.PopStyleColor()

        if BATCH_FARM_LIST[1] == nil then
            col1 = .5
            col2 = 0
            col3 = 0
        else
            col1 = 0
            col2 = .5
            col3 = 0
        end

        ImGui.PushStyleColor(ImGuiCol.TabActive, col1, col2, col3, 1)
        ImGui.PushStyleColor(ImGuiCol.Tab, col1, col2, col3, 1)

        ImGui.PushID('Missing##BatchResults')
        if ImGui.BeginTabItem('Missing##BatchResults') then
            BatchGenerateWindow()
            ImGui.EndTabItem()
        end
        ImGui.PopID()

        ImGui.PopStyleColor()
        ImGui.PopStyleColor()

        ImGui.PushID('Fish##BatchResults')
        if ImGui.BeginTabItem('Fish##BatchResults') then
            StandardFishWindow()
            ImGui.EndTabItem()
        end
        ImGui.PopID()

        ImGui.EndTabBar()
    end
end

local function ArtisanRecipeInfoWindow()
    if ImGui.BeginTabBar('ArtisanResults', ImGuiTabBarFlags.Reorderable) then
        local col1 = 1
        local col2 = 1
        local col3 = 1

        if max_recipe_shopping_data[1] == nil then
            col1 = .5
            col2 = 0
            col3 = 0
        else
            col1 = 0
            col2 = .5
            col3 = 0
        end

        ImGui.PushStyleColor(ImGuiCol.TabActive, col1, col2, col3, 1)
        ImGui.PushStyleColor(ImGuiCol.Tab, col1, col2, col3, 1)

        ImGui.PushID('Shopping##ArtisanResults')
        if ImGui.BeginTabItem('Shopping##ArtisanResults') then
            MaxShoppingListWindow()
            ImGui.EndTabItem()
        end
        ImGui.PopID()

        ImGui.PopStyleColor()
        ImGui.PopStyleColor()

        if mass_bank_array[1] == nil then
            col1 = .5
            col2 = 0
            col3 = 0
        else
            col1 = 0
            col2 = .5
            col3 = 0
        end

        ImGui.PushStyleColor(ImGuiCol.TabActive, col1, col2, col3, 1)
        ImGui.PushStyleColor(ImGuiCol.Tab, col1, col2, col3, 1)

        ImGui.PushID('Bank##ArtisanResults')
        if ImGui.BeginTabItem('Bank##ArtisanResults') then
            MassBankListWindow()
            ImGui.EndTabItem()
        end
        ImGui.PopID()

        ImGui.PopStyleColor()
        ImGui.PopStyleColor()

        if ret_max_depot_data[1] == nil then
            col1 = .5
            col2 = 0
            col3 = 0
        else
            col1 = 0
            col2 = .5
            col3 = 0
        end

        ImGui.PushStyleColor(ImGuiCol.TabActive, col1, col2, col3, 1)
        ImGui.PushStyleColor(ImGuiCol.Tab, col1, col2, col3, 1)

        ImGui.PushID('Depot##ArtisanDepotResults')
        if ImGui.BeginTabItem('Depot##ArtisanDepotResults') then
            MassDepotListWindow()
            ImGui.EndTabItem()
        end
        ImGui.PopID()

        ImGui.PopStyleColor()
        ImGui.PopStyleColor()

        if art_max_farm_list[1] == nil then
            col1 = .5
            col2 = 0
            col3 = 0
        else
            col1 = 0
            col2 = .5
            col3 = 0
        end

        ImGui.PushStyleColor(ImGuiCol.TabActive, col1, col2, col3, 1)
        ImGui.PushStyleColor(ImGuiCol.Tab, col1, col2, col3, 1)

        ImGui.PushID('Missing##ArtisanResults')
        if ImGui.BeginTabItem('Missing##ArtisanResults') then
            MaxFarmTableWindow()
            ImGui.EndTabItem()
        end
        ImGui.PopID()

        ImGui.PopStyleColor()
        ImGui.PopStyleColor()

        ImGui.EndTabBar()
    end
end

function RequestTableWindow()
    if not Request_search_results[1] == nil then
        ImGui.Text("No Data")
        return
    end
    ImGui.BeginChild("Results", 1000, 400)

    ImGui.Text("Items Returned: (" .. #Request_search_results .. ")")

    local flags = bit32.bor(ImGuiTableFlags.Resizable,
        ImGuiTableFlags.Reorderable,
        ImGuiTableFlags.Hideable,
        ImGuiTableFlags.MultiSortable,
        ImGuiTableFlags.Sortable, ImGuiTableFlags.RowBg,
        ImGuiTableFlags.BordersOuter,
        ImGuiTableFlags.BordersV,
        ImGuiTableFlags.NoBordersInBody,
        ImGuiTableFlags.ScrollY)

    if ImGui.BeginTable('##request_table', 4, flags, 0, TEXT_BASE_HEIGHT * 18,
            0.0) then
        -- Declare columns

        ImGui.TableSetupColumn('Request', ImGuiTableColumnFlags.WidthAuto, -1.0,
            ColumnID_Button)

        ImGui.TableSetupColumn('Name', ImGuiTableColumnFlags.WidthStretch, -1.0,
            ColumnID_Name)

        ImGui.TableSetupColumn('ID', ImGuiTableColumnFlags.WidthStretch, -1.0,
            ColumnID_ID)

        local ColumnID_INV = 25

        ImGui.TableSetupColumn('Inventory', ImGuiTableColumnFlags.WidthStretch,
            -1.0, ColumnID_INV)

        ImGui.TableSetupScrollFreeze(0, 1) -- Make row always visible

        local sort_specs = ImGui.TableGetSortSpecs()

        if sort_specs then
            if sort_specs.SpecsDirty then
                if #Request_search_results > 1 then
                    current_sort_specs = sort_specs
                    table.sort(Request_search_results, CompareWithSortSpecs)
                    current_sort_specs = nil
                end
                sort_specs.SpecsDirty = false
            end
        end

        -- Display data
        ImGui.TableHeadersRow()

        local clipper = ImGuiListClipper.new()
        clipper:Begin(#Request_search_results)
        while clipper:Step() do
            for row_n = clipper.DisplayStart, clipper.DisplayEnd - 1, 1 do
                ---- remd  ImGui.SetCursorPosX(4)
                local recipe_items = Request_search_results[row_n + 1]
                ImGui.PushID(recipe_items)

                ImGui.TableNextRow()

                ImGui.TableNextColumn()

                small_button_click_value, _ = ImGui.SmallButton(
                    'Request###Request_ID99')

                if small_button_click_value then
                    local r_item_id = recipe_items.ID
                    local r_amount = R_amount
                    local r_item_name = recipe_items.Name
                    GLOBAL_TEXT = "Requesting (" .. r_amount .. ") " ..
                        r_item_name .. " via DanNet"
                    request_array_list = {}
                    local have_count = mq.TLO.FindItemCount(r_item_id)()
                    if have_count > 0 then
                        r_amount = r_amount - have_count
                    end
                    local request_string = recipe_items.ID .. "," .. r_amount
                    if r_amount > 0 then
                        table.insert(request_array_list, request_string)
                    end
                    if request_array_list[1] ~= nil then
                        go_ask = 1
                    else
                        GLOBAL_TEXT = "Nothing to request via DanNet"
                    end
                end
                ImGui.TableNextColumn()
                ImGui.TextColored(0, .7, 0, 1, recipe_items.Name)
                ImGui.TableNextColumn()
                ImGui.TextColored(0, .7, .3, 1, recipe_items.ID)

                ImGui.TableNextColumn()
                local i_count = mq.TLO.FindItemCount(recipe_items.ID)()
                ImGui.TextColored(0, 1, 0, 1, "(" .. i_count .. ")")
                ImGui.PopID()
            end
        end

        ImGui.EndTable()
    end

    -- ImGui.End()
    ImGui.EndChild()
end

-- JB321 Added 9/8/2025
function RecipeViewerWindow()
    -- Preferred size
    local default_w, default_h = 860, 620

    -- Set preferred size on first use only
    ImGui.SetNextWindowSize(default_w, default_h, ImGuiCond.FirstUseEver)

    -- Pass 2: draw the real window with a stable ID
    local open = ImGui.Begin(
        "TCN Recipe Viewer - " .. (RecipeToShow.name or "Recipe Viewer") .. "##recipe_viewer",
        true
    )

    if not open then
        RecipeToShow = nil
        ImGui.End()
        return
    end

    ImGui.SetWindowFontScale(1)

    -- === FIXED HEADER CONTROLS ===
    local Mode
    if ImGui.Button("Expand") then Mode = "E" end
    ImGui.SameLine()
    if ImGui.Button("Collapse") then Mode = "C" end
    ImGui.SameLine()
    --  if ImGui.Button("Close") then RecipeToShow = nil end

    if ImGui.Button("Close") then
        RecipeToShow = nil
        ImGui.End()
        return
    end

    ImGui.Separator()

    -- === SCROLLABLE CONTENT REGION ===
    -- Fill remaining space and make it scrollable
    ImGui.BeginChild("recipe_scroll_region", 0, 0, false, ImGuiWindowFlags.HorizontalScrollbar)

    local ok, err = pcall(feeder.drawRecipeTree, RecipeToShow, 1, true, Mode)
    if not ok then
        print("Error drawing recipe tree:", err)
        ImGui.Text("Unable to draw recipe tree.")
    end

    ImGui.EndChild()

    ImGui.End()
end

function RecipeTableWindow()
    if not recipe_search_results[1] == nil then
        ImGui.Text("No Data")
        return
    end

    -- Checkmark
    local FA_CHECK = '\xef\x80\x8c'
    -- Magnifying Glass
    local FA_LOOK = '\xef\x80\x82'
    -- Heart
    local FA_HEART = '\xef\x80\x84'

    local ColumnID_Lookup = 26
    local ColumnID_Fav = 20

    -- not sure if this needs to be here anymore..
    ImGui.BeginChild("Results", 1000, 400)

    ImGui.Text("Recipes Returned: (" .. #recipe_search_results .. ")")

    local flags = bit32.bor(ImGuiTableFlags.Resizable,
        ImGuiTableFlags.Reorderable,
        ImGuiTableFlags.Hideable,
        ImGuiTableFlags.MultiSortable,
        ImGuiTableFlags.Sortable, ImGuiTableFlags.RowBg,
        ImGuiTableFlags.BordersOuter,
        ImGuiTableFlags.BordersV,
        ImGuiTableFlags.NoBordersInBody,
        ImGuiTableFlags.ScrollY)

    if ImGui.BeginTable('##recipe_table', 8, flags, 0, TEXT_BASE_HEIGHT * 15,
            0.0) then
        --  ImGui.ImGuiCol_TableRowBg(1,2,1)
        -- ImGui.TableSetBgColor(7, 255, 255)

        -- Declare columns
        -- We use the 'user_id' parameter of TableSetupColumn() to specify a user id that will be stored in the sort specifications.
        -- This is so our sort function can identify a column given our own identifier. We could also identify them based on their index.
        -- Demonstrate using a mixture of flags among available sort-related flags:
        --   ImGuiTableColumnFlags.DefaultSort

        --   ImGuiTableColumnFlags.NoSort / ImGuiTableColumnFlags.NoSortAscending / ImGuiTableColumnFlags.NoSortDescending
        --  ImGuiTableColumnFlags.PreferSortAscending / ImGuiTableColumnFlags.PreferSortDescending

        ImGui.TableSetupColumn(FA_CHECK, ImGuiTableColumnFlags.WidthAuto, -1.0,
            ColumnID_Button)

        ImGui.TableSetupColumn(FA_LOOK, ImGuiTableColumnFlags.WidthAuto, -1.0,
            ColumnID_Lookup)

        ImGui.TableSetupColumn('Expansion', ImGuiTableColumnFlags.WidthFixed,
            -1.0, ColumnID_EXP)

        --  ImGui.TableSetupColumn('Type', ImGuiTableColumnFlags.WidthFixed, TEXT_BASE_WIDTH * 18.0)????

        ImGui.TableSetupColumn('Recipe Name',
            ImGuiTableColumnFlags.WidthStretch, -1.0,
            ColumnID_Name)

        --  ImGui.TableSetupColumn('Recipe Name', ImGuiTableColumnFlags.WidthFixed,

        --    IMGUI_API void          TableSetupColumn(const char* label, ImGuiTableColumnFlags flags = 0, float init_width_or_weight = -1.0f, ImU32 user_id = 0);

        --  ImGui.TableSetupColumn('Recipe ID', bit32.bor(
        --    ImGuiTableColumnFlags.DefaultSort,
        --    ImGuiTableColumnFlags.WidthFixed), -1.0,
        --   ColumnID_ID)

        ImGui.TableSetupColumn('Trivial', ImGuiTableColumnFlags.WidthAuto, -1.0,
            ColumnID_Trivial)

        ImGui.TableSetupColumn('Yield', ImGuiTableColumnFlags.WidthAuto, -1.0,
            ColumnID_Yield)
        -- ImGui.TableSetupColumn('Skill', ImGuiTableColumnFlags.WidthAuto, -1.0,
        --                         ColumnID_Skill)
        ImGui.TableSetupColumn('Container', ImGuiTableColumnFlags.WidthAuto,
            -1.0, ColumnID_Container)

        ImGui.TableSetupColumn(FA_HEART, ImGuiTableColumnFlags.WidthFixed, -1.0,
            ColumnID_Fav)

        ImGui.TableSetupScrollFreeze(0, 1) -- Make row always visible

        local sort_specs = ImGui.TableGetSortSpecs()

        if sort_specs then
            if sort_specs.SpecsDirty then
                if #recipe_search_results > 1 then
                    current_sort_specs = sort_specs
                    table.sort(recipe_search_results, CompareWithSortSpecs)
                    current_sort_specs = nil
                end
                sort_specs.SpecsDirty = false
            end
        end

        -- Display data
        ImGui.TableHeadersRow()

        -- for c = 1 ,#recipe_search_results do print(recipe_search_results[c].Name) end os.exit()

        local clipper = ImGuiListClipper.new()
        clipper:Begin(#recipe_search_results)

        while clipper:Step() do
            for row_n = clipper.DisplayStart, clipper.DisplayEnd - 1, 1 do
                local recipe_items = recipe_search_results[row_n + 1]
                --ImGui.PushID(recipe_items)
                -- Future proof fix test (look here for the rest later JB321 9/8/2025)
                ImGui.PushID(tostring(recipe_items.RID))
                ImGui.TableNextRow()
                ImGui.TableNextColumn()

                -- Push green text color
                ImGui.PushStyleColor(ImGuiCol.Text, 0.0, 1.0, 0.0, 1.0) -- RGBA: bright green

                small_button_click_value, _ = ImGui.SmallButton(FA_CHECK .. "##Select_ID1")

                ImGui.PopStyleColor() -- Restore previous text color

                if small_button_click_value then
                    if not override_cb_bool then
                        GLOBAL_TEXT = "Processing Recipe..."
                    else
                        GLOBAL_TEXT = "Override Enabled"
                    end
                    id_select = recipe_items.RID
                    name_select = recipe_items.Name
                    container_select = recipe_items.Container
                    skill_select = recipe_items.Skill
                    trivial_select = recipe_items.Trivial
                    l_item_id = recipe_items.ID
                    skill_req = recipe_items.SkillRequired

                    scw_r_col, scw_g_col, scw_b_col = 1, .647, 0

                    --  print"testing sugar syrup tcg"
                    --  id_select = 36563

                    -- Skill requirement add checking

                    can_craft = 1

                    -- Query recipe to make sure we can make it
                    if id_select > 0 and tonumber(l_make_amount) > 0 and
                        not override_cb_bool then
                        crunch_go = 1
                    end

                    -- Check primarily for Reinforced Jeweler's Kit Requirement
                    if id_select > 0 then
                        local con_result = feeder.ccr(id_select)
                        if con_result ~= nil then
                            GLOBAL_TEXT =
                                "Unable to make recipe, need quested container: [" ..
                                con_result .. "]"
                            can_craft = 0
                            crunch_go = 0
                        end
                    end

                    -- Check for Coffin Poison Bottle Requirement
                    if id_select > 0 and
                        string.find(container_select, "Coffin Poison Bottle") then
                        GLOBAL_TEXT =
                        "Unable to make recipe, need quested container: [Poison Coffin Bottle]"
                        can_craft = 0
                        crunch_go = 0
                    end
                end

                ImGui.TableNextColumn()

                -- Recipe lookup and pop-out
                -- Optional: give it a blue tint so it stands out
                ImGui.PushStyleColor(ImGuiCol.Text, 0.2, 0.6, 1.0, 1.0) -- light blue

                local view_click, _ = ImGui.SmallButton(FA_LOOK .. "##View_" .. tostring(recipe_items.RID))

                ImGui.PopStyleColor()

                -- On click:
                if view_click then
                    if RecipeToShow and RecipeToShow.id == recipe_items.RID then
                        -- Same recipe → close it
                        RecipeToShow = nil
                        PendingRecipe = nil
                    else
                        -- Different recipe → load it
                        PendingRecipe = { id = recipe_items.RID, name = recipe_items.Name }
                    end
                end

                ImGui.TableNextColumn()

                local r_col, g_col, b_col = 1, .7, 0

                local l_get_logo = feeder.return_logo(recipe_items.Expansion)

                if recipe_items.Expansion == nil then
                    recipe_items.Expansion = " "
                end

                if l_get_logo ~= nil then
                    local animLogoIcons = mq.FindTextureAnimation(l_get_logo)
                    animLogoIcons:SetTextureCell(c)
                    if animLogoIcons ~= nil then
                        ImGui.DrawTextureAnimation(animLogoIcons, 72, 20)
                    end
                else
                    ImGui.TextColored(r_col, g_col, b_col, 1,
                        recipe_items.Expansion)
                end

                ImGui.TableNextColumn()

                local r_col, g_col, b_col = 0, .7, 0

                if recipe_items.Skill == "Make Poison" and mq.TLO.Me.Class() ~=
                    "Rogue" then
                    r_col = 1
                    g_col = .7
                    b_col = 0
                end

                if recipe_items.Skill == "Alchemy" and mq.TLO.Me.Class() ~=
                    "Shaman" then
                    r_col = 1
                    g_col = .5
                    b_col = 1
                end

                if recipe_items.Skill == "Tinkering" and mq.TLO.Me.Race() ~=
                    "Gnome" then
                    r_col = .7
                    g_col = .7
                    b_col = 0
                end

                ImGui.TextColored(r_col, g_col, b_col, 1, recipe_items.Name)

                ImGui.TableNextColumn()
                ImGui.Text(string.format(recipe_items.Trivial))
                ImGui.TableNextColumn()
                ImGui.Text(string.format('%d', recipe_items.Yield))
                ImGui.TableNextColumn()
                ImGui.Text(recipe_items.Container)

                ImGui.TableNextColumn()

                -- animItems:SetTextureCell(1003 - 500)
                --  ImGui.DrawTextureAnimation(animItems, 16, 16)
                -- animItems:SetTextureCell(2068 - 500)
                -- ImGui.DrawTextureAnimation(animItems, 16, 16)

                -- Favorites Checking
                local no_instance = 0
                local fav_index = 0

                local col1, col2, col3 = 1, 1, 1

                for c = #fav_array, 1, -1 do
                    if fav_array[c] == recipe_items.RID then
                        no_instance = 1
                        fav_index = c
                        col1, col2, col3 = 0, 1, 0
                        break
                    end
                end

                if no_instance == 0 then
                    col1, col2, col3 = 1, 0, 0
                end

                ImGui.PushStyleColor(ImGuiCol.Text, col1, col2, col3, 2)
                fav_btn_bool, _ = ImGui.Button(FA_HEART)
                ImGui.PopStyleColor()

                if no_instance == 0 and fav_btn_bool then
                    local rec_id = recipe_items.RID
                    table.insert(fav_array, rec_id)
                    local user_string_struct =
                        "TCS_FAV_" .. mq.TLO.Me() .. "_" ..
                        mq.TLO.MacroQuest.Server()
                    tcglib.write_favorites(user_string_struct, fav_array)
                end

                if no_instance == 1 and fav_btn_bool then
                    if fav_array[1] ~= nil then
                        table.remove(fav_array, fav_index)
                        local user_string_struct =
                            "TCS_FAV_" .. mq.TLO.Me() .. "_" ..
                            mq.TLO.MacroQuest.Server()
                        tcglib.write_favorites(user_string_struct, fav_array)
                    end
                end

                ImGui.PopID()
            end

            -- End For Loop
        end
        -- End While?

        ImGui.EndTable()

        -- End Table?
    end

    ImGui.EndChild()


    -- After EndTable/EndChild:
    if PendingRecipe then
        local ok, result = pcall(feeder.getRecipeTree, PendingRecipe.id)
        if ok and result then
            RecipeToShow = result
        else
            if not ok then
                print("Error in getRecipeTree:", result)
            else
                print("No recipe found for RID:", tostring(PendingRecipe.id))
            end
            RecipeToShow = nil
        end
        PendingRecipe = nil
    end

    -- Draw viewer if we have a recipe
    if RecipeToShow then
        RecipeViewerWindow()
    end
end

-- End Function

function RecipeBatchWindow()
    -- bool to open or close
    --    -- ImGui.SetWindowPos("Search Results###ID1", 100, 100)

    -- indent?
    -- remd  ImGui.SetCursorPosX(4)
    -- ImGui.SetWindowSize(800, 600)

    ImGui.BeginChild("Results", 1000, 400)

    -- ImGui.PushStyleColor(ImGuiCol.Text, 0.56, 0.78, 0.18, 2)

    ImGui.Text("Recipes Returned: (" .. #recipe_batch_results .. ")")

    ImGui.SameLine()
    ImGui.Text("Requirement Legend")
    ImGui.SameLine()
    ImGui.TextColored(1, .7, 0, 1, "Rogue")
    ImGui.SameLine()
    ImGui.TextColored(1, .5, 1, 1, "Shaman")
    ImGui.SameLine()
    ImGui.TextColored(.7, .7, 0, 1, "Gnome")

    local flags = bit32.bor(ImGuiTableFlags.Resizable,
        ImGuiTableFlags.Reorderable,
        ImGuiTableFlags.Hideable,
        ImGuiTableFlags.MultiSortable,
        ImGuiTableFlags.Sortable, ImGuiTableFlags.RowBg,
        ImGuiTableFlags.BordersOuter,
        ImGuiTableFlags.BordersV,
        ImGuiTableFlags.NoBordersInBody,
        ImGuiTableFlags.ScrollY)

    if ImGui.BeginTable('##batch_recipe_table', 5, flags, 0,
            TEXT_BASE_HEIGHT * 15, 0.0) then
        -- Declare columns
        -- We use the 'user_id' parameter of TableSetupColumn() to specify a user id that will be stored in the sort specifications.
        -- This is so our sort function can identify a column given our own identifier. We could also identify them based on their index.
        -- Demonstrate using a mixture of flags among available sort-related flags:
        --   ImGuiTableColumnFlags.DefaultSort

        --   ImGuiTableColumnFlags.NoSort / ImGuiTableColumnFlags.NoSortAscending / ImGuiTableColumnFlags.NoSortDescending
        --  ImGuiTableColumnFlags.PreferSortAscending / ImGuiTableColumnFlags.PreferSortDescending

        ImGui.TableSetupColumn('Batch', ImGuiTableColumnFlags.WidthFixed, -1.0,
            ColumnID_Button)

        --  ImGui.TableSetupColumn('Type', ImGuiTableColumnFlags.WidthFixed, TEXT_BASE_WIDTH * 18.0)????

        ImGui.TableSetupColumn('Recipe Name',
            ImGuiTableColumnFlags.WidthStretch, -1.0,
            ColumnID_Name)

        --  ImGui.TableSetupColumn('Recipe ID', bit32.bor(
        --    ImGuiTableColumnFlags.DefaultSort,
        --    ImGuiTableColumnFlags.WidthFixed), -1.0,
        --   ColumnID_ID)

        ImGui.TableSetupColumn('Trivial', ImGuiTableColumnFlags.WidthFixed,
            -1.0, ColumnID_Trivial)

        ImGui.TableSetupColumn('Yield', ImGuiTableColumnFlags.WidthFixed, -1.0,
            ColumnID_Yield)
        --  ImGui.TableSetupColumn('Skill', ImGuiTableColumnFlags.WidthAuto, -1.0,
        --                         ColumnID_Skill)
        ImGui.TableSetupColumn('Container', ImGuiTableColumnFlags.WidthAuto,
            -1.0, ColumnID_Container)

        ImGui.TableSetupScrollFreeze(0, 1) -- Make row always visible

        local sort_specs = ImGui.TableGetSortSpecs()

        if sort_specs then
            if sort_specs.SpecsDirty then
                if #recipe_batch_results > 1 then
                    current_sort_specs = sort_specs
                    table.sort(recipe_batch_results, CompareWithSortSpecs)
                    current_sort_specs = nil
                end
                sort_specs.SpecsDirty = false
            end
        end

        local myClass = mq.TLO.Me.Class()
        local myRace  = mq.TLO.Me.Race()

        -- Display data
        ImGui.TableHeadersRow()

        local clipper = ImGuiListClipper.new()
        clipper:Begin(#recipe_batch_results)
        while clipper:Step() do
            for row_n = clipper.DisplayStart, clipper.DisplayEnd - 1, 1 do
                -- remd  ImGui.SetCursorPosX(4)
                local recipe_items = recipe_batch_results[row_n + 1]
                local skill = recipe_items.Skill
                ImGui.PushID(recipe_items.RID)

                ImGui.TableNextRow()
                ImGui.TableNextColumn()

                small_button_click_value, _ = ImGui.SmallButton(
                    'Add###Select_ID2')

                if small_button_click_value then
                    GLOBAL_TEXT = "Adding to Batch..."

                    id_select = recipe_items.RID
                    name_select = recipe_items.Name
                    --     container_select = recipe_items.Container
                    skill_select = recipe_items.Skill
                    trivial_select = recipe_items.Trivial
                    l_item_id = recipe_items.ID
                    skill_req = recipe_items.SkillRequired

                    scw_r_col, scw_g_col, scw_b_col = 1, .647, 0

                    -- Skill requirement add checking

                    can_craft = 1

                    local batch_array_structure = {
                        BatchItemID = l_item_id,
                        BatchItemName = name_select,
                        BatchItemMake = l_make_amount,
                        BatchItemRecipe = id_select
                    }

                    table.insert(batch_array, batch_array_structure)

                    --  table.insert(batch_array, l_item_id .. "," .. name_select ..
                    --    "," .. l_make_amount .. "," .. id_select)
                end

                ImGui.TableNextColumn()
                local r_col, g_col, b_col = 0, .7, 0
                if skill == "Make Poison" and myClass ~= "Rogue" then
                    r_col, g_col, b_col = 1, .7, 0
                elseif skill == "Alchemy" and myClass ~= "Shaman" then
                    r_col, g_col, b_col = 1, .5, 1
                elseif skill == "Tinkering" and myRace ~= "Gnome" then
                    r_col, g_col, b_col = .7, .7, 0
                end

                ImGui.TextColored(r_col, g_col, b_col, 1, recipe_items.Name)

                --   ImGui.TableNextColumn()
                --   ImGui.Text(string.format("%04d", recipe_items.RID))

                ImGui.TableNextColumn()
                -- ImGui.Text(string.format(recipe_items.Trivial))
                ImGui.Text(tostring(recipe_items.Trivial))
                ImGui.TableNextColumn()
                --ImGui.Text(string.format('%d', recipe_items.Yield))
                ImGui.Text(tostring(recipe_items.Yield))
                --  ImGui.TableNextColumn()
                -- ImGui.Text(recipe_items.Skill)
                ImGui.TableNextColumn()
                ImGui.Text(recipe_items.Container)

                ImGui.PopID()
            end
        end

        ImGui.EndTable()
    end

    -- ImGui.TreePop()

    ImGui.EndChild()
end

function MassBankListWindow()
    if mass_bank_array[1] == nil then
        ImGui.Text("No Data")
        return
    end

    -- ImGui.SetWindowSize(700, 280)
    -- ImGui.SetWindowFontScale(1)
    -- remd  ImGui.SetCursorPosX(4)

    local flags = bit32.bor(ImGuiTableFlags.Resizable,
        ImGuiTableFlags.Reorderable,
        ImGuiTableFlags.Hideable,
        ImGuiTableFlags.MultiSortable,
        ImGuiTableFlags.Sortable, ImGuiTableFlags.RowBg,
        ImGuiTableFlags.BordersOuter,
        ImGuiTableFlags.BordersV,
        ImGuiTableFlags.NoBordersInBody,
        ImGuiTableFlags.ScrollY)
    if ImGui.BeginTable('##mass_bank_shopping_table', 3, flags, 0,
            TEXT_BASE_HEIGHT * 12, 0.0) then
        ImGui.TableSetupColumn('Name', ImGuiTableColumnFlags.WidthAuto, -1.0,
            ColumnID_Name)
        ImGui.TableSetupColumn('ID', ImGuiTableColumnFlags.WidthAuto, -1.0,
            ColumnID_ID)
        ImGui.TableSetupColumn('Count', ImGuiTableColumnFlags.WidthAuto, -1.0,
            ColumnID_Quantity)

        ImGui.TableSetupScrollFreeze(0, 1) -- Make row always visible

        local sort_specs = ImGui.TableGetSortSpecs()

        if sort_specs then
            if sort_specs.SpecsDirty then
                if #mass_bank_array > 1 then
                    current_sort_specs = sort_specs
                    table.sort(mass_bank_array, CompareWithSortSpecs)
                    current_sort_specs = nil
                end
                sort_specs.SpecsDirty = false
            end
        end

        -- Display data
        ImGui.TableHeadersRow()

        local clipper = ImGuiListClipper.new()
        clipper:Begin(#mass_bank_array)
        while clipper:Step() do
            for row_n = clipper.DisplayStart, clipper.DisplayEnd - 1, 1 do
                local r_col, g_col, b_col = .3, 1, 1
                local convert_item = mass_bank_array[row_n + 1]
                ImGui.PushID(convert_item)
                if string.find(convert_item.Name, "@") then
                    convert_item.Name = convert_item.Name:gsub('@', ',')
                end
                ImGui.TableNextRow()
                ImGui.TableNextColumn()
                ImGui.TextColored(r_col, g_col, b_col, 1, convert_item.Name)
                ImGui.TableNextColumn()
                ImGui.Text(convert_item.ID)
                ImGui.TableNextColumn()
                ImGui.Text(convert_item.Quantity)
                ImGui.PopID()
            end
        end
        ImGui.EndTable()
    end

    ImGui.Text("Options")
    ImGui.SameLine()
    if ImGui.Button("Bank Shop") then go_shop = 49 end

    ImGui.SameLine()
    -- Write artisan bank shopping list to disk
    if ImGui.Button("Save") then
        local skill_used = max_array[l_max_selection]

        local file =
            "Artisan_BSL_" .. skill_used .. "_" .. mq.TLO.Me() .. "_" ..
            mq.TLO.MacroQuest.Server() .. ".csv"

        local file_exist_bool = tcglib.file_exists(file)

        if file_exist_bool then
            local command = 'del ' .. mq.luaDir .. '\\TCN\\ShoppingLists\\' ..
                file
            os.execute(command)
        end

        tcglib.writeshoppinglist("Artisan_BSL_" .. skill_used .. "_" ..
            mq.TLO.Me() .. "_" ..
            mq.TLO.MacroQuest.Server(), "Item,ID,Count")

        for sl = 1, #mass_bank_array do
            local item_id = mass_bank_array[sl].ID
            local item_count = mass_bank_array[sl].Quantity
            local item_name = mass_bank_array[sl].Name

            -- print(item_id, " ",item_count, " ",item_name)

            if string.find(item_name, ",") then
                item_name = item_name:gsub(',', '|')
            end

            local l_shop_string = item_name .. "," .. item_id .. "," ..
                item_count
            tcglib.writeshoppinglist("Artisan_BSL_" .. skill_used .. "_" ..
                mq.TLO.Me() .. "_" ..
                mq.TLO.MacroQuest.Server(),
                l_shop_string)
        end
    end

    ImGui.SameLine()
    HelpMarker("Saves Mass Bank Shopping Data to " .. mq.luaDir ..
        "\\TCN\\ShoppingLists\\ " .. " Directory")

    local skill_used = max_array[l_max_selection]

    local file = "Artisan_BSL_" .. skill_used .. "_" .. mq.TLO.Me() .. "_" ..
        mq.TLO.MacroQuest.Server() .. ".csv"

    local file_exist_bool = tcglib.file_exists(file)

    if file_exist_bool then
        ImGui.SameLine()
        ImGui.TextColored(0, 1, 0, 1, "File Exists")
    else
        ImGui.SameLine()
        ImGui.TextColored(1, 1, 0, 1, "File Not Created")
    end

    ImGui.SameLine()
    if ImGui.Button("Open Folder") then
        -- Open Windows Directory
        os.execute("start " .. mq.luaDir .. "\\TCN\\ShoppingLists")
    end

    ImGui.SameLine()
    HelpMarker("Open Folder " .. mq.luaDir .. "\\TCN\\ShoppingLists\\ ")

    --  ImGui.End()
end

function MassDepotListWindow()
    if not mq.TLO.TradeskillDepot.Enabled() then
        ImGui.Text("Expansion: Night of Shadows not enabled")
        return
    end

    if ret_max_depot_data[1] == nil then
        ImGui.Text("No Data")
        return
    end

    local flags = bit32.bor(ImGuiTableFlags.Resizable,
        ImGuiTableFlags.Reorderable,
        ImGuiTableFlags.Hideable,
        ImGuiTableFlags.MultiSortable,
        ImGuiTableFlags.Sortable, ImGuiTableFlags.RowBg,
        ImGuiTableFlags.BordersOuter,
        ImGuiTableFlags.BordersV,
        ImGuiTableFlags.NoBordersInBody,
        ImGuiTableFlags.ScrollY)
    if ImGui.BeginTable('##mass_depot_shopping_table', 3, flags, 0,
            TEXT_BASE_HEIGHT * 12, 0.0) then
        ImGui.TableSetupColumn('Name', ImGuiTableColumnFlags.WidthAuto, -1.0,
            ColumnID_Name)
        ImGui.TableSetupColumn('ID', ImGuiTableColumnFlags.WidthAuto, -1.0,
            ColumnID_ID)
        ImGui.TableSetupColumn('Count', ImGuiTableColumnFlags.WidthAuto, -1.0,
            ColumnID_Quantity)

        ImGui.TableSetupScrollFreeze(0, 1) -- Make row always visible

        local sort_specs = ImGui.TableGetSortSpecs()

        if sort_specs then
            if sort_specs.SpecsDirty then
                if #ret_max_depot_data > 1 then
                    current_sort_specs = sort_specs
                    table.sort(ret_max_depot_data, CompareWithSortSpecs)
                    current_sort_specs = nil
                end
                sort_specs.SpecsDirty = false
            end
        end

        -- Display data
        ImGui.TableHeadersRow()

        local clipper = ImGuiListClipper.new()
        clipper:Begin(#ret_max_depot_data)
        while clipper:Step() do
            for row_n = clipper.DisplayStart, clipper.DisplayEnd - 1, 1 do
                local r_col, g_col, b_col = .3, 1, 1
                local convert_item = ret_max_depot_data[row_n + 1]
                ImGui.PushID(convert_item)
                if string.find(convert_item.Name, "@") then
                    convert_item.Name = convert_item.Name:gsub('@', ',')
                end
                ImGui.TableNextRow()
                ImGui.TableNextColumn()
                ImGui.TextColored(r_col, g_col, b_col, 1, convert_item.Name)
                ImGui.TableNextColumn()
                ImGui.Text(convert_item.ID)
                ImGui.TableNextColumn()
                ImGui.Text(convert_item.Quantity)
                ImGui.PopID()
            end
        end
        ImGui.EndTable()
    end

    if ImGui.Button("Depot Shop") then go_shop = 1151 end

    ImGui.SameLine()

    HelpMarker("Goes to your tradeskill depot and grabs items.")

    ImGui.SameLine()

    ImGui.Text("Item Count: " .. #ret_max_depot_data)
end

function ToonShoppingListWindow()
    if pass_array[1] == nil then return end

    if not OPENToonShoppingListGUI then return end

    local t_string = "TCSNeXt [" .. mq.TLO.Me.Name() ..
        "] Mass Vendor Shopping Buddy List"
    ImGui.Begin(t_string, OPENToonShoppingListGUI)

    ImGui.SetWindowSize(700, 280)
    ImGui.SetWindowFontScale(1)
    -- remd  ImGui.SetCursorPosX(4)

    local amount_total = 0

    local flags = bit32.bor(ImGuiTableFlags.Resizable,
        ImGuiTableFlags.Reorderable,
        ImGuiTableFlags.Hideable,
        ImGuiTableFlags.MultiSortable,
        ImGuiTableFlags.Sortable, ImGuiTableFlags.RowBg,
        ImGuiTableFlags.BordersOuter,
        ImGuiTableFlags.BordersV,
        ImGuiTableFlags.NoBordersInBody,
        ImGuiTableFlags.ScrollY)

    if ImGui.BeginTable('##toon_recipe_shopping_table', 6, flags, 0,
            TEXT_BASE_HEIGHT * 8, 0.0) then
        local ColumnID_ItemName = 0
        local ColumnID_ItemPrice = 1
        local ColumnID_ItemCount = 2
        local ColumnID_ItemID = 3
        local ColumnID_ItemVendorName = 4
        local ColumnID_ItemZoneName = 5

        ImGui.TableSetupColumn('Name', ImGuiTableColumnFlags.WidthAuto, -1.0,
            ColumnID_ItemName)
        ImGui.TableSetupColumn('Price', ImGuiTableColumnFlags.WidthAuto, -1.0,
            ColumnID_ItemPrice)
        ImGui.TableSetupColumn('Count', ImGuiTableColumnFlags.WidthAuto, -1.0,
            ColumnID_ItemCount)
        ImGui.TableSetupColumn('ID', ImGuiTableColumnFlags.WidthFixed, -1.0,
            ColumnID_ItemID)
        ImGui.TableSetupColumn('Vendor', ImGuiTableColumnFlags.WidthAuto, -1.0,
            ColumnID_ItemVendorName)
        ImGui.TableSetupColumn('Zone', ImGuiTableColumnFlags.WidthAuto, -1.0,
            ColumnID_ItemZoneName)
        ImGui.TableSetupScrollFreeze(0, 1) -- Make row always visible
        -- Display data
        ImGui.TableHeadersRow()

        for iter = 1, #pass_array do
            amount_total = amount_total + pass_array[iter].VendorItemPrice
            -- * pass_array[iter].VendorItemCount
        end

        local clipper = ImGuiListClipper.new()
        clipper:Begin(#pass_array)
        while clipper:Step() do
            for row_n = clipper.DisplayStart, clipper.DisplayEnd - 1, 1 do
                local r_col, g_col, b_col = .3, 1, 1

                local shop_item_zone_id = pass_array[row_n + 1].VendorItemZoneID

                local shop_item_zone_name = mq.TLO.Zone(shop_item_zone_id)()

                local shop_item_id = pass_array[row_n + 1].VendorItemID

                local shop_item_count = pass_array[row_n + 1].VendorItemCount

                local shop_item_price = pass_array[row_n + 1].VendorItemPrice -- * shop_item_count

                local shop_item_name = pass_array[row_n + 1].VendorItemName

                local shop_item_vendor_name = pass_array[row_n + 1].VendorName

                ImGui.PushID('pass_array')

                ImGui.TableNextRow()

                ImGui.TableNextColumn()

                if mq.TLO.FindItemCount(shop_item_id)() >= shop_item_count then
                    r_col = 0
                    g_col = 1
                    b_col = 0
                end

                ImGui.TextColored(r_col, g_col, b_col, 1, shop_item_name)

                shop_item_price = shop_item_price * .001

                ImGui.TableNextColumn()
                ImGui.Text(shop_item_price)

                ImGui.TableNextColumn()
                ImGui.Text(shop_item_count)
                ImGui.TableNextColumn()
                ImGui.Text(string.format(shop_item_id))

                ImGui.TableNextColumn()
                ImGui.Text(shop_item_vendor_name)

                ImGui.TableNextColumn()

                if shop_item_zone_id ~= 202 then
                    r_col = 0
                    g_col = 1
                    b_col = 1
                else
                    r_col = 1
                    g_col = 1
                    b_col = 1
                end

                ImGui.TextColored(r_col, g_col, b_col, 1, shop_item_zone_name)

                ImGui.PopID('pass_array')
            end
        end
        ImGui.EndTable('toon_recipe_shopping_table')
    end

    -- ImGui.TreePop()

    if ImGui.Button("Request Mass Vendored Items") then
        GLOBAL_TEXT = "Requesting Mass Vendor Components via DanNet"
        request_array_list = {}
        for x = 1, #pass_array do
            local request_item_id = pass_array[x].VendorItemID
            local request_item_count = pass_array[x].VendorItemCount
            local have_count = mq.TLO.FindItemCount(request_item_id)()

            if have_count > 0 then
                request_item_count = request_item_count - have_count
            end

            --  works under what condition?
            -- if have_count >= request_item_count then
            --     request_item_count = 0
            --  end

            -- Add condition checks in here
            local request_string = request_item_id .. "," .. request_item_count

            if request_item_count > 0 then
                table.insert(request_array_list, request_string)
            end
        end
        --   for x = 1, #request_array_list do print(request_array_list[x]) end
        if request_array_list[1] ~= nil then
            go_ask = 1
        else
            GLOBAL_TEXT = "Nothing to request via DanNet"
        end
    end
    ImGui.SameLine()
    HelpMarker(
        "Queries other characters in zone for vendor items, and delivers from inventory or bank.")

    -- Reloaded Shop Section
    ImGui.SameLine()
    if ImGui.Button("Shop") then
        local l_zone_lookup = mq.TLO.Zone(pass_zone_array[pass_zone_select])
            .ID()
        local n_array = {}
        if l_zone_lookup == nil then
            for c = 1, #pass_array do
                local shop_string = pass_array[c].VendorItemZoneID .. "," ..
                    pass_array[c].VendorName .. "," ..
                    pass_array[c].VendorItemID .. "," ..
                    pass_array[c].VendorItemCount
                table.insert(n_array, shop_string)
            end
        else
            for c = 1, #pass_array do
                local zone_id = pass_array[c].VendorItemZoneID
                if zone_id == l_zone_lookup then
                    local shop_string = pass_array[c].VendorItemZoneID .. "," ..
                        pass_array[c].VendorName .. "," ..
                        pass_array[c].VendorItemID .. "," ..
                        pass_array[c].VendorItemCount
                    table.insert(n_array, shop_string)
                end
            end
        end

        pass_shop_array = n_array
        go_shop = 51
    end

    local ign_save = 0
    if ign_save == 1 then
        ImGui.SameLine()
        -- Write artisan toon shopping list to disk
        if ImGui.Button("Save") then
            local skill_used = max_array[l_max_selection]

            local file = "Artisan_MSL_" .. skill_used .. "_" .. mq.TLO.Me() ..
                "_" .. mq.TLO.MacroQuest.Server() .. ".csv"

            file_exist_bool = tcglib.file_exists(file)

            if file_exist_bool then
                local command =
                    'del ' .. mq.luaDir .. '\\TCN\\ShoppingLists\\' .. file
                os.execute(command)
            end



            tcglib.writeshoppinglist("Artisan_MSL_" .. skill_used .. "_" ..
                mq.TLO.Me() .. "_" ..
                mq.TLO.MacroQuest.Server(),
                "Vendor,Item,Count,Unit Price,ID,Zone,ZoneID")

            for sl = 1, #max_recipe_shopping_data do
                local item_shop_item_zone_id =
                    tcglib.return_number(max_recipe_shopping_data[sl], 1)
                local vendor_name = tcglib.return_string(
                    max_recipe_shopping_data[sl], 2)
                local item_id = tcglib.return_number(
                    max_recipe_shopping_data[sl], 3)
                local item_count = tcglib.return_number(
                    max_recipe_shopping_data[sl], 4)
                local item_name = tcglib.return_string(
                    max_recipe_shopping_data[sl], 5)
                local item_price = tcglib.return_number(
                    max_recipe_shopping_data[sl], 6)

                local item_zone = mq.TLO.Zone(item_shop_item_zone_id)()

                if string.find(item_zone, ",") then
                    item_zone = item_zone:gsub(',', '|')
                end

                if string.find(item_name, ",") then
                    item_name = item_name:gsub(',', '|')
                end

                local l_shop_string = vendor_name .. "," .. item_name .. "," ..
                    item_count .. "," .. item_price .. "," ..
                    item_id .. "," .. item_zone .. "," ..
                    item_shop_item_zone_id

                tcglib.writeshoppinglist(
                    "Artisan_TSL_" .. skill_used .. "_" .. mq.TLO.Me() .. "_" ..
                    mq.TLO.MacroQuest.Server(), l_shop_string)
                -- print(l_shop_string)
            end
        end

        -- Load shopping list to buy method?

        ImGui.SameLine()
        HelpMarker("Saves Mass Shopping Data to " .. mq.luaDir ..
            "\\TCN\\ShoppingLists\\ " .. " Directory")

        local skill_used = max_array[l_max_selection]

        local file =
            "Artisan_MSL_" .. skill_used .. "_" .. mq.TLO.Me() .. "_" ..
            mq.TLO.MacroQuest.Server() .. ".csv"

        file_exist_bool = tcglib.file_exists(file)

        if file_exist_bool then
            ImGui.SameLine()
            ImGui.TextColored(0, 1, 0, 1, "File Exists")
        else
            ImGui.SameLine()
            ImGui.TextColored(1, 1, 0, 1, "File Not Created")
        end
    end

    ImGui.SameLine()
    if ImGui.Button("Open Folder") then
        -- Open Windows Directory
        os.execute("start " .. mq.luaDir .. "\\TCN\\ShoppingLists")
    end

    ImGui.SameLine()
    HelpMarker("Open Folder " .. mq.luaDir .. "\\TCN\\ShoppingLists\\ ")

    ImGui.SameLine()
    if ImGui.Button("Close") then
        OPENToonShoppingListGUI = false
        pass_array = {}
        GLOBAL_TEXT = "Idle"
    end

    ImGui.Separator()

    ImGui.Text("Est. Total Platinum: " .. amount_total * .001)
    ImGui.SameLine()
    ImGui.Text("Est. Tradeskill Slots Needed: (" .. #pass_array .. ")")

    amount_total = 0

    ImGui.Text("Select Vendor Zone To Shop:")
    ImGui.SameLine()
    ImGui.SetNextItemWidth(180)
    pass_zone_select, _ = ImGui.Combo("##zone_list", pass_zone_select,
        pass_zone_array, #pass_zone_array,
        #pass_zone_array)

    ImGui.SameLine()
    HelpMarker("Will shop specific zone based on drop-down selection.")

    ImGui.End()
end

function MaxShoppingListWindow()
    if max_recipe_shopping_data[1] == nil then
        ImGui.Text("No Data")
        return
    end

    -- if not openMaxShoppingListGUI then return end

    -- ImGui.SetWindowSize(700, 280)
    -- ImGui.SetWindowFontScale(1)
    -- remd  ImGui.SetCursorPosX(4)

    if name_select ~= nil then
        ImGui.Text(name_select .. " Recipe ID: " .. id_select)
        ImGui.SameLine()
        ImGui.Text("Legend")
        ImGui.SameLine()
        ImGui.TextColored(.3, 1, 1, 1, "Buy From Vendor")
        ImGui.SameLine()
        ImGui.TextColored(0, 1, 0, 1, "Local Inventory")
    end

    local amount_total = 0

    local flags = bit32.bor(ImGuiTableFlags.Resizable,
        ImGuiTableFlags.Reorderable,
        ImGuiTableFlags.Hideable,
        ImGuiTableFlags.MultiSortable,
        ImGuiTableFlags.Sortable, ImGuiTableFlags.RowBg,
        ImGuiTableFlags.BordersOuter,
        ImGuiTableFlags.BordersV,
        ImGuiTableFlags.NoBordersInBody,
        ImGuiTableFlags.ScrollY)

    if ImGui.BeginTable('##mass_recipe_shopping_table', 7, flags, 0,
            TEXT_BASE_HEIGHT * 12, 0.0) then
        local ColumnID_Request = 10

        ImGui.TableSetupColumn('Name', ImGuiTableColumnFlags.WidthAuto, -1.0,
            ColumnID_Name)
        ImGui.TableSetupColumn('Price', ImGuiTableColumnFlags.WidthAuto, -1.0,
            ColumnID_Price)
        ImGui.TableSetupColumn('Count', ImGuiTableColumnFlags.WidthFixed, -1.0,
            ColumnID_Quantity)
        ImGui.TableSetupColumn('ID', ImGuiTableColumnFlags.WidthFixed, -1.0,
            ColumnID_ID)
        ImGui.TableSetupColumn('Vendor', ImGuiTableColumnFlags.WidthStretch,
            -1.0, ColumnID_Vendor)
        ImGui.TableSetupColumn('Zone', ImGuiTableColumnFlags.WidthAuto, -1.0,
            ColumnID_ZoneName)
        ImGui.TableSetupColumn('Request', ImGuiTableColumnFlags.WidthAuto, -1.0,
            ColumnID_Request)
        ImGui.TableSetupScrollFreeze(0, 1) -- Make row always visible

        local sort_specs = ImGui.TableGetSortSpecs()

        if sort_specs then
            if sort_specs.SpecsDirty then
                if #converted_mass_shopping_data > 1 then
                    current_sort_specs = sort_specs
                    table.sort(converted_mass_shopping_data,
                        CompareWithSortSpecs)
                    current_sort_specs = nil
                end
                sort_specs.SpecsDirty = false
            end
        end

        -- Display data
        ImGui.TableHeadersRow()

        for iter = 1, #max_recipe_shopping_data do
            amount_total = amount_total +
                tcglib.return_number(
                    max_recipe_shopping_data[iter], 6)
            -- *
            -- tcglib.return_number(max_recipe_shopping_data[iter], 4)
        end

        local clipper = ImGuiListClipper.new()
        clipper:Begin(#converted_mass_shopping_data)
        while clipper:Step() do
            for row_n = clipper.DisplayStart, clipper.DisplayEnd - 1, 1 do
                local r_col, g_col, b_col = .3, 1, 1
                local convert_item = converted_mass_shopping_data[row_n + 1]
                ImGui.PushID(convert_item)
                if string.find(convert_item.Name, "@") then
                    convert_item.Name = convert_item.Name:gsub('@', ',')
                end
                ImGui.TableNextRow()
                ImGui.TableNextColumn()
                if mq.TLO.FindItemCount(convert_item.ID)() >=
                    convert_item.Quantity then
                    r_col = 0
                    g_col = 1
                    b_col = 0
                end
                ImGui.TextColored(r_col, g_col, b_col, 1, convert_item.Name)
                ImGui.TableNextColumn()
                ImGui.Text(convert_item.Price)
                ImGui.TableNextColumn()
                ImGui.Text(convert_item.Quantity)
                ImGui.TableNextColumn()
                ImGui.Text(string.format(convert_item.ID))
                ImGui.TableNextColumn()
                ImGui.Text(convert_item.Vendor)
                ImGui.TableNextColumn()
                if convert_item.ZoneID ~= 202 then
                    r_col = 0
                    g_col = 1
                    b_col = 1
                else
                    r_col = 1
                    g_col = 1
                    b_col = 1
                end
                ImGui.TextColored(r_col, g_col, b_col, 1, convert_item.ZoneName)

                ImGui.TableNextColumn()
                if ImGui.Button("Request") then
                    GLOBAL_TEXT =
                    "Requesting Artisan Single Missing Component via DanNet"
                    request_array_list = {}
                    local have_count = mq.TLO.FindItemCount(convert_item.ID)()
                    local current_qty = convert_item.Quantity
                    if have_count > 0 then
                        current_qty = current_qty - have_count
                    end
                    -- add condition checks in here
                    local request_string = convert_item.ID .. "," .. current_qty
                    if current_qty > 0 then
                        table.insert(request_array_list, request_string)
                    end
                    if request_array_list[1] ~= nil then
                        go_ask = 1
                    else
                        GLOBAL_TEXT = "Nothing to request via DanNet"
                    end
                end

                ImGui.PopID()
            end
        end

        ImGui.EndTable()
    end

    if ImGui.Button("Request Mass Vendored Items") then
        GLOBAL_TEXT = "Requesting Mass Vendor Components via DanNet"
        request_array_list = {}
        for x = 1, #max_recipe_shopping_data do
            local request_item_id = tcglib.return_number(
                max_recipe_shopping_data[x], 3)
            local request_item_count = tcglib.return_number(
                max_recipe_shopping_data[x], 4)
            local have_count = mq.TLO.FindItemCount(request_item_id)()

            if have_count > 0 then
                request_item_count = request_item_count - have_count
            end

            -- Add condition checks in here
            local request_string = request_item_id .. "," .. request_item_count

            if request_item_count > 0 then
                table.insert(request_array_list, request_string)
            end
        end
        --   for x = 1, #request_array_list do print(request_array_list[x]) end
        if request_array_list[1] ~= nil then
            go_ask = 1
        else
            GLOBAL_TEXT = "Nothing to request via DanNet"
        end
    end
    ImGui.SameLine()
    HelpMarker(
        "Queries other characters in zone for vendor items, and delivers from inventory or bank.")

    ImGui.SameLine()
    if ImGui.Button("Shop") then
        local l_zone_lookup = mq.TLO.Zone(mass_zone_array[mass_zone_select])
            .ID()
        local n_array = {}
        if l_zone_lookup == nil then
            mass_shop_array = max_recipe_shopping_data
        else
            for c = 1, #max_recipe_shopping_data do
                local zone_id = tcglib.return_number(
                    max_recipe_shopping_data[c], 1)
                if zone_id == l_zone_lookup then
                    table.insert(n_array, max_recipe_shopping_data[c])
                end
            end
            mass_shop_array = n_array
        end
        -- for c = 1, #mass_shop_array do print(mass_shop_array[c]) end
        go_shop = 42
    end

    ImGui.SameLine()
    -- Write artisan farm shopping list to disk
    if ImGui.Button("Save") then
        local skill_used = max_array[l_max_selection]

        local file =
            "Artisan_MSL_" .. skill_used .. "_" .. mq.TLO.Me() .. "_" ..
            mq.TLO.MacroQuest.Server() .. ".csv"

        local file_exist_bool = tcglib.file_exists(file)

        -- local file_locked = tcglib.is_file_locked(file)

        if file_exist_bool then
            local command = 'del ' .. mq.luaDir .. '\\TCN\\ShoppingLists\\' ..
                file
            os.execute(command)
        end

        -- print(file)

        tcglib.writeshoppinglist("Artisan_MSL_" .. skill_used .. "_" ..
            mq.TLO.Me() .. "_" ..
            mq.TLO.MacroQuest.Server(),
            "Vendor,Item,Count,Unit Price,ID,Zone,ZoneID")

        for sl = 1, #converted_mass_shopping_data do
            local item_id = converted_mass_shopping_data[sl].ID
            local item_count = converted_mass_shopping_data[sl].Quantity
            local item_name = converted_mass_shopping_data[sl].Name
            local vendor_name = converted_mass_shopping_data[sl].Vendor
            local item_shop_item_zone_id =
                converted_mass_shopping_data[sl].ZoneID
            local item_price = converted_mass_shopping_data[sl].Price
            -- print(item_id, " ",item_count, " ",item_name)
            if string.find(item_name, ",") then
                item_name = item_name:gsub(',', '|')
            end

            local item_zone = mq.TLO.Zone(item_shop_item_zone_id)()

            if string.find(item_zone, ",") then
                item_zone = item_zone:gsub(',', '|')
            end

            if string.find(item_name, ",") then
                item_name = item_name:gsub(',', '|')
            end

            local l_shop_string = vendor_name .. "," .. item_name .. "," ..
                item_count .. "," .. item_price .. "," ..
                item_id .. "," .. item_zone .. "," ..
                item_shop_item_zone_id
            tcglib.writeshoppinglist("Artisan_MSL_" .. skill_used .. "_" ..
                mq.TLO.Me() .. "_" ..
                mq.TLO.MacroQuest.Server(),
                l_shop_string)
            -- print(l_shop_string)
        end
    end

    -- Load shopping list to buy method?

    ImGui.SameLine()
    HelpMarker("Saves Mass Shopping Data to " .. mq.luaDir ..
        "\\TCN\\ShoppingLists\\ " .. " Directory")

    local skill_used = max_array[l_max_selection]

    local file = "Artisan_MSL_" .. skill_used .. "_" .. mq.TLO.Me() .. "_" ..
        mq.TLO.MacroQuest.Server() .. ".csv"

    local file_exist_bool = tcglib.file_exists(file)

    if file_exist_bool then
        ImGui.SameLine()
        ImGui.TextColored(0, 1, 0, 1, "File Exists")
    else
        ImGui.SameLine()
        ImGui.TextColored(1, 1, 0, 1, "File Not Created")
    end

    ImGui.SameLine()
    if ImGui.Button("Open Folder") then
        -- Open Windows Directory
        os.execute("start " .. mq.luaDir .. "\\TCN\\ShoppingLists")
    end

    ImGui.SameLine()
    HelpMarker("Open Folder " .. mq.luaDir .. "\\TCN\\ShoppingLists\\ ")

    --  ImGui.SameLine()
    -- if ImGui.Button("Close Window") then
    --  max_recipe_shopping_data = {}
    --  GLOBAL_TEXT = "Idle"
    -- end

    -- ImGui.SameLine()

    ImGui.Text("Est. Total Platinum: " .. amount_total * .001)
    ImGui.SameLine()
    ImGui.Text("Est. Tradeskill Slots Needed: (" .. #max_recipe_shopping_data ..
        ")")
    amount_total = 0

    ImGui.Text("Select Vendor Zone To Shop:")
    ImGui.SameLine()
    ImGui.SetNextItemWidth(180)
    mass_zone_select, _ = ImGui.Combo("##zone_list", mass_zone_select,
        mass_zone_array, #mass_zone_array,
        #mass_zone_array)

    ImGui.SameLine()
    HelpMarker("Will shop specific zone based on drop-down selection.")

    --  ImGui.End()

    -- return
end

function BatchMakeWindow()
    local cc = 0
    local temp_batch_arr = {}

    if batch_window_openGUI == false then return end

    if batch_array[1] == nil then return end

    -- pos_x, pos_y = ImGui.GetWindowPos()
    -- print(pos_x," ",pos_y)

    ImGui.Begin("TCSNeXt Batch Recipe List", batch_window_openGUI) -- ,     ImGuiWindowFlags.AlwaysAutoResize)

    ImGui.SetWindowSize(800, 800)

    ImGui.SetWindowFontScale(1)
    -- remd  ImGui.SetCursorPosX(4)

    if name_select ~= nil then
        -- ImGui.Text(name_select .. "  Selected Recipe ID: " .. id_select)
    end

    -- local flags = bit32.bor(ImGuiTableFlags.Resizable,
    --   ImGuiTableFlags.Reorderable,
    --   ImGuiTableFlags.Hideable,
    --   ImGuiTableFlags.MultiSortable,
    --   ImGuiTableFlags.Sortable, ImGuiTableFlags.RowBg,
    --    ImGuiTableFlags.BordersOuter,
    --    ImGuiTableFlags.BordersV,
    --     ImGuiTableFlags.NoBordersInBody,
    --      ImGuiTableFlags.ScrollY)

    local flags = bit32.bor(ImGuiTableFlags.Resizable,
        ImGuiTableFlags.Reorderable,
        ImGuiTableFlags.Hideable,
        ImGuiTableFlags.MultiSortable,
        ImGuiTableFlags.Sortable, ImGuiTableFlags.RowBg,
        ImGuiTableFlags.BordersOuter,
        ImGuiTableFlags.BordersV,
        ImGuiTableFlags.NoBordersInBody,
        ImGuiTableFlags.ScrollY)

    if ImGui.BeginTable('##batch_recipe_stack_table', 5, flags, 0,
            TEXT_BASE_HEIGHT * 16, 0.0) then
        local ColumnID_RecipeID = 0
        local ColumnID_RecipeName = 1
        local ColumnID_ItemCount = 2
        local ColumnID_ItemHave = 3
        local ColumnID_Remove = 4

        ImGui.TableSetupColumn('Recipe ID', ImGuiTableColumnFlags.WidthFixed,
            -1.0, ColumnID_RecipeID)

        --  ImGui.TableSetupColumn('Item ID', ImGuiTableColumnFlags.WidthFixed,
        --    -1.0, ColumnID_ItemName)

        ImGui.TableSetupColumn('Recipe Name', ImGuiTableColumnFlags.WidthAuto,
            -1.0, ColumnID_ItemCount)

        ImGui.TableSetupColumn('Want', ImGuiTableColumnFlags.WidthStretch, -1.0,
            ColumnID_RecipeName)

        ImGui.TableSetupColumn('Inventory Count',
            ImGuiTableColumnFlags.WidthStretch, -1.0,
            ColumnID_ItemHave)

        ImGui.TableSetupColumn('Remove', ImGuiTableColumnFlags.WidthStretch,
            -1.0, ColumnID_Remove)

        ImGui.TableSetupScrollFreeze(0, 1) -- Make row always visible
        -- Display data
        ImGui.TableHeadersRow()

        local clipper = ImGuiListClipper.new()
        clipper:Begin(#batch_array)

        while clipper:Step() do
            for row_n = clipper.DisplayStart, clipper.DisplayEnd - 1, 1 do
                local batch_array_items = batch_array[row_n + 1]
                ImGui.PushID(batch_array_items)
                local r_col, g_col, b_col = 0, 1, 0

                -- Item ID
                local stack_recipe_item_id = batch_array_items.BatchItemID

                -- Recipe ID
                local stack_recipe_id = batch_array_items.BatchItemRecipe

                -- Recipe Name
                local l_recipe_name = batch_array_items.BatchItemName

                if string.find(l_recipe_name, "@") then
                    l_recipe_name = l_recipe_name:gsub('@', ',')
                end

                -- Buy Count
                local recipe_stack_buy = batch_array_items.BatchItemMake

                --  ImGui.PushID('batch_recipe_stack_data')

                ImGui.TableNextRow()
                ImGui.TableNextColumn()

                -- Recipe ID
                ImGui.Text(stack_recipe_id)
                --   ImGui.TextColored(r_col, g_col, b_col, 1, stack_recipe_id)

                ImGui.TableNextColumn()
                -- Recipe Name
                ImGui.Text(l_recipe_name)

                ImGui.TableNextColumn()
                -- Buy Count
                ImGui.TextColored(r_col, g_col, b_col, 1, recipe_stack_buy)

                ImGui.TableNextColumn()
                -- Inventory Count
                local b_inv_count = mq.TLO.FindItemCount(stack_recipe_item_id)()

                if b_inv_count >= recipe_stack_buy then
                    ImGui.TextColored(0, 1, 0, 1, b_inv_count)
                else
                    ImGui.TextColored(1, 1, 0, 1, b_inv_count)
                end

                ImGui.TableNextColumn()

                if ImGui.SmallButton("Remove") then
                    for c = 1, #batch_array do
                        if batch_array[c].BatchItemRecipe == stack_recipe_id then
                            cc = 100
                        else
                            table.insert(temp_batch_arr, batch_array[c])
                        end
                    end
                end

                ImGui.PopID()
            end
        end

        ImGui.EndTable('batch_recipe_stack_table')
    end

    if ImGui.Button("Execute Batch") then go_batch = 1 end

    ImGui.SameLine()
    if ImGui.Button("Clear Batch") then
        BATCH_FARM_LIST = {}
        BATCH_SHOPPING_DATA = {}
        BATCH_ZONE_ARRAY = {}
        BATCH_BANK_ARRAY = {}
        batch_window_openGUI = false
        batch_array = {}
        ret_batch_depot_data = {}
    end

    ImGui.SameLine()
    if ImGui.Button("Generate Batch List") then
        BATCH_FARM_LIST = {}
        BATCH_SHOPPING_DATA = {}
        BATCH_ZONE_ARRAY = {}
        BATCH_BANK_ARRAY = {}
        ret_batch_depot_data = {}
        go_batch = 72
    end

    -- copy temp_batch_arr to batch_array - items removed
    if cc > 0 then
        batch_array = temp_batch_arr
        cc = 0
    end

    ImGui.Separator()

    BW_OPEN = false

    if BATCH_FARM_LIST ~= nil or BATCH_SHOPPING_DATA ~= nil or
        ret_batch_depot_data ~= nil then
        BatchInfoWindow()
    end

    --  ImGui.SameLine()
    -- HelpMarker(
    --    "Queries other characters in zone for missing recipes, and delivers from inventory or bank.")

    ImGui.End()
end

local function ArtisanPrizeCraftSettings()
    -- Don't use multipliers to shop
    USE_MULT = false
    BUY_MULT = 1

    -- Use specific fish for augment max
    FISH_SCALE_SWAP = false

    OPENToonShoppingListGUI = false

    -- remd  ImGui.SetCursorPosX(4)

    destroy_max_bool, _ = ImGui.Checkbox("Destroy###Destroy350",
        destroy_max_bool)

    if destroy_max_bool then
        GLOBAL_MAX_DESTROY_FLAG = 1
    else
        GLOBAL_MAX_DESTROY_FLAG = 0
    end

    ImGui.SameLine()
    sell_max_bool, _ = ImGui.Checkbox("Sell Threshold###Sell350", sell_max_bool)

    ImGui.SameLine()
    ImGui.SetNextItemWidth(150)
    GLOBAL_MAX_SELL_THRESHOLD, _ = ImGui.SliderInt(
        '##SliderInt_MaxSellThreshold',
        GLOBAL_MAX_SELL_THRESHOLD, 0, 500, "%d")

    if sell_max_bool then
        GLOBAL_MAX_SELL_FLAG = 1
    else
        GLOBAL_MAX_SELL_FLAG = 0
    end

    ImGui.SameLine()
    bank_max_bool, _ = ImGui.Checkbox("Bank###Bank350", bank_max_bool)
    ImGui.SameLine()
    HelpMarker(
        "Bank Every Main Recipe Item That Is Tradeskill Flagged And Used For Maxing The Artisan Prize.")
    if bank_max_bool then
        GLOBAL_MAX_BANK_FLAG = 1
    else
        GLOBAL_MAX_BANK_FLAG = 0
    end

    ImGui.SameLine()
    ImGui.Text("Delay")
    ImGui.SameLine()
    ImGui.SetNextItemWidth(80)
    GLOBAL_MAX_TIMER, _ = ImGui.InputInt('##timerint###timeritnstandard',
        GLOBAL_MAX_TIMER, 15, 15,
        ImGuiInputTextFlags.None)
    if GLOBAL_MAX_TIMER < 0 then GLOBAL_MAX_TIMER = 0 end
    if GLOBAL_MAX_TIMER > 600 then GLOBAL_MAX_TIMER = 600 end
    ImGui.SameLine()
    HelpMarker("Sets delay in seconds between recipe attempts.")

    ImGui.SameLine()
    continue_max_bool, _ = ImGui.Checkbox("Continue###Full350",
        continue_max_bool)
    if continue_max_bool then
        GLOBAL_MAX_CONT = 1
    else
        GLOBAL_MAX_CONT = 0
    end

    ImGui.SameLine()
    HelpMarker("Continue, or die trying.")

    ImGui.SameLine()
    cheap_max_bool, _ = ImGui.Checkbox("Frugal###Cheap350", cheap_max_bool)

    if cheap_max_bool then
        GLOBAL_MAX_CRAFT_ROUTINE = 1
    else
        GLOBAL_MAX_CRAFT_ROUTINE = 0
    end

    ImGui.SameLine()
    HelpMarker(
        "Cheap, efficent, and slow crafting, watching paint drying endeavor.")

    if cheap_max_bool then continue_max_bool = false end

    ImGui.SameLine()
    info_max_bool, _ = ImGui.Checkbox("Info###Info350", info_max_bool)

    if info_max_bool then
        GLOBAL_INFO_MAX = 1
    else
        GLOBAL_INFO_MAX = 0
    end

    -- Show main artisan window
    if GLOBAL_INFO_MAX == 1 then MainArtisanInfoWindow() end

    ImGui.SameLine()
    HelpMarker(
        "Display list of known and unknown recipes after processing the list.")

    if cheap_max_bool then continue_max_bool = false end

    ImGui.SameLine()
    GLOBAL_THREEFITTY, _ = ImGui.Checkbox("350###Stop350", GLOBAL_THREEFITTY)

    ImGui.SameLine()
    HelpMarker("If checked, stops when you reach skill level 250/350")

    ImGui.SameLine()
    new_engine_bool, _ = ImGui.Checkbox("Eng###Engine350", new_engine_bool)

    if new_engine_bool then
        GLOBAL_ENGINE_FLAG = true
    else
        GLOBAL_ENGINE_FLAG = false
    end

    ImGui.SameLine()
    HelpMarker(
        "If checked, use new method to mass generate list (FASTER) (EXPERIMENTAL)")

    if ImGui.Button("Load Recipes") then
        GLOBAL_MAX_KNOWN = 0
        GLOBAL_MAX_HOWMANY = 0
        GLOBAL_MAX_START = 1
        t_max_selection = max_array[l_max_selection]
        GLOBAL_TEXT = "Loading Artisan Prize: " .. t_max_selection .. " Recipes"
        go_max = 1
    end

    ImGui.SetNextItemWidth(130)

    ImGui.SameLine()

    if max_array[1] ~= nil then
        l_max_selection, _ = ImGui.Combo("##max_list", l_max_selection,
            max_array, #max_array, #max_array)
    end

    if l_max_index ~= l_max_selection and max_array[1] ~= nil then
        GLOBAL_MAX_KNOWN = 0
        GLOBAL_MAX_HOWMANY = 0

        t_max_selection = max_array[l_max_selection]

        GLOBAL_TEXT = "Loading Artisan Prize: " .. t_max_selection .. " Recipes"

        GLOBAL_MAX_START = 1

        go_max = 1

        l_max_index = l_max_selection
    end

    ImGui.SameLine()
    local art_skill = max_array[l_max_selection]
    ImGui.Text(" Skill: " .. mq.TLO.Me.Skill(art_skill)())

    if go_max == 0 and GLOBAL_MAX_HOWMANY ~= 0 then
        -- Green
        ImGui.PushStyleColor(ImGuiCol.Button, 0, 0.65, 0, 1)
        ImGui.SameLine()
        if ImGui.Button("Go") -- and max_recipe_array[1] ~= nil
        then
            GLOBAL_STANDARD_UI = 0
            GLOBAL_MISSING_SPAM = 1
            GLOBAL_MAX_CRAFTING = 1
            go_max = 2
            max_farm_list = {}
            max_recipe_shopping_data = {}
            mass_bank_array = {}
            GLOBAL_TOOL_RECIPE = 1
        end
        ImGui.PopStyleColor(1)
    else
        if go_max == 1 then
            -- Orange
            ImGui.PushStyleColor(ImGuiCol.Button, .67, .33, 0, 1)
            ImGui.SameLine()
            ImGui.Button("Go")
            ImGui.PopStyleColor(1)
        else
            -- Blue
            if go_max == 2 then
                ImGui.PushStyleColor(ImGuiCol.Button, 0, 0, 0.65, 1)
                ImGui.SameLine()
                ImGui.Button("Go")

                ImGui.PopStyleColor(1)
            else
                if GLOBAL_MAX_HOWMANY == 0 and max_recipe_array[1] == nil then
                    ImGui.PushStyleColor(ImGuiCol.Text, 1, 1, 1, 1)
                    ImGui.SameLine()
                    ImGui.Button("Go")
                    ImGui.PopStyleColor(1)
                end
            end
        end
    end

    local tcg_script_status = mq.TLO.Lua.Script('tcn').Status()
    -- print(tcg_script_status)

    if tcg_script_status == "RUNNING" then
        set_artisan_text_color_r = 0
        set_artisan_text_color_g = .2
        set_artisan_text_color_b = .3
    end

    if tcg_script_status == "PAUSED" then
        set_artisan_text_color_r = 1
        set_artisan_text_color_g = 0
        set_artisan_text_color_b = 0
    end

    if artisan_button_pause_bool then
        if mq.TLO.Nav.Active() then
            mq.cmd('/squelch /nav pause')
        else
            if mq.TLO.Nav.Paused() then mq.cmd('/squelch /nav pause') end
        end
        mq.cmd('/squelch /lua pause tcn')
    end

    ImGui.SameLine()
    ImGui.PushStyleColor(ImGuiCol.Button, set_artisan_text_color_r,
        set_artisan_text_color_g, set_artisan_text_color_b, 1)
    artisan_button_pause_bool, _ = ImGui.Button("Pause")
    ImGui.PopStyleColor(1)

    if GLOBAL_MAX_KNOWN ~= 0 then
        ImGui.SameLine()
        ImGui.Text(GLOBAL_MAX_KNOWN .. " of " .. GLOBAL_MAX_HOWMANY ..
            " Recipes known")
        --  Make more precise later
        local pct_calc = GLOBAL_MAX_KNOWN / GLOBAL_MAX_HOWMANY
        ImGui.SameLine()
        ImGui.ProgressBar(pct_calc, 100, 22)
    end

    if GLOBAL_MAX_KNOWN < 1 then
        ImGui.SameLine()
        ImGui.Text("0 of " .. GLOBAL_MAX_HOWMANY .. " Recipes known")
        --  Make more precise later
        ImGui.SameLine()
        ImGui.ProgressBar(0, 100, 22)
    end

    ImGui.SameLine()
    if ImGui.Button("Abort") then
        GLOBAL_ABORT_FLAG = 1
        if mq.TLO.Nav.Active() then mq.cmd('/squelch /nav stop') end
    end
    ImGui.SameLine()
    HelpMarker("Aborts current activity and stops navigation.")

    ImGui.SameLine()
    if ImGui.Button('Exit') then
        if GLOBAL_MQ2TSTrophy_Plugin == 1 then
            --  print(msg, "\ap[\awLoading: \agMQ2TSTrophy \awplugin\ap]")
            mq.cmd('/squelch /plugin MQ2TSTrophy load')
        end

        if mq.TLO.Nav.Active() then mq.cmd('/squelch /nav stop') end
        -- mq.cmd('/squelch /lua stop tcxx')
        mq.exit()
    end
    ImGui.SameLine()
    HelpMarker("Exits GUI and stops all TCG processes.")

    -- If it returns nothing then don't show button..
    if max_recipe_array[1] == nil then
        ImGui.TextColored(.6, .3, 0, 1,
            "Generate Mass List: Inactive, please load recipes or select the drop down")
    else
        -- Mass Farm List
        if ImGui.Button("Generate Mass List ") then
            PCT_DONE = 0
            art_max_farm_list = {}
            GLOBAL_SOILED_ARRAY = {}
            MASS_gh_bank_array = {}
            MASS_dh_bank_array = {}

            openShoppingListGUI = false

            mass_bank_array = {}
            quest_farm_list = {}
            max_recipe_shopping_data = {}
            go_max = 3
            GLOBAL_TOOL_RECIPE = 0
        end

        ImGui.SameLine()
        HelpMarker(
            "Generate complete list of missing components for all recipes for selected tradeskill.")

        ImGui.SameLine()
        -- Max Generate 30 Recipes
        max_generate_cb, _ = ImGui.Checkbox("Recipes", max_generate_cb)

        -- Show total remaining recipes in drop down if under 10
        if #max_recipe_array < 10 then
            GEN_array = { tostring(#max_recipe_array) }
        else
            GEN_array = { "10", "20", "30", "40", "50", "75", "100" }
        end

        -- No recipes to learn
        if #max_recipe_array < 1 then GEN_array = { "0" } end

        ImGui.SameLine()
        ImGui.SetNextItemWidth(50)
        GEN_selection, _ = ImGui.Combo("##GEN_array", GEN_selection, GEN_array,
            #GEN_array, #GEN_array)

        GLOBAL_MAX_GEN = tonumber(GEN_array[GEN_selection])

        if GEN_selection_index ~= GEN_selection then
            GEN_selection_index = GEN_selection
        end

        if not max_generate_cb then GLOBAL_MAX_GEN = 0 end

        ImGui.SameLine()
        HelpMarker(
            "Will attempt or generate data for selected amount of recipes, if checked.")

        -- how to have global start calculate the recipes based on the start..

        ImGui.SameLine()
        ImGui.SetNextItemWidth(80)
        GLOBAL_MAX_START, _ = ImGui.SliderInt('##SliderInt_MaxStartThreshold',
            GLOBAL_MAX_START, 1,
            #max_recipe_array, "%d")

        ImGui.SameLine()
        ImGui.SetNextItemWidth(1)
        GLOBAL_MAX_START, _ = ImGui.InputInt('##maxstartint###maxintstart',
            GLOBAL_MAX_START, 1, 1,
            ImGuiInputTextFlags.None)
        if GLOBAL_MAX_START < 1 then GLOBAL_MAX_START = 1 end
        if GLOBAL_MAX_START > #max_recipe_array then
            GLOBAL_MAX_START = #max_recipe_array
        end

        ImGui.SameLine()
        HelpMarker("Pick specific recipe to start on for Artisan prize.")

        ImGui.SameLine()

        if go_max == 2 then
            ImGui.TextColored(0, 1, 0, 1, "Attempting: ")
        else
            ImGui.TextColored(0, 1, 0, 1, "Start On: ")
        end

        ImGui.SameLine()
        local return_recipe_name = feeder.recipe_name(
            max_recipe_array[GLOBAL_MAX_START])
        if go_max == 2 then
            ImGui.TextColored(1, 1, .5, 1, GLOBAL_MAX_RECIPE)
        else
            ImGui.TextColored(1, 1, .5, 1, return_recipe_name)
        end
    end

    if GLOBAL_MAX_RECIPE_COUNTER ~= 0 then
        ImGui.SameLine()

        if GLOBAL_MAX_RECIPE_COUNTER == "Processing List..." then
            GLOBAL_MAX_RECIPE_NAME = "Processing Recipe List..."
            ImGui.ProgressBar(100, 100, 22)
        else
            ImGui.ProgressBar(PCT_DONE, 100, 22)
        end
        ImGui.SameLine()
        ImGui.Text(GLOBAL_MAX_RECIPE_NAME)
    end

    if MASS_gh_bank_array[1] == nil then
        ImGui.TextColored(1, 0, 0, 1, "Check Guild Hall Bank")
    end

    if MASS_dh_bank_array[1] == nil then
        ImGui.SameLine()
        ImGui.TextColored(1, 0, 0, 1, "Check Dragon Hoard Bank")
    end

    -- Provide option to check GH bank and automatically withdraw
    if MASS_gh_bank_array[1] ~= nil and mq.TLO.Me.Guild() ~= nil then
        if ImGui.Button("Check Guild Hall Bank") then GO_GUILD_HALL = 1 end
        ImGui.SameLine()
        HelpMarker(
            "Checks for missing farmed items and automatically grabs items from Guild Hall Bank.")
    end

    -- Provide option to check DH bank and automatically withdraw
    if MASS_dh_bank_array[1] ~= nil then
        if MASS_gh_bank_array[1] ~= nil and mq.TLO.Me.Guild() ~= nil then
            ImGui.SameLine()
        end

        if ImGui.Button("Check Dragon Hoard Bank") then
            GO_DRAGON_HOARD = 1
        end

        ImGui.SameLine()
        HelpMarker(
            "Checks for missing farmed items and automatically grabs items from Dragon Hoard Bank.")
    end

    ImGui.Separator()

    -- Show additional info for recipes when list is generated
    if max_recipe_array[1] ~= nil then ArtisanRecipeInfoWindow() end
end

local function TSSWindow()
    -- needs work! watch the pauses

    -- remd  ImGui.SetCursorPosX(4)

    ImGui.Text("Select The Serpent's Spine Quest ")
    ImGui.SameLine()
    ImGui.SetNextItemWidth(150)
    tss_selection, _ = ImGui.Combo("##tss_quests", tss_selection, tss_quests,
        #tss_quests, #tss_quests)
    -- ImGui.SameLine()

    ImGui.SameLine();
    HelpMarker("Select tradeskill freebie for The Serpent's Spine.")

    -- tss_bool_button_label = "Go"
    -- tss_bool_button, _ = ImGui.SmallButton(tss_bool_button_label)

    ImGui.SameLine()

    if ImGui.Button("Do It") then
        --  if script_status_text ~= "RUNNING" then
        mq.cmd('/squelch /lua run tcn/tcn_tss ', tss_selection)
        --  tss_bool_button_label = "Stop"
        --  end
    end

    local tss_script_status = mq.TLO.Lua.Script('tcn/tcn_tss').Status()

    ImGui.SameLine()

    -- Pause TSS
    if ImGui.Button("Pause") then
        if tss_script_status == "RUNNING" then
            if mq.TLO.Nav.Active() then mq.cmd('/squelch /nav pause') end
            mq.cmd('/squelch /lua pause tcn/tcn_tss')
        else
            -- Unpause TSS
            if tss_script_status == "PAUSED" then
                if mq.TLO.Nav.Paused() then
                    mq.cmd('/squelch /nav pause')
                end
                mq.cmd('/squelch /lua pause tcn/tcn_tss')
            end
        end
    end

    ImGui.SameLine()

    if ImGui.Button("Stop") then
        if mq.TLO.Nav.Active() then mq.cmd('/squelch /nav stop') end
        mq.cmd('/squelch /lua stop tcn/tcn_tss')
    end

    ImGui.SameLine()

    if ImGui.Button("Exit") then
        if GLOBAL_MQ2TSTrophy_Plugin == 1 then
            --  print(msg, "\ap[\awLoading: \agMQ2TSTrophy \awplugin\ap]")
            mq.cmd('/squelch /plugin MQ2TSTrophy load')
        end

        if mq.TLO.Nav.Active() or mq.TLO.Me.Moving() then
            mq.cmd('/squelch /nav stop')
        end

        mq.cmd('/squelch /lua stop tcn/tcn_tss')
        mq.exit()
        -- mq.cmd('/squelch /lua stop tcxx')
    end

    if tss_script_status ~= nil then
        ImGui.SameLine()
        if tss_script_status == "EXITED" then
            tss_script_status = "STOPPED"
        end
        ImGui.Text(tss_script_status)
    end
end

local function GODWindow()
    -- remd  ImGui.SetCursorPosX(4)

    script_status_text = mq.TLO.Lua.Script('tcn/tcn_god').Status()

    ImGui.Text("Select Gates of Discord Quest ")
    ImGui.SameLine()
    ImGui.SetNextItemWidth(150)
    god_selection, _ = ImGui.Combo("##god_quests", god_selection, god_quests,
        #god_quests, #god_quests)

    ImGui.SameLine()

    god_bool_button, _ = ImGui.SmallButton(god_action_button)

    -- Stop GOD
    if god_bool_button and god_action_button == "Stop" then
        mq.cmd('/squelch /nav stop')
        mq.cmd('/squelch /lua stop tcn/tcn_god')
        god_action_button = "Go"
        god_button_label = "Pause"
    else
        -- Go GOD
        if god_bool_button and god_action_button == "Go" then
            if script_status_text ~= "RUNNING" then
                mq.cmd('/lua run tcn/tcn_god ', god_selection)
                god_action_button = "Stop"
            end
        end
    end

    ImGui.SameLine()

    god_button_pause_bool, _ = ImGui.SmallButton(god_button_label)

    -- Pause GOD
    if god_button_pause_bool and god_button_label == "Pause" then
        if script_status_text == "RUNNING" then
            if mq.TLO.Nav.Active() then mq.cmd('/squelch /nav pause') end
            mq.cmd('/squelch /lua pause tcn/tcn_god :on')
            god_button_label = "Unpause"
        end
    else
        -- Unpause GOD
        if god_button_pause_bool and god_button_label == "Unpause" then
            if script_status_text == "PAUSED" then
                if mq.TLO.Nav.Paused() then
                    mq.cmd('/squelch /nav pause')
                end
                mq.cmd('/squelch /lua pause tcn/tcn_god :off')
                god_button_label = "Pause"
            end
        end
    end

    ImGui.SameLine()

    if ImGui.Button('Exit') then
        if GLOBAL_MQ2TSTrophy_Plugin == 1 then
            --  print(msg, "\ap[\awLoading: \agMQ2TSTrophy \awplugin\ap]")
            mq.cmd('/squelch /plugin MQ2TSTrophy load')
        end

        if mq.TLO.Nav.Active() then mq.cmd('/squelch /nav stop') end
        mq.cmd('/squelch /lua stop tcn/tcn_god')
        mq.exit()
        -- mq.cmd('/squelch /lua stop tcxx')
    end

    ImGui.SameLine()
    if script_status_text ~= nil then ImGui.Text(script_status_text) end
end

-----------------------------------

local function ItemLookup()
    -- ?
    GLOBAL_TOOL_RECIPE = 1

    -- remd  ImGui.SetCursorPosX(4)

    -- Add break down of a recipe to the search

    -- Add break down of a recipe to the search

    ImGui.SetNextItemWidth(150)
    text_input, _ = ImGui.InputText("##standardlookup##edit", text_input, 128)

    local l_text_length = tonumber(string.len(text_input))

    -- Trigger search on Enter
    local enterPressed = ImGui.IsItemDeactivatedAfterEdit()
        or ImGui.IsKeyPressed(ImGuiKey.Enter)

    ImGui.SameLine()
    if (ImGui.Button("Text Search") or enterPressed) and l_text_length > 0 then
        ITEM_RECIPE_RESULTS_LOOKUP = {}
        --ITEM_RECIPE_RESULTS = feeder.component_search_results(text_input)
        ITEM_RECIPE_RESULTS = feeder.item_recipe_search(text_input, "like")
    end

    ImGui.SameLine()

    click_value, _ = ImGui.Button(lab)

    if click_value and lab == "Execute Query" then
        ITEM_RECIPE_RESULTS_LOOKUP = {}
        -- make this a run go and wait for results by using nil ~=?
        --   ITEM_RECIPE_RESULTS = feeder.component_search_results_single_char(
        --   alphabet[s_combo_box_selected])
        ITEM_RECIPE_RESULTS = feeder.item_recipe_search(alphabet[s_combo_box_selected], "start")
    end

    ImGui.SameLine()
    click_value, _ = ImGui.Button("Clear Query")

    ImGui.SameLine()
    ImGui.SetNextItemWidth(50)
    s_combo_box_selected, _ = ImGui.Combo("##special_alphabet",
        s_combo_box_selected, alphabet,
        #alphabet, 10)

    if s_combo_box_index ~= s_combo_box_selected then
        s_combo_box_index = s_combo_box_selected
    end

    -- Exit everything
    ImGui.SameLine()
    if ImGui.Button('Exit') then
        if GLOBAL_MQ2TSTrophy_Plugin == 1 then
            --  print(msg, "\ap[\awLoading: \agMQ2TSTrophy \awplugin\ap]")
            mq.cmd('/squelch /plugin MQ2TSTrophy load')
        end

        if mq.TLO.Nav.Active() then mq.cmd('/squelch /nav stop') end
        -- make stop function? to stop all scripts
        mq.cmd('/squelch /lua stop tcn\\tcn_quests')
        mq.cmd('/squelch /lua stop tcn\\tcn_god')
        mq.exit()
        -- mq.cmd('/squelch /lua stop tcxx')
    end

    ImGui.Separator()

    -- if ITEM_RECIPE_RESULTS[1] ~= nil then ItemLookupWindow() end

    if click_value then
        ITEM_RECIPE_RESULTS = {}
        ITEM_RECIPE_RESULTS_LOOKUP = {}
        text_input = ""
    end

    -- Show item lookup and swap in same window
    if ITEM_RECIPE_RESULTS_LOOKUP[1] ~= nil then
        ItemLookupResults()
    else
        if ITEM_RECIPE_RESULTS[1] ~= nil then ItemLookupWindow() end
    end

    -- if ITEM_RECIPE_RESULTS_LOOKUP[1] ~= nil then ItemLookupResults() end

    -- ImGui.PopID()
end

-----------------------------------

local function StandardCraftingWindow()
    --  ImGuiInputTextFlags.new  = "none"

    GLOBAL_TOOL_RECIPE = 1

    -- Standard Destroy Checkbox
    standard_destroy_cb, _ = ImGui.Checkbox("Destroy", standard_destroy_cb)

    -- print(GLOBAL_STANDARD_DESTROY_ID)

    -- Standard Destroy Checkbox Logic
    if standard_destroy_cb then
        GLOBAL_STANDARD_DESTROY_ID = l_item_id
    else
        if not standard_destroy_cb then GLOBAL_STANDARD_DESTROY_ID = 0 end
    end

    ImGui.SameLine()
    -- Standard Sell Checkbox
    standard_sell_cb, _ = ImGui.Checkbox("Sell", standard_sell_cb)
    ImGui.SameLine()
    ImGui.Text("Threshold")
    ImGui.SameLine()

    ImGui.SetNextItemWidth(150)
    GLOBAL_STANDARD_SELL_THRESHOLD, _ = ImGui.SliderInt('##SliderInt_Threshold',
        GLOBAL_STANDARD_SELL_THRESHOLD,
        0, 500, "%d")

    ImGui.SameLine()
    ImGui.SetNextItemWidth(1)

    GLOBAL_STANDARD_SELL_THRESHOLD, _ = ImGui.InputInt(
        '##inputint_point###inputstandardpoint',
        GLOBAL_STANDARD_SELL_THRESHOLD, .99,
        500, ImGuiInputTextFlags.None)

    if GLOBAL_STANDARD_SELL_THRESHOLD < 1 then
        GLOBAL_STANDARD_SELL_THRESHOLD = 0
    else
        if GLOBAL_STANDARD_SELL_THRESHOLD > 500 then
            GLOBAL_STANDARD_SELL_THRESHOLD = 500
        end
    end

    -- print(GLOBAL_STANDARD_SELL_THRESHOLD)

    -- Standard Skill up checkbox logic
    if standard_sell_cb then
        GLOBAL_STANDARD_SELL_ID = l_item_id
    else
        if not standard_sell_cb then GLOBAL_STANDARD_SELL_ID = 0 end
    end

    ImGui.SameLine()
    -- Standard Skill-Up Check box
    standard_skill_cb, _ = ImGui.Checkbox("Skill", standard_skill_cb)

    if standard_skill_cb then
        GLOBAL_STANDARD_SKILL_ID = id_select
    else
        if not standard_skill_cb then GLOBAL_STANDARD_SKILL_ID = 0 end
    end

    ImGui.SameLine()
    -- Standard Continue Check box
    standard_continue_cb, _ = ImGui.Checkbox("Continue", standard_continue_cb)

    if standard_continue_cb then
        GLOBAL_STANDARD_AUTOCONTINUE = 1
        --  go_continue = 1
    else
        if not standard_continue_cb then
            GLOBAL_STANDARD_AUTOCONTINUE = 0
            --  go_continue = 0
        end
    end

    ImGui.SameLine()
    HelpMarker(
        "Will attempt to reach a skill level goal or crafting count goal by cycling endlessly, please do not use with destroy.")

    ImGui.SameLine()
    -- Standard UI Check box
    standard_ui_cb, _ = ImGui.Checkbox("UI", standard_ui_cb)
    if standard_ui_cb then
        GLOBAL_STANDARD_UI = 1
    else
        if not standard_ui_cb then GLOBAL_STANDARD_UI = 0 end
    end

    ImGui.SameLine()
    HelpMarker(
        "uses EQ Tradeskill UI to do crafting (Experimental) this is a roadmap item and may not function correctly.")

    ImGui.SameLine()
    ImGui.Text('Qty:')
    ImGui.SameLine()
    ImGui.SetNextItemWidth(100)

    l_make_amount, _ = ImGui.SliderInt('##SliderInt ', l_make_amount, 1, 1000,
        "%d")
    ImGui.SameLine()
    ImGui.SetNextItemWidth(1)

    l_make_amount, _ = ImGui.InputInt('##inputint###inputstandard',
        l_make_amount, 1, 10000,
        ImGuiInputTextFlags.None)

    ImGui.SameLine()
    if ImGui.Button("+1000") then l_make_amount = l_make_amount + 1000 end

    if l_make_amount < 1 then l_make_amount = 1 end
    if l_make_amount > 10000 then l_make_amount = 10000 end

    ImGui.SameLine()
    -- Standard Info Check box
    standard_info_cb, _ = ImGui.Checkbox("Info", standard_info_cb)
    if standard_info_cb then
        OPENInfoWindow = true

        -- openShoppingListGUI = true
        -- openFarmWindowGUI = true
        -- openRecipeRequirementsGUI = true
        -- openRecipeListGUI = true
    else
        if not standard_info_cb then
            OPENInfoWindow = false

            openShoppingListGUI = false
            openFarmWindowGUI = false
            openRecipeRequirementsGUI = false
            --  openRecipeListGUI = false
        end
    end

    if OPENInfoWindow then MainStandardInfoWindow() end

    ImGui.SameLine()
    HelpMarker("Displays information about the selected recipe.")

    ImGui.SetNextItemWidth(110)
    GLOBAL_TXT_INPUT, _ = ImGui.InputText("##standardinfo##edit",
        GLOBAL_TXT_INPUT, 128)

    local l_text_length = tonumber(string.len(GLOBAL_TXT_INPUT))

    ImGui.SameLine()

    local r_col, g_col, b_col

    r_col = 0
    g_col = .3
    b_col = .7

    if l_text_length > 0 then
        r_col = 0
        g_col = .7
        b_col = .3
    end

    if cb_search_type and l_text_length > 0 then
        r_col = .7
        g_col = .3
        b_col = 0
    end

    -- Trigger search on Enter
    local enterPressed = ImGui.IsItemDeactivatedAfterEdit()
        or ImGui.IsKeyPressed(ImGuiKey.Enter)

    ImGui.PushStyleColor(ImGuiCol.Button, r_col, g_col, b_col, 1);

    -- Trigger search on button click or Enter
    if (ImGui.Button("Text Search") or enterPressed) and l_text_length > 0 then
        recipe_search_results = feeder.single_recipe_search_results(
            GLOBAL_TXT_INPUT, search_type_text
        )
    end

    ImGui.PopStyleColor()

    ImGui.SameLine()

    HelpMarker(
        "Type in the recipe name partial or full that you are looking for and click the Text Search button")

    ImGui.SameLine()
    cb_search_type, _ = ImGui.Checkbox("*", cb_search_type)

    if cb_search_type then
        search_type_text = 1
    else
        search_type_text = 0
    end

    ImGui.SameLine()
    HelpMarker("When selected will perform a loose match text search")

    -- ImGui.SameLine()

    -- ImGui.Text("|")

    ImGui.SameLine()

    click_value, _ = ImGui.Button(lab)

    if click_value and lab == "Execute Query" then
        -- recipe_search_results = {}

        -- make this a run go and wait for results by using nil ~=?
        recipe_search_results = feeder.recipe_search_results(
            alphabet[s_combo_box_selected],
            skill_types[s_combo_box_selected_skill])
    end

    ImGui.SameLine()
    click_value, _ = ImGui.Button("Clear Query")

    if click_value then recipe_search_results = {} end

    -- ImGui.SameLine()
    -- ImGui.Text('Letter:')
    ImGui.SameLine()
    ImGui.SetNextItemWidth(50)
    s_combo_box_selected, _ = ImGui.Combo("##special_alphabet",
        s_combo_box_selected, alphabet,
        #alphabet, 10)

    if s_combo_box_index ~= s_combo_box_selected then
        s_combo_box_index = s_combo_box_selected
    end

    -- ImGui.SameLine()
    -- ImGui.Text('Skill:')

    ImGui.SameLine()

    ImGui.SetNextItemWidth(130)
    -- Skill type combo box
    s_combo_box_selected_skill, _ = ImGui.Combo("##skill_list",
        s_combo_box_selected_skill,
        skill_types, #skill_types,
        #skill_types)

    if s_combo_box_index_skill ~= s_combo_box_selected_skill then
        -- local special_skill = specialized_skills[s_combo_box_selected + 1]
        s_combo_box_index_skill = s_combo_box_selected_skill
        -- i_selection, clicked = ImGui.Combo("##toon_item_list", i_selection, itemray, #itemray, 10)
    end

    if skill_select ~= nil then
        ImGui.SameLine()
        ImGui.Text("Skill [" .. mq.TLO.Me.Skill(skill_select)() .. "]")
    end

    ImGui.SameLine()

    local tcg_script_status = mq.TLO.Lua.Script('tcn').Status()

    if tcg_script_status == "RUNNING" then
        set_artisan_text_color_r = 1
        set_artisan_text_color_g = 1
        set_artisan_text_color_b = 1
    end

    if tcg_script_status == "PAUSED" then
        set_artisan_text_color_r = 1
        set_artisan_text_color_g = 0
        set_artisan_text_color_b = 0
    end

    if standard_button_pause_bool then
        if mq.TLO.Nav.Active() then
            mq.cmd('/squelch /nav pause')
        else
            if mq.TLO.Nav.Paused() then mq.cmd('/squelch /nav pause') end
        end

        mq.cmd('/squelch /lua pause tcn :on')
    end

    ImGui.SameLine()
    ImGui.PushStyleColor(ImGuiCol.Text, set_artisan_text_color_r,
        set_artisan_text_color_g, set_artisan_text_color_b, 1)
    standard_button_pause_bool, _ = ImGui.Button("Pause")
    ImGui.PopStyleColor(1)

    ImGui.SameLine()
    -- turn off autocontinue?
    if ImGui.Button('Abort') then
        go_craft = 0
        if mq.TLO.Nav.Active() then mq.cmd('/squelch /nav stop') end
        GLOBAL_ABORT_FLAG = 1
    end

    -- Exit everything
    ImGui.SameLine()
    if ImGui.Button('Exit') then
        if GLOBAL_MQ2TSTrophy_Plugin == 1 then
            --  print(msg, "\ap[\awLoading: \agMQ2TSTrophy \awplugin\ap]")
            mq.cmd('/squelch /plugin MQ2TSTrophy load')
        end

        if mq.TLO.Nav.Active then mq.cmd('/squelch /nav stop') end
        -- make stop function? to stop all scripts
        mq.cmd('/squelch /lua stop tcn\\tcn_quests')
        mq.cmd('/squelch /lua stop tcn\\tcn_god')
        mq.exit()
        -- mq.cmd('/squelch /lua stop tcxx')
    end

    if id_select ~= 0 then
        ImGui.SameLine()
        ImGui.Text('Inv (' .. mq.TLO.FindItemCount(l_item_id)() .. ')')
        ImGui.SameLine()
        ImGui.Text('Bank (' .. mq.TLO.FindItemBankCount(l_item_id)() .. ')')

        -- Color text to show skill is >= trivial
        -- if  mq.TLO.Me.Skill(skill_select)() >= trivial_select then end
        --   ImGui.SameLine()
        --   ImGui.Text(skill_select .. " Skill: (" ..
        --                  mq.TLO.Me.Skill(skill_select)() .. ')')
        --  ImGui.SameLine()
        --  ImGui.Text('Trivial: (' .. trivial_select .. ')')
        -- ImGui.SameLine()
        -- ImGui.Text('Container: (' .. container_select .. ')')
    end

    if GLOBAL_TEXT == "Missing Items" then
        scw_r_col = 1
        scw_g_col = 1
        scw_b_col = 0
        can_craft = 0
    end

    if recipe_shopping_data[1] ~= nil then
        scw_r_col, scw_g_col, scw_b_col = 0, 1, 0
    end

    if trim_soiled == nil and recipe_disposition_data == nil and
        recipe_shopping_data == nil and recipe_stack_data == nil then
    end

    if trim_soiled[1] == nil and recipe_disposition_data[1] == nil and
        recipe_shopping_data[1] == nil and recipe_stack_data[1] ~= nil then
        scw_r_col, scw_g_col, scw_b_col = 0, 1, 0
    end

    if trim_soiled[1] ~= nil or recipe_disposition_data[1] ~= nil then
        go_craft = 0
        can_craft = 0
        scw_r_col, scw_g_col, scw_b_col = .86, .86, 0
    else
        if recipe_shopping_data[1] ~= nil then
            scw_r_col, scw_g_col, scw_b_col = 0, 1, 0
        end
    end

    -- ImGui.SameLine()
    -- Rogue, Shaman, Gnome
    go_no_go_skill_select = tcglib.check_requirement(skill_select)
    if go_no_go_skill_select ~= nil then
        go_craft = 0
        can_craft = 0
    end

    go_no_go_skillreq = tcglib.check_skill(skill_select, skill_req)
    if go_no_go_skillreq ~= nil then
        go_craft = 0
        can_craft = 0
    end

    if override_cb_bool then
        --  GLOBAL_TEXT = "Override Enabled"
        -- scw_g_col, scw_b_col = 0, 1, 0
    end

    ImGui.PushStyleColor(ImGuiCol.Text, scw_r_col, scw_g_col, scw_b_col, 1);

    if can_craft == 1 or override_cb_bool then
        -- print(override_cb_bool)
        craft_button_bool = ImGui.Button("Craft###Craft_ID1")
    else
        ImGui.Button("Craft###Craft_ID1")
    end

    ImGui.PopStyleColor(1);

    if craft_button_bool and id_select > 0 and tonumber(l_make_amount) > 0 and
        can_craft == 1 then
        --   GLOBAL_STANDARD_CRAFTING = 1
        -- turn off global max just for grins?
        GLOBAL_STANDARD_ID = id_select
        go_craft = 1
    end

    ImGui.SameLine()
    GLOBAL_COLLAPSE_CB, _ = ImGui.Checkbox("Trim", GLOBAL_COLLAPSE_CB)

    if GLOBAL_COLLAPSE_CB then
        GLOBAL_COLLAPSE_FLAG = 1
    else
        GLOBAL_COLLAPSE_FLAG = 0
    end

    ImGui.SameLine()
    HelpMarker(
        "[Experimental] Collapse recipe stack and counts. Adds additional processing time, only applies to crafting order")

    -- Standard Override Check box
    ImGui.SameLine()
    override_cb_bool, _ = ImGui.Checkbox("O/R", override_cb_bool)

    ImGui.SameLine()
    HelpMarker(
        "[Override] Ignores inventory and vendor contraints. Will craft all it can.")

    -- ImGui.SameLine()
    -- if ImGui.Button("Override") and id_select > 0 and tonumber(l_make_amount) >

    if craft_button_bool and override_cb_bool and id_select > 0 and
        tonumber(l_make_amount) > 0 then
        GLOBAL_TEXT = "Recipe Override"
        GLOBAL_STANDARD_ID = id_select
        -- can_craft = 1
        go_craft = 1
    end

    -- Fish Swap code..
    ImGui.SameLine()
    FISH_SWAP, _ = ImGui.Checkbox("Fish", FISH_SWAP)

    ImGui.SameLine()
    HelpMarker(
        "Swaps to other fish to use for crafting scale sheet, patch, etc...")

    if FISH_SWAP then
        FISH_SCALE_SWAP = true
    else
        FISH_SCALE_SWAP = false
    end
    -- End Fish Swap Code

    -- Multiplier Code.
    local multi_array = { "1", "2", "3", "4", "5", "6", "7", "8", "9", "10" }

    ImGui.SameLine()

    ImGui.Text("x: ")

    ImGui.SameLine()

    ImGui.SetNextItemWidth(45)

    -- Skill type combo box
    BUY_MULT_selection, _ = ImGui.Combo("##multiplier", BUY_MULT_selection,
        multi_array, #multi_array, #multi_array)

    ImGui.SameLine()
    HelpMarker(
        "Sets shopping multiplier to buy more than is needed to craft, useful when counting on craft failures")

    local value = tonumber(multi_array[BUY_MULT_selection])

    if value > 1 then
        -- print(value)
        BUY_MULT = value
        USE_MULT = true
    end
    -- end Multiplier code

    ImGui.SameLine()

    if ImGui.Button("Favorites") then
        if fav_array[1] ~= nil then
            -- GLOBAL_TEXT = "Adding "..name_select.." to favorites"
            recipe_search_results = feeder.recipe_search_favorites(fav_array)
        else
            GLOBAL_TEXT = "You are not my favorite."
            recipe_search_results = {}
        end
    end

    ImGui.SameLine()

    if id_select > 0 then
        -- check favorite array and change button
        -- read array
        -- sample array

        ImGui.Text(name_select .. " ID: (" .. id_select .. ")")

        -- work on later for icons
        if GLOBAL_STANDARD_CRAFTING_STATUS_MSG ~= nil then
            --   ImGui.Text(GLOBAL_STANDARD_CRAFTING_STATUS_MSG)

            local iniValue = GLOBAL_PURCHASE_ID
        else

        end
    else
        ImGui.Text("No Recipe Selected")
    end

    -- ImGui.PushID('Recipe_Window')

    -- ImGui.PopID()
end

-------------------------------------

local function StandardBatchWindow()
    USE_MULT = true

    -- Standard Destroy Checkbox Logic
    if standard_destroy_cb then
        GLOBAL_STANDARD_DESTROY_ID = l_item_id
    else
        if not standard_destroy_cb then GLOBAL_STANDARD_DESTROY_ID = 0 end
    end

    -- GLOBAL_STANDARD_DESTROY_ID = 0 ??

    GLOBAL_STANDARD_SELL_ID = 0
    GLOBAL_STANDARD_SKILL_ID = 0
    GLOBAL_STANDARD_AUTOCONTINUE = 0

    -- ImGui.SameLine()
    -- Standard UI Check box
    standard_ui_cb, _ = ImGui.Checkbox("UI", standard_ui_cb)
    if standard_ui_cb then
        GLOBAL_STANDARD_UI = 1
    else
        if not standard_ui_cb then GLOBAL_STANDARD_UI = 0 end
    end

    ImGui.SameLine()
    batch_continue_cb, _ = ImGui.Checkbox("Continue", batch_continue_cb)
    if batch_continue_cb then
        GLOBAL_BATCH_CONTINUE = 1
    else
        if not batch_continue_cb then GLOBAL_BATCH_CONTINUE = 0 end
    end

    -- Set batch filename
    local batch_filename = "batch_" .. mq.TLO.Me() .. "_" ..
        mq.TLO.MacroQuest.Server() .. ".csv"

    -- Load/Save/Delete batch file

    ImGui.SameLine()

    local r1, g1, b1

    r1 = 0
    g1 = .3
    b1 = .7

    if BATCH_OPS_WINDOW_GUI then
        r1 = 0
        g1 = .7
        b1 = .3
    end

    ImGui.PushStyleColor(ImGuiCol.Button, r1, g1, b1, 1)

    if ImGui.Button("Load|Save|Delete") then
        B_dir_results = feeder.b_scandir()
        if #B_dir_results > 0 or batch_array[1] ~= nil then
            BATCH_OPS_WINDOW_GUI = true
        else
            GLOBAL_TEXT = "No Batch Data to Load,Save,or Delete"
        end
    end

    ImGui.PopStyleColor(1)

    ImGui.SameLine()
    ImGui.SetNextItemWidth(100)
    text_input, _ = ImGui.InputText("##standardbatch##edit", text_input, 128)
    local l_text_length = tonumber(string.len(text_input))
    ImGui.SameLine()

    -- Trigger search on Enter
    local enterPressed = ImGui.IsItemDeactivatedAfterEdit()
        or ImGui.IsKeyPressed(ImGuiKey.Enter)

    if (ImGui.Button("Text Search") or enterPressed) and l_text_length > 0 then
        recipe_batch_results = feeder.recipe_batch_single_result(text_input)
    end

    ImGui.SameLine()
    ImGui.Text('Qty:')
    ImGui.SameLine()
    ImGui.SetNextItemWidth(100)

    l_make_amount, _ = ImGui.SliderInt('##SliderInt ', l_make_amount, 1, 1000,
        "%d")
    ImGui.SameLine()
    ImGui.SetNextItemWidth(1)

    l_make_amount, _ = ImGui.InputInt('##inputint###inputbatch', l_make_amount,
        1, 10000, ImGuiInputTextFlags.None)

    ImGui.SameLine()
    if ImGui.Button("+1000") then l_make_amount = l_make_amount + 1000 end

    if l_make_amount < 1 then l_make_amount = 1 end
    if l_make_amount > 10000 then l_make_amount = 10000 end

    -- ImGui.SameLine()
    -- Standard Override Check box
    -- standard_info_cb, _ = ImGui.Checkbox("Info", standard_info_cb)
    if standard_info_cb then
    else
        if not standard_info_cb then end
    end

    -- Fish Swap code..
    ImGui.SameLine()
    FISH_SWAP, _ = ImGui.Checkbox("Fish", FISH_SWAP)

    ImGui.SameLine()
    HelpMarker(
        "Swaps to other fish to use for crafting scale sheet, patch, etc...")

    if FISH_SWAP then
        FISH_SCALE_SWAP = true
    else
        FISH_SCALE_SWAP = false
    end
    -- End Fish Swap Code

    -- Multiplier Code.
    local multi_array = { "1", "2", "3", "4", "5", "6", "7", "8", "9", "10" }

    ImGui.SameLine()

    ImGui.Text("x: ")

    ImGui.SameLine()

    ImGui.SetNextItemWidth(45)

    -- Skill type combo box
    BUY_MULT_selection, _ = ImGui.Combo("##multiplier", BUY_MULT_selection,
        multi_array, #multi_array, #multi_array)

    ImGui.SameLine()
    HelpMarker(
        "Sets shopping multiplier to buy more than is needed to craft, useful when counting on craft failures")

    local value = tonumber(multi_array[BUY_MULT_selection])

    if value > 1 then
        -- print(value)
        BUY_MULT = value
        USE_MULT = true
    end
    -- end Multiplier code

    -- ImGui.PushStyleColor(ImGuiCol.Text, 0.75, 0.4, 0.9, 2)

    -- remd  ImGui.SetCursorPosX(4)
    -- ImGui.PushItemWidth(150)

    -- Add break down of a recipe to the search

    -- ImGui.SameLine()

    click_value, _ = ImGui.Button(lab)

    if click_value and lab == "Execute Query" then
        -- make this a run go and wait for results by using nil ~=?
        --   recipe_batch_results = feeder.recipe_batch_results(
        --       alphabet[s_combo_box_selected + 1],
        --  skill_types[s_combo_box_selected_skill + 1],
        --  expansion_names[s_combo_box_selected_exp + 1])

        recipe_batch_results = feeder.recipe_batch_results(
            skill_types[s_combo_box_selected_skill],
            expansion_names[s_combo_box_selected_exp])
    end

    ImGui.SameLine()
    click_value, _ = ImGui.Button("Clear Query")

    if click_value then recipe_batch_results = {} end

    ImGui.SameLine()
    -- ImGui.Text('Letter:')
    -- ImGui.SameLine()
    -- ImGui.PushItemWidth(50)
    -- s_combo_box_selected, _ = ImGui.Combo("##special_alphabet",
    --              s_combo_box_selected, alphabet,
    --        #alphabet, #alphabet)

    if s_combo_box_index ~= s_combo_box_selected then
        s_combo_box_index = s_combo_box_selected
    end

    -- ImGui.SameLine()
    -- ImGui.Text('Skill:')
    ImGui.SetNextItemWidth(130)
    ImGui.SameLine()

    -- Skill type combo box
    s_combo_box_selected_skill, _ = ImGui.Combo("##skill_list_batch",
        s_combo_box_selected_skill,
        skill_types, #skill_types,
        #skill_types)

    if s_combo_box_index_skill ~= s_combo_box_selected_skill then
        -- local special_skill = specialized_skills[s_combo_box_selected + 1]
        s_combo_box_index_skill = s_combo_box_selected_skill
        -- i_selection, clicked = ImGui.Combo("##toon_item_list", i_selection, itemray, #itemray, 10)
    end

    ImGui.SameLine()
    ImGui.SetNextItemWidth(200)
    s_combo_box_selected_exp, _ = ImGui.Combo("##expansion_list_batch",
        s_combo_box_selected_exp,
        expansion_names, #expansion_names,
        10)

    if s_combo_box_index_exp ~= s_combo_box_selected_exp then
        -- local special_skill = specialized_skills[s_combo_box_selected + 1]
        s_combo_box_index_exp = s_combo_box_selected_exp
        -- i_selection, clicked = ImGui.Combo("##toon_item_list", i_selection, itemray, #itemray, 10)
    end

    if skill_select ~= nil then
        ImGui.SameLine()
        ImGui.Text("Skill [" .. mq.TLO.Me.Skill(skill_select)() .. "]")
    end

    ImGui.SameLine()

    local tcg_script_status = mq.TLO.Lua.Script('tcn').Status()

    if tcg_script_status == "RUNNING" then
        set_artisan_text_color_r = 1
        set_artisan_text_color_g = 1
        set_artisan_text_color_b = 1
    end

    if tcg_script_status == "PAUSED" then
        set_artisan_text_color_r = 1
        set_artisan_text_color_g = 0
        set_artisan_text_color_b = 0
    end

    if standard_button_pause_bool then
        if mq.TLO.Nav.Active() then
            mq.cmd('/squelch /nav pause')
        else
            if mq.TLO.Nav.Paused() then mq.cmd('/squelch /nav pause') end
        end
        mq.cmd('/squelch /lua pause tcn')
    end

    ImGui.SameLine()
    ImGui.PushStyleColor(ImGuiCol.Text, set_artisan_text_color_r,
        set_artisan_text_color_g, set_artisan_text_color_b, 1)
    standard_button_pause_bool, _ = ImGui.Button("Pause")
    ImGui.PopStyleColor(1)

    ImGui.SameLine()
    -- Turn off autocontinue?
    if ImGui.Button('Abort') then
        go_craft = 0
        if mq.TLO.Nav.Active() then mq.cmd('/squelch /nav stop') end
        GLOBAL_ABORT_FLAG = 1
    end

    -- Exit everything
    ImGui.SameLine()
    if ImGui.Button('Exit') then
        if GLOBAL_MQ2TSTrophy_Plugin == 1 then
            --  print(msg, "\ap[\awLoading: \agMQ2TSTrophy \awplugin\ap]")
            mq.cmd('/squelch /plugin MQ2TSTrophy load')
        end

        if mq.TLO.Nav.Active then mq.cmd('/squelch /nav stop') end
        -- make stop function? to stop all scripts
        mq.cmd('/squelch /lua stop tcn\\tcn_quests')
        mq.cmd('/squelch /lua stop tcn\\tcn_god')
        mq.exit()
        -- mq.cmd('/squelch /lua stop tcxx')
    end

    if id_select ~= 0 then
        ImGui.SameLine()
        ImGui.Text('Inv: (' .. mq.TLO.FindItemCount(l_item_id)() .. ')')
        ImGui.SameLine()
        ImGui.Text('Bank: (' .. mq.TLO.FindItemBankCount(l_item_id)() .. ')')
    end

    -- remove?
    if GLOBAL_TEXT == "Missing Items" then
        scw_r_col = 1
        scw_g_col = 1
        scw_b_col = 0
        can_craft = 0
    end

    if batch_array[1] ~= nil then
        batch_window_openGUI = true
    else
        -- Clear data so it does not persist when we remove batch entries manually
        BATCH_FARM_LIST = {}
        BATCH_SHOPPING_DATA = {}
        BATCH_ZONE_ARRAY = {}
        BATCH_BANK_ARRAY = {}
        ret_batch_depot_data = {}
    end

    ImGui.PushStyleColor(ImGuiCol.Text, scw_r_col, scw_g_col, scw_b_col, 1);

    ImGui.PopStyleColor(1);

    -- ImGui.SameLine()
    -- Rogue, Shaman, Gnome
    -- remove this is for standard
    go_no_go_skill_select = tcglib.check_requirement(skill_select)
    if go_no_go_skill_select ~= nil then
        --   go_craft = 0
        --   can_craft = 0
    end
    -- remove this is for standard
    go_no_go_skillreq = tcglib.check_skill(skill_select, skill_req)
    if go_no_go_skillreq ~= nil then
        --  go_craft = 0
        -- can_craft = 0
    end

    if BATCH_OPS_WINDOW_GUI then
        BatchLoadWindow()
    else
        -- Show batch list
        if recipe_batch_results ~= nil then RecipeBatchWindow() end
    end
end

-------------------------------------

local function BuddyWindow()
    if pass_array[1] ~= nil then OPENToonShoppingListGUI = true end
    if ImGui.Button("Load Directory") then dir_results = feeder.scandir() end
    ImGui.SameLine()
    if ImGui.Button("Load List") and dir_results[1] ~= nil then go_buddy = 1 end
    if dir_results[1] ~= nil then
        ImGui.SetNextItemWidth(350)
        f_select, _ = ImGui.ListBox("", f_select, dir_results, #dir_results,
            #dir_results)
    end
end

local function PathWindow()
    if ImGui.TreeNode('Alchemy') then
        ImGui.TextColored(0, 1, 0, 1, "GOD/TSS Freebie (54)")
        ImGui.TextColored(0, 1, 0, 1, "Distillate of Skinspikes IV (106)")
        ImGui.TextColored(0, 1, 0, 1, "Distillate of Immunization IV (110)")
        ImGui.TextColored(0, 1, 0, 1, "Distillate of Antidote V (148)")
        ImGui.TextColored(0, 1, 0, 1, "Philter of the Wolf V (210)")
        ImGui.TextColored(0, 1, 0, 1, "Formed Suspension Of Toxin VII (220)")
        ImGui.TextColored(0, 1, 0, 1, "Basic Suspension Of Slime VII (228)")
        ImGui.TextColored(0, 1, 0, 1, "Formed Suspension Of Slime VII (231)")
        ImGui.TextColored(0, 1, 0, 1, "Distillate of Alacrity IX (300)")
        ImGui.TreePop()
    end

    if ImGui.TreeNode('Baking') then
        ImGui.TextColored(0, 1, 0, 1, "GOD/TSS Freebie (54)")
        ImGui.TextColored(0, 1, 0, 1, "Fish Rolls (135)")
        ImGui.TextColored(0, 1, 0, 1, "Patty Melt (Bear) (191)")
        ImGui.TextColored(0, 1, 0, 1, "Misty Thicket Picnic (300+/EVOLVE)")
        ImGui.TextColored(0, 1, 0, 1, "Broiled Raxil Fish (EVOLVE)")
        ImGui.TreePop()
    end

    if ImGui.TreeNode('Blacksmithing') then
        ImGui.TextColored(0, 1, 0, 1, "GOD/TSS Freebie (54)")
        ImGui.TextColored(0, 1, 0, 1, "Banded Gorget (92)")
        -- ImGui.TextColored(0, 1, 0, 1, "Embroidering Needle (122)")
        ImGui.TextColored(0, 1, 0, 1, "Fulginate Barbs (112)")
        ImGui.TextColored(0, 1, 0, 1, "Rhenium Studs (184)")
        ImGui.TextColored(0, 1, 0, 1, "Cobalt Studs (222)")
        ImGui.TextColored(0, 1, 0, 1, "Tantalum Studs (255)")
        ImGui.TextColored(0, 1, 0, 1, "Tungsten Chain Belt Template (315)")
        ImGui.TreePop()
    end

    if ImGui.TreeNode('Brewing') then
        ImGui.TextColored(0, 1, 0, 1, "GOD/TSS Freebie (54)")
        ImGui.TextColored(0, 1, 0, 1, "Fetid Essence (122)")
        ImGui.TextColored(0, 1, 0, 1, "Faydwer Shaker (188)")
        ImGui.TextColored(0, 1, 0, 1, "Minotaur Hero's Brew (248)")
        ImGui.TextColored(0, 1, 0, 1, "Kaladim Constitutional (335)")
        ImGui.TreePop()
    end

    if ImGui.TreeNode('Fishing') then
        ImGui.TextColored(0, 1, 0, 1, "Sit by the water and go fish! (200)")
        ImGui.TreePop()
    end

    if ImGui.TreeNode('Fletching') then
        ImGui.TextColored(0, 1, 0, 1, "GOD/TSS Freebie (54)")
        ImGui.TextColored(0, 1, 0, 1,
            "CLASS 1 Wood Hooked Arrow (large groove) (102)")
        ImGui.TextColored(0, 1, 0, 1,
            "CLASS 1 Ceramic Point Arrow (large groove) (135)")
        ImGui.TextColored(0, 1, 0, 1,
            "CLASS 3 Wood Silver Tip Arrow (small groove) (182)")

        ImGui.TextColored(0, 1, 0, 1,
            "CLASS 9 Steel Fearbone Arrow (Large Groove) (300)")

        -- 202 Class 6 Wood?
        ImGui.TreePop()
    end

    if ImGui.TreeNode('Jewelry Making') then
        ImGui.TextColored(0, 1, 0, 1, "GOD/TSS Freebie (54)")
        ImGui.TextColored(0, 1, 0, 1, "Stone Furniture Leg (135)")
        ImGui.TextColored(0, 1, 0, 1, "Stone Furniture Base (148)")
        ImGui.TextColored(0, 1, 0, 1, "Stone Furniture Frame (162)")
        ImGui.TextColored(0, 1, 0, 1, "Small Stone Carved Bed (202)")
        ImGui.TextColored(0, 1, 0, 1, "Jaded Platinum Ring (250)")
        ImGui.TextColored(0, 1, 0, 1, "Platinum Diamond Wedding Ring (287)")
        ImGui.TextColored(0, 1, 0, 1, "Platinum Blue Diamond Tiara (295)")
        ImGui.TextColored(0, 1, 0, 1, "Velium Blue Diamond Bracelet (300+)")
        ImGui.TreePop()
    end

    if ImGui.TreeNode('Make Poison') then
        ImGui.TextColored(0, 1, 0, 1, "GOD/TSS Freebie (54)")
        ImGui.TextColored(0, 1, 0, 1, "Scorpion's Agony III (123)")
        ImGui.TextColored(0, 1, 0, 1, "Scorpion's Agony IV (130)")
        ImGui.TextColored(0, 1, 0, 1, "Scorpion's Agony V (152)")
        ImGui.TextColored(0, 1, 0, 1, "Scorpion's Agony VI (170)")
        ImGui.TextColored(0, 1, 0, 1, "Purified Grade A Privet Extract (276)")
        ImGui.TextColored(0, 1, 0, 1, "Distilled Grade C Larkspur Extract (291)")
        ImGui.TextColored(0, 1, 0, 1, "Purified Grade AA Privet Extract (300)")
        ImGui.TreePop()
    end

    if ImGui.TreeNode('Pottery') then
        ImGui.TextColored(0, 1, 0, 1, "GOD/TSS Freebie (54)")
        ImGui.TextColored(0, 1, 0, 1, "Unfired Small Bowl (102)")
        ImGui.TextColored(0, 1, 0, 1, "Unfired Large Bowl (148)")
        ImGui.TextColored(0, 1, 0, 1, "Unfired Casserole Dish (199)")
        ImGui.TextColored(0, 1, 0, 1, "Unfired Hand-Formed Bottle (271)")
        ImGui.TextColored(0, 1, 0, 1, "Unfired Spherical Bottle (300+)")
        ImGui.TreePop()
    end

    if ImGui.TreeNode('Research') then
        ImGui.TextColored(0, 1, 0, 1, "GOD/TSS Freebie (54)")
        ImGui.TextColored(0, 1, 0, 1, "Makeshift Enchanted Spell Parchment (83)")
        ImGui.TextColored(0, 1, 0, 1,
            "Elementary Enchanted Spell Parchment (118)")
        ImGui.TextColored(0, 1, 0, 1, "Modest Enchanted Spell Parchment (152)")
        ImGui.TextColored(0, 1, 0, 1, "Simple Enchanted Spell Parchment (192")
        ImGui.TextColored(0, 1, 0, 1, "Enchanted Spell Parchment (232)")
        ImGui.TextColored(0, 1, 0, 1, "Refined Enchanted Spell Parchment (272)")
        ImGui.TextColored(0, 1, 0, 1,
            "Intricate Enchanted Spell Parchment (300)")
        ImGui.TreePop()
    end

    if ImGui.TreeNode('Tailoring') then
        ImGui.TextColored(0, 1, 0, 1, "GOD/TSS Freebie (54)")
        ImGui.TextColored(0, 1, 0, 1, "Picnic Basket (76)")
        ImGui.TextColored(0, 1, 0, 1, "Sullied Silk/Pelt Wristband (90+)")
        ImGui.TextColored(0, 1, 0, 1, "Crude Silk/Pelt Wristband (124+)")
        ImGui.TextColored(0, 1, 0, 1, "Rough Silk/Pelt Wristband (158+)")
        ImGui.TextColored(0, 1, 0, 1, "Flawed Silk/Pelt Wristband (196+)")
        ImGui.TextColored(0, 1, 0, 1, "Pristine Silk/Pelt Wristband (234+)")
        ImGui.TextColored(0, 1, 0, 1, "Fine Silk/Pelt Wristband (272+)")
        ImGui.TextColored(0, 1, 0, 1, "Excellent Silk/Pelt Wristband (300)")
        ImGui.TreePop()
    end

    if ImGui.TreeNode('Tinkering') then
        ImGui.TextColored(0, 1, 0, 1, "GOD/TSS Freebie (54)")
        ImGui.TextColored(0, 1, 0, 1, "Stalking Probe (102)")
        ImGui.TextColored(0, 1, 0, 1, "Mechanic Ceramic Clay (262)")
        ImGui.TextColored(0, 1, 0, 1, "Silver Conduit (290)")
        ImGui.TextColored(0, 1, 0, 1, "Silver Conduit Cap (300)")
        ImGui.TreePop()
    end
end

-------------------------------------
local function UtilitiesWindow()
    if ImGui.Button("Block Spells") then go_block = 1 end

    ImGui.SameLine()
    HelpMarker("Blocks common mod rods, summoned food and drink")

    ImGui.SameLine()
    if ImGui.Button("Sell All") then go_sell = 99 end

    ImGui.SameLine()
    HelpMarker("Sell everything listed in the SellTable in Artisan.DB")

    ImGui.SameLine()
    if ImGui.Button("Deposit Items") then go_deposit = 1 end
    ImGui.SameLine()
    HelpMarker(
        "Deposit tools and trophies, if TCN was ended or aborted prematurely.")

    ImGui.SameLine()
    levitate_cb_bool, _ = ImGui.Checkbox("Anti-Lev###AntiLev", levitate_cb_bool)

    if levitate_cb_bool then
        if mq.TLO.Lua.Script('tcn/tcn_levutil').Status() ~= "RUNNING" then
            mq.cmd('/squelch /lua run tcn/tcn_levutil')
        end
    else
        if mq.TLO.Lua.Script('tcn/tcn_levutil').Status() == "RUNNING" then
            mq.cmd('/squelch /lua stop tcn/tcn_levutil')
        end
    end
    ImGui.SameLine()
    HelpMarker("Checks for and disables levitation effects every 5 seconds")

    ImGui.SameLine()
    if ImGui.Button("Shrink") then feeder.shrink_methods() end
    ImGui.SameLine()
    HelpMarker(
        "Tries to shrink (bigger/illusioned races) you using abilities or items")

    ImGui.SameLine()
    if ImGui.Button("Destroy") and mq.TLO.Cursor() then mq.cmd('/destroy') end
    ImGui.SameLine()
    HelpMarker("Destroy item on cursor")

    ImGui.SameLine()
    if ImGui.Button("Inventory") and mq.TLO.Cursor() then mq.cmd('/autoinv') end
    ImGui.SameLine()
    HelpMarker("Inventory item on cursor")

    ImGui.SameLine()
    if ImGui.Button("Restart") then mq.cmd('/lua run tcn/tcn_restart') end
    ImGui.SameLine()
    HelpMarker(
        "Restarts TCN if abort or something else may not be working correctly")

    -- Jewel Cut Tools Section
    ImGui.SameLine()
    if ImGui.Button("Jewel Cut Tools") then
        mq.cmd('/lua run tcn\\tcn_tool_kit')
    end
    ImGui.SameLine()
    HelpMarker(
        "Buys and converts cut tools for jewel crafting from POK vendor pre-ROF and banks them")

    ImGui.SameLine()
    if ImGui.Button("Exit") then
        if GLOBAL_MQ2TSTrophy_Plugin == 1 then
            print(msg, "\ap[\awLoadingz: \agMQ2TSTrophy \awplugin\ap]")
            mq.cmd('/squelch /plugin MQ2TSTrophy load')
        end

        if mq.TLO.Nav.Active() then mq.cmd('/squelch /nav stop') end
        -- mq.cmd('/lua stop tcxx')
        mq.exit()
    end

    -- color changer for background?

    -- Forage utils
    -- Fish utils
end
------------------------------------
local function Tab_Setup()
    if ImGui.BeginTabBar("TCNGUIID", ImGuiTabBarFlags.Reorderable) then
        ImGui.SetWindowFontScale(1)

        OPENInfoWindow = false

        OPENToonShoppingListGUI = false

        batch_window_openGUI = false

        ImGui.PushStyleColor(ImGuiCol.TabActive, 0, 0, .5, 1)

        if ImGui.BeginTabItem("Dashboard") then
            DashboardWindow()
            ImGui.EndTabItem()
        end

        if ImGui.BeginTabItem("Craft") then
            if ImGui.BeginTabBar("CraftID", ImGuiTabBarFlags.Reorderable) then
                if ImGui.BeginTabItem("Standard") then
                    if recipe_shopping_data[1] ~= nil then end

                    StandardCraftingWindow()

                    if recipe_search_results[1] ~= nil then
                        RecipeTableWindow()
                    end

                    ImGui.EndTabItem()
                end

                if ImGui.BeginTabItem("Artisan") then
                    OPENToonShoppingListGUI = false
                    ArtisanPrizeCraftSettings()
                    ImGui.EndTabItem()
                end

                if ImGui.BeginTabItem("Batch") then
                    local uc = 0
                    if uc == 1 then
                        ImGui.Text("Under Construction")
                    end
                    if uc ~= 1 then StandardBatchWindow() end
                    ImGui.EndTabItem()
                end

                if ImGui.BeginTabItem("Requests") then
                    --  openShoppingListGUI = false
                    --  openFarmWindowGUI = false
                    --  openRecipeRequirementsGUI = false
                    --   openRecipeListGUI = false
                    --   OPENToonShoppingListGUI = false

                    ItemRequest()

                    ImGui.EndTabItem()
                end

                if ImGui.BeginTabItem("Item Lookup") then
                    --  openShoppingListGUI = false
                    --  openFarmWindowGUI = false
                    --  openRecipeRequirementsGUI = false
                    --   openRecipeListGUI = false
                    OPENToonShoppingListGUI = false

                    ItemLookup()

                    ImGui.EndTabItem()
                end

                if ImGui.BeginTabItem("Global Craft Settings") then
                    autoshop_cb_bool, _ =
                        ImGui.Checkbox("Auto-Shop###AutoShop", autoshop_cb_bool)
                    ImGui.SameLine()
                    HelpMarker(
                        "Travel to vendors and purchase items automatically.")

                    autobank_cb_bool, _ =
                        ImGui.Checkbox("Auto-Bank###AutoBank", autobank_cb_bool)
                    ImGui.SameLine()
                    HelpMarker(
                        "Grab items from bank automatically for crafting.")

                    autodeposit_cb_bool, _ = ImGui.Checkbox(
                        "Auto-Deposit###AutoDeposit",
                        autodeposit_cb_bool)
                    ImGui.SameLine()
                    HelpMarker(
                        "Deposit items to bank automatically after crafting session complete.")

                    autodepot_cb_bool, _ = ImGui.Checkbox(
                        "Auto-Depot###AutoDepot",
                        autodepot_cb_bool)
                    ImGui.SameLine()
                    HelpMarker(
                        "Deposit items to depot automatically after crafting session complete.")

                    -- Add cross country?

                    if GLOBAL_PLATINUM > 0 then
                        autoplatinum_cb_bool = true
                    else
                        autoplatinum_cb_bool = false
                    end

                    autoplatinum_cb_bool, _ = ImGui.Checkbox(
                        "Auto-Platinum###AutoPlatinum",
                        autoplatinum_cb_bool)
                    ImGui.SameLine()
                    ImGui.SetNextItemWidth(100)
                    GLOBAL_PLATINUM, _ = ImGui.SliderInt(
                        '##SliderInt_PlatinumThreshold',
                        GLOBAL_PLATINUM, 0, 25000, "%d")
                    ImGui.SameLine()
                    HelpMarker(
                        "Slide to select maxium amount of platinum to maintain during crafting session.")

                    ImGui.SameLine()
                    ImGui.Text("[Platinum: " .. mq.TLO.Me.Platinum())
                    ImGui.SameLine()
                    ImGui.Text("Bank: " .. mq.TLO.Me.PlatinumBank())
                    ImGui.SameLine()
                    ImGui.Text("Shared: " .. mq.TLO.Me.PlatinumShared() .. "]")

                    autotrophy_cb_bool, _ = ImGui.Checkbox(
                        "Auto-Trophy###AutoTrophy",
                        autotrophy_cb_bool)
                    ImGui.SameLine()
                    HelpMarker("Swap tradeskill trophies automatically.")

                    autoguild_cb_bool, _ = ImGui.Checkbox(
                        "Use Guild Hall###UseGuild",
                        autoguild_cb_bool)
                    ImGui.SameLine()
                    HelpMarker("Use Guild Hall for Crafting.")

                    -- Save Global Settings
                    if ImGui.Button("Save Settings") then
                        -- Don't bother checking for file, we will just overwrite it.
                        local s_file = "Artisan_GS_" .. mq.TLO.Me() .. "_" ..
                            mq.TLO.MacroQuest.Server() .. ".csv"
                        local file_exist_bool = tcglib.settings_exist(s_file)
                        if file_exist_bool then
                            local command =
                                'del ' .. mq.luaDir .. '\\TCN\\Settings\\' ..
                                s_file
                            --  os.execute(command)
                        end

                        -- Translate settings into binary
                        local ass, ags, ats, abs, ads, aps, adt

                        -- Save Settings
                        if autoshop_cb_bool then
                            ass = 1
                        else
                            ass = 0
                        end
                        if autoguild_cb_bool then
                            ags = 1
                        else
                            ags = 0
                        end
                        if autotrophy_cb_bool then
                            ats = 1
                        else
                            ats = 0
                        end
                        if autobank_cb_bool then
                            abs = 1
                        else
                            abs = 0
                        end
                        if autodeposit_cb_bool then
                            ads = 1
                        else
                            ads = 0
                        end
                        if autodepot_cb_bool then
                            adt = 1
                        else
                            adt = 0
                        end

                        aps = GLOBAL_PLATINUM

                        -- Construct settings string
                        local gs_str = ass .. "," .. ags .. "," .. ats .. "," ..
                            abs .. "," .. ads .. "," .. adt ..
                            "," .. aps

                        -- Write settings file
                        tcglib.writefile(s_file, gs_str)

                        GLOBAL_TEXT = "Global Settings Saved"
                    end

                    ImGui.SameLine()
                    HelpMarker(
                        "Save your current checked and selected settings to be reloaded upon restart or start of TCN.")

                    local const = 0

                    if const == 1 then
                        autotoon_cb_bool, _ = ImGui.Checkbox(
                            "UNDER CONSTRUCTION Auto-Toon###AutoToon",
                            autotoon_cb_bool)
                        ImGui.SameLine()
                        HelpMarker(
                            "DanNet Toons in zone will try to bring you missing tradeskill items automatically.")

                        local zauttoon_cb_bool

                        zauttoon_cb_bool, _ = ImGui.Checkbox(
                            "UNDER CONSTRUCTION Auto-Drone Craft###AutoDroneCraft",
                            zauttoon_cb_bool)
                        ImGui.SameLine()
                        HelpMarker(
                            "Attempts to have a character craft a specialized item for your recipe that you can't make.")

                        local zutotoon_cb_bool

                        zutotoon_cb_bool, _ = ImGui.Checkbox(
                            "UNDER CONSTRUCTION Auto-Mule Shop###AutoMuleShop",
                            zutotoon_cb_bool)
                        ImGui.SameLine()
                        HelpMarker(
                            "Attempts to have a character bring you items wherever you are so you don't have to zone to get them.")
                    end
                    -- end construction

                    -- Global Settings Exit

                    if ImGui.Button("Exit") then
                        if GLOBAL_MQ2TSTrophy_Plugin == 1 then
                            -- print(msg,
                            --      "\ap[\awLoading: \agMQ2TSTrophy \awplugin\ap]")
                            mq.cmd('/squelch /plugin MQ2TSTrophy load')
                        end

                        if mq.TLO.Nav.Active() then
                            mq.cmd('/squelch /nav stop')
                        end

                        mq.exit()
                        -- mq.cmd('/lua stop tcxx')

                        -- Anything else to stop and also make exits a function
                    end

                    ImGui.EndTabItem()
                end

                -- Plat spend limit?

                if autoshop_cb_bool then
                    GLOBAL_SHOP_FLAG = 1
                else
                    GLOBAL_SHOP_FLAG = 0
                end

                if autoguild_cb_bool then
                    GLOBAL_CRAFTING_ZONE = 1
                else
                    GLOBAL_CRAFTING_ZONE = 0
                end

                if autotrophy_cb_bool then
                    --    mq.cmd('/squelch /plugin MQ2TSTrophy unload')
                    GLOBAL_TROPHY_FLAG = 1
                else
                    --   if GLOBAL_MQ2TSTrophy_Plugin == 1 then
                    --    mq.cmd('/squelch /plugin MQ2TSTrophy load')
                    --   end

                    GLOBAL_TROPHY_FLAG = 0
                end

                if autobank_cb_bool then
                    GLOBAL_BANK_FLAG = 1
                else
                    GLOBAL_BANK_FLAG = 0
                end

                if autodeposit_cb_bool then
                    GLOBAL_DEPOSIT_FLAG = 1
                else
                    GLOBAL_DEPOSIT_FLAG = 0
                end

                if autodepot_cb_bool then
                    GLOBAL_DEPOT_FLAG = 1
                else
                    GLOBAL_DEPOT_FLAG = 0
                end

                -- ImGui.EndTabItem()
            end

            ImGui.EndTabBar()

            ImGui.EndTabItem()
        end

        -- Main Bar Row

        if ImGui.BeginTabItem("TSS") then
            TSSWindow()
            ImGui.EndTabItem()
        end

        if ImGui.BeginTabItem("GOD") then
            GODWindow()
            ImGui.EndTabItem()
        end

        -- revisit the loading of this
        if ImGui.BeginTabItem("Trophy Quests") then
            if trophy_quest_array[1] ~= nil then
                TrophiesWindow()
            else
                GLOBAL_TEXT = "Congrabulations, You have all the trophies"
            end
            ImGui.EndTabItem()
        end

        if ImGui.BeginTabItem("Artisan Quests") then
            SealsWindow()
            ImGui.EndTabItem()
        end

        if ImGui.BeginTabItem("Merchant Alliance Quest") then
            MAWindow()
            ImGui.EndTabItem()
        end

        if ImGui.BeginTabItem("Utilities") then
            UtilitiesWindow()
            ImGui.EndTabItem()
        end

        if ImGui.BeginTabItem("Shop Buddy") then
            BuddyWindow()
            ImGui.EndTabItem()
        end

        if ImGui.BeginTabItem("300 Path") then
            PathWindow()
            ImGui.EndTabItem()
        end
    end

    ImGui.EndTabBar()

    ImGui.PopStyleColor()
end

-- Status messages and stuff
local function TopBar()
    if max_recipe_array[1] ~= nil then
        ImGui.Button(GLOBAL_MAX_RECIPE_COUNT .. "/" .. #max_recipe_array)
    else
        ImGui.Button("0/0")
    end

    ImGui.SameLine()
    if GLOBAL_TEXT == nil then
        --  ImGui.InvisibleButton("", 100, 22)
        ImGui.Button("Idle")
    else
        ImGui.Button(GLOBAL_TEXT)
    end

    ImGui.Separator()
end

function TCNTablesGUI()
    if not openGUI then return end

    local version = "4.192b"

    openGUI, shouldDrawGUI = ImGui.Begin('TCNGUI ' .. version, openGUI)

    ImGui.SetWindowSize(1024, 620)

    if shouldDrawGUI then
        -- ImGui.PushStyleVar(ImGuiStyleVar.IndentSpacing, 0.0)

        TopBar()

        Tab_Setup()
    end
    ImGui.End()
end

-- Dock-safe main info window (no flicker when tab-docked)
function MainStandardInfoWindow()
    if not OPENInfoWindow then return end

    local default_w, default_h = 840, 620

    -- PASS 1: check docking state without affecting layout
    ImGui.Begin("##tcsnext_info_dockcheck", true,
        bit32.bor(ImGuiWindowFlags.NoTitleBar, ImGuiWindowFlags.NoBackground))
    local is_docked = ImGui.IsWindowDocked()
    ImGui.End()

    -- If floating, enforce our preferred size BEFORE the real Begin()
    if not is_docked then
        ImGui.SetNextWindowSize(default_w, default_h, ImGuiCond.Always)
    end

    -- PASS 2: real window with a stable internal ID
    local win_open, should_draw = ImGui.Begin(
        "TCSNeXt Recipe Information Window##info_main",
        OPENInfoWindow
    )

    -- Keep the open state in sync with the close [X] button
    OPENInfoWindow = win_open
    if not win_open then
        ImGui.End()
        return
    end

    ImGui.SetWindowFontScale(1)

    -- Draw only if ImGui says it's visible this frame
    if should_draw then
        -- Optional: show selection info (commented out in your code)
        -- if name_select ~= nil then
        --     ImGui.Text(name_select .. " Recipe ID: " .. tostring(id_select))
        -- end

        ShowResults()
    end

    ImGui.End()
end

-- Main Window for Standard Information
-- ImGui.Register('MainStandardInfoWindow', MainStandardInfoWindow)

ImGui.Register('TCNTablesGUI', TCNTablesGUI)

-- ImGui.Register('MaxFarmTableWindow', MaxFarmTableWindow)
-- ImGui.Register('MaxShoppingListWindow', MaxShoppingListWindow)
-- ImGui.Register('MassBankListWindow', MassBankListWindow)

-- ImGui.Register('ToonShoppingListWindow', ToonShoppingListWindow)

ImGui.Register('BatchMakeWindow', BatchMakeWindow)

-- ImGui.Register('BatchInfoWindow', BatchInfoWindow)

-- ImGui.Register('QuestFarmTableWindow', QuestFarmTableWindow)

-- ImGui.Register('ItemLookupResults', ItemLookupResults)

-- ImGui.Register('BatchGenerateWindow', BatchGenerateWindow)
-- ImGui.Register('BatchShoppingWindow', BatchShoppingWindow)
-- ImGui.Register('BatchBankWindow', BatchBankWindow)
-- ImGui.Register('KnownMax', KnownMax)
-- ImGui.Register('UnknownMax', UnknownMax)
-- ImGui.Register('StandardFishWindow', StandardFishWindow)
-- ImGui.Register('ShoppingListWindow', ShoppingListWindow)
-- ImGui.Register('StandardFarmTableWindow', StandardFarmTableWindow)
-- ImGui.Register('RecipeStackWindow', RecipeStackWindow)
-- ImGui.Register('StandardRequirementsWindow', StanardRequirementsWindow)
-- ImGui.Register('BankListWindow', BankListWindow)

local function CheckGameState()
    if mq.TLO.MacroQuest.GameState() ~= 'INGAME' then
        print('\arNot in game, stopping TCNGUI.\ax')
        openGUI = false
        shouldDrawGUI = false
        mq.imgui.destroy('TCNTablesGUI')
        -- return?
        mq.exit()
    end
end

-- Main Loop
while openGUI do
    CheckGameState()

    local l_inv = mq.TLO.FindItemCount(l_item_id)()
    local l_have_item = mq.TLO.FindItem(l_item_id).ID()

    -- print(l_item_id)

    -- Unused/Remove?
    -- if peer_go == 1 then
    -- local dn_peers = feeder.dannet_peers()
    --    peer_go = 0
    -- end

    if go_batch == 1 then
        feeder.run_batch_list(batch_array)

        local new_batch_array = {}
        for c = 1, #batch_array do
            local batch_autoremove_array = {
                BatchItemID = batch_array[c].BatchItemID,
                BatchItemName = batch_array[c].BatchItemName,
                BatchItemMake = batch_array[c].BatchItemMake,
                BatchItemRecipe = batch_array[c].BatchItemRecipe
            }
            if mq.TLO.FindItemCount(batch_array[c].BatchItemID)() >=
                batch_array[c].BatchItemMake then
            else
                table.insert(new_batch_array, batch_autoremove_array)
            end
        end

        -- don't mess with batch array window otherwise this will kapow

        if mq.TLO.FindItemCount(batch_array[1].BatchItemID)() >=
            batch_array[1].BatchItemMake and #batch_array == 1 then
            batch_array = {}
        end

        if new_batch_array[1] ~= nil then
            batch_array = new_batch_array
            new_batch_array = {}
        end

        go_batch = 0
    end

    if go_batch == 72 then
        BATCH_FARM_LIST, BATCH_SHOPPING_DATA, BATCH_ZONE_ARRAY, BATCH_BANK_ARRAY, converted_batch_shopping_data, converted_batch_farm_data, ret_batch_depot_data =
            feeder.generate_batch_list(batch_array)
        go_batch = 0
    end

    -- Guild Hall Banking Section
    if GO_GUILD_HALL == 1 then
        feeder.GUILD_HALL_BANKING(MASS_gh_bank_array)
        GO_GUILD_HALL = 0
    end

    -- Dragon Hoard Banking Section
    if GO_DRAGON_HOARD == 1 then
        feeder.DRAGON_HOARD_BANKING(MASS_dh_bank_array)
        GO_DRAGON_HOARD = 0
    end

    -- Standard Crafting Routine Start ************************

    if go_craft == 1 then
        feeder.standard_crafting_routine(id_select, l_make_amount)

        if GLOBAL_ABORT_FLAG == 1 then
            if mq.TLO.Nav.Active() then mq.cmd('/squelch /nav stop') end
            GLOBAL_ABORT_FLAG = 0
            GLOBAL_TEXT = "Aborted..."
            go_craft = 0
            -- can_craft = 0
            standard_continue_cb = false
            standard_destroy_cb = false
            standard_sell_cb = false
            standard_skill_cb = false
            override_cb_bool = false
        end

        if GLOBAL_STANDARD_AUTOCONTINUE ~= 0 then
            standard_continue_cb = false
        end
        if GLOBAL_STANDARD_SKILL_ID ~= 0 then standard_skill_cb = false end
        if GLOBAL_STANDARD_DESTROY_ID ~= 0 then
            standard_destroy_cb = false
        end
        if GLOBAL_STANDARD_SELL_ID ~= 0 then standard_sell_cb = false end

        -- Turn off buttons
        standard_continue_cb = false
        standard_destroy_cb = false
        standard_sell_cb = false
        standard_skill_cb = false

        scw_r_col, scw_g_col, scw_b_col = .8, .8, .8

        -- id_select = 0
        go_craft = 0
        GLOBAL_TEXT = "Crafting Complete"
        override_cb_bool = false
    end

    -- Query recipe for missing items
    if crunch_go == 1 then
        local l_count = tonumber(l_make_amount)
        recipe_disposition_data = {}
        trim_soiled = {}
        recipe_shopping_data = {}
        BANK_ARRAY = {}
        recipe_stack_data = {}

        recipe_disposition_data, trim_soiled, recipe_shopping_data, recipe_stack_data, BANK_ARRAY, converted_shopping_data, converted_farm_data, converted_recipe_data, l_depot_array =
            feeder.query_recipe(id_select, l_count, 0, 0)

        -- SIM
        -- Ignore missing items
        -- trim_soiled = {}

        crunch_go = 0
    end

    if god_go == 1 then
        god_go = 0
        -- mq.cmd('/lua run tcn/tcn_god ', god_selection + 1)
    end

    -- remove? it is not used and loaded at runtime
    if trophy_flag == 1 then
        trophy_quest_array = feeder.trophy_quests()
        trophy_flag = 0
    end

    -- Load 350 recipes
    if go_max == 1 then
        max_recipe_array, MAX_UNKNOWN_ARRAY, MAX_KNOWN_ARRAY =
            feeder.load_max_recipes(t_max_selection)

        go_max = 0
        GLOBAL_MAX_CRAFTING = 0
        GLOBAL_TEXT = "Recipes Loaded..."
    end

    -- 350 Crafting Routine Start
    if go_max == 2 then
        feeder.prize_data_check()

        feeder.run_max_list(max_recipe_array)

        go_max = 0

        sell_max_bool = false
        destroy_max_bool = false
        bank_max_bool = false

        GLOBAL_MAX_CRAFTING = 0

        -- if GLOBAL_MAX_REPORT_FLAG == 1 then
        --   max_farm_list = {}
        --   max_farm_list = GLOBAL_SOILED_ARRAY
        --  end

        GLOBAL_SOILED_ARRAY = {}

        -- Add tools to recipe list--er missing comp list
        --  GLOBAL_GENERATE_FLAG = 0
        -- Turn off missing item spam
        GLOBAL_MISSING_SPAM = 0

        -- Reload after run
        --  t_max_selection = max_array[l_max_selection + 1]
        GLOBAL_TEXT = "Reloading: " .. t_max_selection .. " Recipes"
        go_max = 1
    end

    -- Gets Item Lookup Results
    if go_craft == 8675309 then
        -- ITEM_RECIPE_RESULTS_LOOKUP = feeder.component_search_recipe_results(
        --     GLOBAL_item_id)
        ITEM_RECIPE_RESULTS_LOOKUP = feeder.item_recipe_search(GLOBAL_item_id, "id")

        go_craft = 0
    end

    if go_max == 3 then
        art_max_farm_list, max_recipe_shopping_data, mass_zone_array, mass_bank_array, MASS_gh_bank_array, MASS_dh_bank_array, converted_mass_shopping_data, converted_mass_farm_data, ret_max_depot_data =
            feeder.generate_max_farm_list(max_recipe_array)

        -- local sql_farm_list = feeder.sql_convert_max(max_farm_list)

        -- add to other max gens or batch max gen??

        for c = 1, #MASS_gh_bank_array do
            --  print(MASS_gh_bank_array[c].Name)
        end

        --  and GLOBAL_CRAFTING_ZONE == 1 then
        -- print"checking guild hall"
        -- travelto guild lobby if not in gh
        -- end

        -- for c = 1,#max_recipe_shopping_data do print(max_recipe_shopping_data[c]) end-- os.exit()
        -- for c = 1,#max_recipe_array do print(max_recipe_array[c]) end os.exit()

        go_max = 0
        --   GLOBAL_GENERATE_FLAG = 0
    end

    -- Generate Quest Farm List

    if go_quest == 1 then
        -- get selection for quest name

        max_farm_list = {}

        GLOBAL_SOILED_ARRAY = {}

        GLOBAL_TEXT = "Generating Farm List for " .. t_quest_selection

        local quest_recipe_array = feeder.load_quest_recipes(t_quest_selection)

        if quest_recipe_array ~= nil then
            --   for c = 1, #quest_recipe_array do print(quest_recipe_array[c].RID) end
            quest_farm_list =
                feeder.generate_mass_quest_list(quest_recipe_array)
        end

        --  GLOBAL_GENERATE_FLAG = 0

        go_quest = 0
    end

    -- Artisan Farm List Generate test
    if go_quest == 1492 then
        -- get selection for quest name

        max_farm_list = {}

        GLOBAL_SOILED_ARRAY = {}

        GLOBAL_TEXT = "Generating Farm List for " .. t_quest_selection

        local quest_recipe_array = feeder.load_quest_recipes(t_quest_selection)

        local null_data = {}
        local convert_quest_data = {}

        if quest_recipe_array ~= nil then
            --   for c = 1, #quest_recipe_array do print(quest_recipe_array[c].RID) end
            artisan_farm_list, null_data, null_data, null_data, null_data, convert_quest_data =
                feeder.generate_mass_quest_list(quest_recipe_array)
            --     for c = 1,#artisan_farm_list do print(artisan_farm_list[c]) end
        end

        --  GLOBAL_GENERATE_FLAG = 0

        go_quest = 0
    end

    -- Merchant Alliance Farm List Generate test
    if go_quest == 1812 then
        -- get selection for quest name

        max_farm_list = {}

        GLOBAL_SOILED_ARRAY = {}

        GLOBAL_TEXT = "Generating Farm List for " .. t_quest_selection

        local quest_recipe_array = feeder.load_quest_recipes(t_quest_selection)

        if quest_recipe_array ~= nil then
            --   for c = 1, #quest_recipe_array do print(quest_recipe_array[c].RID) end
            merchant_farm_list = feeder.generate_mass_quest_list(
                quest_recipe_array)
        end

        --  GLOBAL_GENERATE_FLAG = 0

        go_quest = 0
    end

    -- Turn in to Lebounde
    if go_quest == 2 then
        feeder.deliver_artisan(t_quest_selection)
        go_quest = 0
    end

    -- Set for Artisan Quests currently
    -- Monitor script to return ammo slot item
    if go_quest == 99 then
        feeder.script_status()
        go_quest = 0
    end

    -- Shop

    if go_shop == 1 then
        feeder.window_shop(recipe_shopping_data)
        go_shop = 0
    end

    if go_shop == 42 then
        feeder.window_shop(mass_shop_array)
        go_shop = 0
    end

    if go_shop == 43 then
        feeder.window_shop(mass_shop_array)
        -- Verify list is complete before wiping?
        BATCH_SHOPPING_DATA = {}
        go_shop = 0
    end

    if go_shop == 1149 then
        -- for c = 1 ,#l_depot_array do print(l_depot_array[c].Quantity," ",l_depot_array[c].Name) end

        feeder.window_go_depot_shopping(l_depot_array)

        -- Verify list is complete before wiping?
        l_depot_array = {}
        go_shop = 0
    end

    -- print(GLOBAL_STANDARD_UI)

    if go_shop == 1150 then
        feeder.window_go_depot_shopping(ret_batch_depot_data)
        -- Verify list is complete before wiping?
        ret_batch_depot_data = {}
        go_shop = 0
    end

    if go_shop == 1151 then
        feeder.window_go_depot_shopping(ret_max_depot_data)
        -- Verify list is complete before wiping?
        ret_max_depot_data = {}
        go_shop = 0
    end

    if go_shop == 51 then
        feeder.window_shop(pass_shop_array)
        go_shop = 0
    end

    if go_shop == 49 then
        feeder.mass_bank_shop(mass_bank_array)
        go_shop = 0
    end

    if go_shop == 72 then
        feeder.mass_bank_shop(BATCH_BANK_ARRAY)
        go_shop = 0
        BATCH_BANK_ARRAY = {}
    end

    if go_deposit == 1 then
        feeder.deposit_tools_trophies()
        go_deposit = 0
    end

    -- Request

    if go_ask == 1 then
        feeder.request_item_cycle(request_array_list)
        GLOBAL_TEXT = "Request items complete"
        go_ask = 0
    end

    if go_block == 1 then
        feeder.block_cursor_loot()
        go_block = 0
    end

    if go_buddy == 1 then
        pass_array, pass_zone_array = feeder.LOAD_MSL(dir_results[f_select])
        go_buddy = 0
    end

    if go_sell == 99 then
        feeder.SellEverything()
        go_sell = 0
    end

    -- Delay Loop
    mq.delay(100)

    if GLOBAL_ABORT_FLAG == 1 then GLOBAL_ABORT_FLAG = 0 end
end
