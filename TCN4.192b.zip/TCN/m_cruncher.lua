-- created: 4/3/2022
-- updated: 9/11/2025
-- creator: jb321
-- version: 1.22b
-- name: m_cruncher
local mq = require('mq')

-- local PackageMan = require('mq/PackageMan')
local sqlite3 = require('lsqlite3')
-- local sqlite3 = require('lsqlite3')

local db = sqlite3.open(mq.luaDir .. '\\tcn\\Artisan.db')
local dbw = sqlite3.open(mq.luaDir .. '\\tcn\\Work.db')
local lib = require('tcn_Library')
local recrunch = require('tcn_recrunch')

local data_array = {}
local mass_bank_list = {}
local temp_banked_components = {}

local e_tool_array = {}

local start_time

-- local pottery_tools = {}
-- local fletching_tools = {}
-- local convertible_tool_array = {}

local tool_array = {}
local tool_counter = 0

local pass_var2 = 0
local pass_var3 = 0
local pass_var4 = 0
local pass_var5 = 0
local pass_var6 = 0
local pass_var7 = 0
local pass_var8 = 0
local pass_var9 = 0
local pass_var10 = 0
local pass_var11 = 0

local banked_tools_array = {}

local component_array = {}

local msg = "\ap[\atTCSNe\auX\att\ap]\aw "

-- local functions

local function return_toon_item_inv_count(p_id)

    local linv_count = mq.TLO.FindItemCount(p_id)()
    local binv_count = mq.TLO.FindItemBankCount(p_id)()

    local dinv_count = 0

    if mq.TLO.TradeskillDepot.Enabled() then
        dinv_count = mq.TLO.TradeskillDepot.FindItemCount(p_id)()
    end

    local tinv_count = 0

    tinv_count = linv_count + binv_count

    -- Add in TSD
    if mq.TLO.TradeskillDepot.Enabled() then
        if dinv_count > 0 then
            tinv_count = linv_count + binv_count + dinv_count

        end
    end

    if tinv_count < 1 then return 0, nil end

    local s_table = mq.TLO.MacroQuest.Server() .. "_" .. mq.TLO.Me.Name() ..
                        "_Inventory"
    local r_count = 0
    local m_name = nil

    for x in dbw:nrows("SELECT * FROM " .. s_table .. " WHERE ID = " .. p_id) do

        if x.Count > 0 then
            r_count = tonumber(x.Count)
            m_name = x.Name
            break
        end
    end

    return r_count, m_name
end

local function update_toon_item_inv_count(p_id, p_count)
    local s_table = mq.TLO.MacroQuest.Server() .. "_" .. mq.TLO.Me.Name() ..
                        "_Inventory"
    dbw:exec("UPDATE " .. s_table .. " SET Count = " .. p_count ..
                 " WHERE ID = " .. p_id .. ";")
    mq.delay(1)
    return
end

-- Static Item IDs for all purchased tools
local function crunch_purchased_tools(p_id)
    local purchased_tool_id_array = {
        37803, 8086, 7052, 10489, 152401, 17947, 17906, 17882, 21625, 34914,
        95826, 8893, 10425, 81673, 81671, 81670, 81677, 81679, 10477, 10479,
        11397, 81669, 10478, 81676, 98305, 81672, 81678, 81674, 81675, 81661,
        65255, 65189, 81666, 81668, 81663, 65167, 81665, 98304, 81660, 65145,
        81667, 65233, 65211, 81664, 10064, 152402, 152403, 152404, 152405,
        152406, 152407, 152408, 38511, 38512, 38513, 38514, 38515, 12056, 37804,
        95827, 95828, 95829, 95830, 95831, 95832, 29546, 16361, 8085, 29820,
        29816, 29824
    }

    local value = 0
    for c = 1, #purchased_tool_id_array do
        if purchased_tool_id_array[c] == p_id then
            value = 1
            break
        end
    end
    return value
end

-- Static recipe Item IDs for all crafted tools
local function crunch_toolcheck_id(p_id)
    local crafted_tool_id_array = {
        12011, 13439, 9727, 13432, 8174, 13438, 13438, 13430, 37804, 95829,
        95832, 95828, 95831, 95827, 95826, 95830, 37805, 95833, 13432, 9753,
        37803, 12090, 16883, 10064, 33646, 96488, 96492, 96489, 9777, 21565,
        29778, 29760, 29779, 13437, 13437, 65260, 9724, 13436, 13433, 13434,
        14592, 14593, 14594, 13435, 14591, 13436, 13433, 13434, 14592, 14593,
        14594, 13435, 14591, 65259, 13440, 60316, 60187
    }

    local value = 0
    for c = 1, #crafted_tool_id_array do
        if crafted_tool_id_array[c] == p_id then
            value = 1
            break
        end
    end
    return value
end

-- Static recipe IDs for all crafted tools
local function crunch_toolcheck(p_id)
    local crafted_tool_array = {
        94960, 108028, 93131, 9913432, 97063, 98043, 108286, 108961, 88214,
        88534, 88655, 88747, 88776, 88931, 89129, 89306, 89307, 34653, 108293,
        94961, 1234, 98773, 101251, 9910064, 11298, 35559, 35563, 35560, 101062,
        99296, 101063, 101838, 93048, 97036, 108278, 94170, 94183, 92429, 92755,
        95644, 95815, 98848, 99568, 100420, 100468, 108004, 108016, 108127,
        108133, 108958, 109101, 109111, 109229, 95874, 93008, 817, 63767, 99565,
        108968, 97034
    }

    local value = 0
    for c = 1, #crafted_tool_array do
        if crafted_tool_array[c] == p_id then
            value = 1
            break
        end
    end
    return value
end

local function removeDuplicates(arr)
    local newArray = {}
    local checkerTbl = {}
    for _, element in ipairs(arr) do
        if not checkerTbl[element] then -- if there is not yet a value at the index of element, then it will be nil, which will operate like false in an if statement
            checkerTbl[element] = true
            table.insert(newArray, element)
        end
    end
    return newArray
end

-- calc buy  count ---------
----------------------------
local function calc_buy_count(p_id, s_id, p_sets_wanted)

    if p_id == nil then
        print("err calc_buy_count ", p_id, " ", s_id)
        os.exit()
    end

    if s_id == nil then
        print("err calc_buy_count ", s_id, " ", p_id)
        os.exit()
    end

    if p_sets_wanted == nil then
        print("err calc_buy_count ", p_id)
        os.exit()
    end

    -- local bank_item_name = lib.return_recipe_name(s_id)
    -- print(bank_item_name)

    -- bank_item_name = lib.return_recipe_name(p_id)
    -- print(bank_item_name)

    local set_count = 0

    -- print("want count? ",p_sets_wanted, " for recipe ", lib.return_recipe_name(s_id))

    -- How many items are needed of the sub recipe to satisify the main recipe
    -- main recipe needs this many sets of the sub recipe 
    local item_row_count = lib.Return_Calling_Recipe_Row_Count(p_id, s_id)

    if item_row_count == nil then
        print(msg, p_id, " ", s_id,
              " Broked, NIL calling row count TCN Cruncher")
        os.exit()
    end

    -- local prc = lib.load_recipe_table(p_id)
    --  local src = lib.load_recipe_table(s_id)
    --  print(prc[1].RecipeName, " \at", src[1].RecipeName, " Sets:", p_sets_wanted,
    --    " calls for: ", item_row_count)

    -- local tool_check1 = lib.toolcheck(s_id)
    local tool_check1 = crunch_toolcheck(s_id)

    -- p_sets_wanted is how many the main recipe wants of the sub recipe
    -- item_count is how many in the sub recipe items is required to make 1 set

    -- This affects sub-tools in Quests, which is not desired.

    -- tool check should be enacted after every row except 1st row..
    -- regular cruncher?

    -- Disable for TCN_Quests - makes tools
    if GLOBAL_OPTION_FLAG == 1 then tool_check1 = 0 end

    -- The tool array is used to add tools we don't have before the recipe itself
    -- If we have the tool we don't add to the array, if we do have the tool in the bank we add it in the banked tools array.

    -- add more checks
    if tool_check1 == 1 then

        -- local l_item_id = lib.return_item_ID(s_id)
        -- local l_item_name = lib.return_item_name(l_item_id)

    end

    if tool_check1 == 1 then

        local l_item_id = lib.return_item_ID(s_id)
        local lv_inv = mq.TLO.FindItemCount(l_item_id)()
        local lv_b_inv = mq.TLO.FindItemBankCount(l_item_id)()
        local l_item_name = lib.return_item_name(l_item_id)

        if lv_inv >= item_row_count or lv_b_inv >= item_row_count then
            -- We have the count so don't add to the tool array
        else

            if s_id == 63767 or s_id == 97063 or s_id == 101251 or s_id == 11298 or
                s_id == 35563 or s_id == 101062 or s_id == 101063 or s_id ==
                101838 then
                table.insert(e_tool_array, string.format('("%s",%d,%d)',
                                                         l_item_name, s_id,
                                                         item_row_count))
            end

            local tool_string = s_id .. "," .. item_row_count

            -- tool_array[tool_counter] = s_id .. "," .. item_row_count
            -- print(tool_string)

            -- better way is to return tool array and make add it up separate from recipe array
            -- that way we can include the tool comoonents in the missing farm list

            if GLOBAL_TOOL_RECIPE == 1 then
                table.insert(tool_array, tool_string)
            end
        end

        if l_item_name == nil then
            print(msg, "Error no item name in cruncher ", l_item_id)
            os.exit()
        end

        -- If it is tool go off of primary row count

        if lv_inv >= item_row_count or lv_b_inv >= item_row_count then
            if lv_b_inv >= item_row_count and lv_inv < item_row_count then

                local bank_tool_string =
                    l_item_name .. "," .. l_item_id .. "," .. item_row_count
                table.insert(banked_tools_array, bank_tool_string)

            end
            set_count = 0
            return set_count
        else
            local s_yield = lib.return_recipe_yield(s_id)
            local s_inv = lib.return_recipe_inv(s_id)
            local s_desired_count = item_row_count - s_inv
            if s_inv >= item_row_count then return 0 end

            -- set_count = lib.set_amount(s_desired_count, s_yield)
            --   set_count = item_row_count

            --  Stops tool from being added to recipe array just yet
            return 0
            -- for proper count
            --  return set_count
        end
    end

    -- local tool_check = lib.toolcheck(p_id)
    local tool_check = crunch_toolcheck(p_id)

    -- Disable for TCN_Quests - allows you to make unlimited tools if it is required to satisfy trophy req
    if GLOBAL_OPTION_FLAG == 1 then tool_check = 0 end

    if tool_check == 1 then

        local l_item_id = lib.return_item_ID(p_id)
        local lv_inv = mq.TLO.FindItemCount(l_item_id)()
        local lv_b_inv = mq.TLO.FindItemBankCount(l_item_id)()
        local l_item_name = lib.return_item_name(l_item_id)

        if lv_inv >= item_row_count or lv_b_inv >= item_row_count then
            -- We have the count so don't add to the tool array
        else
            local tool_string = p_id .. "," .. item_row_count
            if GLOBAL_TOOL_RECIPE == 1 then
                table.insert(tool_array, tool_string)
            end
        end

        if lv_inv > 0 or lv_b_inv > 0 then
            if lv_b_inv > 0 then
                local bank_tool_string = l_item_name .. "," .. l_item_id .. ",1"
                table.insert(banked_tools_array, bank_tool_string)
                --    print("\agTools adding: ", bank_tool_string)
            end

            set_count = 0
            return set_count
        else
            local s_yield = lib.return_recipe_yield(s_id)
            local s_inv = lib.return_recipe_inv(s_id)
            -- add in how much does item count row call for?
            local s_desired_count = item_row_count - s_inv

            if s_inv >= item_row_count then
                --   print "fire2"
                return 0
            end

            set_count = lib.set_amount(s_desired_count, s_yield)
            -- print(set_count," ",s_id)
            -- set_count=1
            -- tool is not added to recipe array yet
            return 0
            --  return set_count
        end

    end

    local l_yield = lib.return_recipe_yield(s_id)

    if l_yield == nil then
        print(msg, "\ayError: \ag", s_id,
              " Recipe not in table, check component table for ID")
        os.exit()
    end

    local l_sub_item_id = lib.return_item_ID(s_id)

    -- Read dynamic SQL Table
    local toon_inv_count, toon_item_name =
        return_toon_item_inv_count(l_sub_item_id)

    local l_desired_count = math.ceil(item_row_count * p_sets_wanted)

    if toon_item_name ~= nil then

        -- Have recipe counts
        if toon_inv_count >= l_desired_count then
            toon_inv_count = toon_inv_count - l_desired_count
            update_toon_item_inv_count(l_sub_item_id, toon_inv_count)

            if string.find(toon_item_name, ",") then
                toon_item_name = toon_item_name:gsub(',', '@')
            end

            local comp_string = toon_item_name .. "," .. l_sub_item_id .. "," ..
                                    l_desired_count

            table.insert(component_array, comp_string)

            l_desired_count = 0

        else

            if toon_inv_count > 0 and toon_inv_count < l_desired_count then

                l_desired_count = l_desired_count - toon_inv_count

                -- fix this count
                -- think it needs to be diff between desired and toon count???

                if string.find(toon_item_name, ",") then
                    toon_item_name = toon_item_name:gsub(',', '@')
                end

                local comp_string = toon_item_name .. "," .. l_sub_item_id ..
                                        "," .. toon_inv_count

                table.insert(component_array, comp_string)

                --  print("mcruncher Mass checking-Desire partial : ", l_desired_count,
                -- " Have: ", toon_inv_count, " ",
                --  lib.return_item_name(l_sub_item_id))

                toon_inv_count = 0

                update_toon_item_inv_count(l_sub_item_id, 0)
            end
        end

    end

    set_count = lib.set_amount(l_desired_count, l_yield)

    return set_count
end

local function make_data(p_id, s_id, p_bc, p_mc)
    -- Primary ID, Secondary ID, Buy Count
    local primary_id = p_id
    local secondary_id = s_id
    local fv_buy_count = p_bc

    local fv_secondary_item_id = lib.return_item_ID(s_id)
    local fv_secondary_item_name = lib.return_recipe_name(s_id)
    local fv_yield = lib.return_recipe_yield(secondary_id)

    -- print("\agmake_data cruncher string ", fv_secondary_item_name)@

    if fv_yield == nil then
        print(msg, "Error: NIL YIELD BUY CALC")
        os.exit()
    end

    -- watch make count

    local fv_mc = math.ceil(fv_buy_count * fv_yield)

    -- fv_mc = p_mc

    -- For the 2 pottery items
    if string.find(fv_secondary_item_name, ",") then
        fv_secondary_item_name = fv_secondary_item_name:gsub(',', '@')
    end

    -- print("make data_ cruncher: make count ", fv_mc, " second sid: ",
    --  fv_secondary_item_id, " sid ", s_id)

    local data = fv_secondary_item_id .. "," .. fv_secondary_item_name .. "," ..
                     fv_buy_count .. "," .. secondary_id .. "," .. fv_mc
    --   .. "," ..       fv_count
    --  print("\aw",data)
    return data
end

local function multi_option_check(p_id, p_count, p_silent)
    local swap_id, swap_count, conversion_status =
        lib.multi_component_check(p_id, p_count, p_silent)

    local data_string
    local l_item_name

    -- if we have 1 lb then why are we checking and selecting..??
    -- print("cruncher testing multi ",p_id," ",conversion_status)

    --- 0 bypass multi option non conversions
    if swap_id ~= 0 and conversion_status == 99 then
        for x = 0, #data_array do
            local l_recipe_id = lib.return_number(data_array[x], 4)
            if p_id == l_recipe_id then
                l_item_name = lib.return_string(data_array[x], 2)
                print(msg, "\ap[\atRemoving: \ap] \ap[\ag", l_item_name, "\ap]")
                --     table.remove(data_array, l_item_name)
                -- Only remove 1 occurrence -- watch this
                break
            end
        end

        table.remove(data_array, l_item_name)

        data_string = make_data(p_id, swap_id, swap_count)

        local dummy = {}

        for x = 1, #dummy do
            local l_get_soiled_name = lib.return_string(dummy[x], 2)
            if string.find(l_item_name, l_get_soiled_name) then
                --  print(msg, "\atRemoving Soiled: \aw", l_get_soiled_name)
                -- table.remove(soiled, l_item_name)
                break
            end
        end

        table.remove(dummy, l_item_name)

        data_string = make_data(p_id, swap_id, swap_count)
        table.insert(data_array, data_string)

        -- fix
        -- so we need to crunch a swap..  to see if we can make it
        -- 1- is food conversions 0 is multi?
        -- need calling row count or whatever--yields
        -- doesn't add sub recipes on subsequent craft tries.. why not?
        -- inventory already for main swapped recipe,what to do?
        print(msg, "Experimental TCN Cruncher")

        -- second time we run it doesnt reset data or? is it the array and placement?

        for mini in db:nrows("SELECT * FROM MasterCompTable where recipeid=" ..
                                 swap_id) do
            if mini.SubRecipeID > 0 and mq.TLO.FindItemCount(mini.ItemID)() <
                mini.ItemCount then
                print(msg, "\ap[\agAdding Recipe: \ap]\ap [\aw", mini.ItemName,
                      "\ap]")
                -- will counts do it?
                -- swap_id?
                data_string = make_data(p_id, mini.SubRecipeID, swap_count)
                -- do single rec check?

                print(msg, "Second Try: MINI Crunch ", data_string)

                table.insert(data_array, data_string)
            end
        end

        -- for x = 0, #data_array do print(data_array[x]) end -- os.exit()
        return 0
    end

    -- Food conversion lbs to lbs
    if swap_id ~= 0 and conversion_status == 1 then
        data_string = make_data(p_id, swap_id, swap_count)
        table.insert(data_array, data_string)
        return 0
    end

    return 1
end

-- Add items to array - checks inventory, bank, and vendor
local function component_area(p_item_id, p_hc, p_recipe_id, p_need_count,
                              p_silent, p_rcc, p_type, p_item_name, p_mid)

    local l_item_name = p_item_name

    if l_item_name == nil then
        print(msg, "\ayError: \agNo item name found in either table")
        os.exit()
    end

    local tv_nc = math.ceil(p_need_count)
    if p_item_id ~= p_mid then

        if string.find(l_item_name, ",") then
            l_item_name = l_item_name:gsub(',', '@')
        end

        local comp_string = l_item_name .. "," .. p_item_id .. "," .. tv_nc

        table.insert(component_array, comp_string)
    end

    return
end

local function calc_and_soil(p_item_id, p_item_count, p_main_id, p_silent,
                             p_tv_rv, p_item_name, p_mid)

    -- Get inventory count of component
    local tv_hc = mq.TLO.FindItemCount(p_item_id)()

    p_item_count = tonumber(p_item_count)

    -- Error checking
    if p_item_count == nil then
        print("cruncher error NIL passed ItemCount tv_ic", p_main_id, " ",
              p_item_count)
        os.exit()
    end
    -- Calculate buy count * Item count in row
    local l_tv_cr = p_tv_rv * p_item_count
    -- Add item if missing

    -- print("calc and soil ", p_item_id," ",l_tv_cr)

    component_area(p_item_id, tv_hc, p_main_id, l_tv_cr, p_silent, 0, 0,
                   p_item_name, p_mid)
    return
end

local function recipe_calc(p_main_id, p_sub_id, p_pass_var, p_silent,
                           p_row_item_count, p_mitem_id)

    p_pass_var = math.ceil(p_pass_var)

    -- Determine how many sets to buy
    local l_sets_wanted = calc_buy_count(p_main_id, p_sub_id, p_pass_var)

    -- print("\ayCRUNCHER sets wanted: ",  l_sets_wanted ," main ", p_main_id, " sub ",p_sub_id, " pass: ",p_pass_var)

    -- Buy set count
    local l_tv_rv = l_sets_wanted

    -- print ("set count : ",l_tv_rv, " passvr ",p_pass_var)

    -- fix
    -- Check if there is another option for the recipe to be completed

    -- Sets buy count to 0 if multi_option available this needs assistance
    if l_tv_rv ~= 0 then
        local answer = multi_option_check(p_main_id, p_pass_var, p_silent)
        -- it has been doing conversions
        --  print ("here ", p_main_id)
        -- if it the primary id it will never pick the sub?
        if answer == 0 then l_tv_rv = 0 end
    end
    -- Recipe count is satisifed	
    if (l_tv_rv == 0) then
        -- list_row1.SubRecipeID = 0
        -- print(msg, "Returning ", p_sub_id)
        return 0
        -- Recipe count not satisified
    else
        if p_silent == 1 then
            -- print("\ay[Sub-Recipe ID:] \ay[", list_row1.SubRecipeID,
            --  "] \aw[", list_row1.ItemName, "] [Item ID:] \at[",
            --  list_row1.ItemID, "]")
        end

        -- Make another array for a mass breakdown of skills needed for the recipe?
        -- Ignore skill level checking

        -- Add recipe to array
        local data_string = make_data(p_main_id, p_sub_id, l_tv_rv, p_pass_var)
        table.insert(data_array, data_string)

        --   print("data_string ", data_string)
        return l_tv_rv
    end
end

local function processRecipeRows(recipeID, passVar, p_silent, p_mid)
    local silent = p_silent
    local tv_mid = p_mid -- Main Item ID

    -- Iterate over rows in MasterCompTable for the given recipeID
    for list_row in db:nrows(
                        "SELECT * FROM MasterCompTable WHERE RecipeID = " ..
                            recipeID .. " ORDER BY SubRecipeID ASC") do
        local tv_rv = passVar
        local subRecipeID = list_row.SubRecipeID

        if subRecipeID ~= 0 then
            -- Process the sub-recipe
            tv_rv = recipe_calc(recipeID, subRecipeID, tv_rv, silent,
                                list_row.ItemCount, list_row.ItemID)
        else
            -- Check to see if main_id is a tool
            local tcr = crunch_toolcheck(recipeID)
            -- local tcr = 0
            -- Don't soil if the main ID is a tool, because we calculate this later
            if tcr ~= 1 then
                calc_and_soil(list_row.ItemID, list_row.ItemCount, recipeID,
                              silent, tv_rv, list_row.ItemName, tv_mid)
            end
        end

        -- If subRecipeID is greater than 0, recursively process its rows
        if subRecipeID > 0 then
            processRecipeRows(subRecipeID, tv_rv, 0, tv_mid)
        end
    end
end

-- Start the crunch
local crunch = {}
-- p _ option 1 means make tools based on the quest 
function crunch.items(main_id, want_count, p_silent)

    start_time = os.time()

    -- GLOBAL_TEXT = "State: Processing Recipe.."

    -- Initialize Array each run
    component_array = {}

    e_tool_array = {}

    mass_bank_list = {}
    temp_banked_components = {}

    local tv_rv = 0

    -- testing
    -- main_id = 90812
    -- want_count = 500

    local silent = p_silent

    data_array = {}

    -- Overall want count of item
    local tv_pnc = want_count

    local tv_rn = lib.return_recipe_name(main_id)

    if silent == 1 then
        print("\aw[Master Recipe:] \at", tv_rn, " \ag[Recipe ID:] \at[",
              main_id, "]")
    end

    -- Main Item ID
    local tv_mid = lib.return_item_ID(main_id)
    local tv_hc = mq.TLO.FindItemCount(tv_mid)()

    -- Main Recipe Checking 

    -- ROW 0 Main Recipe
    local tv_yc = lib.return_recipe_yield(main_id)

    if tv_yc == nil then
        print(msg, "\ayError: \ag Invalid Recipe ID: ", main_id)
        os.exit()
    end

    if (tv_pnc - tv_hc) <= tv_yc then
        tv_rv = 1
    else
        tv_rv = math.ceil(tv_pnc - tv_hc) / tv_yc

    end

    -- Verify count correct because it is the main recipe?

    -- tv_rv = math.ceil(tv_pnc - tv_hc) / tv_yc

    -- local result = lib.toolcheck(main_id)
    local result = crunch_toolcheck(main_id)

    -- If first recipe is a tool, it will add to the tool array if we don't have it
    -- This area needs work for the tools..

    -- Disable for TCN_Quests - Will make whatever amount of tools the quest needs
    if GLOBAL_OPTION_FLAG == 1 then result = 0 end

    -- Add tool
    if result == 1 then
        local l_item_id = lib.return_item_ID(main_id)
        local lv_inv = mq.TLO.FindItemCount(l_item_id)()
        local lv_b_inv = mq.TLO.FindItemBankCount(l_item_id)()
        -- local l_item_name = lib.return_item_name(l_item_id)
        if lv_inv >= 1 or lv_b_inv >= 1 then
            --  if lv_inv >= tv_pnc or lv_b_inv >= tv_pnc then
            -- We have the count so don't add to the tool array

            local n_array = {}
            GLOBAL_TEXT =
                "We have the tool, in inventory or in the bank, please pick another recipe"
            return n_array, n_array, n_array, n_array, n_array

        else
            local tool_string = main_id .. ",1"
            -- local tool_string = main_id .. ","..tv_pnc

            -- Omit tool if it is first recipe
            --    table.insert(tool_array, tool_string)

        end
    end

    -- skip tool counts for quests?
    if result == 1 then
        local lv_inv = mq.TLO.FindItemCount(main_id)()
        if lv_inv > 0 then
            tv_rv = 0
        else
            -- fix this up
            tv_rv = 1
        end
    end

    local fv_mc = tv_pnc
    -- * yield

    -- print("CRUNCHER want ", tv_pnc, " have: ", tv_hc, " buy: ", tv_rv, " make: ",
    --   fv_mc, " main id ",main_id)

    local main_yield = tv_yc -- lib.return_recipe_yield(main_id)

    tv_rv = tv_pnc / main_yield

    if main_yield >= tv_pnc then tv_rv = 1 end

    -- print("buy ", tv_rv, " want ", tv_pnc, " make ", fv_mc)

    local pass_var1 = tv_rv

    local l_item_id = lib.return_recipe_item_id(main_id)
    local l_recipe_skill = lib.return_recipe_skill(main_id)
    local l_can_make = lib.check_requirements(l_recipe_skill, main_id)
    local l_recipe_item_name = lib.return_recipe_name(main_id)

    -- this is the 1st recipe
    component_area(l_item_id, tv_hc, main_id, 1, silent, l_can_make, 1,
                   l_recipe_item_name, tv_mid)

    -- Convert anyuthing with a , in the name to an @ 
    if string.find(tv_rn, ",") then tv_rn = tv_rn:gsub(',', '@') end

    local data_string =
        tv_mid .. "," .. tv_rn .. "," .. math.ceil(tv_rv) .. "," .. main_id ..
            "," .. fv_mc

    -- print("1st cruncher: ", data_string)
    -- if the recipe is a tool don't add it twice.. or don't add tool because it doesn't matter?
    -- Add if it is not a tool
    if result == 0 then table.insert(data_array, data_string) end

    -- Add 1st recipe to data array
    -- table.insert(data_array, data_string)

    local new_way = 1

   if GLOBAL_ENGINE_FLAG then new_way = 0 end
 
    -- Start Recipe Interrogation
    if new_way == 0 then processRecipeRows(main_id, tv_rv, 0, tv_mid) end

    -- ROW 1

    if new_way == 1 then
        for list_row1 in db:nrows(
                             "SELECT * FROM MasterCompTable where RecipeID=" ..
                                 main_id .. " ORDER BY SubRecipeID ASC") do

            tv_rv = pass_var1
            -- tv_rv = math.ceil(tv_rv)
            pass_var1 = tv_rv

            -- print"row 1"
            -- print("\atwhat ", tv_rv, " \aypassed need: ", pass_var1, " \agItemId ",
            --   list_row1.ItemName, " \awItemCount ", list_row1.ItemCount,
            --   " s \at", list_row1.SubRecipeID)
            --  print("\agCruncher Row 1 ", list_row1.SubRecipeID, " ",
            -- list_row1.ItemName, " Recipe ID: ", list_row1.RecipeID,
            --  " ItemCount: ", list_row1.ItemCount)

            -- slow down
            -- REMD 4/2/2022
            -- mq.delay(1)
            if list_row1.SubRecipeID > 0 then

                -- print(main_id," ",list_row1.SubRecipeID," ",pass_var1," ",list_row1.ItemID )

                local r_tv_rv = recipe_calc(main_id, list_row1.SubRecipeID,
                                            pass_var1, silent,
                                            list_row1.ItemCount,
                                            list_row1.ItemID)

                --   print(tv_rv," ", list_row1.ItemName)

                tv_rv = r_tv_rv

                pass_var2 = tv_rv

                ---   print ("row 1 ",list_row1.ItemName," ",  list_row1.SubRecipeID, " ",tv_rv )

                if tv_rv == 0 then list_row1.SubRecipeID = 0 end

            else
                -- Check to see if main_id is a tool
                local tcr = crunch_toolcheck(main_id)
                -- local tcr = 0
                -- Don't soil if the main ID is a tool, because we calculate this later
                if tcr ~= 1 then
                    calc_and_soil(list_row1.ItemID, list_row1.ItemCount,
                                  main_id, silent, tv_rv, list_row1.ItemName,
                                  tv_mid)
                end
            end

            -- ROW 1 END

            -- ROW 2--

            for list_row2 in db:nrows(
                                 "SELECT * FROM MasterCompTable where recipeid=" ..
                                     list_row1.SubRecipeID ..
                                     " ORDER BY SubRecipeID ASC") do
                mq.delay(1)

                --    print("\atrow 2 start ",list_row2.ItemName)

                --   print("\ayROW 2 ", list_row2.ItemName, " ID:", list_row2.SubRecipeID)

                if list_row1.SubRecipeID == 0 then break end

                if list_row1.SubRecipeID ~= 0 then

                    if list_row2.SubRecipeID > 0 then
                        local r_tv_rv = recipe_calc(list_row1.SubRecipeID,
                                                    list_row2.SubRecipeID,
                                                    pass_var2, silent,
                                                    list_row2.ItemCount,
                                                    list_row2.ItemID)
                        tv_rv = r_tv_rv
                        pass_var3 = tv_rv
                        if tv_rv == 0 then
                            list_row2.SubRecipeID = 0
                        end
                    end

                    if list_row2.SubRecipeID == 0 then

                        --  print(list_row2.ItemID, " ", list_row2.ItemCount, " ",
                        --      list_row1.SubRecipeID, " ", tv_rv)

                        --    print("\atrow 2 cas ",list_row2.ItemName)

                        calc_and_soil(list_row2.ItemID, list_row2.ItemCount,
                                      list_row1.SubRecipeID, silent, tv_rv,
                                      list_row2.ItemName, tv_mid)

                    end

                end
                -- ROW 2 END--

                -- ROW 3 Start --
                for list_row3 in db:nrows(
                                     "SELECT * FROM MasterCompTable where recipeid=" ..
                                         list_row2.SubRecipeID ..
                                         " ORDER BY SubRecipeID ASC") do
                    mq.delay(1)

                    --    print("\atrow 3 start ",list_row3.ItemName)

                    --   print("\ayrow 3 ", list_row3.ItemName," ",list_row3.SubRecipeID," row 2 sub id ",list_row2.SubRecipeID)

                    if list_row2.SubRecipeID == 0 then break end

                    if list_row2.SubRecipeID ~= 0 then

                        -- print(pass_var2, " ROW 3 pass-var")
                        -- switch around so we check for soured items first.. itemid = 0?
                        if list_row3.SubRecipeID > 0 then
                            local r_tv_rv =
                                recipe_calc(list_row2.SubRecipeID,
                                            list_row3.SubRecipeID, pass_var3,
                                            silent, list_row3.ItemCount,
                                            list_row3.ItemID)
                            tv_rv = r_tv_rv
                            pass_var4 = tv_rv
                            if tv_rv == 0 then
                                list_row3.SubRecipeID = 0
                            end
                        else

                            --  print("\atrow 3 cas ",list_row3.ItemName)

                            calc_and_soil(list_row3.ItemID, list_row3.ItemCount,
                                          list_row2.SubRecipeID, silent, tv_rv,
                                          list_row3.ItemName, tv_mid)
                        end

                    end
                    -- ROW 3 END--

                    -- ROW 4 --
                    for list_row4 in db:nrows(
                                         "SELECT * FROM MasterCompTable where recipeid=" ..
                                             list_row3.SubRecipeID ..
                                             " ORDER BY SubRecipeID ASC") do

                        --  print("\atrow 4 start ",list_row4.ItemName)

                        mq.delay(1)

                        if list_row3.SubRecipeID == 0 then
                            break
                        end

                        if list_row3.SubRecipeID ~= 0 then

                            if list_row4.SubRecipeID > 0 then
                                local r_tv_rv = recipe_calc(
                                                    list_row3.SubRecipeID,
                                                    list_row4.SubRecipeID,
                                                    pass_var4, silent,
                                                    list_row4.ItemCount,
                                                    list_row4.ItemID)
                                tv_rv = r_tv_rv
                                pass_var5 = tv_rv
                                if tv_rv == 0 then
                                    list_row4.SubRecipeIDemID = 0
                                end
                            else
                                calc_and_soil(list_row4.ItemID,
                                              list_row4.ItemCount,
                                              list_row3.SubRecipeID, silent,
                                              tv_rv, list_row4.ItemName, tv_mid)
                            end

                        end
                        -- ROW 4 END--

                        -- ROW 5--

                        for list_row5 in db:nrows(
                                             "SELECT * FROM MasterCompTable where recipeid=" ..
                                                 list_row4.SubRecipeID ..
                                                 " ORDER BY SubRecipeID ASC") do
                            mq.delay(1)

                            if list_row4.SubRecipeID == 0 then
                                break
                            end

                            if list_row4.SubRecipeID ~= 0 then

                                if list_row5.SubRecipeID > 0 then
                                    local r_tv_rv = recipe_calc(
                                                        list_row4.SubRecipeID,
                                                        list_row5.SubRecipeID,
                                                        pass_var5, silent,
                                                        list_row5.ItemCount,
                                                        list_row5.ItemID)
                                    tv_rv = r_tv_rv
                                    pass_var6 = tv_rv
                                    if tv_rv == 0 then
                                        list_row5.SubRecipeID = 0
                                    end
                                else
                                    calc_and_soil(list_row5.ItemID,
                                                  list_row5.ItemCount,
                                                  list_row4.SubRecipeID, silent,
                                                  tv_rv, list_row5.ItemName,
                                                  tv_mid)
                                end
                            end

                            -- ROW 6
                            for list_row6 in db:nrows(
                                                 "SELECT * FROM MasterCompTable where recipeid=" ..
                                                     list_row5.SubRecipeID ..
                                                     " ORDER BY SubRecipeID ASC") do
                                --  print("\ag[6] Item ID:\aw",list_row6.ItemID,"",list_row6.ItemName)
                                mq.delay(1)

                                if list_row5.SubRecipeID == 0 then
                                    break
                                end

                                if list_row5.SubRecipeID ~= 0 then

                                    if list_row6.SubRecipeID > 0 then
                                        local r_tv_rv = recipe_calc(
                                                            list_row5.SubRecipeID,
                                                            list_row6.SubRecipeID,
                                                            pass_var6, silent,
                                                            list_row6.ItemCount,
                                                            list_row6.ItemID)
                                        tv_rv = r_tv_rv
                                        pass_var7 = tv_rv
                                        if tv_rv == 0 then
                                            list_row6.SubRecipeID = 0
                                        end
                                    else
                                        calc_and_soil(list_row6.ItemID,
                                                      list_row6.ItemCount,
                                                      list_row5.SubRecipeID,
                                                      silent, tv_rv,
                                                      list_row6.ItemName, tv_mid)
                                    end

                                end

                                -- ROW 7
                                for list_row7 in db:nrows(
                                                     "SELECT * FROM MasterCompTable where recipeid=" ..
                                                         list_row6.SubRecipeID ..
                                                         " ORDER BY SubRecipeID ASC") do
                                    mq.delay(1)

                                    if list_row6.SubRecipeID == 0 then
                                        break
                                    end

                                    if list_row6.SubRecipeID ~= 0 then

                                        if list_row7.SubRecipeID > 0 then
                                            local r_tv_rv = recipe_calc(
                                                                list_row6.SubRecipeID,
                                                                list_row7.SubRecipeID,
                                                                pass_var7,
                                                                silent,
                                                                list_row7.ItemCount,
                                                                list_row7.ItemID)
                                            tv_rv = r_tv_rv
                                            pass_var8 = tv_rv
                                            if tv_rv == 0 then
                                                list_row7.SubRecipeID = 0
                                            end
                                        else
                                            calc_and_soil(list_row7.ItemID,
                                                          list_row7.ItemCount,
                                                          list_row6.SubRecipeID,
                                                          silent, tv_rv,
                                                          list_row7.ItemName,
                                                          tv_mid)
                                        end
                                    end

                                    -- ROW 8
                                    for list_row8 in db:nrows(
                                                         "SELECT * FROM MasterCompTable where recipeid=" ..
                                                             list_row7.SubRecipeID ..
                                                             " ORDER BY SubRecipeID ASC") do
                                        mq.delay(1)

                                        if list_row7.SubRecipeID == 0 then
                                            break
                                        end

                                        if list_row7.SubRecipeID ~= 0 then

                                            if list_row8.SubRecipeID > 0 then
                                                local r_tv_rv = recipe_calc(
                                                                    list_row7.SubRecipeID,
                                                                    list_row8.SubRecipeID,
                                                                    pass_var8,
                                                                    silent,
                                                                    list_row8.ItemCount,
                                                                    list_row8.ItemID)
                                                tv_rv = r_tv_rv
                                                pass_var9 = tv_rv
                                                if tv_rv == 0 then
                                                    list_row8.SubRecipeID = 0
                                                end
                                            else
                                                calc_and_soil(list_row8.ItemID,
                                                              list_row8.ItemCount,
                                                              list_row7.SubRecipeID,
                                                              silent, tv_rv,
                                                              list_row8.ItemName,
                                                              tv_mid)
                                            end
                                        end

                                        -- ROW 9
                                        for list_row9 in db:nrows(
                                                             "SELECT * FROM MasterCompTable where recipeid=" ..
                                                                 list_row8.SubRecipeID ..
                                                                 " ORDER BY SubRecipeID ASC") do
                                            mq.delay(1)

                                            if list_row8.SubRecipeID == 0 then
                                                break
                                            end

                                            if list_row8.SubRecipeID ~= 0 then

                                                if list_row9.SubRecipeID > 0 then
                                                    local r_tv_rv = recipe_calc(
                                                                        list_row8.SubRecipeID,
                                                                        list_row9.SubRecipeID,
                                                                        pass_var9,
                                                                        silent,
                                                                        list_row9.ItemCount,
                                                                        list_row9.ItemID)
                                                    tv_rv = r_tv_rv
                                                    pass_var10 = tv_rv
                                                    if tv_rv == 0 then
                                                        list_row9.SubRecipeID =
                                                            0
                                                    end
                                                else
                                                    calc_and_soil(
                                                        list_row9.ItemID,
                                                        list_row9.ItemCount,
                                                        list_row8.SubRecipeID,
                                                        silent, tv_rv,
                                                        list_row9.ItemName,
                                                        tv_mid)
                                                end
                                            end

                                            -- ROW 10
                                            for list_row10 in db:nrows(
                                                                  "SELECT * FROM MasterCompTable where recipeid=" ..
                                                                      list_row9.SubRecipeID ..
                                                                      " ORDER BY SubRecipeID ASC") do
                                                mq.delay(1)

                                                if list_row9.SubRecipeID == 0 then
                                                    break
                                                end

                                                if list_row9.SubRecipeID ~= 0 then

                                                    if list_row10.SubRecipeID >
                                                        0 then
                                                        local r_tv_rv =
                                                            recipe_calc(
                                                                list_row10.SubRecipeID,
                                                                list_row9.SubRecipeID,
                                                                pass_var10,
                                                                silent,
                                                                list_row10.ItemCount,
                                                                list_row10.ItemID)
                                                        tv_rv = r_tv_rv
                                                        pass_var11 = tv_rv
                                                        if tv_rv == 0 then
                                                            list_row10.SubRecipeID =
                                                                0
                                                        end
                                                    else
                                                        calc_and_soil(
                                                            list_row10.ItemID,
                                                            list_row10.ItemCount,
                                                            list_row9.SubRecipeID,
                                                            silent, tv_rv,
                                                            list_row10.ItemName,
                                                            tv_mid)
                                                    end
                                                end

                                                -- ROW 11
                                                for list_row11 in db:nrows(
                                                                      "SELECT * FROM MasterCompTable where recipeid=" ..
                                                                          list_row10.SubRecipeID ..
                                                                          " ORDER BY SubRecipeID ASC") do
                                                    mq.delay(1)

                                                    if list_row10.SubRecipeID ==
                                                        0 then
                                                        break
                                                    end

                                                    if list_row10.SubRecipeID ~=
                                                        0 then

                                                        if list_row11.SubRecipeID >
                                                            0 then
                                                            local r_tv_rv =
                                                                recipe_calc(
                                                                    list_row11.SubRecipeID,
                                                                    list_row10.SubRecipeID,
                                                                    pass_var11,
                                                                    silent,
                                                                    list_row11.ItemCount,
                                                                    list_row11.ItemID)
                                                            tv_rv = r_tv_rv
                                                            -- rownot implmented
                                                            --   pass_var12 = tv_rv
                                                            if tv_rv == 0 then
                                                                list_row11.SubRecipeID =
                                                                    0
                                                            end
                                                        else
                                                            calc_and_soil(
                                                                list_row11.ItemID,
                                                                list_row11.ItemCount,
                                                                list_row10.SubRecipeID,
                                                                silent, tv_rv,
                                                                list_row11.ItemName,
                                                                tv_mid)
                                                        end
                                                    end

                                                end
                                            end
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
            end
            -- print ("\ay**********************************************************")
        end
    end

    local mass_recipe_list = data_array

    local temp_tool_array = {}
    local last_tool_id = 0

    -- Check if there are any tools that we don't have in the recipe

    if tool_array[1] ~= nil then
        table.sort(tool_array)
        for x = 1, #tool_array do
            -- print("\agCrunchy Tools: ", tool_array[x])
        end
        -- Need to count tools that have a count > 1

        -- Remove Duplicate Tools
        for x = 1, #tool_array do
            local tool_id = lib.return_number(tool_array[x], 1)
            -- print(tool_id)
            -- if last_tool_id ~= tool_array[x] then

            -- Tools that have tools in them agh!

            if last_tool_id ~= tool_id then
                -- If it is a laminator blade and it uses a file don't add the file again!
                if main_id == 35559 and tool_id == 94960 then
                else
                    --    print("\agAdded Tools: ", tool_array[x])
                    table.insert(temp_tool_array, tool_array[x])
                end

            end
            last_tool_id = tool_id
            -- tool_array[x]
        end

        -- Reset main tool array
        tool_array = {}

        -- Only add tools we don't have (This is done twice)
        for x = 1, #temp_tool_array do
            --   print(temp_tool_array[x])
            local tool_recipe_id = lib.return_number(temp_tool_array[x], 1)
            local tool_recipe_row_count =
                lib.return_number(temp_tool_array[x], 2)
            l_item_id = lib.return_item_ID(tool_recipe_id)
            -- local tc,tsb = lib.toolcheck(tool_recipe_id)
            if (mq.TLO.FindItemCount(l_item_id)() >= tool_recipe_row_count or
                mq.TLO.FindItemBankCount(l_item_id)() >= tool_recipe_row_count) then
            else
                --   print(tool_recipe_id, " rec id")
                table.insert(tool_array,
                             tool_recipe_id .. "," .. tool_recipe_row_count)
            end
        end

        temp_tool_array = tool_array

        -- Crunch tool recipe list
        for c = 1, #temp_tool_array do

            local tool_recipe_id = lib.return_number(temp_tool_array[c], 1)
            local tool_recipe_row_count =
                lib.return_number(temp_tool_array[c], 2)
            -- print("count ", tool_recipe_row_count)
            l_item_id = lib.return_item_ID(tool_recipe_id)

            local tool_recipe_list, temp_nothing, temp_nothing, temp_bank,
                  recrunch_soiled = recrunch.items(tool_recipe_id,
                                                   tool_recipe_row_count, 0, 0) -- make known makeable tools with no subs list.. so we don't recrunch a file or something like that.?

            -- Add tools to recipe array to be made
            for d = 1, #tool_recipe_list do

                l_item_id = lib.return_number(tool_recipe_list[d], 1)

                -- local l_recipe_id = lib.return_number(tool_recipe_list[d], 4)
                -- local l_item_inv = mq.TLO.FindItemCount(l_item_id)()
                -- local lb_item_inv = mq.TLO.FindItemBankCount(l_item_id)()
                -- local l_toolcheck = lib.toolcheck_id(l_item_id)

                -- if GLOBAL_GENERATE_FLAG == 0 then
                -- Add tool recipe to recipe array
        
                table.insert(mass_recipe_list, tool_recipe_list[d])

                -- end
            end

            -- Add banked components from tool re-crunch
            if temp_bank[1] ~= nil then
                for e = 1, #temp_bank do
                    -- print("banked items ", temp_bank[e])
                    -- 1/3/22 -- Watch for other things being added to temp_baked_components
                    table.insert(temp_banked_components, temp_bank[e])
                end
            end

            --- Glboal gen flag here?
            -- if GLOBAL_GENERATE_FLAG == 0 then

            -- revisit
            for e = 1, #recrunch_soiled do
                --  Add soled items for...
                -- table.insert(compare_soiled, recrunch_soiled[e])
            end
            --   end

        end

    end

    -- This is used for making tools not for banking lists
    -- for c = 1, #tool_array do print("Cruncher Final Tools: ", tool_array[c]) end

    local tools = tool_array
    tool_array = {}

    for x = #mass_recipe_list, 1, -1 do
        -- print("\aw TCN CRUNCHER \agReverse Order: \at", mass_recipe_list[x])
    end

    -- os.exit()

    -- Add missing items to bank array and squash counts

    local last_id = 0
    local TotalCount = 0
    local var_ItemName
    local temp_bank_array2 = {}
    local final_missing_array = {}
    local go_flag = 1

    -- last chance here

    -- Trophy Selection Code
    local temp_array = {}
    for c = 1, #mass_recipe_list do
        local rec_skill = lib.return_number(mass_recipe_list[c], 4)
        local recipe_skill = lib.return_recipe_skill(rec_skill)
        table.insert(temp_array, recipe_skill)
    end

    temp_array = removeDuplicates(temp_array)

    for c = 1, #temp_array do
        local have_trophy_flag, l_trophy_id = lib.have_trophy(temp_array[c])
        if l_trophy_id ~= nil then
            if mq.TLO.FindItemCount(l_trophy_id)() > 0 then
                -- Trophy on person
            else
                table.insert(temp_bank_array2,
                             have_trophy_flag .. "," .. l_trophy_id .. ",1")
            end
        end
    end
    -- End Trophy Code

    -- note add a recipe to do a conversion or recplace/add to do a sub replace?

    -- Add Tools from Bank

    -- Sort Banked Tools
    table.sort(banked_tools_array)

    --- Squash Banked Tools

    local last_tool = 0
    local tool_temp2 = {}
    for x = 1, #banked_tools_array do
        if last_tool ~= banked_tools_array[x] then
            table.insert(tool_temp2, banked_tools_array[x])
        end
        last_tool = banked_tools_array[x]
    end

    banked_tools_array = {}

    -- Add to banked array

    for x = 1, #tool_temp2 do table.insert(temp_bank_array2, tool_temp2[x]) end

    -- final list of tools, trophies, and whatever
    -- for x = 1, #temp_bank_array2 do print("\agfinal final banked tools: ",temp_bank_array2[x]) end

    tool_temp2 = {}
    mass_bank_list = temp_bank_array2
    temp_bank_array2 = {}

    GLOBAL_TEXT = "Recipe processed..."

    local end_time = os.time()

    if string.find(tv_rn, "@") then tv_rn = tv_rn:gsub('@', ',') end

    print(msg,
          "\agRecipe \ap(\aw" .. tv_rn .. "\ap) \agProcessed In:\at (\ay" ..
              end_time - start_time .. "\at) \agSeconds")

    -- tool recipes independent of main recipes
    -- for c = 1 ,#tools do print(tools[c]) end

    local mass_tool_list = tools

    -- for c = 1 ,#component_array do print("\at",component_array[c]) end

    return mass_recipe_list, mass_tool_list, mass_bank_list, component_array,
           e_tool_array
end

return crunch
