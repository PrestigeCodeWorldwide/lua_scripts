-- tcn_tsd_init
-- 1.2b
-- jb321
-- created: 12/7/2022
-- upd 2/9/2024
local mq = require('mq')

-- if not mq.TLO.TradeskillDepot.Enabled() then return end

if not mq.TLO.TradeskillDepot.ItemsReceived() then

    if not mq.TLO.Window('TradeskillDepotWnd').Open() then
        mq.TLO.Window('TradeskillDepotWnd').DoOpen()
        mq.delay(500)
    end

    print "Initialize Depot"

    -- Wait for list to populate
    while not mq.TLO.TradeskillDepot.ItemsReceived() do mq.delay(1000) end

end
-- mq.TLO.Window('TradeskillDepotWnd').DoClose()

mq.delay(1)
