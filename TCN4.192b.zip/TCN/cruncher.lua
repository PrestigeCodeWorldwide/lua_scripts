-- created: 09/07/2021
-- updated: 09/11/2025
-- creator: jb321
-- version: 2.0b
-- name: Cruncher
local mq = require('mq')

local sqlite3 = require('lsqlite3')

local db = sqlite3.open(mq.luaDir .. '\\tcn\\Artisan.db')
local lib = require('tcn_Library')
local recrunch = require('tcn_recrunch')

local data_array = {}
local bank_table = {}
local start_time
local tool_array = {}

-- Sour Recipe Global?
local revisit_soiled = {}

local msg = "\ap[\atTCSNe\auX\att\ap]\aw "

local component_array = {}
local component_array_inv = {}

local t_main_id = 0

-- local functions
local function return_toon_item_inv_count(p_id)
    local r_value = 0
    local r_name = nil
    local r_flag = 0
    local linv_count = mq.TLO.FindItemCount(p_id)()
    local binv_count = mq.TLO.FindItemBankCount(p_id)()

    local tinv_count = 0

    tinv_count = linv_count + binv_count

    local dinv_count = 0

    -- Account for TSD inventory
    if mq.TLO.TradeskillDepot.Enabled() then
        dinv_count = mq.TLO.TradeskillDepot.FindItemCount(p_id)()
    end

    -- Add in TSD
    if mq.TLO.TradeskillDepot.Enabled() then
        if dinv_count > 0 then
            tinv_count = linv_count + binv_count + dinv_count
        end
    end

    -- None in inventory return nothing
    if tinv_count < 1 then return 0, nil end

    for c = 1, #component_array_inv do
        if component_array_inv[c].ItemID == p_id then
            r_value = component_array_inv[c].ItemCount
            r_name = component_array_inv[c].ItemName
            r_flag = 1
            break
        end
    end

    if r_flag == 1 then return r_value, r_name end

    -- Not In Array/Add It
    local l_item_name = lib.return_item_name(p_id)
    local array_item = {
        ItemID = p_id,
        ItemCount = tinv_count,
        ItemName = l_item_name
    }

    table.insert(component_array_inv, array_item)
    local array_size = #component_array_inv

    return component_array_inv[array_size].ItemCount,
        component_array_inv[array_size].ItemName
end

local function update_toon_item_inv_count(p_id, p_count)
    p_id = tonumber(p_id)
    for c = 1, #component_array_inv do
        local c_id = component_array_inv[c].ItemID
        if c_id == p_id then
            component_array_inv[c].ItemCount = p_count
            break
        end
    end
    return
end

-- Static recipe IDs for all crafted tools
local function crunch_toolcheck(p_id)
    local crafted_tool_array = {
        108028, 93131, 9913432, 97063, 98043, 108286, 108961, 88214, 88534,
        88655, 88747, 88776, 88931, 89129, 89306, 89307, 34653, 94961, 1234,
        98773, 101251, 9910064, 11298, 101062, 99296, 101063, 101838, 93048,
        97036, 108278, 94170, 94183, 92429, 92755, 95644, 95815, 98848, 99568,
        100420, 100468, 108004, 108016, 108127, 108133, 108958, 109101, 109111,
        109229, 95874, 93008, 817, 63767, 99565, 108968, 35560, 94960, 35563,
        108293, 35559, 97034, 93064
    }

    local value = 0
    for c = 1, #crafted_tool_array do
        if crafted_tool_array[c] == p_id then
            value = 1
            break
        end
    end
    return value
end

local function make_data(p_id, s_id, p_bc, p_mc)
    -- Primary ID, Secondary ID, Buy Count
    local primary_id = p_id
    local secondary_id = s_id
    local fv_buy_count = p_bc

    local fv_secondary_item_id = lib.return_item_ID(s_id)
    local fv_secondary_item_name = lib.return_recipe_name(s_id)
    local fv_yield = lib.return_recipe_yield(secondary_id)

    -- print("\agmake_data cruncher string ", fv_secondary_item_name)

    if fv_yield == nil then
        print(msg, "Error: NIL YIELD BUY CALC")
        os.exit()
    end

    local fv_mc = math.ceil(fv_buy_count * fv_yield)

    -- For the 2 pottery items
    if string.find(fv_secondary_item_name, ",") then
        fv_secondary_item_name = fv_secondary_item_name:gsub(',', '@')
    end

    -- print("make data_ cruncher: make count ", fv_mc, " second sid: ",
    --  fv_secondary_item_id, " sid ", s_id)

    local data = fv_secondary_item_id .. "," .. fv_secondary_item_name .. "," ..
        fv_buy_count .. "," .. secondary_id .. "," .. fv_mc
    return data
end

local function removeDuplicates(arr)
    local newArray = {}
    local checkerTbl = {}
    for _, element in ipairs(arr) do
        if not checkerTbl[element] then -- if there is not yet a value at the index of element, then it will be nil, which will operate like false in an if statement
            checkerTbl[element] = true
            table.insert(newArray, element)
        end
    end
    return newArray
end

-- calc buy  count ---------
local function calc_buy_count(p_id, s_id, p_sets_wanted, sid_item_id,
                              pid_item_id, p_mid)
    if p_id == nil then
        print("err calc_buy_count PID1", p_id, " ", s_id)
        os.exit()
    end

    if s_id == nil then
        print("err calc_buy_count SID1", s_id, " ", p_id)
        os.exit()
    end

    if p_sets_wanted == nil then
        print("err calc_buy_count PID", p_id)
        os.exit()
    end

    --   print("PID and SID data: ", p_id, " ", s_id)

    local set_count = 0

    -- How many items are needed of the sub recipe to satisify the main recipe
    local item_row_count = lib.Return_Calling_Recipe_Row_Count(p_id, s_id)

    if item_row_count == nil then
        print(msg, p_id, " ", s_id,
            " Broked, NIL calling row count TCN Cruncher")
        os.exit()
    end

    --  print(msg, p_id, " ", s_id)

    local tool_check1 = crunch_toolcheck(p_id)

    -- Disable for TCN_Quests - makes tools
    if GLOBAL_OPTION_FLAG == 1 then tool_check1 = 0 end

    if tool_check1 == 1 then
        local tool_string = p_id .. "," .. item_row_count
        table.insert(tool_array, tool_string)

        --  print(tool_string," a")

        -- Add Laminator Roller from bank to grab Added: 6/10/2023
        if p_id == 35563 and s_id == 35560 then
            -- Laminator Roller
            local inv_count = mq.TLO.FindItemCount(96489)()
            local b_inv_count = mq.TLO.FindItemBankCount(96489)()

            if inv_count < 1 and b_inv_count > 0 then
                local a_tool_string = s_id .. ",1"
                table.insert(tool_array, a_tool_string)
                -- print("a " ,a_tool_string)
            end

            -- No Laminator Roller, add it to tools to make
            if inv_count < 1 and b_inv_count < 1 then
                local a_tool_string = s_id .. ",1"
                table.insert(tool_array, a_tool_string)
                -- print("b ",a_tool_string)
            end
        end

        return 0
    end

    tool_check1 = crunch_toolcheck(s_id)

    -- Disable for TCN_Quests - makes tools
    -- if GLOBAL_OPTION_FLAG == 1 then tool_check1 = 0 end

    -- Add tool to array and sour chain
    if tool_check1 == 1 then
        local tool_string = s_id .. "," .. item_row_count

        --   print("b ",tool_string)

        table.insert(tool_array, tool_string)
        return 0
    end

    -- p_sets_wanted is how many the main recipe wants of the sub recipe
    -- item_count is how many in the sub recipe items is required to make 1 set

    local l_yield = lib.return_recipe_yield(s_id)

    if l_yield == nil then
        print(msg, "\ayError: \ag", s_id,
            " Recipe not in table, check component table for ID")
        os.exit()
    end

    local l_sub_item_id = lib.return_item_ID(s_id)

    local l_desired_count = (item_row_count * p_sets_wanted)

    if l_desired_count < 1 then return 0 end

    -- Read Dynamic Array Table
    local toon_inv_count, toon_item_name =
        return_toon_item_inv_count(l_sub_item_id)

    if toon_item_name ~= nil then
        -- Have recipe counts
        if toon_inv_count >= l_desired_count then
            toon_inv_count = toon_inv_count - l_desired_count
            update_toon_item_inv_count(l_sub_item_id, toon_inv_count)

            if string.find(toon_item_name, ",") then
                toon_item_name = toon_item_name:gsub(',', '@')
            end

            local comp_string = toon_item_name .. "," .. l_sub_item_id .. "," ..
                l_desired_count

            table.insert(component_array, comp_string)
            l_desired_count = 0
        else
            if toon_inv_count > 0 and toon_inv_count < l_desired_count then
                l_desired_count = l_desired_count - toon_inv_count

                if string.find(toon_item_name, ",") then
                    toon_item_name = toon_item_name:gsub(',', '@')
                end

                local comp_string = toon_item_name .. "," .. l_sub_item_id ..
                    "," .. toon_inv_count

                table.insert(component_array, comp_string)
                update_toon_item_inv_count(l_sub_item_id, 0)
                toon_inv_count = 0
            end
        end
    end

    set_count = lib.set_amount(l_desired_count, l_yield)

    return set_count
end

local function multi_option_check(p_id, p_count, p_silent)
    local swap_id, swap_count, conversion_status =
        lib.multi_component_check(p_id, p_count, p_silent)

    local data_string
    local l_item_name

    -- if we have 1 lb then why are we checking and selecting..??

    -- skipping this right now..
    --- 0 bypass multi option non conversions
    if swap_id ~= 0 and conversion_status == 99 then
        for x = 0, #data_array do
            local l_recipe_id = lib.return_number(data_array[x], 4)
            if p_id == l_recipe_id then
                l_item_name = lib.return_string(data_array[x], 2)
                print(msg, "\ap[\atRemoving: \ap] \ap[\ag", l_item_name, "\ap]")
                --     table.remove(data_array, l_item_name)
                -- Only remove 1 occurrence -- watch this
                break
            end
        end

        table.remove(data_array, l_item_name)

        data_string = make_data(p_id, swap_id, swap_count)

        -- revist and use farm_table
        for x = 1, #revisit_soiled do
            local l_get_soiled_name = lib.return_string(revisit_soiled[x], 2)
            if string.find(l_item_name, l_get_soiled_name) then
                -- get location of soled item.. but well there are no soled items here eh?
                break
            end
        end

        table.remove(revisit_soiled, l_item_name)

        data_string = make_data(p_id, swap_id, swap_count)
        table.insert(data_array, data_string)

        -- fix
        -- so we need to crunch a swap..  to see if we can make it
        -- 1- is food conversions 0 is multi?
        -- need calling row count or whatever--yields
        -- doesn't add sub recipes on subsequent craft tries.. why not?
        -- inventory already for main swapped recipe,what to do?
        print(msg, "Experimental TCN Cruncher")

        -- second time we run it doesnt reset data or? is it the array and placement?

        -- do a full crunch for recipe swap replacement with tcn_recrunch

        for mini in db:nrows("SELECT * FROM MasterCompTable where recipeid=" ..
            swap_id) do
            if mini.SubRecipeID > 0 and mq.TLO.FindItemCount(mini.ItemID)() <
                mini.ItemCount then
                print(msg, "\ap[\agAdding Recipe: \ap]\ap [\aw", mini.ItemName,
                    "\ap]")
                -- will counts work?
                -- swap_id?
                data_string = make_data(p_id, mini.SubRecipeID, swap_count)
                -- do single rec check?

                print(msg, "Second Try: MINI Crunch ", data_string)

                table.insert(data_array, data_string)
            end
        end

        return 0
    end

    -- Food conversion lbs to lbs
    if swap_id ~= 0 and conversion_status == 1 then
        data_string = make_data(p_id, swap_id, swap_count)
        table.insert(data_array, data_string)
        return 0
    end

    return 1
end

-- Add items to array - checks inventory, bank, and vendor (reivist description)
local function component_area(p_item_id, p_hc, p_recipe_id, p_need_count,
                              p_silent, p_rcc, p_type, p_item_name, p_mid)
    local l_item_name = p_item_name

    if l_item_name == nil then
        print(msg, "\ayError: \agNo item name found in either table")
        os.exit()
    end

    local tv_nc = math.ceil(p_need_count)

    -- print("\agID: \at",p_item_id," \agMID: \at",p_mid," \agRID: \at",p_recipe_id," \agItem: \at",p_item_name," \agNeed: \at",tv_nc," ",t_main_id)

    -- Main recipe and main item id
    if p_item_id == p_mid and p_recipe_id == t_main_id then
        -- if p_item_id ~= p_mid then
        -- Do not add
        -- print("\agID: \at",p_item_id," \agMID: \at",p_mid," \agRID: \at",p_recipe_id," \agItem: \at",p_item_name," \agNeed: \at",tv_nc," ",t_main_id)
    else
        if string.find(l_item_name, ",") then
            l_item_name = l_item_name:gsub(',', '@')
        end

        local comp_string = l_item_name .. "," .. p_item_id .. "," .. tv_nc
        --  print("compy3: ", l_item_name)

        table.insert(component_array, comp_string)
    end
    return
end

local function calc_and_soil(p_item_id, p_item_count, p_main_id, p_silent,
                             p_tv_rv, p_item_name, p_mid)
    -- Get inventory count of component
    local tv_hc = mq.TLO.FindItemCount(p_item_id)()

    p_item_count = tonumber(p_item_count)

    -- Error checking
    if p_item_count == nil then
        print("cruncher error NIL passed ItemCount tv_ic", p_main_id, " ",
            p_item_count)
        os.exit()
    end
    -- Calculate buy count * Item count in row
    local l_tv_cr = p_tv_rv * p_item_count
    -- Add item if missing

    -- print("calc and soil ", p_item_id," ",l_tv_cr)

    component_area(p_item_id, tv_hc, p_main_id, l_tv_cr, p_silent, 0, 0,
        p_item_name, p_mid)
    return
end

local function recipe_calc(p_main_id, p_sub_id, p_pass_var, p_silent,
                           p_row_item_count, sid_item_id, pid_item_id, p_mid)
    p_pass_var = math.ceil(p_pass_var)

    -- Determine how many sets to buy
    local l_sets_wanted = calc_buy_count(p_main_id, p_sub_id, p_pass_var,
        sid_item_id, pid_item_id, p_mid)

    -- print("\ayCRUNCHER sets wanted: ", l_sets_wanted, " main ", p_main_id,
    --   " sub ", p_sub_id, " pass: ", p_pass_var)

    -- Buy set count
    local l_tv_rv = l_sets_wanted

    -- fix
    -- Check if there is another option for the recipe to be completed

    -- Sets buy count to 0 if multi_option available this needs work
    if l_tv_rv ~= 0 then
        local answer = multi_option_check(p_main_id, p_pass_var, p_silent)
        -- it has been doing conversions
        --  print ("here ", p_main_id)
        -- if it the primary id it will never pick the sub?
        if answer == 0 then l_tv_rv = 0 end
    end

    -- Recipe count is satisifed	
    if l_tv_rv == 0 then
        return 0
        -- Recipe count not satisified
    else
        if p_silent == 1 then
            -- print("\ay[Sub-Recipe ID:] \ay[", list_row1.SubRecipeID,
            --  "] \aw[", list_row1.ItemName, "] [Item ID:] \at[",
            --  list_row1.ItemID, "]")
        end

        -- Ignore skill level checking

        -- Fish Scale Swap Section
        if FISH_SCALE_SWAP then
            local fish_map = {
                [26567]   = 26566,   -- TBL
                [89577]   = 89576,   -- TBL Primordial Fish Meat
                [17243]   = 17244,   -- RoS
                [23209]   = 23210,   -- ToV Velium Infused Fish Scales
                [89583]   = 89582,   -- ToV Velium Clouded Fish Blood
                [232101]  = 232102,  -- ToV Velium Spotted Fish Fillets
                [26870]   = 26871,   -- CoV
                [5138118] = 5138119, -- CoV Restless Fish Fillets
                [27579]   = 27580,   -- ToL
                [5138116] = 5138117, -- ToL Bloodied Fish Fillets
                [31109]   = 31110,   -- NoS
                [5138121] = 5138122, -- NoS Spiritual Luclin Fish Steaks
                [39103]   = 39104,   -- LSO Fish Recipes
                [5138123] = 5138124, -- Laurion's Song Serene Cut of Fish
                [41109]   = 41110,   -- TOB Fish Recipes
                [5138126] = 5138127, -- The Outer Brood's Abyssal Filet
            }

            local new_id = fish_map[p_sub_id]
            if new_id then
                p_sub_id = new_id
            end
        end
        -- print(p_sub_id)

        local sub_ids = {
            [27579] = true,
            [27580] = true,
            [26870] = true,
            [26871] = true,
            [23210] = true,
            [23209] = true,
            [17243] = true,
            [17244] = true,
            [26567] = true,
            [26566] = true,
            [5138116] = true,
            [5138117] = true,
            [31109] = true,
            [31110] = true,
            [5138121] = true,
            [5138122] = true,
            [5138118] = true,
            [5138119] = true,
            [89577] = true,
            [89576] = true,
            [89583] = true,
            [89582] = true,
            [232101] = true,
            [232102] = true,
            [39103] = true,
            [39104] = true,
            [5138123] = true,
            [5138124] = true,
            [41109] = true,
            [41110] = true,
            [5138126] = true,
            [5138127] = true
        }

        if sub_ids[p_sub_id] then
            -- next exp or p_sub_id == 5138116 or p_sub_id == 5138117
            local recipe_name = lib.return_recipe_name(p_sub_id)
            print(msg, "\ap[\ayUsing:\ap] \ap[\ag", recipe_name, "\ap]")
        end

        -- End Fish Scale Swap

        -- Note: if it is a straight recipe swap with 1 component we can change it here.

        -- Add recipe to array
        local data_string = make_data(p_main_id, p_sub_id, l_tv_rv, p_pass_var)

        table.insert(data_array, data_string)

        -- bam
        -- print("Needed: ", l_tv_rv)
        -- print("data_string ", data_string)

        return l_tv_rv
    end
end

-- Recursive replacement for ROW 2..ROW N
local function process_recipe_level(current_recipe_id, parent_item_id, pass_var, silent, tv_mid, main_id, depth)
    if depth > 14 then return end

    for row in db:nrows("SELECT * FROM MasterCompTable WHERE RecipeID=" .. current_recipe_id .. " ORDER BY SubRecipeID ASC") do
        mq.delay(1)

        local sub_id     = row.SubRecipeID
        local item_id    = row.ItemID
        local item_name  = row.ItemName
        local item_count = tonumber(row.ItemCount) or 1
        local tv_rv      = pass_var

        if sub_id > 0 then
            tv_rv = recipe_calc(
                current_recipe_id, -- p_main_id
                sub_id,            -- p_sub_id
                pass_var,          -- p_pass_var
                silent,            -- p_silent
                item_count,        -- p_row_item_count
                item_id,           -- sid_item_id
                parent_item_id,    -- pid_item_id
                main_id            -- p_mid
            )

            if tv_rv == 0 then
                sub_id = 0
            else
                -- Recurse into this child, then continue siblings
                process_recipe_level(sub_id, item_id, tv_rv, silent, tv_mid, main_id, depth + 1)
            end
        end

        if sub_id == 0 then
            calc_and_soil(item_id, item_count, current_recipe_id, silent, tv_rv, item_name, tv_mid)
        end
        -- Continue loop to process all siblings at this depth
    end
end

-- Replacement for ROW 1 (process ALL top-level rows; no unconditional break)
local function process_root_rows(main_id, tv_mid, silent, pass_var1)
    for row in db:nrows("SELECT * FROM MasterCompTable WHERE RecipeID=" .. main_id .. " ORDER BY SubRecipeID ASC") do
        local sub_id     = row.SubRecipeID
        local item_id    = row.ItemID
        local item_name  = row.ItemName
        local item_count = tonumber(row.ItemCount) or 1
        local tv_rv      = pass_var1

        if sub_id > 0 then
            tv_rv = recipe_calc(
                main_id, -- p_main_id
                sub_id,  -- p_sub_id
                pass_var1,
                silent,
                item_count,
                item_id, -- sid_item_id
                tv_mid,  -- pid_item_id (ROW 1 uses main item id)
                main_id  -- p_mid
            )

            if tv_rv == 0 then
                sub_id = 0
                calc_and_soil(item_id, item_count, main_id, silent, tv_rv, item_name, tv_mid)
            else
                -- Hand off to recursive walker for this sub-recipe
                process_recipe_level(sub_id, item_id, tv_rv, silent, tv_mid, main_id, 2)
            end
        else
            -- Tool check is on main_id at ROW 1
            local tcr = crunch_toolcheck(main_id)
            if tcr ~= 1 then
                calc_and_soil(item_id, item_count, main_id, silent, tv_rv, item_name, tv_mid)
            end
            if tcr == 1 and (main_id == 101062 or main_id == 63767 or main_id == 97034) then
                table.insert(tool_array, main_id .. ",1")
            end
        end

        -- NO break here: process ALL top-level rows
    end
end

-- Start the crunch
local crunch = {}
-- p _ option 1 means make tools based on the quest
function crunch.items(main_id, want_count, p_silent)
    t_main_id = main_id

    -- Initliaze Array
    component_array_inv = {}
    component_array = {}
    start_time = os.time()

    -- All Recipes Start Unsoiled (this is for multi option currently.. which needs work)
    revisit_soiled = {}
    bank_table = {}
    local tv_rv = 0
    local silent = p_silent
    data_array = {}

    -- Overall want count of item
    local tv_pnc = want_count

    local tv_rn = lib.return_recipe_name(main_id)

    if silent == 1 then
        print("\aw[Master Recipe:] \at", tv_rn, " \ag[Recipe ID:] \at[",
            main_id, "]")
    end

    -- Main Item ID
    local tv_mid = lib.return_item_ID(main_id)
    local tv_hc = mq.TLO.FindItemCount(tv_mid)()

    -- Main Recipe Checking

    -- ROW 0 Main Recipe
    local tv_yc = lib.return_recipe_yield(main_id)

    if tv_yc == nil then
        print(msg, "\ayError: \ag Invalid Recipe ID: ", main_id)
        os.exit()
    end

    if (tv_pnc - tv_hc) <= tv_yc then
        tv_rv = 1
    else
        tv_rv = math.ceil(tv_pnc - tv_hc) / tv_yc
    end

    -- Verify count correct because it is the main recipe?
    -- tv_rv = math.ceil(tv_pnc - tv_hc) / tv_yc

    local result = crunch_toolcheck(main_id)

    -- Disable for TCN_Quests - Will make whatever amount of tools the quest needs
    if GLOBAL_OPTION_FLAG == 1 then result = 0 end

    -- Add tool
    if result == 1 then
        local l_item_id = lib.return_item_ID(main_id)
        local lv_inv = mq.TLO.FindItemCount(l_item_id)()
        local lv_b_inv = mq.TLO.FindItemBankCount(l_item_id)()
        -- local l_item_name = lib.return_item_name(l_item_id)
        if lv_inv >= 1 or lv_b_inv >= 1 then
            --  if lv_inv >= tv_pnc or lv_b_inv >= tv_pnc then
            -- We have the count so don't add to the tool array

            local n_array = {}
            GLOBAL_TEXT =
            "We have the tool, in inventory or in the bank, please pick another recipe"
            return n_array, n_array, n_array, n_array, n_array
        else
            -- local tool_string = main_id .. ",1"
            -- local tool_string = main_id .. ","..tv_pnc
            -- Omit tool if it is first recipe
            -- table.insert(tool_array, tool_string)
        end
    end

    -- skip tool counts for quests?
    if result == 1 then
        local lv_inv = mq.TLO.FindItemCount(main_id)()
        if lv_inv > 0 then
            tv_rv = 0
        else
            -- fix this up
            tv_rv = 1
        end
    end

    local fv_mc = tv_pnc
    -- * yield

    -- print("CRUNCHER want ", tv_pnc, " have: ", tv_hc, " buy: ", tv_rv, " make: ",
    --   fv_mc, " main id ",main_id)

    local main_yield = tv_yc -- lib.return_recipe_yield(main_id)

    tv_rv = tv_pnc / main_yield

    if main_yield >= tv_pnc then tv_rv = 1 end

    -- print("buy ", tv_rv, " want ", tv_pnc, " make ", fv_mc)

    local pass_var1 = tv_rv

    local l_item_id = lib.return_recipe_item_id(main_id)
    local l_recipe_skill = lib.return_recipe_skill(main_id)
    local l_can_make = lib.check_requirements(l_recipe_skill, main_id)
    local l_recipe_item_name = lib.return_recipe_name(main_id)

    -- this is the 1st recipe
    component_area(l_item_id, tv_hc, main_id, 1, silent, l_can_make, 1,
        l_recipe_item_name, tv_mid)

    -- Convert anyuthing with a , in the name to an @
    if string.find(tv_rn, ",") then tv_rn = tv_rn:gsub(',', '@') end

    local data_string =
        tv_mid .. "," .. tv_rn .. "," .. math.ceil(tv_rv) .. "," .. main_id ..
        "," .. fv_mc

    -- print("1st cruncher: ", data_string)
    -- if the recipe is a tool don't add it twice.. or don't add tool because it doesn't matter?
    -- Add if it is not a tool
    if result == 0 then table.insert(data_array, data_string) end

    process_root_rows(main_id, tv_mid, silent, pass_var1)
    --
    local recipe_table = data_array

    -- Start Tools
    if tool_array[1] then
        table.sort(tool_array) -- Sort so duplicates are adjacent

        local temp_tool_array = {}
        local last_tool_id

        -- Remove duplicates while sorted
        for i = 1, #tool_array do
            local tool_id = lib.return_number(tool_array[i], 1)
            if tool_id ~= last_tool_id then
                temp_tool_array[#temp_tool_array + 1] = tool_array[i] -- Slightly faster than table.insert
                last_tool_id = tool_id
            end
        end

        tool_array = {} -- Reset main tool array

        -- Only add tools we don't have
        for i = 1, #temp_tool_array do
            local tool_recipe_id        = lib.return_number(temp_tool_array[i], 1)
            local tool_recipe_row_count = lib.return_number(temp_tool_array[i], 2)
            local l_item_id             = lib.return_item_ID(tool_recipe_id)

            local inv_count             = mq.TLO.FindItemCount(l_item_id)() or 0
            local bank_count            = mq.TLO.FindItemBankCount(l_item_id)() or 0

            if inv_count >= tool_recipe_row_count or bank_count >= tool_recipe_row_count then
                if bank_count >= tool_recipe_row_count then
                    local bank_tool_string = table.concat({
                        lib.return_item_name(l_item_id),
                        l_item_id,
                        tool_recipe_row_count
                    }, ",")
                    bank_table[#bank_table + 1] = bank_tool_string
                end
            else
                tool_array[#tool_array + 1] = tool_recipe_id .. "," .. tool_recipe_row_count
            end
        end

        -- Prepare for crunch
        if tool_array[1] then
            GLOBAL_CRUNCH_ARRAY = component_array_inv
        end

        -- Crunch tool recipe list (reverse order)
        for i = #tool_array, 1, -1 do
            local tool_recipe_id                          = lib.return_number(tool_array[i], 1)
            local tool_recipe_row_count                   = lib.return_number(tool_array[i], 2)

            local tool_recipe_list, _, _, _, _, comp_list =
                recrunch.items(tool_recipe_id, tool_recipe_row_count, 0, 0)

            -- Add tools to recipe array
            for j = 1, #tool_recipe_list do
                recipe_table[#recipe_table + 1] = tool_recipe_list[j]
            end

            -- Add components
            for j = 1, #comp_list do
                component_array[#component_array + 1] = comp_list[j]
            end
        end
    end
    -- End Tools

    -- Zero out array
    GLOBAL_CRUNCH_ARRAY = {}

    -- Collapse/Count Section
    local temp_recipe_table = {}

    -- Auto Trim Array
    local autotrim_arr = { 27692, 27643, 27644, 27645 }

    -- Auto-trim Faded Bloodied Luclinite Belts
    if GLOBAL_COLLAPSE_FLAG == 1 or main_id == 27692 or main_id == 27643 or
        main_id == 27644 or main_id == 27645 then
        -- RECIPE_ID is it actually ITEM_ID?

        for x = #recipe_table, 1, -1 do
            local RECIPE_ID = lib.return_number(recipe_table[x], 1)
            local RECIPE_COUNT = lib.return_number(recipe_table[x], 3)
            table.insert(temp_recipe_table,
                string.format('(%d,%d)', RECIPE_ID, RECIPE_COUNT))
        end

        local final_recipe_counts = lib.return_sorted_recipes_array(
            temp_recipe_table)

        temp_recipe_table = {}

        local flag = 0
        for d = #recipe_table, 1, -1 do
            local REC_ID = lib.return_number(recipe_table[d], 1)
            local count = 0
            for c = 1, #final_recipe_counts do
                if REC_ID == final_recipe_counts[c].RecipeID then
                    flag = 1
                    count = final_recipe_counts[c].ItemCount
                    break
                end
            end

            if flag == 1 then
                local REC_NAME = lib.return_string(recipe_table[d], 2)
                local REC_COUNT = count
                local REC_ITEM_ID = lib.return_number(recipe_table[d], 4)
                local REC_MC = 1
                local rec_string =
                    REC_ID .. "," .. REC_NAME .. "," .. REC_COUNT .. "," ..
                    REC_ITEM_ID .. "," .. REC_MC

                table.insert(temp_recipe_table, rec_string)
            end
            flag = 0
        end
    else
        -- Set order of recipes if we are not collapsing
        local temp_switch = {}
        for c = #recipe_table, 1, -1 do
            -- print("\ay", recipe_table[c])
            table.insert(temp_switch, recipe_table[c])
        end

        recipe_table = temp_switch
        temp_switch = {}
    end

    if temp_recipe_table[1] ~= nil then
        temp_recipe_table = removeDuplicates(temp_recipe_table)
        recipe_table = temp_recipe_table
    end
    -- End Collapse Count Section

    -- Trophy Selection Code
    local temp_array = {}
    for c = 1, #recipe_table do
        local rec_skill = lib.return_number(recipe_table[c], 4)
        local recipe_skill = lib.return_recipe_skill(rec_skill)
        table.insert(temp_array, recipe_skill)
    end

    -- Remove single element duplicates
    temp_array = removeDuplicates(temp_array)

    for c = 1, #temp_array do
        local have_trophy_flag, l_trophy_id = lib.have_trophy(temp_array[c])
        if l_trophy_id ~= nil then
            if mq.TLO.FindItemCount(l_trophy_id)() > 0 then
                -- Trophy on person
            else
                table.insert(bank_table,
                    have_trophy_flag .. "," .. l_trophy_id .. ",1")
            end
        end
    end
    -- End Trophy Code

    local tools = tool_array
    tool_array = {}

    -----------------------------------------
    -- Data Crunching Section Meat n Potatoes

    -- for c = 1, #component_array do print("\ay",component_array[c]) end os.exit()

    local c_data = lib.return_sorted_counts_array(component_array)

    local farm_table = {}
    local c_vend_table = {}

    local depot_table = {}

    -- Initialize Depot
    if mq.TLO.TradeskillDepot.Enabled() then
        if not mq.TLO.TradeskillDepot.ItemsReceived() then
            if not mq.TLO.Window('TradeskillDepotWnd').Open() then
                mq.TLO.Window('TradeskillDepotWnd').DoOpen()
                mq.delay(500)
            end
            -- Wait for list to populate
            while not mq.TLO.TradeskillDepot.ItemsReceived() do
                mq.delay(1000)
            end
            mq.TLO.Window('TradeskillDepotWnd').DoClose()
            mq.delay(1000)
        end
    end

    -- Predefine lookup tables for quick checks
    local set_count_one = {
        [30140] = true, -- Coldain Velium Hammer
        [60317] = true, -- Gemming Tool Mold
        [36593] = true, -- Shadowspike Arrow Tip Mold
        [6027]  = true, -- Forging Hammer
        -- [34028] = true, -- Shiny Bundle of Superconductive Wires --
    }

    local fish_swap = {
        [152460] = { 152461, "Timorous Deep Toothfish" },
        [166007] = { 166008, "Velious Bluefish" },
        [163659] = { 163660, "Velious Spiked Pleco" },
        [160765] = { 160764, "Primordial Lion Fish" },
        [166194] = { 166195, "Luclin Dragon Blood Cichlid" },
        [159706] = { 159707, "Luclin Silver Arowana" },
        [154763] = { 154764, "Serene Walleye Perch" }, -- Laurion's Song
        [87350]  = { 87351, "Void Maw Angler" },       -- The Outer Brood
    }

    local depot_enabled = mq.TLO.TradeskillDepot.Enabled()

    -- Shared helper for depot calculation
    local function calcDepotGrab(z_name, z_id, z_count, l_tot_count)
        local tsd_count = mq.TLO.TradeskillDepot.FindItemCount(z_id)()
        local l_d_calc = 0

        if l_tot_count > 0 and tsd_count + l_tot_count >= z_count then
            if tsd_count >= l_tot_count then
                l_d_calc = z_count - l_tot_count
            elseif tsd_count == l_tot_count then
                l_d_calc = math.ceil(z_count / 2)
            end
        elseif l_tot_count < 1 and tsd_count >= z_count and z_count > 0 then
            l_d_calc = z_count
        elseif l_tot_count < 1 and tsd_count > 0 and tsd_count < z_count then
            -- Optional: handle partial depot-only case if needed
            -- l_d_calc = tsd_count
        end

        if l_d_calc > 0 then
            return { Name = z_name, ID = z_id, Quantity = l_d_calc }
        end
    end

    for c = 1, #c_data do
        local z_id    = lib.return_number(c_data[c], 2)
        local z_count = lib.return_number(c_data[c], 3)
        local z_name  = lib.return_string(c_data[c], 1)

        -- Set count to 1 for specific items
        if set_count_one[z_id] then
            z_count = 1
        end

        -- Fish scale swap
        if FISH_SCALE_SWAP and fish_swap[z_id] then
            local swap = fish_swap[z_id]
            z_id, z_name = swap[1], swap[2]
        end

        local l_inv_count = mq.TLO.FindItemCount(z_id)()
        local l_bnk_count = mq.TLO.FindItemBankCount(z_id)()
        local l_tot_count = l_inv_count + l_bnk_count

        -- Bank table logic
        if l_bnk_count > 0 then
            if l_inv_count < 1 then
                table.insert(bank_table, z_name .. "," .. z_id .. "," .. math.min(z_count, l_bnk_count))
            elseif l_inv_count < z_count and l_tot_count >= z_count then
                table.insert(bank_table, z_name .. "," .. z_id .. "," .. (z_count - l_inv_count))
            end
        end

        local ven = lib.vendor_has_item(z_id)

        -- Farm table logic
        if ven == 0 and l_tot_count < z_count then
            local farm_action, farm_zone = lib.return_item_source(z_id)
            local c_string = z_name .. "," .. z_id .. "," .. z_count .. "," .. farm_action .. "," .. farm_zone

            if depot_enabled then
                local depot_item = calcDepotGrab(z_name, z_id, z_count, l_tot_count)
                if depot_item then
                    table.insert(depot_table, depot_item)
                else
                    table.insert(farm_table, c_string)
                end
            else
                table.insert(farm_table, c_string)
            end
        end

        -- Vendor to Depot
        if depot_enabled and z_count > 0 and ven == 1 then
            local depot_item = calcDepotGrab(z_name, z_id, z_count, l_tot_count)
            if depot_item then
                table.insert(depot_table, depot_item)
            end
        end

        -- Vendor Table to shop
        if ven == 1 then
            local l_vendor_name
            local faction_check = 1

            if z_id == 28021 or z_id == 10425 or z_id == 22564 or z_id == 22098 or z_id == 21625 then
                l_vendor_name = lib.return_vendor_name(z_id)
            end

            if l_vendor_name == "Ping Fuzzlecutter" or l_vendor_name == "Nimren Stonecutter"
                or l_vendor_name == "Talem Tucter" or l_vendor_name == "Meg Tucter" then
                faction_check = lib.faction_check(l_vendor_name)
            end

            if faction_check == 0 and l_tot_count < z_count then
                local farm_action, farm_zone = lib.return_item_source(z_id)
                table.insert(farm_table,
                    z_name .. "," .. z_id .. "," .. z_count .. "," .. farm_action .. "," .. farm_zone)
            elseif faction_check ~= 0 then
                table.insert(c_vend_table, z_name .. "," .. z_id .. "," .. z_count)
            end
        end
    end

    -- Create Shopping List
    local shopping_table = {}
    for c = 1, #c_vend_table do
        local vi = lib.return_number(c_vend_table[c], 2)
        local vic = lib.return_number(c_vend_table[c], 3)
        local s_data_string = lib.return_vendor_data(vi, vic)

        table.insert(shopping_table, s_data_string)
    end
    table.sort(shopping_table)

    -- print "check b"

    -- End Meat N Potatoes

    ------------------------------
    -- print "check f"
    --  for c = 1, #farm_table do print("\ar", farm_table[c]) end
    -- print "check b"
    -- for c = 1, #bank_table do print("\ag", bank_table[c]) end
    --  print "check v"
    --   for c = 1 ,#c_vend_table do print("\at",c_vend_table[c]) end
    ------------------------------

    GLOBAL_TEXT = "Recipe processed..."

    local end_time = os.time()

    if string.find(tv_rn, "@") then tv_rn = tv_rn:gsub('@', ',') end

    print(msg,
        "\agRecipe \ap(\aw" .. tv_rn .. "\ap) \agProcessed In:\at (\ay" ..
        end_time - start_time .. "\at) \agSeconds")

    for x = #recipe_table, 1, -1 do
        -- print("\aw TCN CRUNCHER \agReverse Order: \at", recipe_table[x])
    end

    if farm_table[1] == nil then farm_table = {} end

    -- Possibly use in MASS cruncher for tool component count
    local tool_table = tools

    -- Reverse table for proper order..
    local temp_switch = {}
    for x = #recipe_table, 1, -1 do
        table.insert(temp_switch, recipe_table[x])
    end

    recipe_table = temp_switch
    temp_switch = {}
    -- Reverse END

    --  for c = 1, #tool_table do print("tools ", tool_table[c]) end

    --   for c = 1, #shopping_table do print("\ag", shopping_table[c]) end

    --    for c = 1, #recipe_table do print("\ar", recipe_table[c]) end

    --    for c = 1, #farm_table do print("\at", farm_table[c]) end

    -- print("depot elements: ", #depot_table)

    -- for c = 1, #depot_table do
    --   print("\agdepot table: ",
    --        depot_table[c].ID .. "," .. depot_table[c].Name .. "," ..
    --          depot_table[c].Quantity)
    -- end

    -- os.exit()

    return recipe_table, tool_table, bank_table, farm_table, shopping_table,
        depot_table
end

return crunch