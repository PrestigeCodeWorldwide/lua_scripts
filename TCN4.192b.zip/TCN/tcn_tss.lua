-- name: TCN_TSS.lua
-- version 1.21b
-- start date: 5/21/2022
-- updated: 8/18/2024
-- creator: jb321
local mq = require('mq')

local lib = require('TCN_Library')
local shop = require('TCN_Shoplist')
local craft = require('TCN_Craft')
local mv = require('TCN_Movement')

-- declarations
local msg = "\ap[\atTCSNe\auX\att\ap]\aw "

-- event I will give you the recipes after you have helped us enough.. means we messed up!

-- Set trophy swap to auto
GLOBAL_TROPHY_FLAG = 1

-- Local Functions--

local function what_kit()
    -- Casters
    local caster_classes = {NEC = true, WIZ = true, MAG = true, ENC = true}
    local my_class = mq.TLO.Me.Class.ShortName()
    if caster_classes[my_class] then
        return 93492, 11, "Researcher Layla", "Spell Research Kit"
    end

    -- Priests
    local priest_classes = {CLR = true, DRU = true, SHM = true}
    my_class = mq.TLO.Me.Class.ShortName()
    if priest_classes[my_class] then
        return 41631, 11, "Researcher Junna", "Prayer Writing Kit"
    end

    -- Bard
    local brd_classes = {BRD = true}
    my_class = mq.TLO.Me.Class.ShortName()
    if brd_classes[my_class] then
        return 41633, 11, "Researcher Junna", "Song Writing Kit"
    end

    -- Hybrid
    local hybrid_classes = {PAL = true, RNG = true, SHD = true, BST = true}
    my_class = mq.TLO.Me.Class.ShortName()
    if hybrid_classes[my_class] then
        return 41632, 21, "Researcher Junna", "Hybrid Research Kit"
    end

    -- Melee
    local melee_classes = {WAR = true, MNK = true, ROG = true, BER = true}
    my_class = mq.TLO.Me.Class.ShortName()
    if melee_classes[my_class] then
        return 41555, 11, "Researcher Junna", "Tome Binding Kit"
    end
end

local function start_tss_engine(p_id)

    local TS_NPC, TS_Text, TS_WIN, TS_QuestName, TS_NAV, TS_Bag, TS_Bag_Price,
          TS_Bag_ID, TS_Skill = lib.return_quest_info(p_id)

    local legacy_quest_id = p_id
    local success = nil

    local l_skill_level = mq.TLO.Me.Skill(TS_Skill)()

    if TS_Skill == "Research" and l_skill_level < 1 then
        print(msg,
              "\ap[\atPlease train 1 skill point at your \ayGM \atfor \agResearch \atto do this quest\ap]")
        return
    end

    if mq.TLO.Zone.ID() ~= 394 then
        print("\at[TCSNe\awx\att] \aw[Travelling To] \ag[Crescent Reach]")
        -- fix
        mv.crescent()
    end

    TS_QuestName = string.gsub(TS_QuestName, '\\a', '\a')

    print(msg, "\awStarting ", TS_QuestName)

    -- Floor Movement in CR
    if legacy_quest_id > 2407 and legacy_quest_id < 2411 then
        mv.crescent_reach_floor_1()
    else
        if legacy_quest_id < 2408 then mv.crescent_reach_floor_2() end
    end

    if l_skill_level > 53 then
        mv.npc(TS_NPC)
        print(msg, "\ap[\agAsking for recipes\ap]")
        mq.delay(1000)
        mq.cmd('/say recipes')

        local break_counter = 0
        -- Capture events
        while true do
            mq.delay(1)
            mq.doevents()
            break_counter = break_counter + 1
            if break_counter == 20 then break end
        end
        mq.delay(1)
        return
    end

    -- Requirements
    local kit = "nil"
    local l_seller = nil
    local bag_price = TS_Bag_Price

    if string.find(TS_QuestName, "Research") and l_skill_level > 0 then
        kit, TS_Bag_Price, l_seller, TS_Bag = what_kit()
    else
        kit = TS_Bag_ID
    end

    print(msg, "\ap[\atChecking Requirements\ap]")

    if mq.TLO.FindItemCount(TS_Bag)() == 0 and kit ~= "nil" then
        print(msg, "\ay[\aoNeed: \at", TS_Bag, "\ay]")
    end

    if not string.find(TS_QuestName, "Baking") then
        -- Alternate Container Checking
        local result = lib.return_available_container(TS_Bag)
        if result ~= nil then TS_Bag = result end
    end

    local bag_have = nil
    local real_bag_name = mq.TLO.FindItem(TS_Bag).Name()

    if mq.TLO.FindItemCount(TS_Bag)() > 0 and TS_Bag ~= "nil" then
        TS_Bag = real_bag_name
        print(msg, "Have: \at", TS_Bag, "\ap]")
        bag_have = 1
    end

    -- print(kit, " ", TS_Bag, " ", bag_have, " ", l_seller)

    -- Need Bag
    if bag_have == nil and TS_Bag ~= "nil" then

        if TS_Bag == "Jeweler's Kit" then l_seller = "Jeweler Nailah" end

        if TS_Bag == "Mortar and Pestle" then
            l_seller = "Poisoner Salihah"
        end

        if TS_Bag == "Medicine Bag" then l_seller = "Alchemist Naeema" end

        if TS_Bag == "Toolbox" then
            l_seller = "Geerlok Clockwork Merchant IV"
        end

        if TS_Bag == "Fletching Kit" then l_seller = "Fletcher Tahirah" end

        if TS_Bag == "Mixing Bowl" then l_seller = "Cook Kosey" end

        if mq.TLO.Me.Platinum() < TS_Bag_Price then
            mv.bank()
            lib.bank_withdrawal(TS_Bag_Price)
        end

        if mq.TLO.Me.Platinum() < TS_Bag_Price then
            print("\ao[\atTCSNeXt\ao]: \ay[\ayNot Enough Platinum For ", TS_Bag,
                  "\ay]")
            return
        end

        mv.npc(l_seller)

        mq.delay(500)

        if not mq.TLO.Merchant.Open() then
            mq.cmd('/nomodkey /click right target')
        end
        mq.delay(1500)

        while mq.TLO.Merchant.ItemsReceived() ~= true do mq.delay(1000) end

        mq.delay(500)

        shop.buy_item(1, kit)

        -- Buy spit - he doesn't sell spit
        if l_seller == "Cook Kosey" and mq.TLO.FindItemCount(17947)() > 1000 then

            if mq.TLO.Me.Platinum() < 1 then
                mv.bank()
                lib.bank_withdrawal(1)
            end

            if mq.TLO.Me.Platinum() > 0 then
                mv.npc(l_seller)
                shop.buy_item(1, 17947)
            end
        end

        mq.cmd('/cleanup')

    end

    if mq.TLO.FindItemCount(TS_Bag)() == 0 and TS_Bag ~= "nil" then
        print("\ao[\atTCS\ao]: \ay[\ayMissing: \ao" .. TS_Bag .. "\ay]")
        return
    end

    -- goto TSSLoop -- Testing Purposes

    -- Initial Actions
    local skip_ask = 0

    -- Have materials to make a recipe?
    local legacy_quest_recipe_array = lib.return_god_quest_recipe_array(
                                          legacy_quest_id)

    for tss_cycle = 0, #legacy_quest_recipe_array do

        local l_recipe_id = legacy_quest_recipe_array[tss_cycle]

        local result = lib.recipe_check(l_recipe_id)

        if result == 1 then skip_ask = 1 end

    end

    -- No materials, start quest
    if skip_ask == 0 then
        -- Move to NPC
        local my_inv = mq.TLO.Me.FreeInventory()
        mv.npc(TS_NPC)
        mq.delay(1000)
        mq.cmd('/say ' .. TS_Text)
        mq.delay(1000)
        lib.ClearCursor()
        lib.ClearCursor()
        lib.ClearCursor()
        lib.ClearCursor()
        lib.ClearCursor()
        mq.delay(1000)

        -- Quest already started, ask for supplies
        if my_inv == mq.TLO.Me.FreeInventory() then
            mq.cmd('/say supplies')
            mq.delay(1500)
            lib.ClearCursor()
            lib.ClearCursor()
            lib.ClearCursor()
            lib.ClearCursor()
            lib.ClearCursor()
            lib.ClearCursor()
            mq.delay(1500)
        end

    end

    -- ::TSSLoop::

    while true do
        -- Crafting

        local main_id = nil

        local legacy_quest_recipe_array =
            lib.return_god_quest_recipe_array(legacy_quest_id)

        for tss_cycle = 0, #legacy_quest_recipe_array do

            local l_recipe_id = legacy_quest_recipe_array[tss_cycle]

            --  print( legacy_quest_recipe_array[tss_cycle])

            local result = lib.recipe_check(l_recipe_id)

            if result == 1 then

              --  lib.swap_ammo_slot_back(GLOBAL_AMMO_SLOT)
                --   ammo_swap_slot(GLOBAL_AMMO_SLOT)
                -- Fishing
              --  lib.return_primary_item()

              lib.trophy_selector(l_recipe_id)

                craft.main(l_recipe_id, 20, 0, 0)
                main_id = l_recipe_id
                EXP_FLAG = 0

                local l_container = lib.return_container_name(l_recipe_id)
                -- print("container ",l_container)

                if l_container == "Kiln" then end

            end

            local tss_item_id, tss_recipe_name, hc =
                lib.return_recipe_info(l_recipe_id)

            if mq.TLO.FindItemCount(tss_item_id)() > 19 and l_recipe_id == 36599 then
                break
            end

        end

        -- Move to NPC
        mv.npc(TS_NPC)

        local tss_item_id, tss_recipe_name, hc = lib.return_recipe_info(main_id)

        -- Don't turn in unfired TSS items..
        --   if not (tss_item_id == 98261 or tss_item_id == 98262) then

        if mq.TLO.FindItemCount(tss_item_id)() > 19 then
            print(msg,
                  "\ay[\agTurn In:\ay] \ap[\ag" ..
                      mq.TLO.FindItemCount(tss_item_id)() .. "\ap] \ay" ..
                      tss_recipe_name)
            mq.delay(1)

            lib.restack_items(tss_item_id)
            mq.delay(500)

            -- 36615	Unfired Simple Arrow Shaft -- 98261
            -- 36613	Unfired Simple Mug -- 98262

            lib.give_quest_item_id(tss_item_id,
                                   mq.TLO.FindItemCount(tss_item_id)())
            mq.delay(1)

            lib.ClearCursor()
            lib.ClearCursor()
            lib.ClearCursor()

            mq.delay(1)

            if mq.TLO.FindItemCount('Simple Quill Cutting Tool')() > 0 then
                lib.give_quest_item_id(98297, 1)
                mq.delay(1)
                lib.ClearCursor()
                lib.ClearCursor()
            end

            -- Destroy left overs
            lib.legacy_destroy(legacy_quest_id)

        end

        --  end

        mq.cmd('/doevents flush')

        local zz = 2
        if zz == 1 then
            l_skill_level = mq.TLO.Me.Skill(TS_Skill)()

            if l_skill_level > 53 then
                lib.legacy_destroy(legacy_quest_id)
                mv.npc(TS_NPC)
                print(msg, "\ap[\agAsking for recipes\ap]")
                mq.delay(1000)
                mq.cmd('/say recipes')

                local break_counter = 0
                -- Capture events
                while true do
                    mq.delay(1)
                    mq.doevents()
                    break_counter = break_counter + 1
                    if break_counter == 20 then break end
                end
                mq.delay(1)
                success = 1
            end

            if success == 1 then
                mq.delay(1000)
                mq.cmd('/beep')
                print(msg, "\awFinished: ", TS_QuestName)
                break
            end

        end

        local x_result = lib.recipe_check(main_id)

        if x_result == 0 then
            mq.cmd('/say supplies')
            mq.delay(1000)
            lib.ClearCursor()
            lib.ClearCursor()
            lib.ClearCursor()
            lib.ClearCursor()
        end

        mq.delay(1500)
        x_result = lib.recipe_check(main_id)
        mq.delay(1000)

        if x_result == 0 then
            mq.cmd('/say ready to start.')
            mq.delay(1000)
            lib.ClearCursor()
            lib.ClearCursor()
            lib.ClearCursor()
            lib.ClearCursor()
        end

        mq.delay(1500)

        --   Quest Completion

        l_skill_level = mq.TLO.Me.Skill(TS_Skill)()

        local winning = lib.legacy_quest_complete(legacy_quest_id)

        if winning == 1 and l_skill_level > 53 then
            mq.cmd('/doevents flush')
            mq.cmd('/say recipes')

            local break_counter = 0

            -- Capture events
            while true do
                mq.delay(1)
                mq.doevents()
                break_counter = break_counter + 1
                if break_counter == 20 then break end
            end

            print(msg, "\awFinished: ", TS_QuestName)

            break

        end

        mq.delay(1)

    end

    return
end

-- End Local Functions

-- CODE START--

local function TheSerpentSpine(p_id)

    local passed_arg = p_id

    local num_arg = tonumber(passed_arg)

    local tss_quest_values = {
        2407, 2408, 2402, 2401, 2406, 2400, 2405, 2409, 2404, 2403, 2410, 2411
    }

    -- Error checking here.
    if num_arg < 1 or num_arg > 12 then

        print(msg, "\ayInvalid Quest Number.. \agPlease Try Again")
        print " "
        print(msg, "\atValid Quests:")

        for x = 1, #tss_quest_values do

            local TS_NPC, TS_Text, TS_WIN, TS_QuestName, TS_NAV, TS_Bag,
                  TS_Bag_Price, TS_Bag_ID =
                lib.return_quest_info(tss_quest_values[x])

            TS_QuestName = string.gsub(TS_QuestName, '\\a', '\a')

            print("\ao", x, " - [", TS_QuestName, "\ao]")
        end

        print " "
        print(msg, "Usage:  /TSS number")
        return
    end

    for x = 1, #tss_quest_values do
        if num_arg == x then
            num_arg = tss_quest_values[x]
            break
        end
    end

    mq.cmd('/cleanup')
    lib.CloseInventoryWindow()
    mq.delay(1000)
    lib.ClearCursor()
    mq.delay(1000)

    -- Run solo quest
    if num_arg ~= 2411 then
        local legacy_quest_id = lib.return_god_quest_id(num_arg)

        local TS_NPC, TS_Text, TS_WIN, TS_QuestName, TS_NAV, TS_Bag,
              TS_Bag_Price, TS_Bag_ID = lib.return_quest_info(legacy_quest_id)

        if legacy_quest_id == 2409 and mq.TLO.Me.Race() == "Gnome" then
            start_tss_engine(legacy_quest_id)
        else
            if legacy_quest_id == 2409 then
                print(msg,
                      "\ay[Tinkering Freebie \agRace \ayrequirement not met]")
            end
        end

        if legacy_quest_id == 2404 and mq.TLO.Me.Class() == "Shaman" and
            mq.TLO.Me.Level() > 24 then
            start_tss_engine(legacy_quest_id)
        else
            if legacy_quest_id == 2404 then
                print(msg,
                      "\ay[Alchemy Freebie, \aglevel or class \ayrequirements not met]")
            end
        end

        if legacy_quest_id == 2403 and mq.TLO.Me.Class() == "Rogue" and
            mq.TLO.Me.Level() > 19 then
            start_tss_engine(legacy_quest_id)
        else
            if legacy_quest_id == 2403 then
                print(msg,
                      "\ay[Poison Freebie, \aglevel or class \ayrequirements not met]")
            end
        end

        if not (legacy_quest_id == 2409 or legacy_quest_id == 2404 or
            legacy_quest_id == 2403) then
            start_tss_engine(legacy_quest_id)
        end

    else

        -- Run the chain
        local legacy_quest_recipe_array_dump =
            lib.return_tss_quest_id_array_dump()

        for tss_cycle = 0, #legacy_quest_recipe_array_dump do

            local legacy_quest_id = legacy_quest_recipe_array_dump[tss_cycle]

            local TS_NPC, TS_Text, TS_WIN, TS_QuestName, TS_NAV, TS_Bag,
                  TS_Bag_Price, TS_Bag_ID =
                lib.return_quest_info(legacy_quest_id)

            if legacy_quest_id == 2409 and mq.TLO.Me.Race() == "Gnome" then
                start_tss_engine(legacy_quest_id)
            else
                if legacy_quest_id == 2409 then
                    print(msg, "\ay[Tinkering Freebie Race requirement not met]")
                end
            end

            if legacy_quest_id == 2404 and mq.TLO.Me.Class() == "Shaman" and
                mq.TLO.Me.Level() > 24 then
                start_tss_engine(legacy_quest_id)
            else
                if legacy_quest_id == 2404 then
                    print(msg,
                          "\ay[Alchemy Freebie, level or class requirements not met]")
                end
            end

            if legacy_quest_id == 2403 and mq.TLO.Me.Class() == "Rogue" and
                mq.TLO.Me.Level() > 19 then
                start_tss_engine(legacy_quest_id)
            else
                if legacy_quest_id == 2403 then
                    print(msg,
                          "\ay[Poison Freebie, level or class requirements not met]")
                end
            end

            if not (legacy_quest_id == 2409 or legacy_quest_id == 2404 or
                legacy_quest_id == 2403) then

                -- work on time to get minutes and hours or minutes and seconds..
                local startTime = os.time()
                -- Start TSS Quest
                start_tss_engine(legacy_quest_id)
                local endTime = os.time()
                local elapsedTime = os.difftime(endTime, startTime)
                if elapsedTime < 60 then
                    print(msg, "Completion: ", elapsedTime, " seconds")
                end
                if elapsedTime < 3600 and elapsedTime > 59 then
                    print(msg, "Completion: ", math.floor(elapsedTime / 60),
                          " minutes")
                end
                if elapsedTime > 3599 then
                    print(msg, "Completion: ", math.floor(elapsedTime / 3600),
                          " hours")
                end

                -- Pathing Assist

            end
        end

    end

    return
end

BUY_MULT = 1
USE_MULT = false

-- Code start
local args = ...

TheSerpentSpine(args)

-- Stop premature movement for incorrect quest number
if tonumber(args) < 1 or tonumber(args) > 12 then return end

-- destroy  DeleteTSSItemByName() all recipes unless it is food..
-- cycle the legacy recipe >2399? and destroy

mq.delay(1000)

if mq.TLO.Me.Z() > 10 then
    mv.crescent_reach_floor_1()
    mq.delay(5000)
end

     -- Return Trophies
     lib.swap_ammo_slot_back(GLOBAL_AMMO_SLOT)

     -- Fishing
     lib.return_primary_item()

mv.pok()

return
