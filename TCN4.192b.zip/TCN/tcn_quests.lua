-- name: tcn_quests
-- creator: jb321
-- date: 9/21/2021
-- updated: 8/18/2024
-- version: 1.38b
local mq = require('mq')
local lib = require('TCN_Library')
local craft = require('TCN_Craft')
local shop = require('TCN_ShopList')
local crunch = require('cruncher')
local movement = require('tcn_movement')

-- vars
local msg = "\ap[\atTCSNe\auX\att\ap]\aw "

-- Set trophy swap to auto
GLOBAL_TROPHY_FLAG = 1

-- local functions

local function quests_get(p_quest_title)

    local quest_npc, quest_turn_in, quest_zone_id, quest_name, quest_text,
          quest_item, quest_item_id = lib.return_standard_quest_information(
                                          p_quest_title)

    if mq.TLO.Zone.ID() ~= quest_zone_id then

        -- Right now goes to FP

        movement.zone(quest_zone_id)

    end

    -- if we are near npc then skip movement
    local NPCDistance = mq.TLO.Spawn(quest_npc).Distance()
    if NPCDistance > 20 then
        -- Avoid FP guards
        mq.cmd('/squelch /nav locyxz -13 78 -61 |log=off')
        movement.moving()
        -- Walk to Quest NPC
        movement.npc(quest_npc)
        movement.moving()
    end

    mq.cmd('/say ', quest_text)
    mq.delay(1000)
    mq.cmd('/cleanup')

    -- Avoid FP guards
    mq.cmd('/squelch /nav locyxz -13 78 -61 |log=off')
    movement.moving()

    -- go to pok
    movement.fp_pok()

end

-- return quests

local function go_craft(p_recipe_list, p_quest_recipe_id)
    local l_quest_recipe_id = p_quest_recipe_id

    for x = #p_recipe_list, 1, -1 do
        -- print( "tcn quests" , p_recipe_list[x])
    end

    -- reverse order of the recipe list
    for x = #p_recipe_list, 1, -1 do
        local clean_string = string.gsub(p_recipe_list[x], "'", '')
        local l_recipe_id = lib.return_string(clean_string, 4)
        local l_make_count = lib.return_string(clean_string, 5)

        lib.trophy_selector(l_recipe_id)

        craft.main(l_recipe_id, l_make_count, l_quest_recipe_id)

        lib.ClearCursor()

    end

    return
end

local function quests_machine(p_quest_title, p_deposit)

    p_quest_title = p_quest_title:gsub("'", "")
    p_quest_title = p_quest_title:gsub('"', "")

    -- print("quest machine info ",p_quest_title, " ",p_deposit) 

    -- Make tool count based on quest not adherence
    if string.find(p_quest_title, "Test") then
        GLOBAL_OPTION_FLAG = 1
    else
        GLOBAL_OPTION_FLAG = 0
    end

    local l_quest_name = p_quest_title

    local quest_npc, quest_turn_in, quest_zone_id, quest_name, quest_text,
          quest_item, quest_itemid = lib.return_standard_quest_information(
                                         p_quest_title)

    if mq.TLO.FindItemCount(quest_itemid)() > 0 and quest_zone_id == 383 then
        -- assumes in pok
        movement.pok_fp()
        -- Avoid FP guards
        mq.cmd('/squelch /nav locyxz -13 78 -61 |log=off')
        movement.moving()
        movement.npc(quest_npc)
        -- Turn in the scorecard and get shiny new trophy
        lib.give_quest_item_id(quest_itemid, 1)
        mq.delay(1000)
        -- Avoid FP guards
        mq.cmd('/squelch /nav locyxz -13 78 -61 |log=off')
        movement.moving()
        movement.fp_pok()
        return
    end

    lib.open_journal()

    l_quest_name = l_quest_name:gsub("'", '')

    -- print(l_quest_name)
    -- print(mq.TLO.Task(l_quest_name).ID())

    -- get the quest..

    if mq.TLO.Task(l_quest_name).ID() == nil then quests_get(p_quest_title) end

    if mq.TLO.Task(l_quest_name).ID() == nil then
        print(msg, "\atwe dont have the \ag[", l_quest_name, "] \attask")
        return
    end

    movement.pok()

    local l_quest_id = mq.TLO.Task(l_quest_name).ID()

    -- Find task index number in list
    local l_window_index = mq.TLO.Task(l_quest_name).WindowIndex()

    -- NOTE: Set focus on quest in task window
    mq.cmd('/notify TaskWnd Task_TaskList listselect "' .. l_window_index ..
               '" leftmouseup')
    mq.delay(100)

    -- return total objective count for task..
    -- local l_objective_count = mq.TLO.Window('TaskWND').Child(
    --                'Task_TaskElementList').Items()

    -- Start quest engine

    local quest_craft_info = lib.quest_craft_information(l_quest_id)

    for x = 0, #quest_craft_info do

        local l_quest_create_step = lib.return_number(quest_craft_info[x], 1)
        local l_quest_recipe_id = lib.return_number(quest_craft_info[x], 2)

        -- Step not done loop

        while mq.TLO.Task(l_quest_name).Objective(l_quest_create_step).Status() ~=
            "Done" do

            local create_item_req = mq.TLO.Task(l_quest_name).Objective(
                                        l_quest_create_step).RequiredCount()

            local create_item_cur = mq.TLO.Task(l_quest_name).Objective(
                                        l_quest_create_step).CurrentCount()

            -- local quest_recipe_id = quest_row.Quest_Recipe_ID

            local Recipe_Yield = lib.return_recipe_yield(l_quest_recipe_id)

            local Want_Count = (create_item_req - create_item_cur) *
                                   Recipe_Yield

            local recipe_list, nun, bank_list, farmed_list, nun, depot_list =
                crunch.items(l_quest_recipe_id, Want_Count, 0, 1)

            --  for c = 1 ,#depot_list do print("\atquests depot ",depot_list[c].Name) end

            if bank_list[1] ~= nil then
                shop.go_bank_shopping(bank_list)
            end

            if depot_list[1] ~= nil and mq.TLO.TradeskillDepot.Enabled() then
                shop.go_depot_shopping(depot_list)
            end

            -- Reinforced Jeweler's Kit Checking
            -- Recipes that require this:
            -- Marquise Mount Palladium Ring
            -- Platinum-Bladed Long Spear

            -- Full list of recipes that use Reinforced Jeweler's Kit
            local rein_kit = {
                12053, 12054, 12055, 12056, 12057, 34126, 34132, 34138, 34144,
                34150, 34156, 34162, 34168, 34174, 34180, 34186, 34192, 34198,
                34204, 34210, 34216, 34222, 34228, 34234, 34240, 34246, 34252,
                34258, 34264, 34270, 34276, 34282, 34288, 34294, 34300, 34306,
                34312, 34318, 34324, 34330, 34336, 34342, 34348, 34354, 34360,
                34366, 34372, 34378, 34384, 34390, 34396, 34402, 34408, 34414,
                34420, 34426, 34432, 34438, 34444, 34450, 34456, 34462, 34468,
                34474, 34480, 34486, 34492, 34498, 34504, 34510, 34516, 34522,
                34528, 34534, 34540, 34546, 34552, 34558, 34564, 34570, 34576,
                34582, 34588, 34594, 34600, 34606, 34612, 34618, 34624, 36279,
                36285, 36291, 36297, 36303, 36309, 36315, 36321, 36327, 36333,
                36339, 36345, 36351, 36357, 36363, 36369, 36375, 36381, 36387,
                36393, 36399, 94538, 94810
            }

            local special_kit = 0

            for c = 1, #rein_kit do
                if l_quest_recipe_id == rein_kit[c] then
                    special_kit = 1
                    break
                end
            end

            if special_kit == 1 then
                local i_count = mq.TLO.FindItemCount(62480)()
                local b_count = mq.TLO.FindItemBankCount(62480)()
                if i_count + b_count < 1 then
                    print(msg, print(msg, "\ayMissing Items: ",
                                     "\agReinforced Jewler's Kit"))
                    special_kit = 0
                    break
                end
            end

            if farmed_list[1] ~= nil then
                print(msg, "\ayMissing Items:")
                for y = 1, #farmed_list do
                    local l_item_name = lib.return_string(farmed_list[y], 1)
                    local l_item_count = lib.return_number(farmed_list[y], 3)
                    print(msg,
                          "\agRecipe Missing: \at\ay\ap[\aw" .. l_item_name ..
                              "\ap] \a[[\agNeed: ", l_item_count)
                end
                -- os.exit()
                break
            end

            print "\ap____________________________________________________"

            -- Recipes to make
            if recipe_list[1] ~= nil then
                local shopping_list = shop.create_shopping_list(recipe_list)
                -- Shopping to be done
                if shopping_list[1] ~= nil then
                    -- Plat Check
                    if mq.TLO.Me.PlatinumBank() >= 500 or
                        mq.TLO.Me.PlatinumShared() >= 500 then
                        if mq.TLO.Me.Platinum() < 250 then
                            movement.bank()
                            -- Grab 500 plat
                            lib.bank_withdrawal(500)
                        end
                    end
                    -- Go Shopping
                    shop.go_shopping(shopping_list)

                    if mq.TLO.Zone.ID() == 54 and mq.TLO.Me.Z() > 10 then
                        mq.cmd('/nav locyx -443 92 |log=off')
                        while mq.TLO.Nav.Active() do
                            mq.delay(1000)
                        end
                        mq.cmd('/keypress forward hold')
                        mq.delay(6000)
                        mq.cmd('/keypress forward')
                        mq.delay(2000)
                    end

                    if mq.TLO.Zone.ID() == 394 then
                        movement.crescent_reach_floor_1()
                    end

                    if mq.TLO.Zone.ID() ~= 202 then
                        mq.cmd('/squelch /travelto poknowledge')
                        while mq.TLO.Zone.ID() ~= 202 do
                            mq.delay(1)
                        end
                    end

                end
            end

            mq.delay(1000)
            mq.cmd('/cleanup')
            mq.delay(1000)

            go_craft(recipe_list, l_quest_recipe_id)

            lib.ClearCursor()

            mq.delay(1)
        end

    end

    print " "
    print "\ag[Checking Delivery Requirements]"

    -- Delivery Steps

    local delivery_info = lib.quest_deliver_info(l_quest_id)

    for x = 0, #delivery_info do

        local l_deliver_step = lib.return_number(delivery_info[x], 1)

        local l_quest_item_id = lib.return_number(delivery_info[x], 2)
        local l_quest_recipe_id = lib.return_number(delivery_info[x], 3)

        while mq.TLO.Task(l_quest_name).Objective(l_deliver_step).Status() ~=
            nil do

            -- Inventory is full or can't drop item in bag
            lib.ClearCursor()

            mq.delay(100)

            if mq.TLO.Task(l_quest_name).Objective(l_deliver_step).Status() ==
                "Done" then
                --  print("\agBREAKING: STEP: ", quest_row.Quest_Deliver_Step,
                --   " Complete")
                break
            end

            local deliver_item_req = mq.TLO.Task(l_quest_name).Objective(
                                         l_deliver_step).RequiredCount()

            local deliver_item_cur = mq.TLO.Task(l_quest_name).Objective(
                                         l_deliver_step).CurrentCount()

            mq.delay(100)

            -- Determine On Hand Count 
            local rii = l_quest_item_id

            --  print(l_quest_item_id)

            local hc = mq.TLO.FindItemCount(rii)()

            -- Determine delivery item need requirements    
            local l_need_count = deliver_item_req - deliver_item_cur

            local l_want_count = l_need_count - hc
            --- hc

            if l_want_count < 0 then l_want_count = 0 end

            -- print ("TCN QUESTS have: ",hc, " want: ", l_want_count, " need: " ,l_need_count, " ID: ",l_quest_item_id, " required: ",deliver_item_req)

            -- Determine Completion Status
            if l_want_count <= 0 then
                -- if l_need_count <= 0 then
                -- print(msg, "BREAKING: STEP: ", quest_row.Quest_Deliver_Step,
                --   " Ready For Turn in")
                break
            end

            -- Check Recipe and Create Recipe List
            -- was need count

            local recipe_list, nun, bank_list, farmed_list, nun, depot_list =
                crunch.items(l_quest_recipe_id, l_want_count, 0, 1)

            if bank_list[1] ~= nil then
                shop.go_bank_shopping(bank_list)
            end

            if depot_list[1] ~= nil and mq.TLO.TradeskillDepot.Enabled() then
                shop.go_depot_shopping(depot_list)
            end

            if farmed_list[1] ~= nil then
                print(msg, "\ayMissing Items:")
                for y = 1, #farmed_list do
                    local l_item_name = lib.return_string(farmed_list[y], 1)
                    local l_item_count = lib.return_number(farmed_list[y], 3)
                    print(msg,
                          "\agRecipe Missing: \at\ay\ap[\aw" .. l_item_name ..
                              "\ap] \a[[\agNeed: ", l_item_count)
                end
                break
            end

            -- Recipes to make
            if recipe_list[1] ~= nil then
                local shopping_list = shop.create_shopping_list(recipe_list)
                -- Shopping to be done
                if shopping_list[1] ~= nil then
                    -- Plat Check
                    if mq.TLO.Me.PlatinumBank() >= 500 or
                        mq.TLO.Me.PlatinumShared() >= 500 then
                        if mq.TLO.Me.Platinum() < 250 then
                            movement.bank()
                            -- Grab 500 plat
                            lib.bank_withdrawal(500)
                        end
                    end
                    -- Go Shopping
                    shop.go_shopping(shopping_list)

                    if mq.TLO.Zone.ID() == 54 and mq.TLO.Me.Z() > 10 then
                        mq.cmd('/nav locyx -443 92 |log=off')
                        while mq.TLO.Nav.Active() do
                            mq.delay(1000)
                        end
                        mq.cmd('/keypress forward hold')
                        mq.delay(6000)
                        mq.cmd('/keypress forward')
                        mq.delay(2000)
                    end

                    if mq.TLO.Zone.ID() == 394 then
                        movement.crescent_reach_floor_1()
                    end

                    if mq.TLO.Zone.ID() ~= 202 then
                        mq.cmd('/squelch /travelto poknowledge')
                        while mq.TLO.Zone.ID() ~= 202 do
                            mq.delay(1)
                        end
                    end
                end
            end

            mq.delay(1000)
            mq.cmd('/cleanup')
            mq.delay(1000)
            -- Go Crafting
            go_craft(recipe_list, 0)

            lib.ClearCursor()

        end

        lib.ClearCursor()

    end

        -- Return Trophies
        lib.swap_ammo_slot_back(GLOBAL_AMMO_SLOT)

        -- Fishing
        lib.return_primary_item()

    -- Don't auto deliver for Artisan Quests
    if string.find(l_quest_name, "Supplies") then return end

    local return_flag = 1

    local get_deliver_status_array = lib.quest_deliver_status(l_quest_id)

    for x = 0, #get_deliver_status_array do

        local l_deliver_step = lib.return_number(get_deliver_status_array[x], 1)
        --   print ("deliver step: ",l_deliver_step)
        local l_quest_item_id =
            lib.return_number(get_deliver_status_array[x], 2)

        if mq.TLO.Task(l_quest_name).Objective(l_deliver_step).Status() ~=
            "Done" then

            local l_inv_count = mq.TLO.FindItemCount(l_quest_item_id)()

            -- Get total amount of tasks for the quest
            local l_o_count = mq.TLO.Window('TaskWND').Child(
                                  'Task_TaskElementList').Items()
            -- Divide by 2 to get the subtraction number
            l_o_count = l_o_count - l_o_count / 2
            -- print(l_quest_item_id, " ",l_inv_count," step: ",l_deliver_step," create step: ",l_deliver_step-l_o_count)
            -- print("create step: ",mq.TLO.Task(l_quest_name).Objective(l_deliver_step-l_o_count).Status())
            -- get the status of the create quest
            local c_s_step_done = mq.TLO.Task(l_quest_name).Objective(
                                      l_deliver_step - l_o_count).Status()
            -- print("Step: ",l_deliver_step-l_o_count," ",c_s_step_done)

            -- Check inventory >0 and also that the create step is complete!
            if l_inv_count > 0 and c_s_step_done == "Done" then
                return_flag = 0
                print(msg, "We have items to deliver")
                break
            end
        end
    end

    if return_flag == 1 then
        print(msg, "No items to deliver")
        if p_deposit == 1 then
            shop.return_bank_shopping()
         --   shop.return_depot()
        end
        return
    end

    -- Merchant Alliance Quest
    if string.find(l_quest_name, "Alliance") then
        -- print " Alliance under construction"
        -- return
    end

    quest_npc, quest_turn_in, quest_zone_id, quest_name, quest_text, quest_item, quest_itemid =
        lib.return_standard_quest_information(p_quest_title)

    -- Quest Zone is WFP
    if quest_zone_id == 383 then
        if mq.TLO.Zone.ID() ~= quest_zone_id then
            movement.zone(quest_zone_id)
        end

        -- Avoid FP Guards
        mq.cmd('/squelch /nav locyxz -13 78 -61 |log=off')
        movement.moving()
        -- Move to quest NPC
        movement.npc(quest_turn_in)
        movement.moving()
        lib.Turn_In(l_quest_id, quest_name)
        -- Scorecard check
        if mq.TLO.FindItemCount(quest_itemid)() > 0 then
            movement.npc(quest_npc)
            -- Turn in the scorecard and get shiny new trophy
            lib.give_quest_item_id(quest_itemid, 1)

        else
            print(msg, "No Scorecard this time :(")
        end

        mq.cmd('/cleanup')

        -- Avoid FP Guards
        mq.cmd('/squelch /nav locyxz -13 78 -61 |log=off')
        movement.moving()
        movement.fp_pok()
    else
        -- Merchant Alliance Delivery
        if quest_zone_id == 202 then
            movement.npc(quest_turn_in)
            movement.moving()
            lib.Turn_In(l_quest_id, quest_name)
            mq.cmd('/cleanup')
        else
            print "Not ready for Halas"
            mq.exit()
        end
    end
    return
end

BUY_MULT = 1
USE_MULT = false

local args = ...

local s1 = lib.return_string(args, 1)
local n1 = lib.return_number(args, 2)

-- print("args: ",args)

args = args:gsub('"', '')

-- print("quest args: ", args)

quests_machine(s1, n1)

return

-- Only does trophies for now
