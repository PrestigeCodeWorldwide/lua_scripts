-- name: tcn_library
-- creator: jb321
-- date: 9/11/2021
-- updated: 9/15/2025
-- version 1.95b
local mq = require('mq')

-- local PackageMan = require('mq/PackageMan')
--- local sqlite3 = PackageMan.Require('lsqlite3')
local sqlite3 = require('lsqlite3')

local db = sqlite3.open(mq.luaDir .. '\\TCN\\Artisan.db')
-- Database for flagging recipes to skip for Artisan Prize
local dbp = sqlite3.open(mq.luaDir .. '\\TCN\\Prize.db')

local msg = "\ap[\atTCSNe\auX\att\ap]\aw "

-- Local functions

local function split(s, delimiter)
    local result = {};
    for match in (s .. delimiter):gmatch("(.-)" .. delimiter) do
        table.insert(result, match);
    end
    return result;
end

local function round(number, precision)
    local fmtStr = string.format('%%0.%sf', precision)
    number = string.format(fmtStr, number)
    return number
end

local library = {}

function library.get_vendor(p_item_id)
    local MQS = string.lower(mq.TLO.MacroQuest.Server())

    -- Era codes:
    -- 0 = Modern (The Burning Lands+)
    -- 1 = Pre-RoF
    -- 2 = RoF
    local serverEra = {
        rizlona  = 0,
        mischief = 0,
        yelinak  = 2,
        oakwynd  = 1
    }

    local era = serverEra[MQS] or 0 -- default to Modern if not listed

    local sql_map = {
        [0] = "SELECT * FROM VendorTable WHERE ItemID = ",
        [1] = "SELECT * FROM RVendorTable WHERE ItemID = ",
        [2] = "SELECT * FROM ZVendorTable WHERE ItemID = "
    }

    return (sql_map[era] or sql_map[0]) .. p_item_id
end

-- Recipes that require quested container
function library.check_container_requirement(passed_id)
    local result = nil

    -- Reinforced Jeweler's Kit
    local a = {
        12053, 12054, 12055, 12056, 12057, 34126, 34132, 34138, 34144, 34150,
        34156, 34162, 34168, 34174, 34180, 34186, 34192, 34198, 34204, 34210,
        34216, 34222, 34228, 34234, 34240, 34246, 34252, 34258, 34264, 34270,
        34276, 34282, 34288, 34294, 34300, 34306, 34312, 34318, 34324, 34330,
        34336, 34342, 34348, 34354, 34360, 34366, 34372, 34378, 34384, 34390,
        34396, 34402, 34408, 34414, 34420, 34426, 34432, 34438, 34444, 34450,
        34456, 34462, 34468, 34474, 34480, 34486, 34492, 34498, 34504, 34510,
        34516, 34522, 34528, 34534, 34540, 34546, 34552, 34558, 34564, 34570,
        34576, 34582, 34588, 34594, 34600, 34606, 34612, 34618, 34624, 36279,
        36285, 36291, 36297, 36303, 36309, 36315, 36321, 36327, 36333, 36339,
        36345, 36351, 36357, 36363, 36369, 36375, 36381, 36387, 36393, 36399,
        94538, 94810
    }

    -- Coffin Poison Bottle
    local b = {
        3452, 3497, 16246, 16247, 16248, 16249, 16250, 16251, 16252, 16253,
        16254, 16255, 16256, 16257, 16258, 16259, 16260, 17446, 49244
    }

    -- Reinforced Jeweler's Kit
    local a_inv = mq.TLO.FindItemCount(62480)()
    --  a_inv = mq.TLO.FindItemCount(164424)()
    local a_bank = mq.TLO.FindItemBankCount(62480)()
    local a_total = a_inv + a_bank

    -- Coffin Poison Bottle
    local b_inv = mq.TLO.FindItemCount(17149)()
    -- b_inv = mq.TLO.FindItemCount(164424)()
    local b_bank = mq.TLO.FindItemBankCount(17149)()
    local b_total = b_inv + b_bank

    -- check bank or local
    for c = 1, #a do
        if passed_id == a[c] and a_total < 1 then
            result = "Reinforced Jeweler's Kit"
            break
        end
    end

    for d = 1, #b do
        if passed_id == b[d] and b_total < 1 then
            result = "Coffin Poison Bottle"
            break
        end
    end

    return result
end

-- Added JB 3/31/2022 Load Shopping List
function library.LOAD_SL(p_f_name)
    local array = {}
    local data_path = mq.luaDir .. "\\TCN\\ShoppingLists\\" .. p_f_name
    for line in io.lines(data_path) do
        --  line = line:gsub('([A-z]+).*', "")
        if not string.find(line, "Vendor") then
            local vin = library.return_string(line, 1)
            local vi = library.return_string(line, 2)
            local viz = library.return_string(line, 6)
            if string.find(viz, "|") then viz = viz:gsub("|", ",") end
            if string.find(viz, "@") then viz = viz:gsub("@", ",") end
            if string.find(vi, "|") then vi = vi:gsub("|", ",") end
            if string.find(vi, "@") then vi = vi:gsub("@", ",") end
            local list_array = {
                VendorName = vin,
                VendorItemName = vi,
                VendorItemCount = library.return_number(line, 3),
                VendorItemPrice = library.return_number(line, 4),
                VendorItemID = library.return_number(line, 5),
                VendorItemZone = viz,
                VendorItemZoneID = library.return_number(line, 7)
            }
            table.insert(array, list_array)
        end
    end
    return array
end

-- Added JB 3/17/2022
function library.SQL_Shopping_Array(p_array)
    local db_shop = sqlite3.open(mq.luaDir .. '\\TCN\\Work.db')

    -- Create Table
    db_shop:exec(
        [[DROP TABLE IF EXISTS tempshopsort;CREATE TEMP TABLE tempshopsort (ZoneID,Vendor,ItemID,Count,ItemName,TotalPrice);]])
    local insert = table.concat(p_array, ", ")
    -- Insert Data into SQL Table
    db_shop:exec(string.format(
        "INSERT INTO tempshopsort ('ZoneID','Vendor','ItemID','Count','ItemName','TotalPrice') VALUES %s;",
        insert))
    -- Initialize Array
    local final_shop_table = {}

    db_shop:exec(
        [[DROP TABLE IF EXISTS TempVend;CREATE TEMP TABLE TempVend (ZoneID,Vendor,ItemID,Count,ItemName,TotalPrice);]])
    -- mq.delay(1)

    db_shop:exec(
        "INSERT INTO TempVend SELECT ZoneID,Vendor,ItemID,SUM(Count) AS Count,ItemName,TotalPrice FROM tempshopsort GROUP BY ItemID ORDER BY ZoneID ASC, Vendor ASC")
    -- mq.delay(1)

    -- Update all purchased tools to count of 1
    for x in db:nrows("SELECT ItemID FROM Buy_Tools_Table") do
        db_shop:exec(
            "UPDATE TempVend SET Count = 1 WHERE ItemID = " .. x.ItemID .. ";")
    end

    for x in db_shop:nrows("SELECT * FROM TempVend") do
        local shop_string = x.ZoneID .. "," .. x.Vendor .. "," .. x.ItemID ..
            "," .. x.Count .. "," .. x.ItemName .. "," ..
            x.TotalPrice
        table.insert(final_shop_table, shop_string)
    end

    db_shop:close()

    -- for c = 1 ,#final_shop_table do print(final_shop_table[c]) end

    return final_shop_table
end

-- Added JB 3/30/2022
function library.SQL_Bank_Array(p_array)
    local db_bank = sqlite3.open(mq.luaDir .. '\\TCN\\Work.db')

    -- Create Table
    db_bank:exec(
        [[DROP TABLE IF EXISTS tempbanksort;CREATE TEMP TABLE tempbanksort (Name,ID,Count);]])
    local insert = table.concat(p_array, ", ")
    -- Insert Data into SQL Table
    db_bank:exec(string.format(
        "INSERT INTO tempbanksort ('Name','ID','Count') VALUES %s;",
        insert))

    db_bank:exec(
        [[DROP TABLE IF EXISTS TempBank;CREATE TEMP TABLE TempBank (Name,ID,Count);]])
    -- mq.delay(1)

    db_bank:exec(
        "INSERT INTO TempBank SELECT Name,ID,SUM(Count) AS Count FROM tempbanksort GROUP BY ID")
    -- mq.delay(1)

    -- Update all tools to count of 1 (reminder do we have any that need the 2 laminator rollers)
    -- presumably used for mass so no?
    for x in db:nrows("SELECT ToolID FROM All_Tools") do
        db_bank:exec("UPDATE TempBank SET Count = 1 WHERE ID = " .. x.ToolID ..
            ";")
    end

    -- Update all trophies to count of 1
    for x in db:nrows("SELECT ItemID FROM TrophyIDTable") do
        db_bank:exec("UPDATE TempBank SET Count = 1 WHERE ID = " .. x.ItemID ..
            ";")
    end

    local m = {}
    for x in db_bank:nrows("SELECT * FROM TempBank") do
        if string.find(x.Name, "@") then x.Name = x.Name:gsub('@', ',') end
        local array_item = { Name = x.Name, ID = x.ID, Quantity = x.Count }
        table.insert(m, array_item)
    end
    db_bank:close()
    return m
end

-- Added 3/10/22
-- Return sorted array from SQL
function library.SQL_Sort_Array(p_array)
    -- local db_sort = sqlite3.open(mq.luaDir ..
    --      '\\TCN\\aork.db')

    local db_sort = sqlite3.open(":memory:")

    -- Create Table
    db_sort:exec(
        [[DROP TABLE IF EXISTS tempsort;CREATE temp TABLE tempsort (ID,Count);]])

    local final_table = {}

    -- Populate Array with SQL Format
    for c = 1, #p_array do
        -- local name = library.return_string(p_array[c], 1)
        local ID = library.return_number(p_array[c], 2)
        local count = library.return_number(p_array[c], 3)
        -- local act = library.return_string(p_array[c], 4)
        -- local location = library.return_string(p_array[c], 5)

        -- if location == nil then location = "Unknown" end

        -- if string.find(location, ",") then
        --     location = location:gsub(',', '@')
        -- end

        --  if name == nil then name = "Unknown" end

        --  if string.find(name, ",") then name = name:gsub(',', '@') end

        --  if act == nil then act = "Unknown" end

        table.insert(final_table,
            -- string.format("('%s', %d, %d, '%s','%s')", name:gsub("'", "''"), ID,
            --  count, act, location))

            string.format("(%d, %d)", ID, count))
    end

    local insert = table.concat(final_table, ", ")

    -- Insert Data into SQL Table
    db_sort:exec(string.format(
        "INSERT INTO 'tempsort' ('ID','Count') VALUES %s;", insert))
    --  "INSERT INTO 'tempsort' ('Name','ID','Count','Action','Zone') VALUES %s;", insert))

    -- Change to temp table char toon?

    -- Initialize Array
    local final_farm_table = {}

    for r in db_sort:nrows(
        "SELECT ID,SUM(Count)AS ITEMCOUNT FROM tempsort GROUP BY ID ORDER BY ID DESC") do
        local farm_zone = library.lookup_farm_zone(r.ID)
        local farm_action = library.lookup_farm_action(r.ID)
        local farm_name = library.return_item_name(r.ID)

        if farm_name == nil then farm_name = "Unknown" end
        if string.find(farm_name, ",") then
            farm_name = farm_name:gsub(',', '@')
        end

        if farm_action == nil then farm_action = "Unknown" end

        if farm_zone == nil then farm_zone = "Unknown" end
        if string.find(farm_zone, ",") then
            farm_zone = farm_zone:gsub(',', '@')
        end

        -- print(farm_name)

        local final_farm_string =
            farm_name .. "," .. r.ID .. "," .. r.ITEMCOUNT .. "," .. farm_action ..
            "," .. farm_zone
        -- print("match ", r.ID, " ", r.ITEMCOUNT)
        table.insert(final_farm_table, final_farm_string)
    end

    -- Drop temp table here?

    db_sort:close()
    -- Return sorted array
    return final_farm_table
end

function library.check_ts_status(p_item_id)
    local ts_flag = 0
    local l_item_type = mq.TLO.FindItem(p_item_id).Type()
    local l_item_ts = mq.TLO.FindItem(p_item_id).Tradeskills()
    local l_item_stack = mq.TLO.FindItem(p_item_id).Stackable()
    local l_item_stacksize = mq.TLO.FindItem(p_item_id).StackSize()
    -- print(l_item_type, " ",l_item_ts," ", l_item_stack," ",l_item_stacksize)
    if l_item_ts and l_item_stack and l_item_stacksize > 1 then ts_flag = 1 end

    return ts_flag
end

-- Determine free backpack slots
function library.backpack_free_slots(p_ts_stat)
    local container_type
    local container_free
    local container_slots_free = 0

    local bag_iter = 32

    local MQS = mq.TLO.MacroQuest.Server()

    -- TLP Server quick lookup
    -- False means SoL unlocked+
    local tlpServers = {
        rizlona  = false,
        mischief = false,
        yelinak  = false,
        oakwynd  = false
    }

    -- Changed yelinak and rizlona to false on 9/15/2025
    -- Thornblade merged to Mischief in 2024

    -- Case-insensitive check
    if tlpServers[string.lower(MQS)] then
        bag_iter = 30
    end

    for i = 23, bag_iter do
        container_type = mq.TLO.Me.Inventory(i).Type()

        if container_type == "BackPack" or container_type == "Small Chest" or
            container_type == "Large Chest" or container_type == "Small Bag" then
            container_free = mq.TLO.Me.Inventory(i).Container() -
                mq.TLO.Me.Inventory(i).Items()
            container_slots_free = container_slots_free + container_free
        end

        if container_type == "Tradeskill Bag" and p_ts_stat == 1 then
            container_free = mq.TLO.Me.Inventory(i).Container() -
                mq.TLO.Me.Inventory(i).Items()
            container_slots_free = container_slots_free + container_free
        end
    end
    return container_slots_free
end

-- Defunct, make one liner
function library.ascript_status(p_script_name, p_squelch)
    -- print("passed: ", p_script_name)

    if mq.TLO.Lua.Script(string.upper(p_script_name)).Status() == "RUNNING" then
        if p_squelch == 1 then
            print(msg, "\agScript: \at", p_script_name, "\ag running")
        end
        return mq.TLO.Lua.Script(p_script_name).PID(),
            mq.TLO.Lua.Script(p_script_name).Status()
    end

    if mq.TLO.Lua.Script(string.lower(p_script_name)).Status() == "RUNNING" then
        if p_squelch == 1 then
            print(msg, "\agScript: \at", p_script_name, "\ag running")
        end
        return mq.TLO.Lua.Script(p_script_name).PID(),
            mq.TLO.Lua.Script(p_script_name).Status()
    end

    local pid_array = mq.TLO.Lua.PIDs()
    local delimiter = ","
    local pid_table = {};
    for match in (pid_array .. delimiter):gmatch("(.-)" .. delimiter) do
        if match ~= nil then table.insert(pid_table, match); end
    end

    local flag = 0

    local get_pid_name

    if pid_table[1] ~= nil then
        for c = 1, #pid_table do
            get_pid_name = mq.TLO.Lua.Script(pid_table[c]).Name()

            if get_pid_name ~= nil then
                local lower_pid_name = string.lower(get_pid_name)
                local lower_script_name = string.lower(p_script_name)

                --   print(lower_pid_name, " ", lower_script_name)

                if lower_pid_name == lower_script_name then
                    flag = 1
                    -- print(get_pid_name, " ", pid_table[c])
                    break
                end
            end
        end
    else
        return nil, nil
    end

    if flag == 1 then
        return mq.TLO.Lua.Script(get_pid_name).PID(),
            mq.TLO.Lua.Script(get_pid_name).Status()
    end

    return nil, nil
end

function library.event()
    mq.doevents()
    mq.doevents()
    mq.doevents()
    mq.doevents()
    mq.doevents()
    mq.doevents()
    mq.doevents()
    return
end

function library.close_db()
    print(msg, "Closing Artisan.db")
    db:close()
    return
end

--- buyable tools check
function library.return_tool_buy(p_item_id)
    local m = 0
    for r in db:nrows("SELECT * FROM Buy_Tools_Table WHERE ItemID= " ..
        p_item_id) do
        if p_item_id == r.ItemID then
            -- print ("match ",p_item_id)
            m = 1
        end
    end
    return m
end

-- Bought tool and it is in bank
function library.return_banked_tool_buy(p_item_id)
    local m = 0
    for r in db:nrows("SELECT * FROM Buy_Tools_Table WHERE ItemID= " ..
        p_item_id) do
        local b_count = mq.TLO.FindItemBankCount()
        if p_item_id == r.ItemID and mq.TLO.FindItemCount(p_item_id)() > 0 then
            --  print("match ", p_item_id)
            m = 1
        end
    end
    return m
end

--- Vendor Item Zone Lookup
function library.return_vendor_zone(p_item_id)
    local m = 0

    --local sql_string = "SELECT * FROM VendorTable WHERE ItemID= " .. p_item_id

    -- Return appropriate SQL string based on ERA
    local sql_string = library.get_vendor(p_item_id)

    for r in db:nrows(sql_string) do
        if p_item_id == r.ItemID then
            -- print ("match ",p_item_id)
            m = r.VendorZone
        end
        return m
    end
end

--- Vendor Price Lookup
function library.return_item_price(p_item_id)
    local item_price = nil

    -- Return appropriate SQL string based on ERA
    local sql_string = library.get_vendor(p_item_id)

    for r in db:nrows(sql_string) do
        if p_item_id == r.ItemID then
            -- print ("match ",p_item_id)
            item_price = r.VendorPrice
        end
        return item_price
    end
end

-- Added 2/28/2022
-- Vendor Data Lookup
function library.return_vendor_data(p_item_id, p_count)
    local item_price = nil
    local item_data = nil
    local vendor_item_zone_id = 0
    local item_vendor_name = nil
    local vendor_item_id = 0
    local vendor_item_name = nil
    local item_total_price = 0

    -- Return appropriate SQL string based on ERA
    local sql_string = library.get_vendor(p_item_id)

    for r in db:nrows(sql_string) do
        if p_item_id == r.ItemID then
            vendor_item_zone_id = r.VendorZoneID
            item_vendor_name = r.VendorName
            vendor_item_id = r.ItemID
            item_price = r.VendorPrice

            if string.find(r.VendorItemName, ",") then
                r.VendorItemName = r.VendorItemName:gsub(',', '@')
            end

            vendor_item_name = r.VendorItemName
            item_total_price = p_count * item_price

            item_data = vendor_item_zone_id .. "," .. item_vendor_name .. "," ..
                vendor_item_id .. "," .. p_count .. "," ..
                vendor_item_name .. "," .. item_total_price

            break
        end
    end
    return item_data
end

-- quest data

-- Return Legacy Quest Information from SQLite

function library.return_god_quest_id(p_id)
    local m
    for god_row in db:nrows(
        "SELECT * FROM Legacy_Quest_Information_Table WHERE QuestFakeID= " ..
        p_id) do m = god_row.QuestFakeID end
    return m
end

function library.return_god_quest_recipe_array(p_id)
    local m = {}
    local counter = 0
    for god_row in db:nrows(
        "SELECT * FROM Legacy_Quest_Recipe_Table WHERE QuestID=" ..
        p_id) do
        m[counter] = god_row.RecipeID
        counter = counter + 1
    end
    return m
end

-- Removes all spaces?
local function noSpace(str)
    local normalisedString = string.lower(string.gsub(str, "%s+", ""))
    return normalisedString
end

-- unused.. what is/was the intent?
function library.ListGuildItemID(p_item, p_qty) return end

-- Added 4/26/2022 JB321
function library.GrabGuildItemName(p_item_name, p_qty)
    local grab_count = 0

    -- better to get index of amount needed or just bang away
    while true do
        local guild_item_grab_index = mq.TLO.Window('GuildBankWnd').Child(
                'GBANK_ItemList')
            .List('=' .. p_item_name, 2)()

        mq.delay(1)

        local guild_item_current_count = tonumber(
            mq.TLO.Window('GuildBankWnd')
            .Child('GBANK_ItemList')
            .List(guild_item_grab_index, 3)())

        mq.delay(1)

        if guild_item_current_count <= p_qty then
            grab_count = guild_item_current_count
        end

        if guild_item_current_count > p_qty then grab_count = p_qty end

        mq.delay(1)

        mq.cmd('/nomodkey /notify GuildBankWnd GBANK_ItemList listselect ',
            guild_item_grab_index)

        mq.cmd('/notify GuildBankWnd GBANK_WithdrawButton leftmouseup')
        mq.delay(300)

        -- add q_win_open local q_win_open = mq.TLO.Window('QuantityWnd').Open()

        mq.cmd('/notify QuantityWnd QTYW_slider newvalue', grab_count)
        mq.delay(300)

        -- Click Accept
        mq.cmd('/nomodkey /notify QuantityWnd QTYW_Accept_Button leftmouseup')
        mq.delay(500)

        -- Auto-Inventory
        mq.cmd('/autoinv')
        mq.delay(500)

        p_qty = p_qty - grab_count

        if p_qty <= 0 then break end

        -- print("still need: ", p_qty)

        mq.delay(1)
    end

    return
end

-- Grab individual hoard item with quantity
function library.GrabHoardItemName(p_item_name, p_item_qty)
    local need = p_item_qty
    local grab_count = 0

    while true do
        local dragon_item_grab_index = mq.TLO.Window('DragonHoardWnd').Child(
                'DH_Item_List')
            .List('=' .. p_item_name, 2)()
        mq.delay(1)

        local dh_item_current_count = tonumber(
            mq.TLO.Window('DragonHoardWnd').Child(
                'DH_Item_List')
            .List(dragon_item_grab_index, 3)())
        mq.delay(1)

        if dh_item_current_count <= need then
            grab_count = dh_item_current_count
        end

        if dh_item_current_count > need then grab_count = need end

        -- Select Hoard Item
        mq.cmd('/nomodkey /notify DragonHoardWnd DH_Item_List listselect ',
            dragon_item_grab_index)
        mq.delay(1)
        -- Grab from Hoard
        mq.cmd('/nomodkey /notify DragonHoardWnd DH_Retrieve_Button leftmouseup')
        mq.delay(1)

        -- print("count: ", grab_count)

        local q_win_open = mq.TLO.Window('QuantityWnd').Open()

        -- if grab_count > 1 then
        if q_win_open then
            mq.cmd('/notify QuantityWnd QTYW_slider newvalue', grab_count)
            mq.delay(300)
            -- Click Accept
            mq.cmd(
                '/nomodkey /notify QuantityWnd QTYW_Accept_Button leftmouseup')
            mq.delay(500)
            -- Auto-Inventory
            mq.cmd('/autoinv')
            mq.delay(500)
        end

        library.ClearCursor()

        need = need - grab_count
        if need <= 0 then break end
        -- print("still need: ", need)
        mq.delay(1)
    end

    --  library.ClearCursor()

    return
end

-- Grab TSD items with quantity
function library.GrabTSDItemID(p_item_id, p_item_qty)
    library.ClearCursor()

    mq.delay(1)

    if mq.TLO.Merchant.Open() then
        mq.TLO.Window('MerchantWnd').DoClose()
        mq.delay(1500)
    end

    if mq.TLO.Window('TradeskillWnd').Open() then
        mq.TLO.Window('TradeskillWnd').DoClose()
        mq.delay(1500)
    end

    mq.delay(500)

    if not mq.TLO.Window('TradeskillDepotWnd').Open() then
        mq.TLO.Window('TradeskillDepotWnd').DoOpen()
        mq.delay(500)
    end

    while not mq.TLO.TradeskillDepot.ItemsReceived() do mq.delay(1000) end

    local l_need = p_item_qty
    local need = p_item_qty
    local grab_count = 0

    local l_item_name = mq.TLO.TradeskillDepot.FindItem(p_item_id)()

    GLOBAL_TEXT = "Grabbing (" .. need .. ") " .. l_item_name .. " From [DEPOT]"
    -- print(msg, "\ap[\awGrabbing\ap] \ap(\ag", need, "\ap) \ap[\ag", l_item_name,
    --   "\ap] \agfrom [Depot]")

    while true do
        -- Clear cursor after last grab potentially
        if mq.TLO.Cursor() ~= nil then
            library.ClearCursor()
            mq.delay(1000)
        end

        -- local tsd_item_current_count = mq.TLO.TradeskillDepot.FindItemCount(
        --                    '=' .. p_item_name)()

        local tsd_item_current_count = mq.TLO.TradeskillDepot.FindItemCount(
            p_item_id)()

        -- local l_inv = mq.TLO.FindItemCount('=' .. p_item_name)()

        local l_inv = mq.TLO.FindItemCount(p_item_id)()

        mq.delay(1000)

        -- Grab what we can
        if tsd_item_current_count <= need then
            grab_count = tsd_item_current_count
        end

        if tsd_item_current_count > p_item_qty then
            grab_count = p_item_qty
        end

        -- Count over 999
        if grab_count > 999 and need > 999 then grab_count = 1000 end

        -- Small grab
        if grab_count > need then grab_count = need end

        -- Select TradeskillDepot Item
        --  mq.TLO.TradeskillDepot.SelectItem('=' .. p_item_name)()

        local p_item_name = mq.TLO.TradeskillDepot.FindItem(p_item_id)()

        mq.TLO.TradeskillDepot.SelectItem('=' .. p_item_name)()
        mq.delay(1000)
        -- Grab TradeskillDepot Item
        mq.TLO.TradeskillDepot.WithdrawItem('=' .. p_item_name)()
        mq.delay(1000)

        print(msg,
            "\ap[\awGrabbing\ap] [\ay" .. grab_count .. "\ap] \ap(\aw" ..
            p_item_name .. "\ap) \ap[\ayDepot\ap]")

        local q_win_open = mq.TLO.Window('QuantityWnd').Open()

        -- if grab_count > 0 then
        if q_win_open then
            mq.cmd('/notify QuantityWnd QTYW_slider newvalue', grab_count)
            mq.delay(1000)
            -- 500
            -- Click Accept
            mq.cmd(
                '/nomodkey /notify QuantityWnd QTYW_Accept_Button leftmouseup')
            mq.delay(1000)
            -- was 500

            -- Wait for something to be on cursor, but don't wait more than 10 seconds
        end

        -- Auto-Inventory
        mq.cmd('/autoinv')
        mq.delay(1500)

        library.ClearCursor()

        --  print("calc need ",need)

        -- Break out counter
        local boc = 0
        -- If the on hand count = current inventory, wait
        -- Wait until inventory changes (Depot)

        -- revisit and think about this
        -- should be on change.. this just looks at the same value dumb!

        while mq.TLO.FindItemCount(p_item_id)() == l_inv do
            mq.delay(1)
            print(msg, "Waiting for item count in inventory to update")
            -- print(mq.TLO.FindItemCount('=' .. p_item_name)())
            mq.delay(1000)
            boc = boc + 1
            -- Will break out if over 19 seconds
            if boc > 19 then break end
        end

        mq.delay(1)

        need = need - grab_count

        mq.delay(1)

        if need <= 0 then
            mq.delay(1)
            library.ClearCursor()
            mq.delay(1000)
            break
        end
        -- print("still need: ", need)
        mq.delay(700)
        mq.delay(300)
    end

    library.ClearCursor()
    mq.delay(1000)
end

function library.GrabBankItemID(p_id, p_qty)
    local on_hand_ItemCount = mq.TLO.FindItemCount(p_id)()
    local is_tool = library.toolcheck_id(p_id)
    -- If tool and we have it in inventory then return
    if is_tool == 1 and on_hand_ItemCount >= p_qty then return end
    local is_trophy = library.trophycheck_id(p_id)
    -- If trophy and we have in inventory then return
    if is_trophy == 1 and on_hand_ItemCount > 0 then return end

    if p_qty == 0 or p_qty == nil then
        print(msg, "\ap[\awCan't grab nothing, please select a quantity\ap]")
        -- Tools 0?
        --   p_qty = 1
        return
    end

    if mq.TLO.FindItemBank(p_id)() == nil then
        print(msg, " Item ID: ", p_id,
            " \ap[\awdoes not exist in any bank slot:\ap]")
        return
    end

    local ItemToGrab = mq.TLO.FindItemBank(p_id).Name()
    local l_ItemCount = mq.TLO.FindItemBankCount(p_id)()

    -- Only works for total count
    -- Count achieved already - Assuming counts are good!
    -- if on_hand_ItemCount >= p_qty then return end

    -- If we ask for too much, return
    if p_qty > l_ItemCount and l_ItemCount > 0 then
        print(msg, " We don't have: \ap(\ag", p_qty,
            "\ap)\aw of " .. ItemToGrab .. " We have: \ap(\ag", l_ItemCount,
            "\ap)")
        return
        --  p_qty = -1
    end

    -- local BankSlot = mq.TLO.FindItemBank().ItemSlot() + 1
    -- local Slot2 = mq.TLO.FindItemBank('=' .. ItemToGrab).ItemSlot2() + 1

    -- Open bank window
    if not mq.TLO.Window('BigBankWnd').Open() then
        mq.cmd('/nomodkey /click right target')
        mq.delay(1000)
    end

    -- Open Finditem window
    if not mq.TLO.Window('FindItemWnd').Open() and mq.TLO.MacroQuest.Server() ==
        "rizlonas" then
        mq.cmd('/notify BankWnd BW_FindItemButton leftmouseup')
        mq.delay(1000)
    else
        if not mq.TLO.Window('FindItemWnd').Open() then
            mq.cmd('/notify BigBankWnd BIGB_FindItemButton leftmouseup')
            mq.delay(1000)
        end
    end

    GLOBAL_TEXT = "Grabbing (" .. p_qty .. ") " .. ItemToGrab
    print(msg, "\ap[\awGrabbing\ap] \ap(\ag", p_qty, "\ap) \ap[\ag", ItemToGrab,
        "\ap]")

    local c_inv = on_hand_ItemCount + p_qty
    local o_qty = p_qty

    while mq.TLO.FindItemCount(p_id)() < c_inv do
        local BankSlot = mq.TLO.FindItemBank(p_id).ItemSlot() + 1
        local Slot2 = mq.TLO.FindItemBank(p_id).ItemSlot2() + 1
        local SlotStack = mq.TLO.FindItemBank(p_id).Stack()

        -- Select bank from drop down
        local location = "Bank"

        -- Return index # of Bank in 'Select By Location' Window
        local find_item_location_index =
            mq.TLO.Window('FindItemWnd').Child('FIW_ItemLocationCombobox')
            .List(location)()

        if find_item_location_index == nil or find_item_location_index == 0 then
            print(msg, "\ayError Invalid Location Combo")
            return
        end

        local find_item_current_location =
            mq.TLO.Window('FindItemWnd').Child('FIW_ItemLocationCombobox')
            .GetCurSel()

        local l_text_length = tonumber(string.len(
            mq.TLO.Window('FindItemWnd').Child(
                'FIW_ItemNameInput').Text()))

        mq.delay(300)

        if find_item_current_location ~= find_item_location_index or
            l_text_length > 0 then
            -- Click reset
            mq.cmd('/notify FindItemWnd FIW_Default leftmouseup')
            mq.delay(300)
            -- Click drop down for location
            mq.cmd('/notify FindItemWnd FIW_ItemLocationCombobox leftmouseup')
            mq.delay(300)
            -- Select Bank From Locations Drop-Down
            mq.cmd('/notify FindItemWnd FIW_ItemLocationCombobox listselect ' ..
                find_item_location_index .. ' leftmouseup')
            mq.delay(300)
        end

        -- end testing

        -- Get length of text in search box
        local l_text_length = tonumber(string.len(
            mq.TLO.Window('FindItemWnd').Child(
                'FIW_ItemNameInput').Text()))

        -- if l_text_length > 0 then
        -- Click reset

        -- Click reset without checking text length

        --  mq.cmd('/notify FindItemWnd FIW_Default leftmouseup')
        --  mq.delay(1000)
        --  end

        -- Click Text Input Window
        mq.cmd('/notify FindItemWnd FIW_ItemNameInput leftmouseup')
        mq.delay(1000)
        mq.cmd('/notify FindItemWnd FIW_QueryButton leftmouseup')
        mq.delay(1000)

        -- Change to repeat?

        -- Get index of item we want from bank
        local bank_index = mq.TLO.Window('FindItemWnd').Child('FIW_ItemList')
            .List('=' .. ItemToGrab, 2)()
        mq.delay(1000)

        if bank_index == nil or bank_index == 0 then
            print " Item is not in bank"
            --  library.writefile("itemNotinbank", ItemToGrab .. "," .. mq.TLO.Me())
            return
        end

        mq.delay(500)
        -- Select Item
        mq.cmd('/nomodkey /notify FindItemWnd FIW_ItemList listselect ',
            bank_index)
        mq.delay(1000)
        -- Highlight item
        mq.cmd('/nomodkey /notify FindItemWnd FIW_HighlightButton leftmouseup')
        mq.delay(1000)

        -- print("Location ", mq.TLO.Window('FindItemWnd').Child('FIW_ItemList')
        --   .List(bank_index, 4)())

        local cmd_string = ""
        local bank_area = "bank"

        -- was 1000
        mq.delay(300)

        local l_item_location = mq.TLO.Window('FindItemWnd').Child(
            'FIW_ItemList').List(bank_index, 4)()

        -- Is it a shared bank slot
        if string.find(l_item_location, "SharedBank") then
            bank_area = "sharedbank"
        end

        --  GLOBAL_TEXT = "Grabbing (" .. p_qty .. ") " .. ItemToGrab
        -- print(msg, "\ap[\awGrabbing\ap] \ap(\ag", p_qty, "\ap) \ap[\ag",
        --     ItemToGrab, "\ap]")

        -- DBG UI Delay Bank -- was 3000
        mq.delay(1000)

        if p_qty == 1 then
            cmd_string =
                '/ctrl /itemnotify in ' .. bank_area .. BankSlot .. " " .. Slot2 ..
                ' leftmouseup'
        end

        if p_qty == -1 then
            cmd_string = '/shift /itemnotify in ' .. bank_area .. BankSlot ..
                " " .. Slot2 .. ' leftmouseup'
        end

        if p_qty > 1 then
            cmd_string = '/nomodkey /itemnotify in ' .. bank_area .. BankSlot ..
                " " .. Slot2 .. ' leftmouseup'
            mq.cmd(cmd_string)

            -- was 1000
            mq.delay(300)
            -- Select Qty..

            if SlotStack < o_qty then
                mq.cmd('/notify QuantityWnd QTYW_slider newvalue', SlotStack)
                o_qty = o_qty - SlotStack
                mq.delay(1)
            else
                mq.cmd('/notify QuantityWnd QTYW_slider newvalue', o_qty)
                mq.delay(1)
            end

            -- was 1500
            mq.delay(300)

            -- Click Accept
            -- slider wait?
            -- wait until slider = p_qty..

            mq.cmd(
                '/nomodkey /notify QuantityWnd QTYW_Accept_Button leftmouseup')
            mq.delay(1000)

            cmd_string = nil
        end

        if cmd_string ~= nil then mq.cmd(cmd_string) end

        if mq.TLO.Cursor.ID() == nil then
            print(msg, "\ayError: Couldn't pick up the item ", ItemToGrab)
            --  library.writefile("Couldnotgrab",
            --          ItemToGrab .. "," .. p_qty .. "," .. mq.TLO.Me())
            return
        end

        if mq.TLO.Cursor.ID() ~= nil then library.ClearCursor() end

        mq.delay(1000)
    end

    return
end

function library.return_god_quest_id_array_dump()
    local m = {}
    local counter = 0
    for god_row in db:nrows(
        "SELECT * FROM Legacy_Quest_Information_Table WHERE Quest_Zone = 'Abysmal Sea'") do
        -- QuestFakeID != 2322") do
        m[counter] = god_row.QuestFakeID
        counter = counter + 1
    end
    return m
end

function library.return_tss_quest_id_array_dump()
    local m = {}
    local counter = 0
    for god_row in db:nrows(
        "SELECT * FROM Legacy_Quest_Information_Table WHERE Quest_Zone = 'Crescent Reach'") do
        m[counter] = god_row.QuestFakeID
        counter = counter + 1
    end
    return m
end

-- performs queries for DanNet
function library.query_dannet(peer, query, timeout)
    mq.cmdf('/dquery %s -q "%s"', peer, query)
    mq.delay(timeout or 200)
    local value = mq.TLO.DanNet(peer).Q(query)()
    return value
end

-- Performs faction searches based on name to determine if NPC will sell to us
-- Usage faction_search("Coldain") -- returns faction reaction
function library.faction_search(p_faction)
    local l_faction_index = mq.TLO.Window('FactionWnd/FAC_FactionList').Items()

    -- l_faction_index = 0

    if l_faction_index == 0 then
        mq.TLO.Window('FactionWnd').DoOpen()
        -- mq.cmd('/faction')

        mq.delay(1000)
        while l_faction_index == 0 do
            -- print(l_faction_index)
            -- l_faction_index = mq.TLO.Window('FactionWnd/FAC_FactionList')
            --   .Items()
            l_faction_index = mq.TLO.Window('FactionWnd').Child(
                'FAC_FactionList').Items()

            mq.delay(1000)
        end
        mq.delay(1000)
    end

    mq.delay(1)

    if mq.TLO.Window('FactionWnd')() then
        mq.TLO.Window('FactionWnd').DoClose()
    end
    mq.delay(1000)

    local l_faction_reaction = nil
    for x = 1, l_faction_index do
        local l_faction_name = mq.TLO.Window('FactionWnd/FAC_FactionList').List(
            x, 1)()
        l_faction_reaction = mq.TLO.Window('FactionWnd/FAC_FactionList').List(x,
            2)()
        --  local l_faction_search = "Coalition of Tradefolk"
        local l_faction_search = p_faction
        if l_faction_name == l_faction_search then
            -- print(l_faction_name, " ", l_faction_reaction)
            break
        end
    end
    mq.delay(1000)
    return l_faction_reaction
end

function library.faction_required(p_vendor_name)
    local m = nil
    local n = nil

    p_vendor_name = "'" .. p_vendor_name .. "'"
    for r in db:nrows(
        "SELECT DISTINCT * FROM VendorLocations WHERE VendorName=" ..
        p_vendor_name .. " ORDER BY VendorZoneID ASC") do
        if r.VendorFaction == nil then r.VendorFaction = "None" end
        if r.VendorFactionRequired == nil then
            r.VendorFactionRequired = "None"
        end
        m = r.VendorFactionRequired
        n = r.VendorFaction
    end
    return m, n
end

function library.faction_check(p_vendor_name)
    local player_faction = 0
    local needed_faction = 0

    local l_faction_standing = nil
    local l_faction_required = nil
    local l_faction_name = nil

    -- Faction check
    local factions = {
        "Scowls", "Threateningly", "Dubious", "Apprehensive", "Indifferent",
        "Amiably", "Kindly", "Warmly", "Ally"
    }

    l_faction_required, l_faction_name = library.faction_required(p_vendor_name)
    l_faction_standing = library.faction_search(l_faction_name)

    -- print("need fac: ",l_faction_required, " have: ",l_faction_standing)

    for x = 1, #factions do
        if l_faction_required == factions[x] then
            needed_faction = x
            break
        end
    end

    for x = 1, #factions do
        if l_faction_standing == factions[x] then
            player_faction = x
            break
        end
    end

    if player_faction >= needed_faction then
        return 1
    else
        return 0
    end
end

function library.legacy_destroy(p_id)
    for list_row in db:nrows(
        "SELECT * FROM Legacy_Quest_Recipe_Table WHERE QuestID=" ..
        p_id) do
        local des_id = list_row.RecipeID
        library.destroy_recipe_components_id(des_id)
    end
    return
end

function library.legacy_quest_complete(p_id)
    local winning = 1
    ---print(p_id)
    for r2 in db:nrows(
        "SELECT * FROM Legacy_Quest_Recipe_Table WHERE QuestID=" ..
        p_id) do
        for r in db:nrows("SELECT * FROM MasterCompTable WHERE RecipeID=" ..
            r2.RecipeID) do
            -- print("\atItem ID: ",r.ItemID)
            if mq.TLO.FindItem(r.ItemID)() ~= nil then winning = 0 end
            mq.delay(1)
        end
        mq.delay(1)
    end
    return winning
end

function library.return_quest_info(p_id)
    for god_info in db:nrows(
        "SELECT * FROM Legacy_Quest_Information_Table WHERE QuestFakeID=" ..
        p_id) do
        return god_info.Quest_NPC, god_info.Quest_Text, god_info.Quest_Win,
            god_info.QuestName, god_info.Quest_NAV, god_info.Quest_Bag,
            god_info.Quest_Bag_Price, god_info.Quest_Bag_ID,
            god_info.Quest_Skill
    end
end

function library.return_god_quest_number(p_skill)
    local quest_number
    local db_skill = '"' .. p_skill .. '"'
    for legacy_row in db:nrows(
        "SELECT * FROM Legacy_Quest_Information_Table WHERE Quest_Skill= " ..
        db_skill) do
        quest_number = legacy_row.Quest_Row
        break
    end

    return quest_number
end

-- Return set of recipes for a tradeskill quest based on Quest Task ID
function library.return_quest_recipes(p_id, p_name)
    local m = {}

    for quest_row in db:nrows(
        "SELECT * FROM Master_Quest_Table WHERE Quest_Step_Order = 1 AND Quest_Task_ID=" ..
        p_id) do
        local step = quest_row.Quest_Create_Step
        -- Don't add completed steps to recipe list
        if mq.TLO.Task(p_name).Objective(step).Status() ~= "Done" then
            local need_count = mq.TLO.Task(p_name).Objective(step)
                .RequiredCount()
            local have_count = mq.TLO.Task(p_name).Objective(step)
                .CurrentCount()
            if have_count >= need_count then
                -- Lazy: Do Nothing
            else
                local want_count = need_count - have_count
                -- Get Recipe Yield
                local return_yield = library.return_recipe_yield(
                    quest_row.Quest_Recipe_ID)
                local item = {
                    RID = quest_row.Quest_Recipe_ID,
                    ID = quest_row.Quest_Item_ID,
                    QTY = want_count * return_yield
                }
                table.insert(m, item)
            end
        end
    end
    return m
end

function library.return_quest_step(p_id)
    local m
    for quest_row in db:nrows(
        "SELECT * FROM Master_Quest_Table WHERE Quest_Step_Order = 1 AND Quest_Recipe_ID=" ..
        p_id .. " LIMIT 1") do
        m = quest_row.Quest_Create_Step
    end
    return m
end

function library.return_quest_id(p_id)
    local m
    for quest_row in db:nrows(
        "SELECT * FROM Master_Quest_Table WHERE Quest_Step_Order = 1 AND Quest_Recipe_ID=" ..
        p_id .. " LIMIT 1") do
        m = quest_row.Quest_Task_ID
    end
    return m
end

function library.return_quest_name(p_id)
    local m
    for quest_row in db:nrows(
        "SELECT * FROM Master_Quest_Information_Table WHERE Quest_Task_ID=" ..
        p_id .. " LIMIT 1") do m = quest_row.Quest_Name end
    return m
end

----

function library.multi_component_check(p_id, p_need, p_silent)
    -- add silent to this

    -- dunno why there is no accurate count of tuna meat well I do know it calcs the overall need in cruncher not the actual need.. that
    -- is determine other places

    local l_inv = library.return_recipe_inv(p_id)
    local l_need = p_need - l_inv

    if l_inv >= l_need then return 0, 0 end

    local m_RID = 0
    local MAKE_C = 0
    local MR_RID

    local conversion_type = 99

    local flag = 0

    local calling_recipe_sets_wanted = 0

    for r in db:nrows(
        "SELECT * FROM MasterMultiTable where MultiRecID !=0 AND MultiRecID =" ..
        p_id .. " ORDER BY MYield ASC") do
        if p_id == r.MultiRecID then
            MR_RID = r.RecipeID
            -- print("mr rid ",MR_RID)
            flag = 1
            -- Get the calling recipe count in there
            calling_recipe_sets_wanted = r.MCount
            break
        end
    end

    if flag == 0 then return 0, 0 end

    for m_r in db:nrows(
        "SELECT * FROM MasterMultiTable where MultiRecID !=0 AND MultiRecID =" ..
        MR_RID .. " ORDER BY MYield ASC") do
        -- print("Multi ",MR_RID, " ",m_r.MItemID)

        -- Returns recipe id and make count for alternate component use

        -- MType not used currently

        -- make shop 1 recipe in buy routine or somewhere fix

        -- print "testing TCN library multi option"
        -- print("\aymulti_comp_check ", m_r.ItemID, " ", m_r.RecipeID, " ",
        --  m_r.MName)

        -- How many will it take to satisfy the need
        local l_want = math.ceil((l_need / m_r.MYield) * m_r.MCount *
            calling_recipe_sets_wanted)
        local l_have = math.ceil(mq.TLO.FindItemCount(m_r.MItemID)())

        -- p_silent = 1

        if l_have >= l_want then
            --   print(l_have, "have ", l_want, " multi tech id ", m_r.MItemID)
            m_RID = m_r.RecipeID
            MAKE_C = math.ceil(l_want)
            conversion_type = m_r.ConversionType

            if p_silent == 0 then
                print(msg,
                    "\ap[\agMulti-Option Tech:\ap] \ap[\awSelecting\ap] \ap[\aw",
                    m_r.MName, "\ap]")
            end
            break
        end
    end

    -- need to add banking checks in here also.. to add to multi bank temp

    -- spammy
    -- if MAKE_C == 0 and p_silent == 2 then
    if MAKE_C == 0 then
        --  print(msg, "\ap[\aoRecipe Component Alternatives:\ap]")
        for m_r in db:nrows(
            "SELECT * FROM MasterMultiTable where MultiRecID !=0 AND MultiRecID =" ..
            MR_RID .. " ORDER BY MYield ASC") do
            local l_have = mq.TLO.FindItemCount(m_r.ItemID)()
            local row_counts = m_r.MCount * calling_recipe_sets_wanted - l_have
            local l_want = math.ceil(l_need / m_r.MYield) * row_counts

            --  print(msg, "\ap[\at", m_r.MName, "\ap] \ap[\agNeed: \ap(\ag",
            --   l_want, "\ap)\ap]")
        end
    end
    return m_RID, MAKE_C, conversion_type
end

-- craft info

-- used?
function library.farm_table_lookup(p_item_id)
    local items = {}

    local sql_string = "SELECT * FROM FarmTable WHERE ItemID=" .. p_item_id ..
        " ORDER BY ItemID ASC"

    for r in db:nrows(sql_string) do
        if r.ItemMob == nil then r.ItemMOB = "" end
        if r.ItemNAV == nil then r.ItemNAV = "" end

        items = {
            ItemZone = r.ItemZone,
            ItemAction = r.ItemAction,
            ItemMOB = r.ItemMOB,
            ItemNAV = r.ItemNAV
        }
        -- REMD 4/2/2022
        -- mq.delay(1)
    end

    if items == nil then items = {} end
    return items
end

-- Added 3/1/2022
function library.lookup_farm_zone(p_item_id)
    local items = nil
    local sql_string = "SELECT * FROM FarmTable WHERE ItemID=" .. p_item_id ..
        " ORDER BY ItemID ASC"
    for r in db:nrows(sql_string) do
        if r.ItemMob == nil then r.ItemMOB = "" end
        if r.ItemNAV == nil then r.ItemNAV = "" end
        -- REMD 4/2/2022
        -- mq.delay(1)
        items = r.ItemZone
    end
    if items == nil then items = nil end
    return items
end

-- Added 3/1/2022
function library.lookup_farm_action(p_item_id)
    local items = nil
    local sql_string = "SELECT * FROM FarmTable WHERE ItemID=" .. p_item_id ..
        " ORDER BY ItemID ASC"
    for r in db:nrows(sql_string) do
        if r.ItemMob == nil then r.ItemMOB = "" end
        if r.ItemNAV == nil then r.ItemNAV = "" end
        -- REMD 4/2/2022
        -- mq.delay(1)
        items = r.ItemAction
    end
    if items == nil then items = nil end
    return items
end

function library.print_missing_components(p_id, p_mc)
    local m = 0

    -- print("lib print missing comps")

    -- make count used for what?

    -- p_id = tonumber(p_id)

    for craft_row in db:nrows("SELECT * FROM MasterCompTable WHERE RecipeID=" ..
        p_id) do
        local craft_inventory = mq.TLO.FindItemCount(craft_row.ItemID)()

        -- if craft_inventory >= p_mc then m = 1 break end

        local craft_count = tonumber(craft_row.ItemCount)
        if craft_count > craft_inventory then
            -- but if we have the recipe count then ignore.. revisit this!
            m = 1
            if craft_row.SubRecipeID == 0 then
                print(msg, "\ay[Missing Item] ** \ag[", craft_row.ItemName,
                    "] \awCount: \ag[", craft_count, "]")
            else
                print(msg, "\ao[Missing Recipe] \ag[", craft_row.ItemName,
                    "] \awCount: \ag[", craft_count, "]")
            end
        end
    end

    return m
end

-- tradeskill function

-- Determines 1 make can be achieved
function library.single_recipe_check(p_id)
    local flag = 1

    for r in db:nrows("SELECT * FROM MasterCompTable WHERE RecipeID=" .. p_id) do
        -- Check inventory only, check bank?
        local l_inv = mq.TLO.FindItemCount(r.ItemID)()
        local l_row = r.ItemCount

        -- Add in vendor check??

        -- print (msg,"LIB single_recipe_check testing ",r.ItemName)
        -- REMD 4/2/2022
        -- mq.delay(10)
        --  print(r.ItemName, " ",l_inv," row: ",l_row)

        if l_inv < l_row then
            flag = 0
            print(msg, "\ayMissing: \ap[\ag", r.ItemName,
                "\ap] \agHave: \ap(\ag", l_inv, "\ap) \agNeed: \ap(\ag",
                l_row, "\ap)")
            --    print("\atMissing: ",r.ItemName, " ",l_inv," row: ",l_row)
        end
        -- REMD 4/2/2022
        -- mq.delay(10)
    end
    return flag
end

-- Determines if 1 set of recipe can be crafted for array
function library.component_check(p_id, p_craft_normal)
    local pass_id = p_id
    local a_craft_item_normal = p_craft_normal

    local flag = 1
    for x = 0, #a_craft_item_normal do
        -- Return row count per recipe item
        local a = library.return_item_row_count(pass_id, a_craft_item_normal[x])

        if a == nil then
            print(msg,
                "\ayError: if component has no calling recipe TCN_library ok")
            mq.exit()
            --   a = 1
        end

        if (mq.TLO.FindItemCount(a_craft_item_normal[x])() < a) then
            local rin = library.return_item_name(a_craft_item_normal[x])
            print(msg, "\ap[\ayMissing\ap] \ap[\aw", a, "\ap] ", "[\aw", rin,
                "\ap]")
            flag = 0
        end

        -- REMD 4/2/2022
        -- mq.delay(1)
    end

    return flag
end

function library.craft_preparation(p_id)
    local l_recipe_id = p_id
    local scc = 0
    local nsc = 0
    local craft_item_split_count = {}
    local craft_item_normal_count = {}

    -- print(l_recipe_id)

    for sub_craft_row in db:nrows(
        "SELECT * FROM MasterCompTable WHERE RecipeID=" ..
        l_recipe_id) do
        craft_item_normal_count[nsc] = sub_craft_row.ItemID
        nsc = nsc + 1
    end
    -- Split Counts greater than 1

    for sub_craft_row in db:nrows(
        "SELECT * FROM MasterCompTable WHERE RecipeID=" ..
        l_recipe_id) do
        if (sub_craft_row.ItemCount > 1) then
            for y = 1, sub_craft_row.ItemCount do
                craft_item_split_count[scc] = sub_craft_row.ItemID
                scc = scc + 1
            end
        end
        if (sub_craft_row.ItemCount == 1) then
            craft_item_split_count[scc] = sub_craft_row.ItemID
            scc = scc + 1
        end
    end

    -- fix
    -- if it is portable get the size and go off of that
    if #craft_item_split_count > 9 then
        print(msg,
            "\ayError: \awWay too many items to put in the container \atTCN_Craft ID: ",
            p_id)
        mq.cmd('/cleanup')
        os.exit()
    end

    -- for c = 1,#craft_item_split_count do
    --          local rrn = library.return_item_name(craft_item_split_count[c])
    --   print(rrn," ",craft_item_split_count[c]) end

    return craft_item_split_count, craft_item_normal_count
end

-- tradeskill data

function library.return_recipe_skill(p_id)
    local m = nil
    for list_row in db:nrows(
        "SELECT * FROM MasterRecipeTable where RecipeID=" ..
        p_id) do m = list_row.Skill end
    return m
end

function library.return_recipe_skill_level(p_id)
    local m
    for list_row in db:nrows(
        "SELECT * FROM MasterRecipeTable where RecipeID=" ..
        p_id) do m = list_row.ReqSkill end

    if m == nil then m = 0 end

    if tonumber(m) == nil then
        print "there is a problem with the skill field TCN LIB"
        os.exit()
    end

    return tonumber(m)
end

function library.return_container_skill(p_id)
    local m
    for craft_row in db:nrows(
        "SELECT * FROM MasterRecipeTable WHERE RecipeID=" ..
        p_id) do m = craft_row.Skill end
    return m
end

function library.return_recipe_trivial(p_id)
    local m
    for list_row in db:nrows(
        "SELECT * FROM MasterRecipeTable where RecipeID=" ..
        p_id) do m = list_row.Trivial end
    return m
end

function library.return_item_recipe_id(p_id)
    local m
    for list_row in db:nrows(
        "SELECT * FROM MasterRecipeTable where RecipeID=" ..
        p_id) do m = list_row.ItemID end
    return m
end

-- fix
-- testing this is in use! is it better to use ItemID
function library.Return_Calling_Recipe_Row_Count(p_id, s_id)
    local calling_count
    for list_rows in db:nrows("SELECT * FROM MasterCompTable where RecipeID=" ..
        p_id .. " AND SubRecipeID=" .. s_id ..
        " LIMIT 1") do
        calling_count = list_rows.ItemCount
        if calling_count == nil then
            print "TCN Lib GCR NIL ItemCount Error"
            mq.exit()
        end
    end
    return calling_count
end

-- testing

-- Return ItemCount for row matching primary and sub-recipe ID
function library.return_item_count(p_id, p_id1)
    local count_needed
    for list_rows in db:nrows("SELECT * FROM MasterCompTable where RecipeID=" ..
        p_id .. " AND SubRecipeID=" .. p_id1 ..
        " LIMIT 1") do
        count_needed = list_rows.ItemCount
        if count_needed == nil then
            print "TCN Lib GCR NIL ItemCount Error"
        end
    end
    return count_needed
end

-- Return ItemCount for component based on Primary Recipe ID and ItemID
function library.return_item_count_id(p_id, p_item_id)
    --  print("lib.return_item_count_id ",p_id, " ", p_item_id)

    local count_needed
    for list_rows in db:nrows("SELECT * FROM MasterCompTable where RecipeID=" ..
        p_id .. " AND ItemID=" .. p_item_id ..
        " LIMIT 1") do
        count_needed = list_rows.ItemCount
        if count_needed == nil then
            print "TCN Lib GCR NIL ItemCount Error"
        end
    end
    return count_needed
end

-- fix for graceful
function library.Return_Calling_Recipe_Row_Count_Multi(s_id)
    -- function library.Return_Calling_Recipe_Row_Count_Multi(p_id, s_id)
    local calling_count
    for list_rows in db:nrows(
        "SELECT * FROM MasterMultiTable where RecipeID=" ..
        s_id) do
        --   for list_rows in db:nrows(
        --      "SELECT * FROM MasterMultiTable where MultiRecID=" ..
        --         p_id .. " AND RecipeID=" .. s_id .. " LIMIT 1") do

        calling_count = list_rows.MCount
        if calling_count == nil then
            print "TCN Library GCR Multi NIL Error"
            mq.exit()
        end
    end
    return calling_count
end

-- print--data

local function highlight_recipe_requirements(p_skill, p_recipe_id,
                                             p_recipe_name, p_yield, p_trivial)
    if p_skill == "Make Poison" then
        --  p_recipe_name = "\ay" .. p_recipe_name
        p_skill = "\ay" .. p_skill
    end
    if p_skill == "Alchemy" then
        --   p_recipe_name = "\ao" .. p_recipe_name
        p_skill = "\ao" .. p_skill
    end
    if p_skill == "Tinkering" then
        --  p_recipe_name = "\at" .. p_recipe_name
        p_skill = "\at" .. p_skill
    end

    if tonumber(mq.TLO.Me.Skill(p_skill)()) ~= nil and tonumber(p_trivial) ~=
        nil then
        if tonumber(mq.TLO.Me.Skill(p_skill)()) >= p_trivial then
            p_trivial = "\ag" .. p_trivial
        end
    end

    print("\awID: [", p_recipe_id, "]\ag ", p_recipe_name, " \aw(", p_skill,
        ") \agYield \ap(\ag", p_yield, "\ap) \awTrivial: \ap(\aw", p_trivial,
        "\ap)")
    return
end

function library.search_by_name(p_string)
    local m_array = {}
    local ct = 1
    for make_row in db:nrows(
        "SELECT * FROM MasterRecipeTable where RecipeID > 0 and Upper(RecipeName) LIKE " ..
        p_string) do
        -- highlights..
        print(msg, ct, " - \awID: [", make_row.RecipeID, "]\ag ",
            make_row.RecipeName)

        m_array[ct] = make_row.RecipeID
        ct = ct + 1
        -- REMD 4/2/2022
        -- mq.delay(1)
        if ct > 20 then break end
    end
    return m_array, ct
end

-- search recipes sql
function library.search_recipes(parg)
    for make_row in db:nrows(
        "SELECT * FROM MasterRecipeTable where RecipeID !=0 and RecipeID < 90000000 and Upper(RecipeName) LIKE " ..
        parg) do
        highlight_recipe_requirements(make_row.Skill, make_row.RecipeID,
            make_row.RecipeName, make_row.Yield,
            make_row.Trivial)
        -- put a pause continue option? limiter
        -- REMD 4/2/2022
        -- mq.delay(1)
    end

    -- add enchanter legend.. how? -- recipe db or itemid -1?

    print(msg, "Legend")
    print(msg, "\aoOrange \aw= Shaman Class Requirement")
    print(msg, "\ayYellow \aw= Rogue Class Requirement")
    print(msg, "\atTeal \aw= Gnome Race Requirement")

    print(msg, "\agSearch returned: \aw[", library.return_row_count(parg),
        "] recipes")
    return
end

function library.return_database_count()
    -- Change to allow for specfic table or criteria
    local m
    for list_row in db:urows(
        "SELECT count(*)  FROM MasterRecipeTable WHERE RecipeID !=0 and RecipeID < 90000000") do
        local rows_count = list_row
        if (rows_count < 1) then
            m = 0
        else
            m = rows_count
        end
    end
    return m
end

function library.return_id_row_count(p_id)
    local m
    for list_row in db:urows(
        "SELECT count(*)  FROM MasterRecipeTable where RecipeID= " ..
        p_id) do
        m = list_row
        if (m < 1) then m = 0 end
    end
    return m
end

-- testing???
function library.return_recipe_total_buy_count(rr_id, rr_id1, p_pnc)
    local hc = mq.TLO.FindItemCount(rr_id)()
    -- local yc = Return_Recipe_Yield(rr_id)
    local nc = p_pnc - hc
    -- local pbc = math.ceil(nc / yc)
    local pbc = math.ceil(nc / 1)
    local cr = library.Get_Calling_Recipe_Row_Count(rr_id, rr_id1)
    -- REMD 4/2/2022
    -- mq.delay(1)
    if cr == nil then
        print "\arNil Error TCN_LIB"
        mq.exit()
    end
    nc = pbc * cr
    -- yc = Return_Recipe_Yield(rr_id1)
    -- local tv_bc = math.ceil(nc / yc)
    local tv_bc = math.ceil(nc / 1)
    if tv_bc < 0 then tv_bc = 0 end
    return tv_bc
end

-- oprhans
-- oprhans
-- oprhans

local function get_need_count(p_main, p_sub, p_want)
    -- || MID Recipe Calcs ||

    -- Get Calling Row Count
    local fv_calling = library.Return_Calling_Recipe_Row_Count(p_main, p_sub)
    -- Get Primary Item ID
    local fv_mid = library.return_item_ID(p_main)
    -- Get Primary Inventory
    local fv_inv = mq.TLO.FindItemCount(fv_mid)()

    -- Calculate Need??????
    local l_need = fv_calling * p_want - fv_inv

    -- Get Yield Primary
    local fv_yield = library.return_recipe_yield(p_main)

    -- get set amount
    local fv_sa = 0
    -- library.set_amount(l_need, fv_yield)

    -- SID Calcs

    -- |Return Yield Of Sub Recipe
    local fv_yield = library.return_recipe_yield(p_sub)
    -- Get Item ID
    local fv_sid = library.return_item_ID(p_sub)
    -- Get Primary Inventory
    local fv_inv = mq.TLO.FindItemCount(fv_sid)()

    local s_need = l_need - fv_inv

    local fv_na = 0
    -- library.set_amount(s_need, fv_yield)

    return fv_na
end

local function display_vendor_item(p_id)
    for list_row in db:nrows("SELECT * FROM VendorTable where ItemID=" .. p_id) do
        -- print("\ag[] Item ID:\ag[",list_row1.SubRecipeID,"] [",list_row1.VendorItemName, "] \ao[On Vendor:]\aw[",list_row1.VendorName,"]")
    end
end

-- checks single item needs to check the whole shebang..
local function vendor_item_check(p_id)
    -- if rows == 0 then item is not on vendor
    for list_row in db:urows("SELECT count(*) FROM VendorTable where ItemID=" ..
        p_id) do
        local rows_count = list_row
        if (rows_count < 1) then
            -- uncrutch
            -- local tv_tn = get_item_name(p_id)
            -- crutch
            local tv_tn

            print("\ag[x] Item ID: \ar[", p_id, "] \ag", tv_tn,
                " \ao[No Vendor", "/", "Not In Inventory]")
        else
            display_vendor_item(p_id)
        end
    end
end

function library.return_item_source(p_item_id)
    local i_zone = nil
    local i_action = nil

    for r in db:nrows("SELECT * FROM FarmTable where ItemID=" .. p_item_id) do
        i_action = r.ItemAction
        i_zone = r.ItemZone
    end

    if i_action == nil then i_action = "Unknown" end
    if i_zone == nil then i_zone = "Unknown" end

    if string.find(i_zone, ",") then i_zone = i_zone:gsub(',', '@') end

    --   print("lib return item source ",i_action, " " ,i_zone) os.exit()
    return i_action, i_zone
end

function library.return_vendor_zone_id(p_item_id)
    --  p_name = '"' .. p_name .. '"'
    local m = nil
    local n = nil

    -- print(msg, p_item_id)

    -- Return appropriate SQL string based on ERA
    local sql_string = library.get_vendor(p_item_id)

    for row in db:nrows(sql_string) do
        -- if row.VendorZoneID == nil or row.VendorName == nil then
        m = row.VendorZoneID
        n = row.VendorName
    end
    return m, n
end

-- Return Vendor Name from SQL
-- when we add other vendors and zones need to add zone id
function library.return_vendor_location(p_name)
    p_name = '"' .. p_name .. '"'
    local m = nil

    local sql_string = "SELECT * FROM VendorTable where VendorName=" .. p_name

    -- Rof Vendors
    if mq.TLO.MacroQuest.Server() == "arizlona" or mq.TLO.MacroQuest.Server() ==
        "amischief" or mq.TLO.MacroQuest.Server() == "yelinak" then
        sql_string = "SELECT * FROM ZVendorTable where VendorName=" .. p_name
    end

    -- Old Vendors
    if mq.TLO.MacroQuest.Server() == "oakwynd" or mq.TLO.MacroQuest.Server() ==
        "athornblade" or mq.TLO.MacroQuest.Server() == "ayelinak" then
        sql_string = "SELECT * FROM RVendorTable where VendorName=" .. p_name
    end

    for row in db:nrows(sql_string) do m = row.VendorZoneID end
    return m
end

function library.return_vendor_name(p_id)
    -- REMD 4/2/2022
    -- mq.delay(1)
    local m = nil
    local n = nil

    -- Return appropriate SQL string based on ERA
    local sql_string = library.get_vendor(p_id)

    for row in db:nrows(sql_string) do
        m = row.VendorName
        n = row.VendorPrice
    end
    return m, n
end

function library.vendor_distance(p_id)
    if mq.TLO.Me.Moving() or mq.TLO.Nav.Active() then
        mq.cmd('/squelch /nav stop')
    end

    while mq.TLO.Me.Moving() or mq.TLO.Nav.Active() do
        GLOBAL_TEXT =
        "Please, stop moving, so we can calculate vendor distances"
        mq.delay(1)
    end

    -- REMD 4/2/2022
    -- mq.delay(1)
    local m = {}
    local counter = 0
    local current_zone_id = mq.TLO.Zone.ID()

    -- Return appropriate SQL string based on ERA
    local sql_string = library.get_vendor(p_id)

    for row in db:nrows(sql_string) do
        table.insert(m, row.VendorName)
        --         print (row.VendorName, " ",row.VendorItemName," ",row.ItemID)
        -- REMD 4/2/2022
        -- mq.delay(1)
    end

    -- if mq.TLO.Zone.ID() ~= m_location_id then print (msg,"Vendor \ap[\aw", m[0], "\ap]\aw is in another zone ", m_location_name)  os.exit() end

    local distance_table = {}

    local npc_distance
    for x = 1, #m do
        npc_distance = mq.TLO.Spawn(m[x]).Distance()
        -- print ("\ay",npc_distance, " ",m[x])
        table.insert(distance_table, npc_distance)
        -- REMD 4/2/2022
        -- mq.delay(1)
    end

    -- table.sort(distance_table, function(a,b) return tonumber(a) < tonumber(b) end)
    table.sort(distance_table)

    for z = 1, #distance_table do
        --   print ("\ag",distance_table[z])
    end

    local closest_vendor = distance_table[1]

    local vendor_to_return = nil
    for x = 1, #m do
        npc_distance = mq.TLO.Spawn(m[x]).Distance()
        if npc_distance == closest_vendor then
            vendor_to_return = m[x]
            -- print(msg, "\ap[\awClosest Vendor:\ap] \ap[]\aw", m[x], "\ap] ",npc_distance," ")
            break
        end
    end

    distance_table = nil

    -- need to not be moving.. if mq.tlo>nav active then pause -- check above code

    if vendor_to_return == nil or vendor_to_return == 0 then
        print(msg, "Vendor Selection Error Based On Distance LIB ID:", p_id)
        --    mq.cmd('/lua pause')
        os.exit()
    end

    -- os.exit()
    return vendor_to_return
end

function library.return_vendor_name_distance(p_id)
    if mq.TLO.Me.Moving() or mq.TLO.Nav.Active() then
        mq.cmd('/squelch /nav stop')
    end

    while mq.TLO.Me.Moving() or mq.TLO.Nav.Active() do
        GLOBAL_TEXT =
        "Please, stop moving, so we can calculate vendor distances"
        mq.delay(1)
    end

    -- REMD 4/2/2022
    -- mq.delay(1)
    local m = {}
    local n = {}
    local m_location_id = nil
    local m_location_name = nil
    local counter = 0
    local current_zone_id = mq.TLO.Zone.ID()

    -- Return appropriate SQL string based on ERA
    local sql_string = library.get_vendor(p_id)

    for row in db:nrows(sql_string) do
        -- m[counter] = row.VendorName
        table.insert(m, row.VendorName)
        n = row.VendorPrice
        m_location_id = row.VendorZoneID
        m_location_name = row.VendorZone
        --         print (row.VendorName, " ",row.VendorItemName," ",row.ItemID)
        -- counter = counter + 1
        -- REMD 4/2/2022
        -- mq.delay(1)
    end

    -- so we need to know what zone this guy is in..

    -- if mq.TLO.Zone.ID() ~= m_location_id then print (msg,"Vendor \ap[\aw", m[0], "\ap]\aw is in another zone ", m_location_name)  os.exit() end
    -- now we need to sort vendors based on zone and distance
    -- poiosned salslah, and whatever the heck thurgadin guy
    -- make sure they only have items that no one else has

    local distance_table = {}

    local npc_distance
    for x = 1, #m do
        npc_distance = mq.TLO.Spawn(m[x]).Distance()
        -- print ("\ay",npc_distance, " ",m[x])
        table.insert(distance_table, npc_distance)
        -- REMD 4/2/2022
        -- mq.delay(1)
    end

    -- table.sort(distance_table, function(a,b) return tonumber(a) < tonumber(b) end)
    table.sort(distance_table)

    for z = 1, #distance_table do
        --   print ("\ag",distance_table[z])
    end

    local closest_vendor = distance_table[1]

    local vendor_to_return = nil
    for x = 1, #m do
        npc_distance = mq.TLO.Spawn(m[x]).Distance()
        if npc_distance == closest_vendor then
            vendor_to_return = m[x]
            -- print(msg, "\ap[\awClosest Vendor:\ap] \ap[]\aw", m[x], "\ap] ",npc_distance," ")
            break
        end
    end

    distance_table = nil

    -- need to not be moving.. if mq.tlo>nav active then pause -- check above code

    if vendor_to_return == nil or vendor_to_return == 0 then
        print(msg, "Vendor Selection Error Based On Distance LIB ID:", p_id)
        --    mq.cmd('/lua pause')
        os.exit()
    end

    -- os.exit()
    return vendor_to_return, n
end

-- End Vendor Name

-- returns calling count # for item.. dup I suppose
function library.return_item_row_count(p_id, p_item_id)
    local m
    for list_row in db:nrows(
        "SELECT * FROM MasterCompTable where RecipeID = " ..
        p_id .. " AND ItemID = " .. p_item_id) do
        m = list_row.ItemCount
    end
    return m
end

----return row count for MRT search
-- fix
function library.return_row_count(p_id)
    for list_row in db:urows(
        "SELECT count (*)  FROM MasterRecipeTable where RecipeID !=0 and RecipeID < 90000000 and Upper(RecipeName) LIKE " ..
        p_id) do
        -- change to breaks fix or limit 1 return
        local rows_count = list_row
        if (rows_count < 1) then return 0 end
        return rows_count
    end
end

function library.return_associated_tool(p_id)
    local t_var
    for r in db:nrows(
        "SELECT * FROM MasterCompTable WHERE RecipeID !=0 and RecipeID =" ..
        p_id .. " ORDER BY RecipeID ASC") do
        if string.find(r.ItemName, 'Cut Tool') then
            t_var = r.ItemID
            break
        end
    end
    return t_var
end

-- Returns item id from recipe id
function library.return_recipe_item_id(p_id)
    local m
    for r in
    db:nrows("SELECT * FROM MasterRecipeTable where RecipeID= " .. p_id) do
        m = r.ItemID
    end

    if m == nil then
        print "No Item ID associated with RecipeID"
        m = 0
    end
    return m
end

function library.return_recipe_id(p_id, m_id)
    local m
    for make_row in db:nrows(
        "SELECT * FROM MasterRecipeTable where RecipeID = " ..
        p_id .. " AND ItemID = " .. m_id) do
        m = make_row.RecipeID
    end
    return m
end

function library.is_recipe(m_id)
    local m
    for make_row in db:nrows(
        "SELECT * FROM MasterRecipeTable where ItemID = " ..
        m_id) do m = make_row.RecipeID end
    return m
end

-- Return the row count for a recipe
function library.return_row_recipe_count(p_id)
    for list_row in db:urows(
        "SELECT count(*) FROM MasterCompTable where RecipeID=" ..
        p_id) do
        local rows_count = list_row
        if (rows_count < 1) then return 0 end
        return 1
    end
end

-- Return recipe name, item id, and inventory count
local function Return_Recipe_Information(p_id)
    for recipe_row in db:nrows(
        "SELECT * FROM MasterRecipeTable where RecipeID=" ..
        p_id) do
        -- limit 1 for dups will return 1st one it sees
        local hc = mq.TLO.FindItemCount(recipe_row.SubRecipeID)()
        return recipe_row.SubRecipeID, recipe_row.RecipeName, hc
    end
end

-- Math Functions

local function subtract(v1, v2)
    local sum
    if v1 > v2 then
        sum = v1 - v2
        return sum
    end
    if v2 > v1 then
        sum = v2 - v1
        return sum
    end
    if v1 == v2 then
        sum = 0
        return sum
    end
end

----

-- Data Functions:

-- 350 recipe stuff

function library.print_reason(p_array, p_id)
    --  local test = 1 if test == 1 then return end

    for x = 1, #p_array do
        -- Services Required
        local g = library.return_number(p_array[x], 6)

        -- Component ID
        local a = library.return_number(p_array[x], 1)

        -- Component Name
        local b = library.return_string(p_array[x], 2)

        -- Recipe ID
        local c = library.return_number(p_array[x], 3)

        local l_recipe_name = library.return_recipe_name(c)

        if g == 1 then
            print(msg,
                "\ap[\atEnchanter Services: \aoRequired\ap]  \ap[\ao" .. b ..
                "\ap] \atItem ID: \ap(\ag" .. a .. "\ap)")
        end

        -- print what is soiled and why recipes are soiled becuase of skill class race, special item? container

        local g_string

        if g == 4 then
            g_string = "\ap[\awShaman Services: \aoRequired\ap] \ap[\ao" ..
                l_recipe_name .. "\ap] \atRecipe ID: \ap(\ag" .. c ..
                "\ap)"
        end
        if g == 5 then
            g_string = "\ap[\awRogue Services: \aoRequired\ap] \ap[\ao" ..
                l_recipe_name .. "\ap] \atRecipe ID: \ap(\ag" .. c ..
                "\ap)"
        end
        if g == 6 then
            g_string = "\ap[\awGnome Power \aoRequired\ap] \ap[\ao" ..
                l_recipe_name .. "\ap] \atRecipe ID: \ap(\ag" .. c ..
                "\ap)"
        end
        if g == 7 then
            local i = library.return_number(p_array[x], 7)
            g_string =
                "\ap[\awSkill Power \aoRequired\ap] \atSkill Needed: \ap(\ag" ..
                i .. "\ap)"
        end
        if g == 8 then
            g_string =
            "\ap[\awVendor doesn't like you very much, I don't like you either\ap]"
        end
        if g > 1 then print(msg, g_string) end
    end
    return
end

function library.print_missing_items(p_array, p_id)
    -- local test = 1 if test == 1 then return end

    for x = 1, #p_array do
        --    print(msg, "\ay", p_array[x]) -- end

        -- Component ID
        local a = library.return_number(p_array[x], 1)

        -- Component-Inventory..? --squash and counts overall
        local l_inv = mq.TLO.FindItemCount(a)()

        -- Component Name
        local b = library.return_string(p_array[x], 2)

        -- Recipe ID
        local c = library.return_number(p_array[x], 3)

        -- Multi-Component
        local d = library.return_number(p_array[x], 4)

        -- Need Count
        local f = library.return_number(p_array[x], 5)

        -- Services Required
        local g = library.return_number(p_array[x], 6)

        -- Sub-Recipe ID -- should only be a Recipe ID or 0
        local h = library.return_number(p_array[x], 7)

        if g == 1 then
            print(msg, "\ap[\atEnchanter Services: \aoRequired\ap]")
        end

        -- print what is soiled and why recipes are soiled becuase of skill class race, special item? container

        local g_string

        if g == 4 then
            g_string = "\ap[\awShaman services are required\ap]"
        end
        if g == 5 then
            g_string = "\ap[\awRogue services are required\ap]"
        end
        if g == 6 then g_string = "\ap[\awGnome power required\ap]" end
        if g == 7 then
            local i = library.return_number(p_array[x], 8)

            g_string = "\ap[\awSkill power required\ap]" .. i
        end
        if g == 8 then g_string = "\ap[\awVendor don't like you\ap]" end

        -- more conditions
        local e = library.return_recipe_name(c)

        --    print(msg,"\agID: \aw", c," \agRecipe: \aw",e)
        if g > 0 then
            print(msg, "\ap[\aoRecipe:\ap] \ap[\ag", b, "\ap] ", g_string)
        else
            if g < 1 then
                local l_vendor_check = library.vendor_has_item(a)
                -- print(l_vendor_check, " ", a)
                -- multi vendors

                -- poisoner salihah has  limestone 16844 8g3s9c
                -- craft in abysmal nah?

                -- need to start adding vendor check by zone

                -- if l_vendor_check == 0 then

                local calc = f - l_inv
                if calc < 0 then calc = 0 end
                if calc ~= 0 then
                    print(msg, "\ap[\atComponent:\ap] \ap[\ag", b,
                        "\ap] \ap[\awNeed:\ap] \ap(\ag", calc, "\ap)")
                end
                --  end
            end
        end
    end
end

function library.generate_recipes(p_skill)
    local l_name = mq.TLO.Me.Name()
    local l_server = mq.TLO.MacroQuest.Server()

    local recipe_skill = p_skill

    local recipe_skill_dump_name = recipe_skill

    if recipe_skill == "Jewelry Making" then
        recipe_skill_dump_name = "jewelcrafting"
    end

    if recipe_skill == "Make Poison" then
        recipe_skill_dump_name = "poisonmaking"
    end

    local name = mq.TLO.Me.Name()
    local a_string = name .. "_" .. mq.TLO.MacroQuest.Server() .. "_" ..
        recipe_skill .. ".txt"

    local unknown_array = {}
    local known_array = {}

    local null_array = {}

    if recipe_skill == "Tinkering" and mq.TLO.Me.Race() ~= "Gnome" then
        --   print(msg, "Gnome Power is required to do this")
        print(msg, "You are not a \agGnome, \awBegone!")
        return null_array, null_array, null_array
    end
    if recipe_skill == "Alchemy" and mq.TLO.Me.Class() ~= "Shaman" then
        --    print(msg, "Shaman Power is required to do this")
        print(msg, "You are not a \agShaman, \awBegone!")
        return null_array, null_array, null_array
    end
    if recipe_skill == "Make Poison" and mq.TLO.Me.Class() ~= "Rogue" then
        --   print(msg, "Rogue Power is required to do this")
        print(msg, "You are not a \agRogue, \awBegone!")
        return null_array, null_array, null_array
    end

    print(msg, "Loading Recipes")

    -- print(recipe_skill) os.exit()

    mq.cmd('/outputfile recipes ', recipe_skill_dump_name, " ",
        '"' .. a_string .. '"')

    -- mq.delay(2000)
    -- print "delay done"

    -- mq.cmd('/doevents flush')

    -- Wait for server to be done
    while GL_SWITCH == 0 do
        mq.doevents()
        mq.delay(1)
    end

    local start_time = os.time()

    -- Use this to generate a table to write for 350 max
    -- local table_array = library.return_max_recipe_array_table(recipe_skill)

    local t_file = 'd_' .. l_name .. "_" .. l_server .. "_" .. recipe_skill
    local m_file = 'm_' .. recipe_skill
    local f_file = 'f_' .. l_name .. '_' .. l_server

    local d_path_string = mq.luaDir .. '\\TCN\\Working\\'

    local source_d_file = d_path_string .. t_file .. '.txt'
    local source_m_file = d_path_string .. m_file .. '.txt'
    local dest_m_file = d_path_string .. f_file .. '.txt'

    -- Set count to 0 for recipe skill, not an array!
    local master_finish_array = 0

    -- Pre-ToL counts
    if recipe_skill == "Tailoring" then master_finish_array = 2292 end
    if recipe_skill == "Blacksmithing" then master_finish_array = 2195 end
    if recipe_skill == "Baking" then master_finish_array = 762 end
    if recipe_skill == "Fishing" then master_finish_array = 150 end
    if recipe_skill == "Pottery" then master_finish_array = 2173 end
    if recipe_skill == "Brewing" then master_finish_array = 345 end
    if recipe_skill == "Fletching" then master_finish_array = 995 end
    if recipe_skill == "Jewelry Making" then master_finish_array = 1448 end
    if recipe_skill == "Research" then master_finish_array = 4073 end
    if recipe_skill == "Tinkering" then master_finish_array = 854 end
    if recipe_skill == "Alchemy" then master_finish_array = 609 end
    if recipe_skill == "Make Poison" then master_finish_array = 646 end

    -- master finish array is just the total amount of recipes

    source_m_file = '"' .. source_m_file .. '"'
    source_d_file = '"' .. source_d_file .. '"'
    dest_m_file = '"' .. dest_m_file .. '"'

    -- Don't know any recipes or wrong class
    if GL_SWITCH == 2 then
        print(msg, "\ayYou don't know any \ap(\ag" .. recipe_skill ..
            "\ap) \ayrecipes, it is \awhighly advisable \ayto")

        print(msg, "\aydo the TSS or GOD freebies and have a base")

        print(msg, "\ayskill of 300 or a skill of 200 for fishing")

        print(msg,
            "\ayContinuing may result in waste of materials and platinum for no sane reason.")

        -- Read the master artisan text file
        local source_zero_file = d_path_string .. m_file .. '.txt'
        local zerorecipes = library.readfile_artisan(source_zero_file)

        GL_SWITCH = 0
        GLOBAL_MAX_KNOWN = 0
        GLOBAL_MAX_HOWMANY = master_finish_array
        GLOBAL_MAX_PCT = 0

        -- test 1 recipe if none are known
        --  local zerorecipes = {}
        --  table.insert(zerorecipes,35139)
        --  GLOBAL_MAX_HOWMANY = 1

        return zerorecipes, null_array, null_array
    end

    GL_SWITCH = 0

    local del_string = a_string

    a_string = '"' .. a_string .. '"'

    -- copy recipe dump file from EQ Directory based on skill
    -- local command = 'copy ' .. a_string .. " " .. mq.luaDir ..
    --    '\\TCN\\Working'

    -- local command = 'copy ' .. a_string .. " " .. 'D:\\MQNext - test\\Lua\\TCN\\Working'

    local path_string = mq.luaDir .. "\\TCN\\Working"

    path_string = '"' .. path_string .. '"'

    local command = 'copy ' .. a_string .. " " .. path_string

    os.execute(command)

    mq.delay(1000)

    -- Better to check for file existence? instead of arbitrary delay?

    local p_file = l_name .. "_" .. l_server .. "_" .. recipe_skill .. ".txt"

    -- Output file dump
    local dump_array = library.return_max_recipe_array_dump(p_file)

    -- Write dump file with ID's only
    for x = 1, #dump_array do
        -- print(msg,dump_array[x])
        library.writetextfile(t_file, dump_array[x])
    end

    -- print("Known: ",#dump_array)

    -- Use to refresh master table for Artisan
    -- for y = 1, #table_array do library.writetextfile(m_file, table_array[y]) end
    -- os.exit()

    -- Remove duplicates
    command =
        'findstr /vixg:' .. source_d_file .. ' ' .. source_m_file .. ' > ' ..
        dest_m_file

    -- print(command)

    os.execute(command)

    dest_m_file = dest_m_file:gsub('"', '')

    -- Read the final artisan text file
    local finish_array = library.readfile_artisan(dest_m_file)

    -- print(dest_m_file," ",#finish_array)
    -- os.exit()

    -- Replace " with space
    source_d_file = source_d_file:gsub('"', '')

    -- These are unknown
    --- for c = 1 ,#finish_array do print(finish_array[c])end
    --- print  (#finish_array)

    -- SIM
    -- Ignore what we have learned
    -- finish_array = table_array --fix this up

    -- do lookups
    -- dump_array
    --  finish_array

    -- Inefficient, looks up recipe names by ID and slows the process down

    -- Global Switch to perform Artisan Info
    if GLOBAL_INFO_MAX == 1 then
        -- Create Known Array
        for c = 1, #dump_array do
            local lookup_recipe_name = library.return_recipe_name(dump_array[c])
            local item = { ID = dump_array[c], Name = lookup_recipe_name }

            -- Account for NOS/LSO/TOB known recipes.
            if item.Name ~= nil then table.insert(known_array, item) end

            --  print(known_array[c].RecipeID, " ", known_array[c].RecipeName)
        end

        -- Create Unknown Array

        -- Faster way by just getting all the names at once..?

        for c = 1, #finish_array do
            local lookup_recipe_name = library.return_recipe_name(
                finish_array[c])
            local item = { ID = finish_array[c], Name = lookup_recipe_name }
            table.insert(unknown_array, item)
            -- print(unknown_array[c].RecipeID, " ", unknown_array[c].RecipeName)
        end
    end

    local calc = #dump_array / #finish_array + #dump_array

    local pct = round(calc * 100, 1)

    -- 49 2255 2206

    GLOBAL_MAX_KNOWN = #dump_array -- + 1
    GLOBAL_MAX_HOWMANY = #finish_array + #dump_array
    GLOBAL_MAX_PCT = pct

    -- clean up EQ DIR
    -- command = "del " .. string
    -- assert(io.popen(command))

    local res = os.remove(del_string)
    -- if res ~= nil then print "deleted" end

    -- clean up working TCN directory
    -- command = "del " .. mq.luaDir .. "\\TCN\\Working\\" ..
    --              string
    -- assert(io.popen(command))

    res = os.remove(mq.luaDir .. "\\TCN\\Working\\" .. del_string)
    -- if res ~= nil then print "deleted" end
    mq.delay(1)

    -- total amount of recipe left to know
    -- print (#finish_array)

    -- print(source_d_file)
    os.remove(source_d_file)
    mq.delay(1)

    -- print(dest_m_file)
    os.remove(dest_m_file)
    mq.delay(1)

    local end_time = os.time()

    print(msg, "\ap[\aoArtisan Recipe Load Time: \ap] \ap(\ag",
        end_time - start_time, "\ap) \aoseconds")

    mq.delay(1)

    -- SIM
    -- test a recipe
    -- finish_array = {}
    -- table.insert(finish_array, 35139)

    return finish_array, unknown_array, known_array
end

-- Return skip flag for Artisan Prize Crafting
function library.return_max_skip_flag(p_id)
    local result = nil

    for r in
    dbp:nrows("SELECT * FROM Max_Trophy_Table WHERE RecipeID =" .. p_id) do
        result = r.RecipeSkip
    end
    return result
end

-- Used table from Artisan.DB to determine to skip
function library.old_return_max_skip_flag(p_id)
    local result = nil
    for r in db:nrows("SELECT * FROM Max_Trophy_Table WHERE RecipeID =" .. p_id) do
        result = r.RecipeSkip
    end
    return result
end

function library.read_no_destroy()
    local d_file = "NoArtisan_Destroy.csv"
    local data_array = {}
    local path = mq.luaDir .. "\\TCN\\Settings"
    local p_data = path .. "\\" .. d_file
    -- print(p_data)
    for line in io.lines(p_data) do table.insert(data_array, line) end
    return data_array
end

function library.read_no_depot()
    local d_file = "Depot_Ignore.csv"
    local data_array = {}
    local path = mq.luaDir .. "\\TCN\\Settings"
    local p_data = path .. "\\" .. d_file
    -- print(p_data)
    for line in io.lines(p_data) do
        local convert_line = tonumber(line)
        --  print(convert_line)
        table.insert(data_array, convert_line)
    end
    -- os.exit()
    return data_array
end

function library.read_global_destroy()
    local d_file = "Global_Destroy.csv"
    local data_array = {}
    local path = mq.luaDir .. "\\TCN\\Settings"
    local p_data = path .. "\\" .. d_file
    -- print(p_data)
    for line in io.lines(p_data) do table.insert(data_array, line) end
    return data_array
end

-- Return data matching skill from max 350 table
function library.return_max_recipe_array_table(p_skill)
    local m = {}

    p_skill = '"' .. p_skill .. '"'

    for r in db:nrows( --  "SELECT * FROM TestTable WHERE RecipeSkill LIKE " ..
        "SELECT * FROM Max_Trophy_Table WHERE RecipeSkill LIKE " .. p_skill ..
        " ORDER BY RecipeID ASC") do
        if r.RecipeID == nil then
            print("nil, exiting lib return_max_recipe_array_table ", p_skill)
            os.exit()
        end

        r.RecipeID = tonumber(r.RecipeID)

        if r.RecipeID == nil then
            print(
                "tonumber failed , exiting lib return_max_recipe_array_table ",
                p_skill)
            os.exit()
        end

        local l_single_recipe_information =
            library.load_recipe_table(r.RecipeID)

        local skill_level_required = l_single_recipe_information[1]
            .SkillRequired

        if skill_level_required == nil then skill_level_required = 0 end

        -- print("skill required: ", skill_level_required)
        -- if skill_level_required > 0 then os.exit() end

        -- Should we omit these from the max generated list?
        if skill_level_required >
            mq.TLO.Me.Skill(l_single_recipe_information[1].Skill)() then
            --  print(r.RecipeName, " ", r.RecipeID,
            --       " Needs more skill than we got ")
        end

        -- Strip bugged recipes from the list
        if l_single_recipe_information[1].RecipeBugged == 0 then
            table.insert(m, r.RecipeID)
        end
    end
    return m
end

function library.deletefile(p_file)
    local path = mq.luaDir .. "\\TCN\\Working"
    local p_data = path .. "\\" .. p_file
    local answer = library.file_exists(p_data)
    if not answer then return end
    os.remove(p_data)
end

function library.file_exists(name)
    local f = io.open(name, "r")
    return f ~= nil and io.close(f)
end

-- Read Artisan File (number)
function library.readfile_artisan(p_file)
    local array = {}

    local path = mq.luaDir .. "\\TCN\\Working"
    -- local p_data = path .. "\\" .. p_file
    local p_data = p_file
    -- print(p_data)
    local answer = library.file_exists(p_data)

    if not answer then return array end

    for line in io.lines(p_data) do
        --  line = line:gsub('([A-z]+).*', "")
        line = tonumber(line)

        local skip_recipe_flag = library.return_max_skip_flag(line)

        local l_race_check = library.return_recipe_race(line)

        -- Checks for quested container
        local con_result = library.check_container_requirement(line)

        -- local rrna = library.return_recipe_name(line)
        -- print(msg, "Adding Recipe: " .. rrna .. " ID: " .. line)

        if con_result ~= nil then
            local rrn = library.return_recipe_name(line)
            --  print(msg, "\atNot adding Recipe: ", rrn, " \apID: ", line,
            --  " \ag it requires ", con_result, " ")
            GLOBAL_TEXT = "Not adding Recipe: " .. rrn .. " ID: " .. line ..
                " it requires [" .. con_result .. "]"
            print(msg,
                "Not adding Recipe: " .. rrn .. " ID: " .. line ..
                " it requires [" .. con_result .. "]")
            -- mq.delay(1)
        end

        local ignore_special_jewelcraft = 0

        -- Raw Gem of (Brell's Temple)
        local raw_gem_array = {
            [15227] = true,
            [15228] = true,
            [15229] = true,
            [15230] = true,
            [15231] = true,
            [15232] = true,
            [15233] = true
        }
        if raw_gem_array[line] then
            ignore_special_jewelcraft = 1
            local rrn = library.return_recipe_name(line)
            GLOBAL_TEXT = "Not adding Recipe: " .. rrn .. " ID: " .. line ..
                " it requires ['Brell's Temple Font Room Coldain Prayer Shawl 2.0 #6 - Honoring the Elements']"
            print(msg, "Not adding Recipe: " .. rrn .. " ID: " .. line ..
                " it requires ['Brell's Temple Font Room Coldain Prayer Shawl 2.0 #6 - Honoring the Elements']")
        end

        if skip_recipe_flag == 0 and l_race_check == nil and con_result == nil and
            ignore_special_jewelcraft == 0 then
            table.insert(array, line)
        end

        if skip_recipe_flag == 1 then
            local rrn = library.return_recipe_name(line)
            print(msg, "Not adding Recipe: " .. rrn .. " ID: " .. line ..
                " \ag(Skipped) \atPRIZE.DB")
        end

        -- Used to check for race requirements for Artisan Prize recipes

        -- Only checks 37 recipes

        if skip_recipe_flag == 0 and l_race_check ~= nil then
            local toon_races = {
                "OGR", "Ogre", "IKS", "Iksar", "DEF", "Dark Elf", "DWF",
                "Dwarf", "FRG", "Froglok", "TRL", "Troll", "VAH", "Vah Shir",
                "GNM", "Gnome", "HFL", "Halfling", "HUM", "Human", "HEF",
                "Half Elf", "ERU", "Erudite", "HIE", "High Elf", "ELF",
                "Wood Elf", "DRK", "Drakkin", "BAR", "Barbarian"
            }

            local return_race = nil

            for c = 1, #toon_races do
                if toon_races[c] == l_race_check and toon_races[c + 1] ==
                    mq.TLO.Me.Race() then
                    return_race = toon_races[c + 1]
                    -- print("race match: ", return_race, " recipe ID: ", line)
                    table.insert(array, line)
                    break
                end
            end
        end
    end

    return array
end

function library.readfile_banking(p_file)
    local array = {}
    local count = 0
    local path = mq.luaDir .. "\\TCN\\Working"
    local p_data = path .. "\\" .. p_file
    local answer = library.file_exists(p_data)
    if not answer then return array end
    for line in io.lines(p_data) do
        array[count] = line
        count = count + 1
    end
    return array
end

-- make into a better named function?
-- from eq dump file
function library.return_max_recipe_array_dump(p_file)
    local array = {}
    local path = mq.luaDir .. "\\TCN\\Working"
    -- print(path)
    local p_data = path .. "\\" .. p_file

    -- if not (library.file_exists(p_data)) then return nil end

    for line in io.lines(p_data) do
        -- remove everything after space?
        -- s=  line:gsub("(.*)%s.*$","%1")
        line = line:gsub('([A-z]+).*', "")

        local convert = line
        --  local  s =  trimit(convert)
        -- line = line:gsub("%s+", "")
        convert = tonumber(convert)
        -- print("return max recipe array: ",line)
        table.insert(array, convert)
    end
    return array
end

function library.return_make_list(p_max_table, p_dump)
    --  for c = 1 ,#p_dump do print (p_dump[c]) end

    -- for c = 1 ,#p_max_table do print (p_max_table[c]) end

    local do_flag = 0

    local final_array = {}
    local final_array_counter = 0

    local tester = 1

    if tester == 1 then
        for x = 0, #p_max_table do
            do_flag = 1

            for y = #p_dump, 0, -1 do
                if p_max_table[x] == p_dump[y] then do_flag = 0 end
            end

            if do_flag == 1 then
                final_array[final_array_counter] = p_max_table[x]
                final_array_counter = final_array_counter + 1
                do_flag = 0
            end
        end
    end

    for c = 1, #final_array do print(final_array[c]) end

    return final_array
end

-- Load recipe table
function library.load_recipe_table(p_id)
    local m = {}
    local sql_string
    sql_string =
        "SELECT * FROM MasterRecipeTable WHERE RecipeID !=0 AND ItemID !=0 AND RecipeID < 90000000 AND RecipeID=" ..
        p_id .. " ORDER BY RecipeName ASC"
    --    print("string ",sql_string)

    for r in db:nrows(sql_string) do
        if r.Bugged == nil then r.Bugged = 0 end
        if r.ReqSkill == nil then r.ReqSkill = 0 end
        if tonumber(r.ReqSkill) == nil then r.ReqSkill = 0 end
        if r.ReqRace == nil or r.ReqRace == "nil" or r.ReqRace == 0 or r.ReqRace ==
            '' or r.ReqRace == "" then
            r.ReqRace = nil
        end

        -- if r.ReqSkill > 300 then r.ReqSkill = 300 end

        -- print("lib load recipe table rskill ",r.Skill, " ",r.ReqSkill)

        local item = {
            RecipeID = r.RecipeID,
            RecipeName = r.RecipeName,
            Trivial = r.Trivial,
            Skill = r.Skill,
            Yield = r.Yield,
            Container = r.Container,
            ItemID = r.ItemID,
            SkillRequired = r.ReqSkill,
            ClassRequired = r.ReqClass,
            RecipeBugged = r.Bugged,
            RaceRequired = r.ReqRace
        }
        table.insert(m, item)
    end
    return m
end

function library.can_make(p_id)
    local recipe_comp_array = library.return_recipe_components(p_id)
    -- Check vendor or inventory for items to make recipe
    local no_make = 1
    for z = 0, #recipe_comp_array do
        --  print("comp array ",recipe_comp_array[z])
        local l_inv_item = tonumber(library.return_number(recipe_comp_array[z],
            1))
        if l_inv_item == nil then
            print("tcg inventory check error for ", recipe_comp_array[z])
            os.exit()
        end
        local l_inv = mq.TLO.FindItemCount(l_inv_item)()
        local l_vendor_has_item = library.vendor_has_item(l_inv_item)
        if l_vendor_has_item == 0 then
            local l_row_count = tonumber(
                library.return_number(recipe_comp_array[z],
                    2))
            if l_inv < l_row_count then
                --  local rn = lib.return_number(recipe_comp_array[z],1)
                -- print(l_row_count, " ", recipe_comp_array[z], " ",lib.return_item_name(rn))
                no_make = 0
            end
        end
    end
    return no_make
end

function library.vendor_has_item(p_id)
    -- if rows == 0 then item is not on vendor
    local m = 1

    -- ?
    local current_zone = mq.TLO.Zone.ID()
    current_zone = 202

    -- for list_row in db:urows("SELECT count(*) FROM VendorTable where ItemID=" ..
    -- p_id.. " AND VendorZoneID ="..current_zone) do

    local rows_count = 0

    -- Main Vendor Table
    local sql_string = "SELECT count(*) FROM VendorTable WHERE ItemID=" .. p_id

    -- RoF Vendor Table
    if mq.TLO.MacroQuest.Server() == "arizlona" or mq.TLO.MacroQuest.Server() ==
        "amischief" or mq.TLO.MacroQuest.Server() == "yelinak" then
        sql_string = "SELECT count(*) FROM ZVendorTable WHERE ItemID=" .. p_id
    end

    -- Pre-RoF Table
    if mq.TLO.MacroQuest.Server() == "oakwynd" or mq.TLO.MacroQuest.Server() ==
        "athornblade" or mq.TLO.MacroQuest.Server() == "ayelinak" then
        sql_string = "SELECT count(*) FROM RVendorTable WHERE ItemID=" .. p_id
    end

    --  sql_string = "SELECT count(*) FROM RVendorTable where ItemID=" .. p_id
    for list_row in db:urows(sql_string) do
        -- for list_row in db:nrows("SELECT count(*) FROM VendorTable WHERE ItemID=" .. p_id) do
        rows_count = list_row
        -- how many vendors have the item
        -- print ("rows: ",rows_count)
        if (rows_count < 1) then
            m = 0
            break
        end
    end

    return m
end

-- returns array of recipe components
function library.return_recipe_components(p_id)
    local m = {}
    local count = 0
    for row in db:nrows("SELECT * FROM MasterCompTable where RecipeID=" .. p_id) do
        m[count] = row.ItemID .. "," .. row.ItemCount
        count = count + 1
    end
    -- if m == 0 or m == nil then m = {}  end
    return m
end

function library.type_chars(p_chars)
    local converted_name = nil

    if string.find(p_chars, "%(") then
        converted_name = split(p_chars, " %(")
        p_chars = converted_name[1]
    end

    -- print(p_chars)
    -- print(string.len(p_chars))

    for i = 1, string.len(p_chars) do
        local str = string.sub(p_chars, i, i)
        if str == " " then
            mq.cmd('/squelch /keypress space chat')
        else
            mq.cmd('/squelch /keypress ' .. str .. ' chat')
            mq.delay(10)
        end
    end
end

-- Turns in quest items
function library.Turn_In(p_quest_id, p_quest_title)
    -- GO VISIBLE
    if mq.TLO.Me.Invis() then
        mq.cmd('/makemevisible')
        mq.delay(1)
    end

    -- Main Turn IN Loop

    for row in db:nrows(
        "SELECT * FROM Master_Quest_Table WHERE Quest_Step_Order = 2 and Quest_Task_ID =" ..
        p_quest_id) do
        local deliver_item_req = mq.TLO.Task(p_quest_title).Objective(
            row.Quest_Deliver_Step).RequiredCount()

        local deliver_item_cur = mq.TLO.Task(p_quest_title).Objective(
            row.Quest_Deliver_Step).CurrentCount()

        local fv_item_count = mq.TLO.FindItemCount(row.Quest_Item_ID)()

        mq.delay(1)
        --   if mq.TLO.Task(p_quest_title).Objective(row.Quest_Deliver_Step).Status() ~=
        --  "Done" then

        local val1 = mq.TLO.Task(p_quest_title)
            .Objective(row.Quest_Deliver_Step).Status()

        mq.delay(1)

        if mq.TLO.Task(p_quest_title).Objective(row.Quest_Deliver_Step).Status() ==
            nil and mq.TLO.FindItemCount(row.Quest_Item_ID)() > 0 then
            local returnname = library.return_item_name(row.Quest_Item_ID)
            print(msg,
                "We need to make the item to update the task, \atItem Name: \aw",
                returnname, " \atItem ID: \aw", row.Quest_Item_ID)
            break
        else
            if mq.TLO.Task(p_quest_title).Objective(row.Quest_Deliver_Step)
                .Status() ~= "Done" then
                --  print(remaining_deliver_count, " Step: ", row.Quest_Deliver_Step,
                --  " ID: ", row.Quest_Item_ID, " TI: ", fv_turn_in)

                -- Items to turn in
                mq.delay(100)

                if mq.TLO.FindItemCount(row.Quest_Item_ID)() > 0 then
                    local remaining_deliver_count = deliver_item_req -
                        deliver_item_cur

                    local fv_turn_in = remaining_deliver_count

                    if fv_item_count > remaining_deliver_count then
                        fv_turn_in = remaining_deliver_count
                    end

                    if fv_item_count ~= 0 and fv_item_count <
                        remaining_deliver_count then
                        fv_turn_in = fv_item_count
                    end
                    -- No-Stack
                    if mq.TLO.FindItem(row.Quest_Item_ID).StackSize() == 1 and
                        remaining_deliver_count > 0 then
                        -- Item Inventory
                        fv_item_count = mq.TLO
                            .FindItemCount(row.Quest_Item_ID)()
                        for x = 1, fv_turn_in do
                            library.give_quest_item_id(row.Quest_Item_ID, 1)
                            mq.delay(500)
                        end
                    else
                        -- Stacks
                        library.give_quest_item_id(row.Quest_Item_ID, fv_turn_in)
                        mq.delay(500)
                    end
                end
            end
        end
    end
    mq.delay(1)
    return
end

-- Could squash this also and send 1 or 2 for the quest_step_order
function library.quest_craft_information(p_id)
    local m = {}
    local counter = 0
    for r in db:nrows("SELECT * FROM Master_Quest_Table where Quest_Task_ID=" ..
        p_id .. " AND Quest_Step_Order = 1") do
        m[counter] = r.Quest_Create_Step .. "," .. r.Quest_Recipe_ID
        counter = counter + 1
        mq.delay(1)
    end
    return m
end

-- squash down.. have them deliver all info only pick what you want!
function library.quest_deliver_info(p_id)
    local m = {}
    local counter = 0
    for r in db:nrows("SELECT * FROM Master_Quest_Table where Quest_Task_ID=" ..
        p_id .. " AND Quest_Step_Order = 2") do
        m[counter] = r.Quest_Deliver_Step .. "," .. r.Quest_Item_ID .. "," ..
            r.Quest_Recipe_ID
        -- print(m[counter])
        counter = counter + 1
        mq.delay(1)
    end
    return m
end

function library.quest_deliver_status(p_id)
    local m = {}
    local counter = 0
    for r in db:nrows("SELECT * FROM Master_Quest_Table where Quest_Task_ID=" ..
        p_id .. " AND Quest_Step_Order = 2") do
        m[counter] = r.Quest_Deliver_Step .. "," .. r.Quest_Item_ID
        counter = counter + 1
        mq.delay(1)
    end
    return m
end

---- for getting and ending a quest?
function library.return_standard_quest_information(p_quest_name)
    local fv_quest_name = '"' .. p_quest_name .. '"'
    fv_quest_name = fv_quest_name:gsub('"', "'")

    -- print("\at", fv_quest_name)

    local Quest_NPC
    local TI_NPC
    local Quest_Zone_ID
    local Quest_Name
    local Quest_Text
    local Quest_Item
    local Quest_Item_ID

    for quest_row in db:nrows(
        "SELECT * FROM Master_Quest_Information_Table where Quest_Name=" ..
        fv_quest_name) do
        Quest_NPC = quest_row.Quest_NPC

        TI_NPC = quest_row.Quest_NPC_TurnIN
        Quest_Zone_ID = quest_row.Quest_Zone_ID
        Quest_Name = quest_row.Quest_Name
        Quest_Text = quest_row.QuestText
        Quest_Item = quest_row.QuestItem
        Quest_Item_ID = quest_row.QuestItemID
        mq.delay(1)
    end
    return Quest_NPC, TI_NPC, Quest_Zone_ID, Quest_Name, Quest_Text, Quest_Item,
        Quest_Item_ID
end

function library.available_artisan_quests(p_text)
    -- fishing    -- skill

    if p_text == 1 then
        print " "
        print(msg, " Available Artisan Seal Quests")
    end

    local counter = 1
    local quest_array = {}

    local ts_ = {
        "Baking", "Brewing", "Blacksmithing", "Fletching", "Jewelry Making",
        "Pottery", "Tailoring", "Tinkering", "Alchemy", "Make Poison",
        "Research", "Fishing"
    }

    local ts_artisan_id = {
        14559, 14560, 14568, 14567, 14562, 14561, 14563, 14565, 14564, 14569,
        14566, 14558
    }

    for x = 1, #ts_artisan_id do
        local trophy_have = library.have_trophy(ts_[x]) -- do we have the trophy

        local result = library.have_task(ts_[x])

        if result ~= nil then
            quest_array[counter] = result
            counter = counter + 1
        else
            local task_name = library.return_task_name(ts_[x])
        end
    end

    if p_text == 1 then
        for x = 1, #quest_array do
            print(msg, "\ao[", x, "\ao] \ao[\ag", quest_array[x], "\ao]")
        end

        if mq.TLO.Me.Skill('Research')() == 0 then
            print(msg, "NOTE: Research requires 1 skill point")
        end
    end
    return quest_array
end

---determine avaible trophy quests

function library.available_trophy_quests(p_text)
    -- fishing    -- skill

    if p_text == 1 then
        print " "
        print(msg, " Available Trophy Quests")
    end

    local counter = 1
    local quest_array = {}

    local ts_ = {
        "Baking", "Brewing", "Blacksmithing", "Fletching", "Jewelry Making",
        "Pottery", "Tailoring", "Tinkering", "Alchemy", "Make Poison",
        "Research"
    }

    for x = 1, #ts_ do
        local l_skill_level = mq.TLO.Me.Skill(ts_[x])()
        local finding = library.trophy_requirements(ts_[x])

        -- use for trophy swapping -- but need to do a finditemcount local because it returns bank items
        -- based on skill

        --  level to do toxi and alchemy.. for trophy..?

        local trophy_have = library.have_trophy(ts_[x]) -- do we have the trophy

        if finding == 1 and trophy_have == nil then
            local result = library.have_task(ts_[x])

            if result ~= nil then
                quest_array[counter] = result
                counter = counter + 1
            else
                local task_name = library.return_task_name(ts_[x])

                if l_skill_level < 50 then
                    task_name = "Beginner " .. task_name
                    quest_array[counter] = task_name
                    counter = counter + 1
                end

                if l_skill_level >= 50 and l_skill_level < 100 then
                    task_name = "Beginner " .. task_name
                    quest_array[counter] = task_name
                    counter = counter + 1
                end
                if l_skill_level >= 100 and l_skill_level < 150 then
                    task_name = "Apprentice " .. task_name
                    quest_array[counter] = task_name
                    counter = counter + 1
                end

                if l_skill_level >= 150 and l_skill_level < 199 then
                    task_name = "Freshman " .. task_name
                    quest_array[counter] = task_name
                    counter = counter + 1
                end
                if l_skill_level >= 200 and l_skill_level < 250 then
                    task_name = "Journeyman " .. task_name
                    quest_array[counter] = task_name
                    counter = counter + 1
                end
                if l_skill_level >= 250 and l_skill_level < 299 then
                    task_name = "Expert " .. task_name
                    quest_array[counter] = task_name
                    counter = counter + 1
                end
                if l_skill_level >= 300 then
                    task_name = "Master " .. task_name

                    quest_array[counter] = task_name
                    counter = counter + 1
                end
            end
        end
    end

    if p_text == 1 then
        for x = 1, #quest_array do
            print(msg, "\ao[", x, "\ao] \ao[\ag", quest_array[x], "\ao]")
        end

        if mq.TLO.Me.Skill('Research')() == 0 or mq.TLO.Me.Skill('Research')() <
            1 then
            print(msg, "NOTE: Research requires 1 skill point")
        end
    end
    return quest_array
end

-- determines if we have trophy
function library.have_trophy(p_skill)
    local trophy_skill = '"' .. p_skill .. '"'

    local trophy_name
    local trophy_id
    for trophy_row in db:nrows(
        "SELECT * FROM TrophyTable WHERE TrophySkill= " ..
        trophy_skill) do
        local trophy_string = trophy_row.TrophyTest .. " Trophy"
        local InventoryTrophyCount = mq.TLO.FindItemCount(trophy_string)()
        local BankedTrophyCount = mq.TLO.FindItemBankCount(trophy_string)()
        local InventoryMasterTrophy = mq.TLO
            .FindItemCount(trophy_row.TrophyName)()
        local BankedMasterTrophy = mq.TLO.FindItemBankCount(
            trophy_row.TrophyName)()

        if InventoryTrophyCount > 0 then
            trophy_name = mq.TLO.FindItem(trophy_string).Name()
            trophy_id = mq.TLO.FindItem(trophy_name).ID()
            break
        end

        if BankedTrophyCount > 0 then
            trophy_name = mq.TLO.FindItemBank(trophy_string).Name()
            trophy_id = mq.TLO.FindItemBank(trophy_name).ID()
            break
        end

        if InventoryMasterTrophy > 0 then
            trophy_name = trophy_row.TrophyName
            trophy_id = mq.TLO.FindItem(trophy_name).ID()
            break
        end

        if BankedMasterTrophy > 0 then
            trophy_name = trophy_row.TrophyName
            trophy_id = mq.TLO.FindItemBank(trophy_name).ID()
            break
        end
    end

    return trophy_name, trophy_id
end

-- returns matching task from database if we already have it
function library.have_task(p_skill)
    local trophy_skill = '"' .. p_skill .. '"'
    local trophy_test
    for trophy_row in db:nrows(
        "SELECT * FROM TrophyTable WHERE TrophySkill= " ..
        trophy_skill) do
        local test_string = trophy_row.TrophyTest .. " Test"
        if mq.TLO.Task(test_string).ID() ~= nil then
            trophy_test = mq.TLO.Task(test_string).Title()
            break
        end
    end
    return trophy_test
end

-- return skill associated with test.. is there an easier way.. short answer is yes
function library.return_skill(p_test)
    local trophy_skill
    local trophy_text
    for trophy_row in db:nrows("SELECT * FROM TrophyTable") do
        if trophy_row.TrophyTest == string.match(p_test, trophy_row.TrophyTest) then
            trophy_skill = trophy_row.TrophySkill
            trophy_text = trophy_row.TrophyText
            break
        end
    end
    return trophy_skill, trophy_text
end

-- Check if we have the specified task by name
function library.match_task(p_task)
    local trophy_test
    if mq.TLO.Task(p_task).WindowIndex() ~= nil then
        trophy_test = mq.TLO.Task(p_task).Title()
        return trophy_test
    end
    return trophy_test
end

-- return task name based on a skill
function library.return_task_name(p_skill)
    local trophy_skill = '"' .. p_skill .. '"'
    local trophy_test
    for trophy_row in db:nrows(
        "SELECT * FROM TrophyTable WHERE TrophySkill= " ..
        trophy_skill) do
        local test_string = trophy_row.TrophyTest .. " Test"
        if mq.TLO.Task(test_string).ID() == nil then
            trophy_test = test_string
            break
        end
    end
    return trophy_test
end

function library.trophy_requirements(p_skill)
    if p_skill == "Alchemy" and mq.TLO.Me.Class() ~= "Shaman" then return 0 end

    if p_skill == "Alchemy" and mq.TLO.Me.Class() == "Shaman" and
        mq.TLO.Me.Level() < 25 then
        return 0
    end
    if p_skill == "Make Poison" and mq.TLO.Me.Class() ~= "Rogue" then
        return 0
    end
    if p_skill == "Make Poison" and mq.TLO.Me.Class() == "Rogue" and
        mq.TLO.Me.Level() < 34 then
        return 0
    end
    if p_skill == "Tinkering" and mq.TLO.Me.Race() ~= "Gnome" then return 0 end
    if p_skill == "Research" and
        (mq.TLO.Me.Skill('Research')() < 1 or mq.TLO.Me.Skill('Research')() ==
            nil or mq.TLO.Me.Skill('Research')() == 0) then
        return 0
    end
    return 1
end

function library.return_req_skill(p_sub_id)
    local m
    for r in db:nrows(
        "SELECT * FROM MasterRecipeTable where ItemID > 0 and RecipeID =" ..
        p_sub_id) do m = r.ReqSkill end
    if m == nil or m == 0 then return 0 end
    return m
end

function library.check_requirements(p_skill, p_sub_id)
    -- print(p_skill," ",p_sub_id)
    if p_skill == "Alchemy" and mq.TLO.Me.Class() ~= "Shaman" then return 1 end
    if p_skill == "Make Poison" and mq.TLO.Me.Class() ~= "Rogue" then
        return 2
    end
    if p_skill == "Tinkering" and mq.TLO.Me.Race() ~= "Gnome" then return 3 end
    local l_req_skill = tonumber(library.return_req_skill(p_sub_id))
    if l_req_skill == nil then return 0 end
    --   print(l_req_skill, " ", p_skill)
    if mq.TLO.Me.Skill(p_skill)() < l_req_skill then return 4 end
    return 0
end

function library.check_raceclass(p_id)
    -- fix  -- and means both have to match    -- conditions!

    local finding = 1
    for row in db:nrows(
        "SELECT * FROM MasterRecipeTable where ItemID > 0 and RecipeID =" ..
        p_id) do
        if row.Skill == "Alchemy" then
            if mq.TLO.Me.Level() < 33 and mq.TLO.Me.Class() ~= "Shaman" then
                --   print(msg, "[Recipe] ", row.RecipeName)
                --   print(msg, "[Class Requirement] \ag[Shaman] \ay<> \ag[\ay",
                --       mq.TLO.Me.Class(), "\ag]")
                finding = 0
                break
            end
        end
        if row.Skill == "Make Poison" then
            if mq.TLO.Me.Level() < 33 and mq.TLO.Me.Class() ~= "Rogue" then
                --   print(msg, "[Recipe] ", row.RecipeName)
                --   print(msg, "[Class Requirement] \ag[Rogue] \ay<> \ag[\ay",
                --        mq.TLO.Me.Class(), "\ag]")
                finding = 0
                break
            end
        end
        if row.Skill == "Tinkering" and mq.TLO.Me.Race() ~= "Gnome" then
            --  print(msg, "[Recipe] ", row.RecipeName)
            --  print(msg, "[Race Requirement] \ag[Gnome] \ay<> \ag[\ay",
            --        mq.TLO.Me.Race(), "\ag]")
            finding = 0
            break
        end
        if row.Skill == "Research" and mq.TLO.Me.Skill('Research')() < 1 then
            -- print(msg, "[Recipe] ", row.RecipeName)
            --   print(msg, "[Skill Requirement] \ag[Research Points]")
            finding = 0
            break
        end
    end
    return finding
end

function library.special_conditions(p_id)
    -- fix  -- and means both have to match    -- conditions!

    local finding = 1
    for row in db:nrows(
        "SELECT * FROM MasterRecipeTable where ItemID > 0 and RecipeID =" ..
        p_id) do
        if row.Skill == "Alchemy" and mq.TLO.Me.Class() ~= "Shaman" then
            --   print(msg, "[Recipe] ", row.RecipeName)
            --   print(msg, "[Class Requirement] \ag[Shaman] \ay<> \ag[\ay",
            --       mq.TLO.Me.Class(), "\ag]")
            finding = 0
            break
        end

        if row.Skill == "Make Poison" and mq.TLO.Me.Class() ~= "Rogue" then
            --   print(msg, "[Recipe] ", row.RecipeName)
            --   print(msg, "[Class Requirement] \ag[Rogue] \ay<> \ag[\ay",
            --        mq.TLO.Me.Class(), "\ag]")
            finding = 0
            break
        end

        if row.Skill == "Tinkering" and mq.TLO.Me.Race() ~= "Gnome" then
            --  print(msg, "[Recipe] ", row.RecipeName)
            --  print(msg, "[Race Requirement] \ag[Gnome] \ay<> \ag[\ay",
            --        mq.TLO.Me.Race(), "\ag]")
            finding = 0
            break
        end
        if row.Skill == "Research" and mq.TLO.Me.Skill('Research')() < 1 then
            -- print(msg, "[Recipe] ", row.RecipeName)
            --   print(msg, "[Skill Requirement] \ag[Research Points]")
            finding = 0
            break
        end
    end
    return finding
end

function library.return_recipe_item_ID(p_id)
    -- get the Item ID for the Recipe
    local m
    for list_row in db:nrows(
        "SELECT * FROM MasterRecipeTable where RECIPEID=" ..
        p_id .. " ORDER BY ItemID ASC LIMIT 1") do
        m = list_row.ItemID
    end
    return m
end

function library.return_recipe_race(p_id)
    -- get the Race for the Recipe
    local m
    for list_row in db:nrows(
        "SELECT * FROM MasterRecipeTable where RECIPEID=" ..
        p_id .. " ORDER BY ReqRace ASC LIMIT 1") do
        m = list_row.ReqRace
        -- if m ~= nil then print("race is: ", m) end
    end
    return m
end

-- Return id based on text name of item
function library.return_itemname_id(p_item_name)
    p_item_name = '"' .. p_item_name .. '"'
    local m
    for r in db:nrows(
        "SELECT * FROM ItemTable where ItemName=" .. p_item_name ..
        " LIMIT 1") do m = r.ItemID end
    return m
end

function library.return_item_name(p_item_id)
    -- get the Item ID for the Recipe
    local m = nil

    local test = 1

    if test == 1 then
        for list_row in db:nrows(
            "SELECT * FROM MasterCompTable WHERE ItemID =" ..
            p_item_id .. " ORDER BY SubRecipeID ASC LIMIT 1") do
            m = list_row.ItemName
        end

        if m == nil then
            for list_row in db:nrows(
                "SELECT * FROM MasterRecipeTable WHERE ItemID=" ..
                p_item_id) do
                --     p_id .. " ORDER BY ItemID ASC LIMIT 1") do
                m = list_row.RecipeName
            end
        end
    end

    if m == nil then
        -- print(msg, "\ap[\awChecking experimental item table\ap]")
        for r in db:nrows("SELECT * FROM ItemTable where ItemID=" .. p_item_id) do
            m = r.ItemName
        end
    end

    if m == nil then
        print(msg, "\ayError: \atNo Item Name in any tables LIB ID: ", p_item_id)
        os.exit()
    end

    return m
end

-- Added: JB321 4/6/2022
function library.get_tool_recipe(p_id)
    local m = {}
    for r in db:nrows("SELECT * FROM Toolsets WHERE RecipeID = " .. p_id) do
        --   print(m)
        print(r.ItemName, " ", r.ItemID, " ", r.SubRecipeID, " ", r.ItemCount)
        --            -- break
        local s_string =
            r.ItemName .. "," .. r.ItemID .. "," .. r.SubRecipeID .. "," ..
            r.ItemCount
        table.insert(m, s_string)
    end
    return m
end

function library.toolswap(p_id)
    local m = 0
    if m == 0 then return end
    for r in db:nrows("SELECT * FROM ToolTable") do
        --    print(r.ToolItemID)
        if p_id ~= r.ItemID and mq.TLO.FindItemCount(r.ItemID)() > 0 and
            (string.find(r.ToolName, "Cut") or
                string.find(r.ToolName, "Setting")) then
            m = r.ItemID
            --   print(m)
            print(r.ToolName)
            -- break
        end
    end

    return m
end

function library.bank_returns_data()
    local m = {}

    -- Add crafted tools
    for row in db:nrows("SELECT * FROM ToolTable ") do
        -- add inventory so if it is 1 or greater then no need for an extra check
        --   print("\aoLibrary Tool Checking: ", row.ToolName)
        if mq.TLO.FindItemCount(row.ItemID)() > 0 then
            table.insert(m, row.ItemID .. ",1")
            --                print("\aoLibrary Tool Checking: ", row.ToolName)
        end
    end

    -- Add purchased tools
    for row in db:nrows("SELECT * FROM Buy_Tools_Table ") do
        -- add inventory so if it is 1 or greater then no need for an extra check
        --   print("\aoLibrary Tool Checking: ", row.ToolName)
        if mq.TLO.FindItemCount(row.ItemID)() > 0 then
            table.insert(m, row.ItemID .. ",1")
            --                print("\aoLibrary Tools Checking: ", row.ToolName)
        end
    end

    -- Add tradeskill Trophies
    for row in db:nrows("SELECT * FROM TrophyIDTable") do
        -- add inventory so if it is 1 or greater then no need for an extra check
        --   print("\aoLibrary Tool Checking: ", row.ToolName)
        if mq.TLO.FindItemCount(row.ItemID)() > 0 then
            table.insert(m, row.ItemID .. ",1")
            --                print("\aoLibrary Trophy Checking: ", row.ToolName)
        end
    end

    -- list of items to always put back.. add

    if m == nil then m = {} end
    return m
end

-- Return 1 if the id is a trophy!
function library.trophycheck_id(p_item_id)
    local m = 0
    for r in db:nrows("SELECT * FROM TrophyIDTable where ItemID= " .. p_item_id) do
        if p_item_id == r.ItemID then m = 1 end
    end
    if m == nil then m = 0 end
    return m
end

-- Added 3/2/2022 Check all tools
function library.return_tool_determination(p_item_id)
    local is_tool = false
    for r in db:nrows("SELECT * FROM All_Tools WHERE ToolID= " .. p_item_id) do
        if p_item_id == r.ToolID then
            is_tool = true
            break
        end
    end
    return is_tool
end

-- Return 1 and if vendor purchased from item id
function library.toolcheck_id(p_item_id)
    local m = 0
    local sb = 0
    for r in db:nrows("SELECT * FROM ToolTable where ItemID= " .. p_item_id ..
        " Order By ToolRecipeID ASC") do
        if p_item_id == r.ItemID then
            m = 1
            sb = r.StoreBought
        end
    end
    if m == nil then
        m = 0
        sb = 0
    end
    return m, sb
end

-- Return ItemID for a Tool Recipe ID
function library.return_tool_item_ID(p_id)
    local m = 0
    local sb = 0
    for r in db:nrows("SELECT * FROM ToolTable where ToolRecipeID= " .. p_id ..
        " Order By ToolRecipeID ASC") do
        -- add inventory so if it is 1 or greater then no need for an extra check
        --    print("\aoLibrary Crafted Tool Checking: ", r.ToolName)
        if p_id == r.ToolRecipeID then
            -- print("\aoLibrary Crafted Tool Checking: ", r.ToolName)

            m = r.ItemID

            sb = r.StoreBought
            -- row.ToolType
        end
    end
    if m == nil then
        m = 0
        sb = 0
    end

    -- REMD 4/2/2022
    -- mq.delay(1)

    return m, sb
end

function library.toolcheck(p_id)
    local m = 0
    local sb = 0
    for r in db:nrows("SELECT * FROM ToolTable where ToolRecipeID= " .. p_id ..
        " Order By ToolRecipeID ASC") do
        -- add inventory so if it is 1 or greater then no need for an extra check
        --    print("\aoLibrary Crafted Tool Checking: ", r.ToolName)
        if p_id == r.ToolRecipeID then
            -- print("\aoLibrary Crafted Tool Checking: ", r.ToolName)

            m = 1

            sb = r.StoreBought
            -- row.ToolType
        end
    end
    if m == nil then
        m = 0
        sb = 0
    end

    -- REMD 4/2/2022
    -- mq.delay(1)

    return m, sb
end

function library.check_purchased_tools(p_id)
    local m = 0
    for row in db:nrows(
        "SELECT * FROM Buy_Tools_Table where ItemID= " .. p_id ..
        " Order By ItemID ASC") do
        -- add inventory so if it is 1 or greater then no need for an extra check
        --   print("\aoLibrary Purchased Tool Checking: ", row.ToolName)
        if p_id == row.ItemID then
            --     print("\aoLibrary Purchased Tool Checking: ", row.ToolName)
            m = 1
            -- row.ToolType
        end
    end
    if m == nil then m = 0 end
    return m
end

-- better to dump and concat data in table?

function library.return_recipe_yield(p_id)
    -- print(p_id)
    local m
    for list_row1 in db:nrows(
        "SELECT * FROM MasterRecipeTable where recipeid=" ..
        p_id .. " ORDER BY ItemID ASC LIMIT 1") do
        m = list_row1.Yield
    end
    return m
end

function library.set_amount(p_need, p_yield)
    if p_need == nil then
        print("error nil need set amount ", p_need, " yield: ", p_yield)
        os.exit()
    end
    if p_yield == nil then
        print("error nil yield set amount ", p_need, " yield: ", p_yield)
        os.exit()
    end
    -- need , yield
    if p_need < 1 then return 0 end
    -- if p_yield == p_need then return p_need end
    if p_yield >= p_need then return 1 end
    -- print ("set: NEED: ",p_need, " YIELD: ",p_yield)
    if p_need > p_yield then
        --  print ("RESULT: ",math.ceil(p_need / p_yield))
        return math.ceil(p_need / p_yield)
    end
end

function library.get_total_count(p_id, s_id, fv_p_pnc, p_mitem_id)
    p_id = tonumber(p_id)
    s_id = tonumber(s_id)

    if (p_id == 0 or s_id == 0) then
        print "LIB Invalid Primary or Secondary Recipe ID"
        mq.exit()
    end

    local fv_p_yc = library.return_recipe_yield(p_id)
    local fv_s_yc = library.return_recipe_yield(s_id)

    local fv_sub_inv = mq.TLO.FindItemCount(p_mitem_id)()

    if fv_sub_inv == nil then
        print("Item ID: ", p_mitem_id,
            "\aw GET_BUY_COUNT Function Error: \apNil \awValue")
        mq.exit()
    end

    local fv_need

    if fv_p_pnc < 1 then return 0 end

    -- if fv_p_yc >= fv_p_pnc then print "stop this library" fv_p_pnc = fv_p_yc mq.exit() end

    local fv_cr = library.Return_Calling_Recipe_Row_Count(p_id, s_id)

    if fv_cr == nil then
        -- fv_cr = library.Return_Calling_Recipe_Row_Count_Multi(s_id)
    end

    -- my row..

    -- local my_row = library.return_item_row_count(s_id)

    --   print ("\agTCN Library primary: ",p_id, " secondary: ",s_id , " multi: ",p_multi_rid)
    -- print("calling row " ,fv_cr)

    -- if it is still NIL then we have a problem Houston.
    if fv_cr == nil then
        print "problem tcn_library calling row count NIL error"
        print("\agMain ", p_id, " \awSub: ", s_id, " calling: ", fv_cr,
            " yield: ", fv_s_yc, " inv ", fv_sub_inv, " item: ", p_mitem_id)
        mq.exit()
    end

    -- print "watch this tcn_library row count maths"
    fv_need = (fv_p_pnc / fv_p_yc) * fv_cr - fv_sub_inv

    fv_need = math.ceil(fv_need)

    if s_id >= 90000000 then
        -- get yield count for the row that we picked otherwise yield is?
        fv_s_yc = fv_p_yc
    end

    local get_amount = library.set_amount(fv_need, fv_s_yc)

    return get_amount, fv_cr
end

-- returns item ID from recipe ID
function library.return_item_ID(p_id)
    -- REMD 4/2/2022
    -- mq.delay(1)
    -- sqlite complete?

    -- db-prepare what does it do?
    -- print (db:changes())

    -- os.exit()

    local m
    -- for list_row in db:nrows("SELECT * FROM MasterCompTable where itemid="..sr_1.." AND recipeid="..cr_1.." ORDER BY ItemID ASC LIMIT 1") do
    for list_row in db:nrows(
        "SELECT * FROM MasterRecipeTable where recipeid=" ..
        p_id .. " ORDER BY ItemID ASC LIMIT 1") do
        m = list_row.ItemID
    end
    return m
end

function library.return_recipe_name(p_id)
    local m
    for list_row in db:nrows(
        "SELECT * FROM MasterRecipeTable where RecipeID=" ..
        p_id) do m = list_row.RecipeName end
    return m
end

-- every recipe used in another recipe
function library.return_table()
    local xx = {}
    local counter = 0
    for list_row in db:nrows(
        "SELECT * FROM MasterCompTable WHERE SubRecipeID > 0 ORDER BY SubRecipeID ASC") do
        -- print (list_row.RecipeID)
        --  local rin = library.return_recipe_name(list_row.RecipeID)

        xx[counter] = list_row.CRecipeName .. "," .. list_row.RecipeID .. "," ..
            list_row.ItemName .. "," .. list_row.SubRecipeID
        counter = counter + 1
    end
    return xx
end

-- junk

-- Write shopping list to shoppinglist folder
function library.writeshopping(p_filename, data)
    local file = io.open(mq.luaDir .. "\\TCN\\ShoppingLists\\" .. p_filename ..
        ".csv", "a")
    file:write(data, "\n")
    file:close()
end

-- Write data to working directory

-- (Validated)
-- Writes file data to TCN working directory
function library.writefile(p_filename, data)
    local file = io.open(
        mq.luaDir .. "\\TCN\\Working\\" .. p_filename .. ".csv",
        "a")
    file:write(data, "\n")
    file:close()
end

function library.writetextfile(p_filename, data)
    local file = io.open(
        mq.luaDir .. "\\TCN\\Working\\" .. p_filename .. ".txt",
        "a")
    file:write(data, "\n")
    file:close()
end

function library.writetofile(data)
    --   local file = io.open("D:\\shop.csv", "a")
    --   file:write(data, "\n")
    --   file:close()
    --   return
end

-- return recipe ID from item ID
function library.return_max(p_id)
    local xx = {}
    local counter = 0
    for row in db:nrows("SELECT * FROM MasterCompTable WHERE SubRecipeID = " ..
        p_id ..
        " AND SubRecipeID > 0 ORDER BY SubRecipeID ASC") do
        -- print (list_row.RecipeID)

        -- write file without all the nonsense.

        local string = row.ItemName .. "," .. row.SubRecipeID .. "," ..
            row.CRecipeName .. "," .. row.RecipeID
        --  print("\aw",string)
        --   xx[counter] = row.CRecipeName..","..row.RecipeID..","..row.ItemName..","..row.SubRecipeID
        library.writetofile(string)
        --  xx[counter] = row.SubRecipeID
        --  counter=counter+1
    end

    return
end

function library.return_max_used(p_id, p_opt)
    local flag = 1
    local m = 0
    local f_used_in = ""
    for list_row in db:nrows("SELECT * FROM Max_Used_Table WHERE RecipeID = " ..
        p_id) do
        f_used_in = list_row.UsedINRecipeID

        if f_used_in == 0 then
            print(msg, "\ap[\aw", library.return_recipe_name(p_id),
                "\ap] \agUSED in other recipes\ap]")
        else
            if p_opt == 1 then
                print(msg, "\ap[\aw", library.return_recipe_name(f_used_in),
                    "\ap] \agUSES \ap[\aw", library.return_recipe_name(p_id),
                    "\ap]")
            end
        end

        m = 1
    end
    return m
end

function library.return_max_table()
    local xx = {}
    local counter = 0
    for list_row in db:nrows("SELECT * FROM Max_Trophy_Table") do
        -- print (list_row.RecipeID)

        xx[counter] = list_row.RecipeID
        --  xx[counter] = list_row.RecipeID..","..list_row.RecipeName..","..list_row.RecipeSkill
        counter = counter + 1
    end
    return xx
end

-- removes quotes?
function library.return_string(str, int)
    local counter = 0
    -- print(str, " error")
    for word in string.gmatch(str, '([^,]+)') do
        counter = counter + 1
        if counter == int then return word end
    end
end

function library.return_number(str, int)
    -- print(str, " num")
    if int == nil or str == nil then
        print(str, " ", int, " LIBrary Return_number error")
        return 0
    end

    local counter = 0
    for number in string.gmatch(str, '([^,]+)') do
        counter = counter + 1
        if counter == int then return tonumber(number) end
    end
    --  return 0
end

-- Format for array ItemName, ItemID, ItemCount
function library.return_sorted_counts_array(p_array)
    local working_array = {}
    for c = 1, #p_array do
        local l_count = library.return_number(p_array[c], 3)
        if l_count > 0 then
            local l_item_name = library.return_string(p_array[c], 1)
            local l_item_id = library.return_number(p_array[c], 2)
            l_count = library.return_number(p_array[c], 3)

            -- time to switch overs to the .ID .Name era?
            -- or since these are the only 4 jury rig?--
            -- how do we get the count?

            table.insert(working_array, string.format('("%s",%d,%d)',
                l_item_name, l_item_id,
                l_count))
        end
    end

    local db_t_sort = sqlite3.open(mq.luaDir .. '\\TCN\\Work.db')
    db_t_sort:close()

    db_t_sort = sqlite3.open(mq.luaDir .. '\\TCN\\Work.db')

    -- Create Table
    db_t_sort:exec(
        [[DROP TABLE IF EXISTS tempsortedarray;CREATE TEMP TABLE tempsortedarray (ItemName,ItemID,ItemCount);]])
    local insert = table.concat(working_array, ", ")
    -- Insert Data into SQL Table
    db_t_sort:exec(string.format(
        "INSERT INTO tempsortedarray ('ItemName','ItemID','ItemCount') VALUES %s;",
        insert))

    -- Create Table
    db_t_sort:exec(
        [[DROP TABLE IF EXISTS tsa;CREATE TEMP TABLE tsa (ItemName,ItemID,ItemCount);]])

    -- Insert Data into SQL Table
    db_t_sort:exec(
        "INSERT INTO tsa SELECT ItemName,ItemID,SUM(ItemCount) AS ItemCount FROM tempsortedarray GROUP BY ItemID")

    for x in db:nrows("SELECT ItemID FROM Buy_Tools_Table") do
        db_t_sort:exec("UPDATE tsa SET ItemCount = 1 WHERE ItemID = " ..
            x.ItemID .. ";")
    end

    -- Initialize Array
    local temp_array = {}

    for x in db_t_sort:nrows(
        "Select ItemName,ItemID,SUM(ItemCount) AS ItemCount FROM tsa GROUP BY ItemID") do
        local table_string = x.ItemName .. "," .. x.ItemID .. "," .. x.ItemCount
        table.insert(temp_array, table_string)
    end

    db_t_sort:close()

    return temp_array
end

function library.return_max_farm_list_sql(p_array)
    local sql_farm_list = {}

    for c = 1, #p_array do
        local item_name = library.return_string(p_array[c], 1)
        local item_id = library.return_number(p_array[c], 2)
        local item_count = library.return_number(p_array[c], 3)
        local item_action = library.return_string(p_array[c], 4)
        local item_zone = library.return_string(p_array[c], 5)

        local item = {
            ItemName = item_name,
            ItemID = item_id,
            ItemCount = item_count,
            ItemAction = item_action,
            ItemZone = item_zone
        }

        -- table.insert(sql_farm_list, item)

        table.insert(sql_farm_list,
            string.format('(%s,%d,%d,%s,%s)', item_name, item_id,
                item_count, item_action, item_zone))
    end

    -- what can we do with this..? --sort by item asc recipe asc?
    -- for c = 1 ,#sql_farm_list do print("\ag",sql_farm_list[c]) end

    return sql_farm_list
end

function library.return_sorted_recipes_array(p_array)
    -- local db_t_sort = sqlite3.open(mq.luaDir ..
    --                                   '\\TCN\\aork.db')

    local db_t_sort = sqlite3.open(":memory:")

    db_t_sort:close()

    -- db_t_sort = sqlite3.open(mq.luaDir .. '\\TCN\\aork.db')

    db_t_sort = sqlite3.open(":memory:")

    -- Create Table
    db_t_sort:exec(
        [[DROP TABLE IF EXISTS temprecipearray;CREATE TEMP TABLE temprecipearray (RecipeID,ItemCount);]])

    local insert = table.concat(p_array, ", ")
    -- Insert Data into SQL Table
    db_t_sort:exec(string.format(
        "INSERT INTO temprecipearray ('RecipeID','ItemCount') VALUES %s;",
        insert))

    -- Create Table
    db_t_sort:exec(
        [[DROP TABLE IF EXISTS CAP;CREATE TEMP TABLE CAP (RecipeID,ItemCount);]])

    -- Insert Data into SQL Table
    db_t_sort:exec(
        "INSERT INTO CAP SELECT RecipeID,SUM(ItemCount) AS ItemCount FROM temprecipearray GROUP BY RecipeID")

    -- Initialize Array
    local temp_array = {}

    for x in db_t_sort:nrows(
        "Select RecipeID,SUM(ItemCount) AS ItemCount FROM CAP GROUP BY RecipeID") do
        local table_string = { RecipeID = x.RecipeID, ItemCount = x.ItemCount }
        table.insert(temp_array, table_string)
    end

    db_t_sort:close()

    return temp_array
end

function library.return_item_id(p_id)
    local m
    for row in db:nrows("SELECT * FROM MasterRecipeTable WHERE RecipeID=" ..
        p_id, " LIMIT 1") do m = row.ItemID end
    return m
end

function library.return_recipe_inv(p_id)
    local rii = library.return_item_id(p_id)
    local m = mq.TLO.FindItemCount(rii)()
    return m
end

-- change all to nums
function library.return_recipe_bank_inv(p_id)
    local rii = library.return_item_id(p_id)
    local m = mq.TLO.FindItemBankCount(rii)()
    return m
end

function library.return_item_inv(p_id)
    local m = mq.TLO.FindItemCount(p_id)()
    return m
end

-- returns a container based on loose match and count
function library.return_available_container(p_name)
    local available_containers = {
        "Deluxe Toolbox", "Planar Fletching Kit", "Reinforced Medicine Bag",
        "Foldable Medicine Bag", "Marble Mortar and Pestle",
        "Planar Jeweler's Kit", "Reinforced Jeweler's Kit"
    }
    for x = 1, #available_containers do
        if string.match(available_containers[x], p_name) and
            mq.TLO.FindItemCount(available_containers[x])() > 0 then
            local m = available_containers[x]
            return m
        end
    end
end

-- should we return all elements or one element?
function library.return_container_name(p_id)
    local m
    for row in db:nrows("SELECT * FROM MasterRecipeTable WHERE RecipeID=" ..
        p_id) do m = row.Container end
    return m
end

-- return more info?
function library.return_recipe_info(p_id)
    local m, n, hc
    for row in db:nrows("SELECT * FROM MasterRecipeTable WHERE RecipeID= " ..
        p_id) do
        m = row.ItemID
        n = row.RecipeName
        hc = mq.TLO.FindItemCount(m)()
    end
    return m, n, hc
end

-- determines if we can make 1 recipe?
function library.recipe_check(p_id)
    local m = 1
    for row in db:nrows("SELECT * FROM MasterCompTable where recipeid=" .. p_id) do
        local hc = mq.TLO.FindItemCount(row.ItemID)()
        if row.ItemCount > hc then m = 0 end
    end
    return m
end

-- Destruction Functions:

-- Grabs stack for now
function library.destroy_recipe_components_id(p_id)
    for row in db:nrows("SELECT * FROM MasterCompTable WHERE RecipeID=" .. p_id) do
        -- avoids destroying recipes...
        --  "SELECT * FROM MasterCompTable WHERE SubRecipeID = 0 AND RecipeID=" ..

        local l_item_id = row.ItemID
        local l_inv = mq.TLO.FindItemCount(l_item_id)()

        if l_inv > 0 then
            library.GrabItemID(l_item_id, -1)
            -- mq.cmd('/shift /itemnotify "${FindItem["' .. m .. '"]}" leftmouseup')

            mq.delay(500)
            if mq.TLO.Cursor.ID() == l_item_id then
                print(msg, "\ap[\aoDestroying\ap] \ap[\aw", mq.TLO.Cursor.Name,
                    "\ap]")
                mq.cmd('/destroy')
                mq.delay(1000)
            end
        end
    end
    return
end

-- Window Functions

function library.GrabItemID(p_id, p_count)
    mq.delay(1)

    if p_id == nil or p_count == nil then
        print(msg, "LIB Grabitem id error ID:", p_id, " Count: ", p_count)
        return
    end

    local l_id = p_id

    if mq.TLO.FindItemCount(l_id)() < 1 or mq.TLO.FindItem(l_id)() == nil then
        print(msg, "Nothing found to grab")
        return
    end

    mq.delay(1)

    local l_count = p_count

    local slot2 = mq.TLO.FindItem(l_id).ItemSlot2() + 1

    if slot2 == 0 then
        -- Workaround for UI interference
        if GLOBAL_STANDARD_UI == 1 then mq.delay(2000) end

        -- Not in bag
        local slot1 = mq.TLO.FindItem(l_id).ItemSlot()

        if l_count == 1 then
            mq.cmd('/ctrl /itemnotify ' .. slot1 .. ' leftmouseup')
            -- mq.delay(1000)
            mq.delay(200)
        end
        if l_count == -1 then
            mq.cmd('/shift /itemnotify ' .. slot1 .. ' leftmouseup')
            -- mq.delay(1000)
            mq.delay(100)
        end
        if l_count > 1 then
            mq.cmd('/nomodkey /itemnotify ' .. slot1 .. ' leftmouseup')
            -- mq.delay(1000)
            mq.delay(100)
            mq.cmd('/notify QuantityWnd QTYW_slider newvalue', l_count)
            --  mq.delay(1000)
            mq.delay(100)
            mq.cmd(
                '/nomodkey /notify QuantityWnd QTYW_Accept_Button leftmouseup')
            --  mq.delay(500)
            mq.delay(100)
        end
    else
        -- In bag

        mq.delay(1)

        local pack = mq.TLO.FindItem(l_id).ItemSlot() - 22

        -- Workaround for UI interference
        if GLOBAL_STANDARD_UI == 1 then mq.delay(2000) end

        mq.delay(1)

        -- Code to open bags first no matter what JB 2/13/2025

        local bag_slot = mq.TLO.FindItem(l_id).ItemSlot()

        if mq.TLO.Me.Inventory(bag_slot).Open() == 0 then
            mq.cmd('/itemnotify pack' .. pack .. ' rightmouseup')
            --   mq.delay(500)
            mq.delay(100)
        end

        -- End Open Bag Code

        if l_count == 1 then
            -- mq.exit()
            mq.delay(1)

            mq.cmd('/ctrl /itemnotify in pack' .. pack .. ' ' .. slot2 ..
                ' leftmouseup')
            mq.delay(200)
            -- extra delay DBG screw up
            -- mq.delay(100)
        end

        if l_count == -1 then
            mq.cmd('/shift /itemnotify in pack' .. pack .. ' ' .. slot2 ..
                ' leftmouseup')
            mq.delay(200)
            -- extra delay DBG screw up
            -- mq.delay(100)
        end

        if l_count > 1 then
            -- Bag open?
            local slot1 = mq.TLO.FindItem(l_id).ItemSlot()
            if mq.TLO.Me.Inventory(slot1).Open() == 0 then
                mq.cmd('/itemnotify pack' .. pack .. ' rightmouseup')
                --   mq.delay(500)
                mq.delay(100)
            end

            mq.cmd('/nomodkey /itemnotify in pack' .. pack .. ' ' .. slot2 ..
                ' leftmouseup')
            --  mq.delay(500)
            mq.delay(100)
            mq.cmd('/notify QuantityWnd QTYW_slider newvalue', l_count)
            --  mq.delay(500)
            mq.delay(100)
            mq.cmd(
                '/nomodkey /notify QuantityWnd QTYW_Accept_Button leftmouseup')
            --  mq.delay(500)
            mq.delay(100)
        end
        --  mq.cmd('/itemnotify pack' .. pack .. ' rightmouseup')
        -- mq.delay(1000)
    end

    -- print("grabsit: ", mq.TLO.Cursor.Name)

    if mq.TLO.Cursor.Name == nil or mq.TLO.Cursor.Name == "NULL" then
        os.exit()
    end
    -- mq.cmd('/lua pause')

    return
end

-- Destroy all of something by Item ID
function library.DestroyItemID(p_item_id)
    -- local l_inv = mq.TLO.FindItemCount(p_item_id)()
    local l_have = mq.TLO.FindItem(p_item_id).ID()
    while true do
        l_have = mq.TLO.FindItem(p_item_id).ID()
        if l_have ~= nil then
            library.GrabItemID(p_item_id, -1)
            mq.delay(500)
            if p_item_id == mq.TLO.Cursor.ID() then
                print(msg, "Destroying ", mq.TLO.Cursor.Name())
                mq.cmd('/squelch /destroy')
                mq.delay(1000)
            end
        end
        mq.delay(300)
        if l_have == nil then
            mq.delay(2000)
            break
        end
    end
end

function library.CloseInventoryWindow()
    if mq.TLO.Window('InventoryWindow').Open() then
        mq.cmd('/squelch /windowstate InventoryWindow close')
    end
    mq.delay(500)
    return
end

-- NPC interactions

function library.give_quest_item_id(p_id, p_count)
    local l_item = p_id
    local l_turn_in = mq.TLO.FindItem(l_item)()
    local l_item_name = mq.TLO.FindItem(l_item).Name()
    local l_count = p_count

    -- add turn in counts..

    if l_count == 0 then
        print "0 error library"
        mq.exit()
    end

    -- pick up 1
    if l_count == 1 then
        library.GrabItemID(l_item, 1)
        -- mq.cmd('/ctrl /itemnotify "${FindItem["' .. l_item .. '"]}" leftmouseup')
    end
    -- pick up stack
    if l_count == -1 then
        library.GrabItemID(l_item, -1)

        --  mq.cmd('/shift /itemnotify "${FindItem["' .. l_item ..
        -- '"]}" leftmouseup')
    end
    -- pick up a few
    if l_count > 1 then
        library.GrabItemID(l_item, l_count)

        --  mq.cmd('/nomodkey /itemnotify "${FindItem["' .. l_item ..
        -- '"]}" leftmouseup')

        --  local item_id = "" .. mq.TLO.FindItem(l_item)() .. ""

        -- mq.cmd('/nomodkey /itemnotify "${' .. item_id .. '}" leftmouseup')

        -- mq.delay(500)
        -- mq.cmd('/notify QuantityWnd QTYW_slider newvalue', l_count)
        -- mq.delay(500)
        -- mq.cmd('/nomodkey /notify QuantityWnd QTYW_Accept_Button leftmouseup')
        -- mq.delay(500)
    end

    mq.delay(500)

    if mq.TLO.Cursor.ID() ~= l_item then
        print("\at[TCSNext] [invalid item on cursor] \ay", mq.TLO.Cursor.Name,
            " ", mq.TLO.Cursor.ID, " (should Be: \ag", l_item_name, " ",
            l_item)
        mq.exit()
    end

    -- mq.delay(1000)
    -- mq.cmd('/click left target')

    -- Open Give Window
    while not mq.TLO.Window('GiveWnd').Open() do
        mq.cmd('/doevents')
        mq.cmd('/click left target')
        mq.delay(1000)
    end

    mq.delay(500)

    library.CloseInventoryWindow()

    mq.delay(500)

    -- Give Items
    if mq.TLO.Window('GiveWnd').Open() and
        mq.TLO.Window('GiveWnd').Child('GVW_MyItemSlot0').Tooltip() == l_turn_in then
        mq.cmd('/notify GiveWnd GVW_Give_Button leftmouseup')
        mq.cmd('/doevents')
        mq.delay(1000)
    end

    library.ClearCursor()

    return
end

-- used for legacy quests for now
function library.give_item_id(p_id)
    local l_item = p_id
    local l_turn_in = mq.TLO.FindItem(l_item)()
    local l_item_name = mq.TLO.FindItem(l_item).Name()

    -- Add turn in counts..

    print("\ap[\atTCSNe\auX\att\ap] \aw[Turning in Items]")

    -- Pick up stack by ID!
    -- mq.cmd('/shift /itemnotify "${FindItem["' .. l_item .. '"]}" leftmouseup')

    library.GrabItemID(l_item, -1)

    mq.delay(1000)

    if not mq.TLO.Cursor.ID() == l_item then
        print("\at[TCSNext] [invalid item on cursor] \ay", mq.TLO.Cursor.Name,
            " (should Be: \ag", l_item_name)
        mq.exit()
    end

    -- mq.delay(1000)
    -- mq.cmd('/click left target')

    -- Open Give Window
    while not mq.TLO.Window('GiveWnd').Open() do
        mq.cmd('/doevents')
        mq.cmd('/click left target')
        mq.delay(1000)
    end

    mq.delay(500)

    library.CloseInventoryWindow()

    mq.delay(500)

    -- Give Items
    if mq.TLO.Window('GiveWnd').Open() and
        mq.TLO.Window('GiveWnd').Child('GVW_MyItemSlot0').Tooltip() == l_turn_in then
        mq.cmd('/notify GiveWnd GVW_Give_Button leftmouseup')
        mq.cmd('/doevents')
        mq.delay(1000)
    end
    return
end

-- Task Interactions
function library.open_journal()
    -- print(mq.TLO.Window('TaskWnd').Child('TASK_TaskList').Items)
    mq.delay(500)
    if mq.TLO.Window('TaskWnd').Child('TASK_TaskList').Items() == 0 then
        -- mq.cmd('/keypress ALT+Q')
        local t_msg = "\at[\aoTCSNe\agX\aot\at]\aw "
        print(t_msg, "Initializing Quest Log")
        mq.TLO.Window('TaskWnd').DoOpen()
        mq.delay(500)
        while not mq.TLO.Window('TaskWnd').Open() do mq.delay(100) end
        --  mq.cmd('/keypress ALT+Q')
        mq.TLO.Window('TaskWnd').DoClose()
    end
    return
end

-- Currency Interaction
function library.bank_withdrawal(p_amount)
    if not mq.TLO.Window('BigBankWnd').Open() then
        mq.cmd('/nomodkey /click right target')
        mq.delay(1500)
    end

    if mq.TLO.Me.PlatinumBank() >= p_amount then
        mq.cmd('/notify BigBankWnd BIGB_Money0 leftmouseup')
    else
        if mq.TLO.Me.PlatinumShared() >= p_amount then
            mq.cmd('/notify BigBankWnd BIGB_SharedMoney0 leftmouseup')
        else
            print("\ao[\atTCSNeXt\ao]: \ay[\awNot Enough Cash:\ay] \ap[\ag",
                p_amount, "\ap] \atPlatinum \ay[\ayNeeded\ay]")
            return
        end
    end
    GLOBAL_STANDARD_CRAFTING_STATUS_MSG = " Grabbing " .. p_amount .. "Platinum"

    print(msg, "\ay[\awGrabbing:\ay] \ap[\ag", p_amount,
        "\ap] \atPlatinum \agfrom: \ay[\ayBank\ay]")
    mq.delay(1000)
    mq.cmd('/notify QuantityWnd QTYW_slider newvalue ' .. p_amount)
    mq.delay(1000)
    mq.cmd('/notify QuantityWnd QTYW_Accept_Button leftmouseup')
    mq.delay(1000)
    mq.cmd('/autoinv')
    mq.delay(1000)
    mq.cmd('/notify BigBankWnd BIGB_DoneButton leftmouseup')
    mq.delay(1500)

    -- cleanup?

    return
end

-- Shopping Data

-- Added 3/17/22 JB321
function library.return_recipe_shop_info(p_id, p_count)
    local m = {}

    local sql_string =
        "SELECT * FROM MasterCompTable r Join VendorTable v on r.ItemID = v.ItemID WHERE RecipeID =" ..
        p_id .. " AND SubRecipeID = 0 Group by r.ItemID"

    -- RoF
    if mq.TLO.MacroQuest.Server() == "arizlona" or mq.TLO.MacroQuest.Server() ==
        "amischief" or mq.TLO.MacroQuest.Server() == "yelinak" then
        sql_string =
            "SELECT * FROM MasterCompTable r Join ZVendorTable v on r.ItemID = v.ItemID WHERE RecipeID =" ..
            p_id .. " AND SubRecipeID = 0 Group by r.ItemID"
    end

    -- Pre-RoF
    if mq.TLO.MacroQuest.Server() == "oakwynd" or mq.TLO.MacroQuest.Server() ==
        "athornblade" or mq.TLO.MacroQuest.Server() == "ayelinak" then
        sql_string =
            "SELECT * FROM MasterCompTable r Join RVendorTable v on r.ItemID = v.ItemID WHERE RecipeID =" ..
            p_id .. " AND SubRecipeID = 0 Group by r.ItemID"
    end

    for r in db:nrows(sql_string) do
        local l_item_count = r.ItemCount
        local l_item_total_count = p_count * l_item_count
        local l_item_calc = l_item_count * p_count * r.VendorPrice

        -- print("\atVendor Name: ", r.VendorName, " ItemID ", r.ItemID, " Name: ",
        --     r.ItemName, " Price: ", r.VendorPrice, " total price ",
        --    l_item_calc, " ZoneID: ", r.VendorZoneID)

        table.insert(m,
            string.format('(%d,"%s",%d,%d,"%s",%d)', r.VendorZoneID,
                r.VendorName, r.ItemID, l_item_total_count,
                r.ItemName, l_item_calc))
    end
    return m
end

-- Added 4/6/2022 JB321
function library.return_recipe_comp_data(p_id, p_count)
    local m = {}
    for r in db:nrows(
        "SELECT * FROM MasterCompTable WHERE RecipeID =" .. p_id ..
        " AND SubRecipeID = 0 GROUP by ItemID") do
        local l_item_count = r.ItemCount
        local l_item_total_count = p_count * l_item_count
        --  local l_item_calc = l_item_count * p_count * r.VendorPrice

        -- local l_item_total_count = l_item_count

        local s_string = r.ItemName .. "," .. r.ItemID .. "," ..
            l_item_total_count

        table.insert(m, s_string)
    end
    return m
end

-- Added 4/6/2022 JB321
function library.return_recipe_shop_NOSQL(p_id, p_count)
    local m = {}

    local sql_string =
        "SELECT * FROM MasterCompTable r Join VendorTable v on r.ItemID = v.ItemID WHERE RecipeID =" ..
        p_id .. " AND SubRecipeID = 0 Group by r.ItemID"

    -- RoF
    if mq.TLO.MacroQuest.Server() == "arizlona" or mq.TLO.MacroQuest.Server() ==
        "amischief" or mq.TLO.MacroQuest.Server() == "yelinak" then
        sql_string =
            "SELECT * FROM MasterCompTable r Join ZVendorTable v on r.ItemID = v.ItemID WHERE RecipeID =" ..
            p_id .. " AND SubRecipeID = 0 Group by r.ItemID"
    end

    -- Pre-RoF
    if mq.TLO.MacroQuest.Server() == "oakwynd" or mq.TLO.MacroQuest.Server() ==
        "athornblade" or mq.TLO.MacroQuest.Server() == "ayelinak" then
        sql_string =
            "SELECT * FROM MasterCompTable r Join RVendorTable v on r.ItemID = v.ItemID WHERE RecipeID =" ..
            p_id .. " AND SubRecipeID = 0 Group by r.ItemID"
    end

    for r in db:nrows(sql_string) do
        local l_item_count = r.ItemCount
        local l_item_total_count = p_count * l_item_count
        local l_item_calc = l_item_count * p_count * r.VendorPrice

        local s_string = r.VendorZoneID .. "," .. r.VendorName .. "," ..
            r.ItemID .. "," .. l_item_total_count .. "," ..
            r.ItemName .. "," .. l_item_calc
        table.insert(m, s_string)
    end
    return m
end

function library.return_recipe_array_info(p_id)
    local m = {}
    local counter = 0
    for r in db:nrows("SELECT * FROM MasterCompTable WHERE RecipeID=" .. p_id) do
        m[counter] =
            r.ItemCount .. "," .. r.ItemID .. "," .. '"' .. r.ItemName .. '"'
        counter = counter + 1
    end
    return m
end

-- Vendor stuff

-- take from tcn sell? change????

-- Return nearest vendor with a path
function library.nearest_vendor_spawn()
    -- Variables
    local suitable_vendor = 0
    local nearest_vendor_name
    local nearest_vendor_dist
    local nearest_vendor_path
    local nearest_vendor_id

    for c = 1, mq.TLO.SpawnCount('Merchant')() do
        --  print(mq.TLO.NearestSpawn(c, 'Merchant').DisplayName())
        --  print(mq.TLO.NearestSpawn(c, 'Merchant').ID())

        nearest_vendor_id = mq.TLO.NearestSpawn(c, 'Merchant').ID()
        -- REMD 4/2/2022
        -- mq.delay(1)

        nearest_vendor_path = mq.TLO.Nav
            .PathExists('id ' .. nearest_vendor_id)()

        -- print("Path Exists ", nearest_vendor_path)

        -- Select a vendor

        if nearest_vendor_path and
            mq.TLO.NearestSpawn(c, 'Merchant').DisplayName() ~=
            "Parcel Delivery Liaison" then
            nearest_vendor_id = mq.TLO.NearestSpawn(c, 'Merchant').ID()
            nearest_vendor_name = mq.TLO.NearestSpawn(c, 'Merchant')
                .DisplayName()
            nearest_vendor_dist = math.ceil(
                mq.TLO.Spawn(nearest_vendor_id).Distance())
            print("We found a suitable vendor and their name is: ",
                nearest_vendor_name, " Distance: ", nearest_vendor_dist)
            suitable_vendor = 1
            break
        end
    end

    -- Unable to find vendor with path
    if suitable_vendor == 0 then
        print "We were unable to find a suitable vendor"
        return nil
    end

    -- print(nearest_vendor_name, " ", nearest_vendor_dist, " ", nearest_vendor_id)
    return nearest_vendor_name
end

-- ? Interactions..

-- Item Manipulation

-- Re-stack items
function library.restack_items(p_id)
    local l_stack_count = mq.TLO.FindItem(p_id).Stacks()
    if l_stack_count < 2 then return end
    print(msg, "\aw[Auto-Restack]")
    for c = 0, l_stack_count do
        library.GrabItemID(p_id, -1)
        library.ClearCursor()
    end
    return
end

-- unused...
function library.grab_id(p_id, p_count)
    -- Other Scenarios stack, ?
    if p_count == 1 then
        mq.cmd('/nomodkey /itemnotify "${FindItem["' .. p_id ..
            '"]}" leftmouseup')
        return
    end

    if p_count > 1 then
        mq.cmd('/nomodkey /itemnotify "${FindItem["' .. p_id ..
            '"]}" leftmouseup')
        mq.delay(1000)
        mq.cmd('/nomodkey /notify QuantityWnd QTYW_Accept_Button leftmouseup')
        -- slider
        mq.delay(1000)
        return
    end
end

function library.ClearCursor()
    local flag = 0

    -- if flag == 0 then return end

    while mq.TLO.Cursor.ID() do
        if mq.TLO.Cursor.ID() ~= nil then
            --  library.writefile("crafticons",
            --             mq.TLO.Cursor.ID() .. "," .. mq.TLO.Cursor.Icon() ..
            --           "," .. mq.TLO.Cursor.Name())
        end

        -- Global Destroy Code
        if mq.TLO.Cursor.ID() ~= nil then
            local global_array_list = library.read_global_destroy()
            local global_array_len = string.len(global_array_list[1])

            if global_array_len < 1 then
                -- print(msg, "No Global Destroy Data")
            else
                for c = 1, #global_array_list do
                    if mq.TLO.Cursor.ID() == tonumber(global_array_list[c]) then
                        print(msg, "\ap[\agGlobal Destroy:\ap] \ap[\aw",
                            mq.TLO.Cursor.Name(), "\ap]")
                        mq.delay(1)
                        mq.cmd('/destroy')
                        mq.delay(500)
                    end
                end
            end
        end
        -- End Global Destroy

        mq.cmd('/autoinv')

        library.event()

        mq.delay(500)

        if GLOBAL_ABORT_FLAG == 1 then break end
    end

    mq.delay(1)
    return flag
end

-- put somewhere

-- check recipes for same item twice..

function library.dostuff()
    print("\awrecipe list")
    -- for x = 0, #recipe_list do print("\ag", recipe_list[x]) end
    -- local raw_table = raw_item_list_table(recipe_list)
    print("\awraw table")
    -- for x = 0, #raw_table do print("\ag", raw_table[x]) end
    print("\awshopping list")
    -- local shopping_list = final_shopping_list_table(raw_table)
    mq.delay(100)
    -- for x = 0, #shopping_list do print("\ag", shopping_list[x]) end

    -- shop!
    -- go_shopping(shopping_list)

    -- if it requires a cut tool then get we need 2 square tools?
    -- go_craft(recipe_list, 0)
    return
end

-- Graveyard

local function return_primary_buy_count_for_secondary(p_id, p_id1, p_pnc)
    -- divide for PID..
    --  local fv_cr = Return_Calling_Recipe_Row_Count(p_id, p_id1)
    --  local fv_mid = Return_Item_ID(p_id)
    -- local fv_hc = mq.TLO.FindItemCount(fv_mid)()
    -- local fv_nc = (p_pnc - fv_hc) * fv_cr
    --  local fv_yc = Return_Recipe_Yield(p_id)
    --  local fv_bc = math.ceil(fv_nc / fv_yc)
    --  return fv_bc
end
---------------

-- returns buy count without checking inventory
local function return_recipe_total_buy_count(rr_id, rr_id1, rr_pnc)
    local fv_hc = mq.TLO.FindItemCount(rr_id)()
    -- local fv_yc = Return_Recipe_Yield(rr_id)
    local fv_nc = rr_pnc - fv_hc
    -- if > logic and < logic for 0 and -
    -- local fv_pbc = math.ceil(fv_nc / fv_yc)
    -- local fv_cr = Return_Calling_Recipe_Row_Count(rr_id, rr_id1)
    -- if fv_cr == nil then
    print "\arNil Error TCN_Lib"
    print "check the item ids 1 ,2 .. 3 ,4 etc"
    mq.exit()
    return
end
--  fv_nc = fv_pbc * fv_cr
--  fv_yc = Return_Recipe_Yield(rr_id1)
--  local fv_bc = math.ceil(fv_nc / fv_yc)
--  if fv_bc < 0 then fv_bc = 0 end
--  return fv_bc
-- end

function library.return_primary_item()
    -- Return Primary Item
    if GLOBAL_PRIMARY_SLOT == nil then return false end
    if GLOBAL_PRIMARY_SLOT == mq.TLO.Me.Inventory(13).ID() then return false end
    -- GrabItemID(GLOBAL_PRIMARY_SLOT)
    library.GrabItemID(GLOBAL_PRIMARY_SLOT, 1)
    print(msg, "\ap[\agReturning\ap \ap[\aw",
        mq.TLO.FindItem(GLOBAL_PRIMARY_SLOT)(), "\ap]")
    mq.delay(1000)
    mq.cmd('/nomodkey /itemnotify 13 leftmouseup')
    mq.delay(1000)
    library.ClearCursor()
    return true
end

function library.swap_primary_item()
    -- No Bone Rod
    if mq.TLO.FindItemCount(151934)() < 1 then return end
    -- Bone Rod Already in primary
    if mq.TLO.Me.Inventory(13).ID() == 151934 then return end
    -- Bone Rod
    if mq.TLO.Me.Inventory(13)() == nil then
        -- just swap item in
        -- GrabItemID(151934)
        library.GrabItemID(151934, 1)
        mq.delay(1000)
        mq.cmd('/nomodkey /itemnotify 13 leftmouseup')
        mq.delay(1000)
        print(msg, "\ap[\agUsing\ap] \ap[\awThe Bone Rod\ap]")
    else
        library.GrabItemID(151934, 1)
        -- GrabItemID(151934)
        mq.delay(300)
        mq.cmd('/nomodkey /itemnotify 13 leftmouseup')
        mq.delay(500)
        library.ClearCursor()
        print(msg, "\ap[\agUsing\ap] \ap[\awThe Bone Rod\ap]")
        GLOBAL_STANDARD_CRAFTING_STATUS_MSG = "Using The Bone Rod"
    end
end

function library.trophy_selector(p_rid)
    if GLOBAL_TROPHY_FLAG == 1 then
        local cs = library.return_container_skill(p_rid)

        -- print(cs)

        if cs == nil then
            print(msg, "TCN_Craft Invalid Recipe ID: \ag", p_rid, " \ayError")
            os.exit()
        end

        local trophy_have = library.have_trophy(cs)

        -- Swap The Bone Rod -- 151934
        -- Brell's Testing -- 29193
        if cs == "Fishing" and mq.TLO.FindItemCount(151934)() > 0 then
            library.swap_primary_item()
        end

        if mq.TLO.FindItemCount(trophy_have)() > 0 and trophy_have ~= nil then
            local l_trophy_id = mq.TLO.FindItem(trophy_have).ID()

            --  print(l_trophy_id," ",mq.TLO.Me.Inventory(22).ID())

            -- Item in slot already - return
            if mq.TLO.Me.Inventory(22).ID() == l_trophy_id then
                return
            end

            local inv_slots = { "11", "13", "14", "22" }

            local swap_flag = 1
            for x = 1, #inv_slots do
                local trophy_slot = tostring(
                    mq.TLO.FindItem(trophy_have).ItemSlot())
                if trophy_slot == inv_slots[x] then
                    swap_flag = 0
                    break
                end
            end

            if swap_flag == 1 then
                -- Record what is in ammo slot to return later
                if mq.TLO.Me.Inventory(22)() == nil then
                    library.GrabItemID(l_trophy_id, 1)
                    -- print(l_trophy_id)
                    mq.delay(1000)
                    mq.cmd('/nomodkey /itemnotify 22 leftmouseup')
                    mq.delay(1000)
                    print(msg, "\ap[\agUsing\ap] \ap[\aw", trophy_have, "\ap]")

                    GLOBAL_STANDARD_CRAFTING_STATUS_MSG = "Using " ..
                        trophy_have
                else
                    -- l_ammo_slot_id = GLOBAL_AMMO_SLOT

                    library.GrabItemID(l_trophy_id, 1)

                    -- print(l_trophy_id)

                    mq.delay(300)
                    mq.cmd('/nomodkey /itemnotify 22 leftmouseup')
                    -- print("was it swapped? ammo: ",mq.TLO.Me.Inventory(22).ID())
                    mq.delay(300)

                    library.ClearCursor()

                    -- swap to originating slot
                    --   mq.cmd('/nomodkey /itemnotify 22 leftmouseup')
                    --  mq.delay(500)
                    --  lib.GrabItemID(l_trophy_id, 1)
                    --  mq.delay(500)
                    --  mq.cmd('/nomodkey /itemnotify 22 leftmouseup')
                    print(msg, "\ag[Using] \ap[\aw", trophy_have, "\ap]")

                    GLOBAL_STANDARD_CRAFTING_STATUS_MSG = "Using " ..
                        trophy_have
                end
            end
        end

        -- print("in ammo: ",mq.TLO.Me.Inventory(22).ID())
        --  mq.cmd('/lua pause')
    end

    return
end

function library.swap_ammo_slot_back(p_item_id)
    mq.delay(1)

    if mq.TLO.FindItem(p_item_id)() == nil or mq.TLO.FindItemCount(p_item_id)() <
        1 then
        return
    end

    if mq.TLO.Me.Inventory(22).ID() == p_item_id then return end
    if mq.TLO.Me.Inventory(22).ID() == nil then return end

    if p_item_id == nil or p_item_id == 0 then return end

    if mq.TLO.Me.Inventory(22).ID() ~= nil then
        mq.cmd('/nomodkey /itemnotify 22 leftmouseup')
        -- was 750 speed change 1/12/22
        mq.delay(200)
    end

    library.GrabItemID(p_item_id, 1)

    mq.delay(200)

    print(msg, "\ap[\agReturning\ap \ap[\aw", mq.TLO.FindItem(p_item_id)(),
        "\ap]")
    -- mq.delay(500)
    mq.cmd('/nomodkey /itemnotify 22 leftmouseup')
    -- mq.delay(500)
    mq.delay(200)
    library.ClearCursor()
    return
end

return library

-- save for (SQL) reference
--  local sql = "INSERT INTO ShoppingRecipeTable VALUES ('" ..
--  list_row2.ItemID .. "', '" ..
--  list_row2.ItemName .. "','" .. tv_rv ..
--  "' ,'" .. list_row2.SubRecipeID .. "','" .. tv_yc *
--  tv_rv .. "')"
