-- tcn_tool_kit
-- 1.1a
-- jb321
-- created: 10/18/2024
-- upd 10/20/2024
local mq = require('mq')
--
local shop = require('tcn_shoplist')
--
local movement = require('tcn_movement')

-- Functions

-- Open static container if closed
local function open_static_container(p_craft_container)

    -- fix later
    if p_craft_container == "Fly Making Bench" then
        p_craft_container = "Fishing Table"
    end

    if mq.TLO.Window('TradeSkillWnd').Open() then return end
    mq.delay(750)
    if mq.TLO.ItemTarget() == nil then
        mq.cmd('/squelch /itemtarget ' .. p_craft_container)
    end

    if mq.TLO.ItemTarget.Distance() > 20 then
        mq.cmd('/squelch /nav item|dist=15 log=off')
        while mq.TLO.Nav.Active() do mq.delay(1) end
    end

    mq.cmd('/click left item')

    mq.delay(2000)
    while not mq.TLO.Window('TradeSkillWnd').Open() do mq.delay(10) end
    return
end
-- 
-- Click experiment button
local function experiment()

    -- Stupid Depot
    -- lib.ClearCursor()
    mq.delay(1)

    -- if container is open already just return.. --combine items
    if mq.TLO.Window('ContainerCombine_Items').Open() then return end

    -- print(msg, "\ap[\agExperimenting\ap]")

    -- Change to wait and click..
    while not mq.TLO.Window('TradeskillWnd').Child('ExperimentButton').Enabled() do
        mq.delay(10)
    end
    mq.cmd('/notify TradeskillWnd COMBW_ExperimentButton leftmouseup')
    mq.delay(750)
    -- DBG UI stuff -- was 4000
    mq.delay(500)
    return
end
--
-- Grab a Single Item BY ID
local function GrabItemID(p_id)

    mq.delay(1)

    local l_id = p_id

    if mq.TLO.FindItemCount(l_id)() < 1 or mq.TLO.FindItem(l_id)() == nil then
        print("Nothing found to grab")
        return
    end

    mq.delay(1)

    local l_count = 1

    local slot2 = mq.TLO.FindItem(l_id).ItemSlot2() + 1

    if slot2 == 0 then

        -- Workaround for UI interference
        if GLOBAL_STANDARD_UI == 1 then mq.delay(2000) end

        -- Not in bag
        local slot1 = mq.TLO.FindItem(l_id).ItemSlot()

        if l_count == 1 then
            mq.cmd('/ctrl /itemnotify ' .. slot1 .. ' leftmouseup')
            -- mq.delay(1000)
            mq.delay(200)
        end

    else
        -- In bag

        mq.delay(1)
        local pack = mq.TLO.FindItem(l_id).ItemSlot() - 22
        -- Workaround for UI interference
        if GLOBAL_STANDARD_UI == 1 then mq.delay(2000) end

        mq.delay(1)

        if l_count == 1 then

            mq.delay(1)

            mq.cmd('/ctrl /itemnotify in pack' .. pack .. ' ' .. slot2 ..
                       ' leftmouseup')
            mq.delay(200)
            -- extra delay DBG screw up
            -- mq.delay(100)
        end

    end

    if mq.TLO.Cursor.Name == nil or mq.TLO.Cursor.Name == "NULL" then
        mq.exit()
    end
    -- mq.cmd('/lua pause')

    return
end
--

local msg = "\ap[\atTCSNe\auX\att\ap]\aw "

-- Vendors in POK
-- Audri Deepfacet, Noirin Khalen, Jeweler Nonny

-- 37804	Duo Setting Tool
-- 95829	Half-Moon Cut Tool
-- 95827	Round Cut Tool
-- 95826	Square Cut Tool
-- 37805	Trio Setting Tool
-- 37803	Solo Setting Tool
-- 95828	Oval Cut Tool
-- 95830	Trillion Cut Tool
-- 95831	Pear Cut Tool
-- 95832	Marquise Cut Tool

-- Conversion Order
-- Square | Round (1) | Oval (2) | Half-Moon (3) | Trillion (4) | Pear (5) | Marquise (6) | Solo Setting Tool (7) | Duo Setting Tool (8) | Trio Setting Tool (9)

if mq.TLO.Zone.ID() ~= 202 then
    print(msg, "Please travel to POK to execute this")
    return
end

local tool_ids = {
    95827, 95828, 95829, 95830, 95831, 95832, 37803, 37804, 37805, 95826
}

local tool_table = {}

for c = 1, #tool_ids do
    if mq.TLO.FindItemBankCount(tool_ids[c])() > 0 or
        mq.TLO.FindItemCount(tool_ids[c])() > 0 then
        -- Do Nothing 
    else
        --  print(tool_ids[c])
        table.insert(tool_table, tool_ids[c])
    end
end

-- print(#tool_table)

-- No Tools to Buy or Convert
if #tool_table < 1 then
    print(msg, " No tools to buy or convert")
    return
end

-- print(mq.TLO.Me.ExpansionFlags())
-- print(mq.TLO.Me.HaveExpansion(19)())

local H_E = mq.TLO.Me.HaveExpansion(19)()

local npc = "Audri Deepfacet"

if H_E then npc = "Jeweler Nonny" end

-- Head to vendor
movement.npc(npc)

if not mq.TLO.Merchant.Open() then
    --   mq.cmd('/nomodkey /click right target')
    repeat
        mq.TLO.Merchant.OpenWindow()
        mq.delay(100)
        if GLOBAL_ABORT_FLAG == 1 then break end
    until mq.TLO.Merchant.Open()
end

-- Wait until the merchant list populated
while mq.TLO.Merchant.ItemsReceived() ~= true do mq.delay(100) end

local ItemAmount = #tool_table
local p_ItemID = 95826

BUY_MULT = 0

-- un rem later
shop.buy_item(ItemAmount, p_ItemID)

-- Close Vendor window when done shopping overall
if mq.TLO.Merchant.Open() then
    mq.delay(500)
    mq.TLO.Window('MerchantWnd').DoClose()
    mq.delay(500)
end

-- Add in jewelry bag usage - for portable container

-- Do PRE-ROF TLP check
-- expansion #..

-- Move to Container
movement.container("Jewelry Making Table")

if mq.TLO.ItemTarget() == nil then
    print(msg, "Jewelry Making Table", " \ap[\awNot selected\ap]")
    return
end

open_static_container("Jewelry Making Table")
mq.delay(1000)

experiment()
mq.delay(1000)

for c = 1, #tool_table do

    -- print(tool_table[c]) 

    -- Grab Square Cut Tool from Inventory
    GrabItemID(95826)
    mq.delay(1000)

    -- Place item in container environment slot 1
    mq.cmd('/nomodkey /itemnotify enviro1 leftmouseup')
    mq.delay(1000)

    -- Combine
    mq.cmd('/notify ContainerCombine_Items Container_Combine leftmouseup')
    mq.delay(2000)

    local l_id = 0

    while true do

        l_id = mq.TLO.Cursor.ID()

        if l_id == tool_table[c] then
            -- print(l_id)
            print(msg, "\atWe have made: \ag" .. mq.TLO.Cursor.Name())
            mq.cmd('/autoinv')
            break
        end

        -- Place item in container environment slot 1
        mq.cmd('/nomodkey /itemnotify enviro1 leftmouseup')
        mq.delay(1000)

        -- Combine
        mq.cmd('/notify ContainerCombine_Items Container_Combine leftmouseup')
        mq.delay(2000)

    end

end

mq.delay(1000)
mq.cmd('/cleanup')
mq.delay(3000)

-- If We don't have the square, buy it
if mq.TLO.FindItemBankCount(95826)() < 1 and mq.TLO.FindItemCount(95826)() < 1 then

    H_E = mq.TLO.Me.HaveExpansion(19)()

    npc = "Audri Deepfacet"

    if H_E then npc = "Jeweler Nonny" end

    -- Head to vendor
    movement.npc(npc)

    if not mq.TLO.Merchant.Open() then
        --   mq.cmd('/nomodkey /click right target')
        repeat
            mq.TLO.Merchant.OpenWindow()
            mq.delay(100)
            if GLOBAL_ABORT_FLAG == 1 then break end
        until mq.TLO.Merchant.Open()
    end

    -- Wait until the merchant list populated
    while mq.TLO.Merchant.ItemsReceived() ~= true do mq.delay(100) end

    ItemAmount = #tool_table
    p_ItemID = 95826

    BUY_MULT = 0

    -- un rem later
    shop.buy_item(ItemAmount, p_ItemID)

    -- Close Vendor window when done shopping overall
    if mq.TLO.Merchant.Open() then
        mq.delay(500)
        mq.TLO.Window('MerchantWnd').DoClose()
        mq.delay(500)
    end

end

mq.delay(1000)
mq.cmd('/cleanup')
mq.delay(3000)

print(msg,
      "You should now have all the cut tools, you can deposit these using the Deposit Items Button or leave them on person")

-- Use Deposit for now in utilties menu
