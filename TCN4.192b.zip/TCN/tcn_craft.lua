local mq = require('mq')
local movement = require('TCN_Movement')
local lib = require('TCN_Library')

-- TCN_craft.lua
-- Version 2.22b
-- Date: 8/30/2021
-- UPDATED: 05/16/2025
-- creator: JB321

---changed all mq.delay(1000) to 750

-- Explain: more to come
-- Usage: craft.main (6905,4,0,0)
--		  Recipe ID   , Make Count.. 

-- Declarations
local l_make_count = 0
local l_quest_recipe_id = 0
local l_ammo_slot_id = GLOBAL_AMMO_SLOT

-- Knowledge lacking flag
GLOBAL_GOD_NOCOMBINE_FLAG = 0

local cn = ""

local msg = "\ap[\atTCSNe\auX\att\ap]\aw "

local lv_missing_components = 1

local function check_artisan_destruction_list()

    local var_x = 0

    -- Artisan NoDestroy Code
    if mq.TLO.Cursor.ID() ~= nil then
        local nd_artisan_array_list = lib.read_no_destroy()
        local nd_artisan_array_len = string.len(nd_artisan_array_list[1])
        if nd_artisan_array_len < 1 then
            -- print(msg, "No Artisan Destroy Data")
        else
            for c = 1, #nd_artisan_array_list do
                if mq.TLO.Cursor.ID() == tonumber(nd_artisan_array_list[c]) then
                    print(msg, "\ap[\agNot Destroying:\ap] \ap[\aw",
                          mq.TLO.Cursor.Name(), "\ap]")
                    mq.delay(300)
                    var_x = 1
                    break
                end
            end
        end
    end

    return var_x
end

-- Cycles through tools on cursor and inventories them 1 by 1 x 4
local function inventory_tools()

    local bought_tool_array = {
        38511, 38512, 38513, 38514, 38515, 10489, 10425, 81673, 81671, 81670,
        81677, 81679, 10477, 10479, 11397, 81669, 10478, 81676, 98305, 81672,
        81678, 81674, 81675, 29546, 95818, 95825, 95811, 95814, 95821, 95807,
        95806, 95820, 95813, 95810, 95824, 95817, 95808, 95822, 95815, 37800,
        37802, 37798, 37801, 37799, 37803, 8086, 21625, 95826, 8893, 37804,
        95827, 95828, 95829, 95830, 95831, 95832, 7052, 152401, 8085, 29820,
        29816, 29824, 9471, 24095, 24096, 24097, 24098, 34914, 81661, 65255,
        65189, 81666, 81668, 81663, 65167, 81665, 98304, 81660, 65145, 81667,
        65233, 65211, 81664, 10064, 16361, 152402, 152403, 152404, 152405,
        152406, 152407, 152408
    }

    for d = 1, 4 do
        for c = 1, #bought_tool_array do
            local curs_ID = mq.TLO.Cursor.ID()
            if curs_ID == bought_tool_array[c] then
                mq.cmd('/autoinv')
                mq.delay(1500)
            end
        end
    end
    return
end

local function what_spell_kit()
    -- Casters
    local caster_classes = {NEC = true, WIZ = true, MAG = true, ENC = true}
    local my_class = mq.TLO.Me.Class.ShortName()
    if caster_classes[my_class] then return "Spell Research Kit" end

    -- Priests
    local priest_classes = {CLR = true, DRU = true, SHM = true}
    my_class = mq.TLO.Me.Class.ShortName()
    if priest_classes[my_class] then return "Prayer Writing Kit" end

    -- Bard
    local brd_classes = {BRD = true}
    my_class = mq.TLO.Me.Class.ShortName()
    if brd_classes[my_class] then return "Song Writing Kit" end

    -- Hybrid
    local hybrid_classes = {PAL = true, RNG = true, SHD = true, BST = true}
    my_class = mq.TLO.Me.Class.ShortName()
    if hybrid_classes[my_class] then return "Hybrid Research Kit" end

    -- Melee
    local melee_classes = {WAR = true, MNK = true, ROG = true, BER = true}
    my_class = mq.TLO.Me.Class.ShortName()
    if melee_classes[my_class] then return "Tome Binding Kit" end
end

local function event_a()
    lv_missing_components = 0
    -- better just do a single recipe check and abort?
    return
end

local function event_b()
    print(msg, "\ap[\ayWARNING: \awNot experienced enough\ap]")
    CRAFT_STATUS_FLAG = 1
    EXP_FLAG = 1
    return
end

local function event_c()
    print(msg,
          "\ap[\ayWARNING: \awCan't Combine these items in this container type\ap]")
    CRAFT_STATUS_FLAG = 2
    return
end

local function event_task_update(line, p_result)
    -- print(msg, "\ap[\agTask Update: \aw", p_result, "\ap]")
    GLOBAL_TASK_UPDATE = 1
    return
end

local function MadeItem() return end

-- Event Functions
local function event_failed(line, pResult)
    --  if pResult ~= nil then
    --  print(msg, "\ap[\agFailed\ap] \ap[\aw", pResult, "\ap]")
    GLOBAL_MAX_FAILED_FLAG = 1
    -- end
    return
end

local function Learned_New_Recipe(line, pResult)
    --  if pResult ~= nil then
    -- remove !
    pResult = string.gsub(pResult, "!", '')
    print(msg, "\ap[\agLearned\ap] \ap[\aw", pResult, "\ap]")
    GLOBAL_MAX_LEARNED_FLAG = 1
    GLOBAL_TEXT = "Learned: " .. pResult
    mq.delay(1)
    return
end

local function event_know()
    print(msg,
          "\ap[\ayWARNING: \awYou are not able to work with this material becuase you lack the knowledge\ap]")
    print(msg,
          "\ap[\ayWARNING: \awThis may be a result of not doing the Gates of Discord TS Freebies\ap]")
    GLOBAL_GOD_NOCOMBINE_FLAG = 1
    mq.delay(1)
    return
end

local function event_lore_combine()
    GLOBAL_LORE_FLAG = 1
    mq.delay(1)
    return
end

local function event_seems_combine()
    GLOBAL_LORE_FLAG = 1
    print(msg, "Recipe is correct, \atbut you need to know something more.")
    mq.delay(1)
    return
end

mq.event('learnt', "You have learned the recipe #1#", Learned_New_Recipe)

-- log each success and win.. and add them up and then delete file

-- missing?
mq.event('NoLonger', "Sorry, but#*#", event_a)

mq.event('NoExp', "You are too inexperienced in your craft#*#", event_b)

mq.event('NoComb', "You cannot combine these items#*#", event_c)

mq.event('NoKnown', "You lack the knowledge to work with this material.",
         event_know)

mq.event('YouLack', "You lacked the skills to fashion #1#", event_failed)

mq.event('TaskUpdate', "Your task |#1#| has been updated#*#", event_task_update)

mq.event('Seems', "This seems correct#*#", event_seems_combine)

mq.event('LoreUpdate', "That combine would result in a LORE#*#",
         event_lore_combine)

mq.event('YouMadeAnItem',
         "You have fashioned the items together to create something new: #1#",
         MadeItem)

-- Local Functions

local function place_medium_clay_jar()
    if GLOBAL_ABORT_FLAG == 1 then return end

    local craft_container = "Medium Clay Jar"

    mq.delay(350)
    -- was
    -- mq.delay(1500)

    -- Live Servers most bottom right slot
    local special_slot = 32
    -- Slot Iterator for Live
    local bag_iter = 31

    -- TLP Server
    if mq.TLO.MacroQuest.Server() == "rizlona" or mq.TLO.MacroQuest.Server() ==
        "mischief" or mq.TLO.MacroQuest.Server() == "thornblade" or
        mq.TLO.MacroQuest.Server() == "yelinak" then
        special_slot = 30
        bag_iter = 29
    end

    -- Live Server
    if mq.TLO.Me.Inventory(special_slot)() ~= craft_container then
        local item_type = {
            "Baking", "Medicine", "Fletching", "Jewelry Making", "Mixing",
            "Tinkering", "Make Poison", "Food", "Drink", "Misc", "Book",
            "Combinable", "Lexicon", "Alchemy", "Shield", "Armor", "nil"
        }

        local swappable = 0

        for x = 0, #item_type do
            if mq.TLO.Me.Inventory(special_slot).Type() ~= item_type[x] then
                swappable = 1
                mq.delay(100)
            end
        end

        mq.delay(350)
        -- was
        -- mq.delay(1500)

        if swappable == 1 then
            mq.cmd('/ctrl /itemnotify "' .. craft_container .. '" leftmouseup')
            mq.delay(1500)
            mq.cmd('/nomodkey /itemnotify ' .. special_slot .. ' leftmouseup')
            mq.delay(750)
            lib.ClearCursor()
        end

        lib.ClearCursor()

        mq.delay(750)

        if swappable == 0 then
            local move_slot = 0

            for x = bag_iter, 23, -1 do
                if mq.TLO.Me.Inventory(x)() == nil then
                    move_slot = x
                end
            end

            if move_slot ~= 0 then
                mq.cmd('/nomodkey /itemnotify ' .. special_slot ..
                           ' leftmouseup')
                mq.delay(750)
                mq.cmd('/ctrl /itemnotify "' .. move_slot .. '" leftmouseup')
                mq.delay(750)
                mq.cmd('/ctrl /itemnotify "' .. craft_container ..
                           '" leftmouseup')
                mq.delay(750)
                mq.cmd('/ctrl /itemnotify ' .. special_slot .. ' leftmouseup')
                mq.delay(750)
            end

        end
    end

    mq.delay(300)

    if mq.TLO.Me.Inventory(special_slot)() ~= craft_container then
        print(msg,
              "\ay[We Failed Somehow to put the portable container in slot " ..
                  special_slot .. "  Routine TCN_Craft]")
        -- change to flag and return-- fix
        print(msg, "\ap[\ayPausing\ap] \ap[\agUnable to place ",
              craft_container, " in a inventory slot\ap]")
        mq.cmd('/lua pause tcn')
        -- os.exit()
    end

end

local function open_medium_clay_jar()
    -- Add: Already open return
    -- Add: Open container by ID
    -- Live Servers most bottom right slot
    local special_slot = 32
    -- TLP Server
    if mq.TLO.MacroQuest.Server() == "rizlona" or mq.TLO.MacroQuest.Server() ==
        "mischief" or mq.TLO.MacroQuest.Server() == "thornblade" or
        mq.TLO.MacroQuest.Server() == "yelinak" then special_slot = 30 end
    local pack = special_slot
    if mq.TLO.Window('pack' .. pack).Open() == nil then
        mq.cmd('/nomodkey /itemnotify ' .. pack .. ' rightmouseup')
        mq.delay(1000)
    end
end

local function place_components_in_jar(p_id)

    local a_craft_item, a_craft_item_normal = lib.craft_preparation(p_id)

    -- open jar experiment

    -- local pack = mq.TLO.FindItem(17961).ItemSlot() - 22

    -- Live Servers most bottom right slot
    local special_slot = 32
    -- Slot Iterator for Live

    -- TLP Server
    if mq.TLO.MacroQuest.Server() == "rizlona" or mq.TLO.MacroQuest.Server() ==
        "mischief" or mq.TLO.MacroQuest.Server() == "thornblade" or
        mq.TLO.MacroQuest.Server() == "yelinak" then special_slot = 30 end

    -- for live not tlp add that in

    local d = 0
    local pack = special_slot - 22

    for c = 0, #a_craft_item do
        --  print(a_craft_item[c])
        d = c + 1
        lib.GrabItemID(a_craft_item[c], 1)
        mq.delay(1)
        mq.cmd('/itemnotify in pack' .. pack .. " " .. d .. ' leftmouseup')
        mq.delay(500)
    end

end

local function combine_medium_clay_jar()
    mq.cmd('/notify ContainerCombine_Items Container_Combine leftmouseup')
    mq.delay(2000)
    lib.ClearCursor()
    mq.delay(1000)
end

local function dye_check(p_id)
    local dye_array = {
        5150001, 5150002, 5160001, 5150003, 5150004, 5150005, 5150006, 5150007,
        5150008, 5150009, 5150010, 5150011, 5150012, 5150013, 5150014, 5150015,
        5150016
    }
    local dye_recipe = 0
    for c = 1, #dye_array do
        if p_id == dye_array[c] then
            dye_recipe = 1
            break
        end
    end
    return dye_recipe
end

local function return_primary_item()
    local zz = 1
    if zz == 1 then return end
    -- Return Primary Item
    if GLOBAL_PRIMARY_SLOT == nil then return false end
    if GLOBAL_PRIMARY_SLOT == mq.TLO.Me.Inventory(13).ID() then return false end
    -- GrabItemID(GLOBAL_PRIMARY_SLOT)
    lib.GrabItemID(GLOBAL_PRIMARY_SLOT, 1)
    print(msg, "\ap[\agReturning\ap \ap[\aw",
          mq.TLO.FindItem(GLOBAL_PRIMARY_SLOT)(), "\ap]")
    mq.delay(1000)
    mq.cmd('/nomodkey /itemnotify 13 leftmouseup')
    mq.delay(1000)
    lib.ClearCursor()
    return true
end

local function swap_primary_item()
    local zz = 1
    if zz == 1 then return end
    -- No Bone Rod
    if mq.TLO.FindItemCount(151934)() < 1 then return end
    -- Bone Rod Already in primary
    if mq.TLO.Me.Inventory(13).ID() == 151934 then return end
    -- Bone Rod
    if mq.TLO.Me.Inventory(13)() == nil then
        -- just swap item in
        -- GrabItemID(151934)
        lib.GrabItemID(151934, 1)
        mq.delay(1000)
        mq.cmd('/nomodkey /itemnotify 13 leftmouseup')
        mq.delay(1000)
        print(msg, "\ap[\agUsing\ap] \ap[\awThe Bone Rod\ap]")
    else
        lib.GrabItemID(151934, 1)
        -- GrabItemID(151934)
        mq.delay(300)
        mq.cmd('/nomodkey /itemnotify 13 leftmouseup')
        mq.delay(500)
        lib.ClearCursor()
        print(msg, "\ap[\agUsing\ap] \ap[\awThe Bone Rod\ap]")
        GLOBAL_STANDARD_CRAFTING_STATUS_MSG = "Using The Bone Rod"
    end
end

local function swap_ammo_slot_back(p_item_id)
    local zz = 1
    if zz == 1 then return end

    mq.delay(1)

    if mq.TLO.FindItem(p_item_id)() == nil or mq.TLO.FindItemCount(p_item_id)() <
        1 then return end

    if mq.TLO.Me.Inventory(22).ID() == p_item_id then return end
    if mq.TLO.Me.Inventory(22).ID() == nil then return end

    if p_item_id == nil or p_item_id == 0 then return end

    if mq.TLO.Me.Inventory(22).ID() ~= nil then
        mq.cmd('/nomodkey /itemnotify 22 leftmouseup')
        -- was 750 speed change 1/12/22
        mq.delay(200)
    end

    lib.GrabItemID(p_item_id, 1)

    mq.delay(200)

    print(msg, "\ap[\agReturning\ap \ap[\aw", mq.TLO.FindItem(p_item_id)(),
          "\ap]")
    -- mq.delay(500)
    mq.cmd('/nomodkey /itemnotify 22 leftmouseup')
    -- mq.delay(500)
    mq.delay(200)
    lib.ClearCursor()
    return
end

local function tsui_click_auto_inv()
    if mq.TLO.Cursor.ID() ~= nil then
        mq.cmd('/notify TradeskillWnd COMBW_AutoInvButton leftmouseup')
        mq.delay(500)
    end
end

local function tsui_disable_make_all()
    if mq.TLO.Window('TradeskillWnd').Child('MakeAllCheckBox').Checked() then
        mq.cmd('/notify TradeskillWnd COMBW_MakeAllCheckbox leftmouseup')
        mq.delay(500)
    end
end

-- Change from windowstate
local function close_inventory_window()
    if mq.TLO.Window('InventoryWindow').Open() then
        mq.cmd('/squelch /windowstate InventoryWindow close')
        mq.delay(100)
    end
    return
end

local function experiment()

    -- Stupid Depot
    lib.ClearCursor()
    mq.delay(1)

    -- if container is open already just return.. --combine items
    if mq.TLO.Window('ContainerCombine_Items').Open() then return end

    -- print(msg, "\ap[\agExperimenting\ap]")

    -- Change to wait and click..
    while not mq.TLO.Window('TradeskillWnd').Child('ExperimentButton').Enabled() do
        mq.delay(10)
    end
    mq.cmd('/notify TradeskillWnd COMBW_ExperimentButton leftmouseup')
    mq.delay(750)
    -- DBG UI stuff -- was 4000
    mq.delay(500)
    return
end

--  while not mq.TLO.Window('TradeskillWnd').Child('ExperimentButton').Enabled() do
--     mq.delay(10)
--  end

-- Open static container if closed
local function open_static_container(p_craft_container)

    -- fix later
    if p_craft_container == "Fly Making Bench" then
        p_craft_container = "Fishing Table"
    end

    if mq.TLO.Window('TradeSkillWnd').Open() then return end
    mq.delay(750)
    if mq.TLO.ItemTarget() == nil then
        mq.cmd('/squelch /itemtarget ' .. p_craft_container)
    end

    if mq.TLO.ItemTarget.Distance() > 20 then
        mq.cmd('/squelch /nav item|dist=15 log=off')
        while mq.TLO.Nav.Active() do mq.delay(1) end
    end

    mq.cmd('/click left item')

    mq.delay(2000)
    while not mq.TLO.Window('TradeSkillWnd').Open() do mq.delay(10) end
    return
end

-- Empty out static container based on slot that is occupied
local function clean_static_container()
    for x = 1, 10 do
        if mq.TLO.InvSlot("enviro" .. x).Item.ID() ~= nil then
            --  local str = "enviro" .. x
            mq.cmd('/itemnotify enviro' .. x .. ' leftmouseup')
            mq.delay(300)
            lib.ClearCursor()
            -- print("number: ", x, " ", mq.TLO.InvSlot(str).Item.ID())
            --  mq.delay(100)
        end
        mq.delay(300)
    end

end

-- Determine if dialog box is open and message is stacked items (static container)
local function check_stacked_static()
    if mq.TLO.Window('ConfirmationDialogBox').Open() then
        local text_string = mq.TLO.Window('ConfirmationDialogBox/CD_TextOutput')
                                .Text()
        if string.find(text_string, "You may") then
            mq.delay(1)
            mq.TLO.Window('ConfirmationDialogBox').DoClose()
            mq.delay(1000)
            clean_static_container()
        end
    end
end

-- Picks up items and puts them in static container
local function populate_static_container(p_craft_array)
    local a_craft_static = p_craft_array
    -- Environment variable
    local ev
    local status_flag = 1
    for x = 0, #a_craft_static do
        ev = x + 1
        -- Missing an item - abort
        if mq.TLO.FindItemCount(a_craft_static[x])() < 1 then
            status_flag = 0
            clean_static_container()
            break
        end

        -- table.insert(GLOBAL_CRAFT_ARRAY,mq.TLO.FindItem(a_craft_static[x]).Icon())

        GLOBAL_CRAFT_ID = a_craft_static[x]

        -- Pick it up
        lib.GrabItemID(a_craft_static[x], 1)

        -- Put in container
        mq.cmd('/nomodkey /itemnotify enviro"' .. ev .. '" leftmouseup')

        -- was 300 11/29/2022
        mq.delay(200)
    end

    -- GLOBAL_CRAFT_ARRAY = {}

    GLOBAL_CRAFT_ID = 0

    return status_flag
end

local function learn_static_container(p_id, pa_craft_list, pa_craft_normal)

    if GLOBAL_ABORT_FLAG == 1 then return 3 end

    local a_craft_items = pa_craft_list
    local a_craft_normal = pa_craft_normal
    local l_rec_id = p_id
    local flag = 0

    local l_recipe_name = lib.return_recipe_name(l_rec_id)

    print(msg, "\ap[\agAttempting To Learn\ap] \ap[\aw", l_recipe_name, "\ap]")

    while true do

        if GLOBAL_ABORT_FLAG == 1 then break end

        -- Get flag from here

        ---should we move this?
        flag = lib.component_check(l_rec_id, a_craft_normal)
        -- missing components.. go home!
        if flag == 0 then
            flag = 1
            break
        end

        experiment()

        close_inventory_window()

        mq.delay(500)

        -- Container --Add text shaping for different skills/containers 

        local l_recipe_item_id = lib.return_item_recipe_id(l_rec_id)
        mq.delay(100)

        -- Populate static container with recipe items
        local status_flag = populate_static_container(a_craft_items)

        -- was 1500 delay changed
        mq.delay(100)
        if status_flag == 0 then
            flag = 4
            break
        end

        -- Combine
        mq.cmd('/notify ContainerCombine_Items Container_Combine leftmouseup')
        mq.delay(2000)

        check_stacked_static()

        inventory_tools()

        -- Egg Yolk Recipe (Auto Inventory Egg White)
        if p_id == 9996728 and mq.TLO.Cursor.ID() == 96729 then
            mq.cmd("/autoinv")
            -- Add issue handling later
            -- Checks: Cannot place item in inventory
            mq.delay(1500)
        end

        -- Learned without doevents (change)

        -- change to doevents
        if mq.TLO.Cursor.ID() == l_recipe_item_id then
            flag = 2
            -- print(msg, "Learned: ", rrn)
            lib.ClearCursor()
            clean_static_container()
            break
        end

        clean_static_container()

    end

    lib.ClearCursor()
    clean_static_container()

    if GLOBAL_ABORT_FLAG == 1 then
        mq.delay(750)
        return 3
    end

    mq.delay(750)
    return flag
end

-- Open portable container in Inventory
local function open_portable_container(p_container_name)
    -- Add: Already open return
    -- Add: Open container by ID
    mq.cmd('/shift /itemnotify "' .. p_container_name .. '" rightmouseup')
    mq.delay(1500)
    return
end

-- Added Return 11/17/21
-- Destroy item by ID
local function item_destroy(p_item_id)
    if p_item_id ~= 0 and mq.TLO.Cursor.ID() == p_item_id then
        local result = check_artisan_destruction_list()
        if result == 1 then
            -- Do nothing, does not destroy
        else
            print(msg, "\ap[\agAuto-Destroying\ap [\aw", mq.TLO.Cursor.Name(),
                  "\ap]")
            mq.delay(300)
            mq.cmd('/destroy')
            mq.delay(750)
        end
    end
    return
end

-- Empty portable container after recovered 
local function clean_portable_container(p_container_name)
    -- Items in the container
    local leftovers = mq.TLO.FindItem('=' .. p_container_name).Items()
    if leftovers < 1 then return end
    -- Container slot size
    local Container_Size = mq.TLO.Me.Inventory(32).Container()

    -- Rizlona/Mischief Crutching
    if mq.TLO.MacroQuest.Server() == "rizlona" or mq.TLO.MacroQuest.Server() ==
        "mischief" or mq.TLO.MacroQuest.Server() == "thornblade" or
        mq.TLO.MacroQuest.Server() == "yelinak" then
        Container_Size = mq.TLO.Me.Inventory(30).Container()
    end

    local pack = mq.TLO.FindItem('=' .. p_container_name).ItemSlot() - 22

    print(msg, "\ay[Cleaning:] ", p_container_name)
    for slot_iter = 1, Container_Size do
        mq.cmd('/shift /itemnotify in pack"' .. pack .. '" "' .. slot_iter ..
                   '" leftmouseup')
        mq.delay(500)
        lib.ClearCursor()
    end
    print(msg, "\ag[Cleansed:]  ", p_container_name)
    return
end

-- Determine if dialog box is open and message is stacked items
local function check_stacked_portable()
    if mq.TLO.Window('ConfirmationDialogBox').Open() then
        local text_string = mq.TLO.Window('ConfirmationDialogBox/CD_TextOutput')
                                .Text()
        if string.find(text_string, "You may") then
            mq.delay(1)
            mq.TLO.Window('ConfirmationDialogBox').DoClose()
            mq.delay(1000)
            clean_portable_container()
        end
    end
end

-- Validate / Remove
local function RecoveredItems()
    mq.delay(100)
    -- Clean Container
    clean_static_container()
    -- for x = 1, 10 do
    -- if mq.TLO.InvSlot("enviro" .. x).Item.ID() ~= nil then
    --    local str = "enviro" .. x
    --  mq.cmd('/itemnotify enviro' .. x .. ' leftmouseup')
    -- lib.ClearCursor()
    -- print("number: ", x, " ", mq.TLO.InvSlot(str).Item.ID())
    -- end
    --  mq.delay(1)
    -- end
    return
end

-- Portable Crafting
local function craft_portable(p_id)
    if GLOBAL_ABORT_FLAG == 1 then return end

    local a_craft_item, a_craft_item_normal = lib.craft_preparation(p_id)

    -- pass the container name
    local craft_container = cn
    mq.delay(350)
    -- was
    -- mq.delay(1500)

    -- Live Servers most bottom right slot
    local special_slot = 32
    -- Slot Iterator for Live
    local bag_iter = 31

    -- TLP Server
    if mq.TLO.MacroQuest.Server() == "rizlona" or mq.TLO.MacroQuest.Server() ==
        "mischief" or mq.TLO.MacroQuest.Server() == "thornblade" or
        mq.TLO.MacroQuest.Server() == "yelinak" then
        special_slot = 30
        bag_iter = 29
    end

    -- Live Server
    if mq.TLO.Me.Inventory(special_slot)() ~= craft_container then
        local item_type = {
            "Baking", "Medicine", "Fletching", "Jewelry Making", "Mixing",
            "Tinkering", "Make Poison", "Food", "Drink", "Misc", "Book",
            "Combinable", "Lexicon", "Alchemy", "Shield", "Armor", "nil"
        }

        local swappable = 0

        for x = 0, #item_type do
            if mq.TLO.Me.Inventory(special_slot).Type() ~= item_type[x] then
                swappable = 1
                mq.delay(100)
            end
        end

        mq.delay(350)
        -- was
        -- mq.delay(1500)

        if swappable == 1 then
            mq.cmd('/ctrl /itemnotify "' .. craft_container .. '" leftmouseup')
            mq.delay(1500)
            mq.cmd('/nomodkey /itemnotify ' .. special_slot .. ' leftmouseup')
            mq.delay(750)
            lib.ClearCursor()
        end

        lib.ClearCursor()
        mq.delay(750)

        if swappable == 0 then
            local move_slot = 0

            for x = bag_iter, 23, -1 do
                if mq.TLO.Me.Inventory(x)() == nil then
                    move_slot = x
                end
            end

            if move_slot ~= 0 then
                mq.cmd('/nomodkey /itemnotify ' .. special_slot ..
                           ' leftmouseup')
                mq.delay(750)
                mq.cmd('/ctrl /itemnotify "' .. move_slot .. '" leftmouseup')
                mq.delay(750)
                mq.cmd('/ctrl /itemnotify "' .. craft_container ..
                           '" leftmouseup')
                mq.delay(750)
                mq.cmd('/ctrl /itemnotify ' .. special_slot .. ' leftmouseup')
                mq.delay(750)
            end

        end
    end

    mq.delay(300)

    if mq.TLO.Me.Inventory(special_slot)() ~= craft_container then
        print(msg,
              "\ay[We Failed Somehow to put the portable container in slot " ..
                  special_slot .. "  Routine TCN_Craft]")
        -- change to flag and return-- fix
        print(msg, "\ap[\ayPausing\ap] \ap[\agUnable to place ", cn,
              " in a inventory slot\ap]")
        mq.cmd('/lua pause tcn')
        -- os.exit()
    end

    mq.delay(1000)

    -- Open Container in Inventory
    open_portable_container(craft_container)
    -- Experiment
    experiment()
    -- Wait until container is open
    while not mq.TLO.Window('ContainerCombine_Items').Open() do mq.delay(100) end

    mq.delay(500)

    local breaker = 0

    -- Container --if oven then baking or cooking, if pottery wheel then text shaping?
    local rrn = lib.return_recipe_name(p_id)
    print(msg, "\aw[Crafting:] \ag[", rrn, "]", " \at[IN:] \aw", cn)

    while true do

        clean_portable_container(craft_container)

        mq.delay(750)

        -- Missing items .. where to do this check? in here somewhere
        for x = 0, #a_craft_item_normal do
            -- return row count per recipe item
            mq.delay(300)
            local a = lib.return_item_row_count(p_id, a_craft_item_normal[x])
            if (mq.TLO.FindItemCount(a_craft_item_normal[x])() < a) then
                --  print("\ayMissing: ", a, " ", craft_item_normal_array[x])
                breaker = 1
                -- mq.cmd('/notify ContainerWindow CombineDoneButton leftmouseup')
                mq.delay(250)
            end
        end

        if (breaker == 1) then
            mq.cmd('/cleanup')
            break
        end

        local ev

        -- Array to use to pick up items and put in container..
        for x = 0, #a_craft_item do
            ev = x + 1

            --  local l_inv = mq.TLO.FindItemCount(a_craft_item[x])()

            lib.GrabItemID(a_craft_item[x], 1)

            -- Testing delay
            mq.delay(100)

            -- Notes:
            -- If there is 2 of any container after it is moved we record either one in pack 10 or pack 8.. 

            -- if Riz/Mischief/Thornblade/yelinak pack 8 and nothing then return
            -- if any other server pack 10 and nothing then return
            -- if nothing than issue, because we should have a container there      

            local pack = mq.TLO.FindItem(craft_container).ItemSlot() - 22

            -- Account for collection item Spitoon
            if craft_container == "Spit" then
                pack = mq.TLO.FindItem(17947).ItemSlot() - 22
                mq.delay(1)
            end

            mq.cmd('/nomodkey /itemnotify in pack"' .. pack .. '" "' .. ev ..
                       '" leftmouseup')
            mq.delay(300)
        end

        -- Add: Combine button ready check

        -- Combine
        mq.cmd('/notify ContainerCombine_Items Container_Combine leftmouseup')
        mq.delay(1500)

        check_stacked_portable()

        inventory_tools()

        -- Event checking
        local break_out = 0
        while true do
            mq.delay(1)
            mq.doevents()
            mq.doevents()
            mq.doevents()
            lib.event()
            break_out = break_out + 1
            if break_out > 9 then break end
        end

        if GLOBAL_LORE_FLAG == 1 then
            GLOBAL_LORE_FLAG = 0
            break
        end

        if GLOBAL_GOD_NOCOMBINE_FLAG == 1 then
            GLOBAL_GOD_NOCOMBINE_FLAG = 0
            break
        end

        local cursor_string = mq.TLO.Cursor.Name()

        -- Revisit

        -- If we fail any recipe, do not continue to craft if we have inventory
        if GLOBAL_MAX_CRAFTING == 1 and GLOBAL_MAX_FAILED_FLAG == 1 then
            lib.ClearCursor()
            GLOBAL_MAX_FAILED_FLAG = 0
            break
        end

        -- Get recipe item id
        local l_item_id = lib.return_item_id(p_id)
        local l_item_inv = mq.TLO.FindItemCount(l_item_id)()

        -- Successful Subcombine
        if GLOBAL_MAX_CRAFTING == 1 and mq.TLO.Cursor.ID() == l_item_id and
            l_item_id ~= GLOBAL_MAX_ITEM_ID and l_item_inv >= l_make_count then
            lib.ClearCursor()
            break
        end

        mq.delay(500)

        if GLOBAL_MAX_CRAFTING == 1 then
            if mq.TLO.Cursor.ID() ~= nil then

                local cursor_ID = mq.TLO.Cursor.ID()

                -- Not the main item
                if cursor_ID ~= GLOBAL_MAX_ITEM_ID then
                    -- Inventory tools prior to checking (Jeweler's Glass crafted)
                    if cursor_ID == 95833 then
                        mq.cmd('/autoinv')
                        mq.delay(1000)
                    end
                end

                -- Main MAX Recipe Check

                if mq.TLO.Cursor.ID() == GLOBAL_MAX_ITEM_ID then

                    local l_tradeskill =
                        mq.TLO.FindItem(mq.TLO.Cursor.ID()).Tradeskills()
                    -- add in for quests being worked on? artisan trophies etc?
                    local used = lib.return_max_used(GLOBAL_MAX_RECIPE_ID, 1)

                    if used == 1 then GLOBAL_MAX_USED = 1 end

                    -- Bypass tradeskill used check
                    -- used = 0
                    -- GLOBAL_MAX_USED = 0

                    -- Sell item under specific conditions
                    if mq.TLO.Cursor.Value() > GLOBAL_MAX_SELL_THRESHOLD * 1000 and
                        GLOBAL_MAX_SELL_FLAG == 1 and used == 0 then
                        break
                    end

                    -- Destroy items not used in other recipes
                    if GLOBAL_MAX_DESTROY_ID == mq.TLO.Cursor.ID() and used == 0 then
                        local l_cursor_count =
                            mq.TLO.FindItemCount(mq.TLO.Cursor.ID())()
                        --  print(cursor_string)

                        local destroy_go = 0

                        if cursor_string ~= nil then
                            if cursor_string ~= nil then
                                local result = check_artisan_destruction_list()
                                if result == 1 then
                                    destroy_go = 1
                                end
                            end
                        end

                        -- doevents -- set flag if flag = 1 then dont destroy
                        -- if task update don't destroy..
                        if destroy_go == 0 then
                            GLOBAL_TEXT = "Destroying " .. mq.TLO.Cursor()
                            print(msg, "\ap[\arDestroying\ap] (\ag",
                                  l_cursor_count, "\ap)\ap[\aw",
                                  lib.return_recipe_name(p_id), "\ap]")
                            mq.delay(750)
                            mq.cmd('/destroy')
                            mq.delay(750)
                        end

                        destroy_go = 0

                    end
                    --   if hc >= l_make_count then
                    --   -- print "TCN_Craft goal complete"
                    --     break
                    -- end

                    -- Trigger learned flag even if event didn't fire
                    GLOBAL_MAX_LEARNED_FLAG = 1

                    break
                end
            end
        else

            -- Add in quest checking for using portables

            -- Standard Crafting
            -- print("sell id: ", GLOBAL_STANDARD_SELL_ID, " threshold ",
            -- GLOBAL_STANDARD_SELL_THRESHOLD)

            if GLOBAL_STANDARD_SELL_ID ~= 0 and GLOBAL_STANDARD_SELL_ID ~= nil and
                mq.TLO.Cursor.Value() > GLOBAL_STANDARD_SELL_THRESHOLD then
                lib.ClearCursor()
            end

            if mq.TLO.Me.FreeInventory() < 3 and GLOBAL_STANDARD_SELL_ID ~= 0 and
                GLOBAL_STANDARD_SELL_ID ~= nil then
                -- Break and return to sell
                break
            end

            -- Destroy by ID option
            if GLOBAL_STANDARD_DESTROY_ID ~= 0 and GLOBAL_STANDARD_DESTROY_ID ~=
                nil then item_destroy(GLOBAL_STANDARD_DESTROY_ID) end

            -- Skill Up Check
            if GLOBAL_STANDARD_SKILL_ID ~= 0 and GLOBAL_STANDARD_SKILL_ID ==
                tonumber(p_id) then
                local l_recipe_skill = lib.return_recipe_skill(p_id)
                local l_recipe_trivial = lib.return_recipe_trivial(p_id)
                if mq.TLO.Me.Skill(l_recipe_skill)() >= l_recipe_trivial then
                    print(msg, l_recipe_skill, " Skill-Up Goal Met ",
                          l_recipe_trivial)
                    mq.delay(1)
                    mq.cmd('/cleanup')
                    --   SKILL_ID = 0
                    break
                end
            end
        end

        lib.ClearCursor()

        mq.delay(1)

        local rii = lib.return_item_id(p_id)
        local hc = mq.TLO.FindItemCount(rii)()

        -- Check Make Count Completion
        if hc >= l_make_count then break end

        -- This would break after every learned Max 350 recipe, not just the main ones
        -- if GLOBAL_MAX_LEARNED_FLAG == 1 and GLOBAL_MAX_CRAFTING == 1 then break end

        if GLOBAL_ABORT_FLAG == 1 then break end
    end
    return
end

local function craft_select(p_recipe_name)
    mq.delay(100)
    print(msg, "\ap[\awChecking Database...\ap]")
    mq.delay(100)

    -- print(p_recipe_name)

    if mq.TLO.Window('COMBW_RecipeListArea').Child('COMBW_RecipeList').List(
        '=' .. p_recipe_name)() then
        print(msg, "\ap[\aw", p_recipe_name, "\ap] [\agRecipe Found\ap]")
    else
        print(msg, "\ap[\aw", p_recipe_name, "\ap] [\aoRecipe Not Found\ap]")
        return 0
        -- os.exit()
    end

    mq.cmd(
        '/notify COMBW_RecipeListArea COMBW_RecipeList listselect ${Window[COMBW_RecipeListArea].Child[COMBW_RecipeList].List[=' ..
            p_recipe_name .. ']}')

    -- Delay for item selected
    mq.delay(750)
    return 1
end

local function craft_Search_UI(p_item_name, p_recipe_name)
    -- was 500 
    mq.delay(100)

    -- Add: Change to repeat until open

    while not mq.TLO.Window('TradeskillWnd').Open() do mq.delay(1) end
    -- Click in text box
    mq.cmd('/notify COMBW_SearchArea COMBW_SearchTextEdit leftmouseup')
    mq.delay(750)

    GLOBAL_TEXT = "Searching for recipe"

    -- Type text in box
    lib.type_chars(p_item_name)
    mq.delay(100)
    -- Search button ready
    -- print "Waiting for search button to become active"
    while not mq.TLO.Window('COMBW_SearchArea').Child('COMBW_SearchButton')
        .Enabled() do mq.delay(500) end
    -- Click search button
    mq.cmd('/notify COMBW_SearchArea COMBW_SearchButton leftmouseup')
    mq.delay(1000)
    -- Wait until populated
    while not mq.TLO.Window('COMBW_SearchArea').Child('COMBW_SearchButton')
        .Enabled() do mq.delay(500) end

    if mq.TLO.Window('COMBW_RecipeListArea').Child('COMBW_RecipeList').Items() ==
        0 then
        -- This just sees if there is any entry not the entry
        -- check item DB  item ID? for typos
        print(msg, "\ap[\ag", p_item_name, " \ap[\awNot Found\ap]")
        return 0
    end

    local select_result = craft_select(p_recipe_name)

    return select_result
end

-- Static Crafting
local function craft_static(p_id, p_container_name, p_options)

    if GLOBAL_ABORT_FLAG == 1 then return end

    local inventory_threshold_flag = 0

    -- Load recipe data
    local a_craft_item, a_craft_item_normal = lib.craft_preparation(p_id)

    local craft_container = p_container_name

    -- for c = 0 ,#a_craft_item do print(a_craft_item[c])end

    -- for c = 0 ,#a_craft_item_normal do print(a_craft_item[c])end

    -- Craft_container_name (craft_container)
    -- Determines what container name to provide given quest/zone..etc..

    -- Need mixing bowl, use mixing bowl in inventory only if not in POK and so on

    -- Move to static container
    -- GLOBAL_TEXT = "Container " .. craft_container

    movement.container(craft_container)

    -- print(craft_container)
    -- GLOBAL_TEXT = craft_container

    if GLOBAL_ABORT_FLAG == 1 then return end

    if mq.TLO.ItemTarget() == nil then
        print(msg, craft_container, " \ap[\awNot selected\ap]")
        return
    end

    open_static_container(craft_container)

    local outer_flag = 0

    -- Use UI
    if GLOBAL_STANDARD_UI == 1 then

        local result = 0

        -- UI Crafting
        while true do

            if GLOBAL_ABORT_FLAG == 1 then
                outer_flag = 2
                break
            end

            local l_recipe_name = lib.return_recipe_name(p_id)
            local l_recipe_item_id = lib.return_item_recipe_id(p_id)

            GLOBAL_STANDARD_CRAFTING_STATUS_MSG = "Crafting: " .. l_recipe_name

            local l_item_name = lib.return_item_name(l_recipe_item_id)

            -- Note: Not used in any recipes.. Use recipe table name
            if l_item_name == nil then l_item_name = l_recipe_name end

            if inventory_threshold_flag == 1 then
                mq.cmd('/cleanup')
                break
            end

            -- SIM 
            -- REM to test UI search
            local c_check = lib.component_check(p_id, a_craft_item_normal)

            if c_check == 0 then
                mq.cmd('/cleanup')
                outer_flag = 2
                break
            end

            open_static_container()

            local l_search_result = craft_Search_UI(l_item_name, l_recipe_name)

            if l_search_result == 1 then

                -- jb 11/30/2023
                -- This is for returning from learn and count achieved.
                -- Beginning Inventory (should return but break would be better)
                -- break and then break and then return.. is best?
                -- but the flow!

                GLOBAL_TEXT = "UI Crafting " .. l_recipe_name

                -- Enable TSD always
                if mq.TLO.TradeskillDepot.Enabled() then
                    if not mq.TLO.Window('TradeskillWnd').Child(
                        'PersonalDepotCheckbox').Checked() then
                        mq.delay(500)
                        mq.TLO.Window('TradeskillWnd').Child(
                            'COMBW_PersonalDepotCheckbox').LeftMouseUp()
                        mq.delay(500)
                    end
                end

                if not mq.TLO.Window('TradeskillWnd').Child('MakeAllCheckBox')
                    .Checked() then
                    mq.delay(500)
                    mq.cmd(
                        '/notify TradeskillWnd COMBW_MakeAllCheckbox leftmouseup')
                end

                if mq.TLO.Window('TradeskillWnd').Child('CombineButton')
                    .Enabled() then
                    mq.delay(500)
                    mq.cmd(
                        '/notify TradeskillWnd COMBW_CombineButton leftmouseup')
                end

                lib.ClearCursor()
                mq.delay(100)

                while true do

                    mq.delay(1)
                    -- lib.event()

                    local tester = 1
                    if tester == 1 then
                        local break_out = 0
                        while true do
                            mq.delay(1)
                            mq.doevents()
                            mq.doevents()
                            mq.doevents()
                            --    lib.event()
                            break_out = break_out + 1
                            if break_out > 4 then

                                break
                            end
                        end
                    end

                    local l_inv = mq.TLO.FindItemCount(l_recipe_item_id)()

                    local check_ts_status =
                        lib.check_ts_status(l_recipe_item_id)

                    local backpack_free_space =
                        lib.backpack_free_slots(check_ts_status)

                    -- Break to sell if inventory < and conditions met
                    if GLOBAL_STANDARD_SELL_ID ~= 0 and GLOBAL_STANDARD_SELL_ID ~=
                        nil and GLOBAL_STANDARD_SELL_ID == l_recipe_item_id and
                        backpack_free_space < 4 and l_inv > 0 and
                        mq.TLO.FindItem(l_recipe_item_id).Value() >
                        GLOBAL_STANDARD_SELL_THRESHOLD then

                        if mq.TLO.Window('TradeskillWnd').Child(
                            'MakeAllCheckBox').Checked() then
                            mq.delay(500)
                            mq.cmd(
                                '/notify TradeskillWnd COMBW_MakeAllCheckbox leftmouseup')
                        end

                        inventory_threshold_flag = 1
                        break
                    end

                    -- Add Tradeskill Item Conditions

                    -- Break to destroy if inventory < and conditions met
                    if GLOBAL_STANDARD_DESTROY_ID ~= 0 and
                        GLOBAL_STANDARD_DESTROY_ID ~= nil and
                        GLOBAL_STANDARD_DESTROY_ID == l_recipe_item_id and
                        backpack_free_space < 4 and l_inv > 0 then
                        if mq.TLO.Window('TradeskillWnd').Child(
                            'MakeAllCheckBox').Checked() then
                            mq.delay(500)
                            mq.cmd(
                                '/notify TradeskillWnd COMBW_MakeAllCheckbox leftmouseup')
                        end
                        inventory_threshold_flag = 1
                        break
                    end

                    -- Skill Up Check
                    if GLOBAL_STANDARD_SKILL_ID ~= 0 and
                        GLOBAL_STANDARD_SKILL_ID == tonumber(p_id) then
                        local l_recipe_skill = lib.return_recipe_skill(p_id)
                        local l_recipe_trivial = lib.return_recipe_trivial(p_id)
                        if mq.TLO.Me.Skill(l_recipe_skill)() >= l_recipe_trivial then
                            print(msg, l_recipe_skill, " Skill-Up Goal Met ",
                                  l_recipe_trivial)
                            mq.delay(1)
                            mq.cmd('/cleanup')
                            --   SKILL_ID = 0
                            -- do outerflag numbers matter? no they dont just a number to break out
                            inventory_threshold_flag = 1
                            outer_flag = 3
                            break
                        end
                    end

                    -- Make Count Check
                    if l_inv >= l_make_count then
                        mq.delay(1)
                        mq.cmd('/cleanup')
                        --  tsui_disable_make_all()
                        print(msg, "Craft goal complete UI testing")
                        inventory_threshold_flag = 1
                        outer_flag = 1
                        break
                    end

                    -- Out of components
                    if lv_missing_components == 0 then
                        print(msg, "\ap[\awTCN_Craft Materials needed UI: \ap]")
                        local check = mq.cmd('/cleanup')
                        lv_missing_components = 1
                        outer_flag = 2
                        lib.component_check(p_id, a_craft_item_normal)
                        break
                    end

                end

                if GLOBAL_ABORT_FLAG == 1 then break end

                if outer_flag > 0 then break end

            end

            if l_search_result == 0 then
                -- Make until learned
                result = learn_static_container(p_id, a_craft_item,
                                                a_craft_item_normal)
            end

            if result == 2 then
                print(msg, "Learn Mode Static Container: \ap[\agSuccess\ap]")
                mq.cmd('/cleanup')
                result = 0
            end

            local b_inv = mq.TLO.FindItemCount(l_recipe_item_id)()
            mq.delay(1)

            if b_inv >= l_make_count then
                mq.delay(1)
                mq.cmd('/cleanup')
                print(msg, "UI Craft Goal Complete (Exact)")
                result = 0
                break
            end

            if result == 1 then
                result = 0
                print(msg, "Learn Mode: \ap[\atOut of Components\ap]")
                break
            end

            if result == 3 then
                print(msg, "\atUser Abort")
                mq.cmd('/cleanup')
                result = 0
                break
            end

            if result == 4 then
                result = 0
                print(msg, "Learn Mode: \ap[\atMissing Components\ap]")
                break
            end

            mq.delay(1)

        end

        return
    end

    ---------------------- Static crafting experiment

    if GLOBAL_ABORT_FLAG == 1 then return end

    -- regular crafting

    experiment()
    -- container wait?

    local breaker = 0

    -- print(hc, " ",l_make_count, " ",rii)

    close_inventory_window()

    -- container --if oven then baking or cooking, if pottery wheel then text shaping?
    local rrn = lib.return_recipe_name(p_id)
    -- crafting to potting to smithing to ...
    print(msg, "\ap[\agCrafting\ap] \ap[\aw", rrn, "\ap]")

    GLOBAL_TEXT = "Crafting: " .. rrn

    -- Crafting loop

    while true do

        if GLOBAL_ABORT_FLAG == 1 then break end

        local l_item_id = lib.return_item_id(p_id)
        -- remd 12/17/2022
        -- local l_recipe_name = lib.return_recipe_name(p_id)

        local l_item_inv = mq.TLO.FindItemCount(l_item_id)()

        -- remd 12/17/2022
        -- local l_recipe_item_id = lib.return_item_recipe_id(p_id)

        -- print(hc, " ",l_make_count, " ",l_recipe_name," ",p_id)

        -- for x = 0 ,# a_craft_item do print (a_craft_item[x]) end

        -- Populate static container with recipe items
        local status_flag = populate_static_container(a_craft_item)

        if status_flag == 0 then
            mq.cmd('/cleanup')
            break
        end

        -- Add is combine ready - check combine button

        -- Combine
        mq.cmd('/notify ContainerCombine_Items Container_Combine leftmouseup')
        mq.delay(1500)

        check_stacked_static()

        inventory_tools()

        local break_out = 0
        while true do
            mq.delay(1)
            mq.doevents()
            mq.doevents()
            mq.doevents()
            break_out = break_out + 1
            if break_out > 9 then break end
        end

        -- mq.delay(1)

        if GLOBAL_LORE_FLAG == 1 then
            GLOBAL_LORE_FLAG = 0
            break
        end

        -- print("GGNF ",GLOBAL_GOD_NOCOMBINE_FLAG)

        if GLOBAL_GOD_NOCOMBINE_FLAG == 1 then
            GLOBAL_GOD_NOCOMBINE_FLAG = 0
            mq.delay(1)
            break
        end

        local cursor_string = mq.TLO.Cursor.Name()

        if mq.TLO.Cursor.ID() ~= nil then
            --  lib.writefile("crafticons",
            --               mq.TLO.Cursor.ID() .. "," .. mq.TLO.Cursor.Icon() ..
            --                   "," .. mq.TLO.Cursor.Name())
        end

        -- If we fail any recipe, do not continue to craft if we have inventory
        if GLOBAL_MAX_CRAFTING == 1 and GLOBAL_MAX_FAILED_FLAG == 1 then
            lib.ClearCursor()
            --  print "failed recipe testing tcn_craft"
            GLOBAL_MAX_FAILED_FLAG = 0
            break
        end

        --  print("make: ",l_make_count)

        --  print (GLOBAL_MAX_CRAFTING, " GMC setting ")
        --   print("cursor setting ",mq.TLO.Cursor.ID() )
        --   print(GLOBAL_MAX_LEARNED_FLAG, " flag learn")

        -- Egg Yolk Recipe (Auto Inventory Egg White)
        if p_id == 9996728 and mq.TLO.Cursor.ID() == 96729 then
            mq.cmd("/autoinv")
            -- Add issue handling later
            -- Checks: Cannot place item in inventory
            mq.delay(1500)
        end

        -- Validate inventory after craft attempt
        mq.delay(300)
        l_item_id = lib.return_item_id(p_id)
        l_item_inv = mq.TLO.FindItemCount(l_item_id)()
        mq.delay(500)

        -- Workaround for Glob of Edible Muck
        if p_id == 365886 then l_item_id = 98246 end

        -- Successful Subcombine
        if GLOBAL_MAX_CRAFTING == 1 and mq.TLO.Cursor.ID() == l_item_id and
            l_item_id ~= GLOBAL_MAX_ITEM_ID and l_item_inv >= l_make_count then
            -- print "bammo"
            lib.ClearCursor()
            break
        end

        mq.delay(1)
        -- Max Recipe Success
        if mq.TLO.Cursor.ID() ~= nil and mq.TLO.Cursor.ID() ==
            GLOBAL_MAX_ITEM_ID and GLOBAL_MAX_CRAFTING == 1 then
            -- Main MAX Recipe Check

            -- Increment known progress bar
            GLOBAL_MAX_KNOWN = GLOBAL_MAX_KNOWN + 1

            local l_tradeskill = mq.TLO.FindItem(mq.TLO.Cursor.ID())
                                     .Tradeskills()
            -- Used in other 350 recipes
            local used = lib.return_max_used(GLOBAL_MAX_RECIPE_ID, 1)
            if used == 1 then GLOBAL_MAX_USED = 1 end

            -- Bypass tradeskill check for 350
            -- used = 0
            -- GLOBAL_MAX_USED = 0

            -- Learned and it is a task we are working on
            if GLOBAL_TASK_UPDATE == 1 then break end

            -- Sell item under specific conditions
            if mq.TLO.Cursor.Value() > GLOBAL_MAX_SELL_THRESHOLD * 1000 and
                GLOBAL_MAX_SELL_FLAG == 1 and used == 0 then break end

            if GLOBAL_MAX_DESTROY_ID == mq.TLO.Cursor.ID() and used == 0 then
                local l_cursor_count = mq.TLO
                                           .FindItemCount(mq.TLO.Cursor.ID())()

                local destroy_go = 0

                if cursor_string ~= nil then
                    local result = check_artisan_destruction_list()
                    if result == 1 then destroy_go = 1 end
                end

                -- doevents -- set flag if flag = 1 then dont destroy
                -- if task update don't destroy..

                if destroy_go == 0 then
                    GLOBAL_TEXT = "Destroying " .. mq.TLO.Cursor()
                    print(msg, "\ap[\arDestroying\ap] (\ag", l_cursor_count,
                          "\ap)\ap[\aw", lib.return_recipe_name(p_id), "\ap]")
                    mq.delay(750)
                    mq.cmd('/destroy')
                    mq.delay(750)
                end

                destroy_go = 0

            end

            -- Trigger learned flag even if event didn't fire
            GLOBAL_MAX_LEARNED_FLAG = 1

            break

        else

            -- Standard Crafting Condition Checks

            if mq.TLO.Cursor.ID() == GLOBAL_STANDARD_SELL_ID then
                if GLOBAL_STANDARD_SELL_ID ~= 0 and GLOBAL_STANDARD_SELL_ID ~=
                    nil and mq.TLO.Cursor.Value() >
                    GLOBAL_STANDARD_SELL_THRESHOLD and GLOBAL_STANDARD_SELL_ID ==
                    mq.TLO.Cursor.ID() then lib.ClearCursor() end
            end

            -- Skill Up Check
            if GLOBAL_STANDARD_SKILL_ID ~= 0 and GLOBAL_STANDARD_SKILL_ID ==
                tonumber(p_id) then
                local l_recipe_skill = lib.return_recipe_skill(p_id)
                local l_recipe_trivial = lib.return_recipe_trivial(p_id)
                if mq.TLO.Me.Skill(l_recipe_skill)() >= l_recipe_trivial then
                    print(msg, l_recipe_skill, " Skill-Up Goal Met ",
                          l_recipe_trivial)
                    mq.delay(1)
                    mq.cmd('/cleanup')
                    --   SKILL_ID = 0
                    break
                end
            end

            -- inventory threshold , value threshold to sell

            local check_ts_status = lib.check_ts_status(l_item_id)

            local backpack_free_space = lib.backpack_free_slots(check_ts_status)

            -- Break if inventory < x and sell when we get back to standard crafting routine
            if backpack_free_space < 4 and GLOBAL_STANDARD_SELL_ID ~= 0 and
                GLOBAL_STANDARD_SELL_ID ~= nil and
                mq.TLO.FindItemCount(GLOBAL_STANDARD_SELL_ID)() > 0 then
                -- Break and return to sell
                print(msg, "Inventory Threshold: Selling")
                break
            end

            -- Destroy by ID option
            --   print(GLOBAL_STANDARD_DESTROY_ID, " ID DESTROY")
            if GLOBAL_STANDARD_DESTROY_ID ~= 0 and GLOBAL_STANDARD_DESTROY_ID ~=
                nil and mq.TLO.Cursor.ID() == GLOBAL_STANDARD_DESTROY_ID then
                item_destroy(GLOBAL_STANDARD_DESTROY_ID)
            end

        end

        -- Artifact list for destruction?
        -- learn mode?

        lib.ClearCursor()

        -- does this matter?
        lib.event()

        --  GLOBAL_STANDARD_CRAFTING
        -- get a hold of the flags.. pass flags back to main routine and determine from there.. remove globals

        if CRAFT_STATUS_FLAG == 2 then
            lib.writefile("wrongcontainer",
                          rrn .. "," .. p_id .. "," .. craft_container)
            CRAFT_STATUS_FLAG = 0
            break
        end

        -- Event driven not experienced enough
        if CRAFT_STATUS_FLAG == 1 then break end

        -- check for learning and learn flag.. then exit?

        clean_static_container()

        lib.ClearCursor()

        --  mq.delay(100)

        -- it will be nil if we run quests or god or tss or ..

        if GLOBAL_MAX_CRAFTING == 0 or GLOBAL_MAX_CRAFTING == nil then

            local rii = lib.return_item_id(p_id)
            local hc = mq.TLO.FindItemCount(rii)()

            -- Quest Recipe ID Passed
            if l_quest_recipe_id == tonumber(p_id) then

                local l_quest_step = tonumber(
                                         lib.return_quest_step(l_quest_recipe_id))
                local l_quest_id = tonumber(
                                       lib.return_quest_id(l_quest_recipe_id))
                local l_quest_name = lib.return_quest_name(l_quest_id)

                -- Check Task Status Completion
                if mq.TLO.Task(l_quest_name).Objective(l_quest_step).Status() ==
                    "Done" then break end
            else

                lib.ClearCursor()

                --   print("TCN Craft Have: ", hc, " want ", l_make_count, " ID: ",
                --       rii)

                -- Check Make Count Completion
                if hc >= l_make_count then
                    -- print "TCN_Craft goal complete"
                    break
                end
            end

            -- Check Missing Components
            for x = 0, #a_craft_item_normal do
                -- return row count per recipe item
                -- mq.delay(100)
                local a =
                    lib.return_item_row_count(p_id, a_craft_item_normal[x])
                if (mq.TLO.FindItemCount(a_craft_item_normal[x])() < a) then
                    -- rem'd out
                    -- local rin = lib.return_item_name(a_craft_item_normal[x])
                    -- print("\ayTCN_Craft Missing: ", a, " ", "[", rin, "]")
                    breaker = 1
                    -- mq.cmd('/notify ContainerWindow CombineDoneButton leftmouseup')
                end
            end
            if (breaker == 1) then
                mq.cmd('/cleanup')
                break
            end
        end
        mq.delay(1)
        mq.doevents()
    end
    return
end

-- mq.event('ItemsRecovered', "#*#but you managed to recover #*#", RecoveredItems)

-- if we cant combine then.. reset// because we have bad recipe or.. we messed it up

-- need to know if container is portable or static otherwise blammo..
-- mq.event('ItemsRecovered', "You cannot combine these items in this container type!", RecoveredItems)

local craft = {}

function craft.list(p_recipe_list, p_quest_recipe_id, p_option)
    -- print(msg, "\awCrafting the list TCN_Craft")

    local l_option_flag = p_option
    l_quest_recipe_id = p_quest_recipe_id
    -- reverse order of the recipe list

    for x = #p_recipe_list, 0, -1 do

        -- Clean this up.. someday
        local clean_string = string.gsub(p_recipe_list[x], "'", '')
        local l_recipe_id = lib.return_string(clean_string, 4)
        l_make_count = tonumber(lib.return_string(clean_string, 5))
        local l_item_id = lib.return_string(clean_string, 1)

        local l_inv = mq.TLO.FindItemCount(l_item_id)()

        if l_inv >= l_make_count then
            -- get inv get make count,,compare,, skip
            -- count good
            --  print(l_item_id, " ", l_make_count, " INV: ", l_inv, " TCN_Craft")

        else
            -- recipe check?
            --    craft.main(l_recipe_id, l_make_count, l_quest_recipe_id)

        end
        -- print ("RecipeID:" ,l_recipe_id," make count: ",l_make_count)

        local check = lib.single_recipe_check(l_recipe_id)
        if check == 0 then break end

        craft.main(l_recipe_id, l_make_count, l_quest_recipe_id, l_option_flag)
    end
    -- Added return 11/17/21
    return
end

function craft.main(p_id, p_make_count, q_id, p_option_flag)

    -- Dye Code Section
    local dye_recipe = dye_check(p_id)

    local jar_have_count = mq.TLO.FindItemCount(17961)()

    if dye_recipe == 1 and jar_have_count < 1 then
        print(msg, "We have no Medium Clay Jars in inventory, please make some")
        return
    end

    -- Check if we can make 1 recipe
    local check = lib.single_recipe_check(p_id)

    if dye_recipe == 1 and check == 0 then
        print(msg, "We are not able to even make 1 dye recipe")
        return
    end

    if dye_recipe == 1 then
        -- Place jar
        place_medium_clay_jar()
        -- Open Jar
        open_medium_clay_jar()
        -- Put Items In Jar
        place_components_in_jar(p_id)
        -- Combine Jar
        combine_medium_clay_jar()
        return
    end
    -- End Dye Code Section

    lib.ClearCursor()

    -- print(p_make_count)
    -- print(p_id)

    mq.cmd('/doevents flush')

    if GLOBAL_ABORT_FLAG == 1 then return end

    local test_flag = 1
    if test_flag == 0 then return end

    local options = p_option_flag
    local l_craft_skill = lib.return_recipe_skill(p_id)

    -- Add flag to turn off auto continue or 
    if l_craft_skill == "Alchemy" and mq.TLO.Me.Class() ~= "Shaman" then
        print(msg, "\ap[\atShaman Services: \agRequired\ap]")
        return
    end
    if l_craft_skill == "Tinkering" and mq.TLO.Me.Race() ~= "Gnome" then
        print(msg, "\ap[\atGnome Power: \agRequired\ap]")
        return
    end
    if l_craft_skill == "Make Poison" and mq.TLO.Me.Class() ~= "Rogue" then
        print(msg, "\ap[\atRogue Services: \agRequired\ap]")
        return
    end

    lib.ClearCursor()

    -- mq.cmd('/doevents flush')

    l_make_count = tonumber(p_make_count)

    l_quest_recipe_id = q_id

    -- Disable right click to experiment
    if mq.TLO.Window('OptionsWindow').Child('OGP_TradeskillCtrlClickCheckbox')
        .Checked() then
        mq.cmd(
            '/notify OptionsWindow OGP_TradeskillCtrlClickCheckbox leftmouseup')
        mq.delay(750)
    end

    mq.cmd('/cleanup')

    local RID = p_id

    -- Missing Components/Recipe Check

    local test_1 = 0
    if test_1 == 1 then
        -- Turn on UI
        GLOBAL_STANDARD_UI = 1
        cn = "Brewing Barrel"
        -- print(cn)
        craft_static(RID, cn, options)
        mq.cmd('/doevents flush')
        mq.delay(750)
        mq.cmd('/cleanup')

        lib.ClearCursor()
        local testy = 1
        if testy == 1 then
            print(msg, "Returning")
            return
        end
    end

    -- end test

    local MIS = lib.print_missing_components(RID, p_make_count)

    -- SIM test crafting without components
    -- MIS = 0

    if GLOBAL_CULT_TESTING == 1 then MIS = 0 end

    -- If we are missing components for that recipe return
    if MIS == 1 then
        mq.delay(500)
        mq.cmd('/cleanup')
        mq.delay(500)
        return
    end

    -- Swap Trophy based on skill

    mq.delay(1)

    -- value was one for swapping trophies
    if GLOBAL_TROPHY_FLAG == 99 then
        local cs = lib.return_container_skill(RID)

        -- print(cs)

        if cs == nil then
            print(msg, "TCN_Craft Invalid Recipe ID: \ag", RID, " \ayError")
            os.exit()
        end

        local trophy_have = lib.have_trophy(cs)

        -- Swap The Bone Rod -- 151934
        -- Brell's Testing -- 29193
        if cs == "Fishing" and mq.TLO.FindItemCount(151934)() > 0 then
            swap_primary_item()
        end

        if mq.TLO.FindItemCount(trophy_have)() > 0 and trophy_have ~= nil then

            local l_trophy_id = mq.TLO.FindItem(trophy_have).ID()

            local inv_slots = {"11", "13", "14", "22"}

            local swap_flag = 1
            for x = 1, #inv_slots do
                local trophy_slot = tostring(
                                        mq.TLO.FindItem(trophy_have).ItemSlot())
                if trophy_slot == inv_slots[x] then
                    swap_flag = 0
                    break
                end
            end

            if swap_flag == 1 then

                -- Record what is in ammo slot to return later
                if mq.TLO.Me.Inventory(22)() == nil then
                    lib.GrabItemID(l_trophy_id, 1)
                    -- print(l_trophy_id)
                    mq.delay(1000)
                    mq.cmd('/nomodkey /itemnotify 22 leftmouseup')
                    mq.delay(1000)
                    print(msg, "\ap[\agUsing\ap] \ap[\aw", trophy_have, "\ap]")

                    GLOBAL_STANDARD_CRAFTING_STATUS_MSG = "Using " ..
                                                              trophy_have

                else
                    l_ammo_slot_id = GLOBAL_AMMO_SLOT

                    lib.GrabItemID(l_trophy_id, 1)

                    -- print(l_trophy_id)

                    mq.delay(300)
                    mq.cmd('/nomodkey /itemnotify 22 leftmouseup')
                    -- print("was it swapped? ammo: ",mq.TLO.Me.Inventory(22).ID())
                    mq.delay(300)

                    lib.ClearCursor()

                    -- swap to originating slot
                    --   mq.cmd('/nomodkey /itemnotify 22 leftmouseup')
                    --  mq.delay(500)
                    --  lib.GrabItemID(l_trophy_id, 1)
                    --  mq.delay(500)
                    --  mq.cmd('/nomodkey /itemnotify 22 leftmouseup')
                    print(msg, "\ag[Using] \ap[\aw", trophy_have, "\ap]")

                    GLOBAL_STANDARD_CRAFTING_STATUS_MSG = "Using " ..
                                                              trophy_have

                end
            end
        end

        -- print("in ammo: ",mq.TLO.Me.Inventory(22).ID())
        --  mq.cmd('/lua pause')

    end

    lib.ClearCursor()

    mq.delay(750)

    local portable = 0

    -- if portable == 0 then return end

    cn = lib.return_container_name(RID)

    -- consolidate non pok/gh zones later

    -- local other zones = if the zone returnes then do below????

    -- Frogland
    if mq.TLO.Zone.ID() == 50 then
        craft_static(RID, cn, options)
        mq.delay(750)
        if l_ammo_slot_id ~= nil then swap_ammo_slot_back(l_ammo_slot_id) end
        -- Fishing
        if GLOBAL_PRIMARY_SLOT ~= nil then return_primary_item() end
        mq.cmd('/doevents flush')
        mq.delay(750)
        mq.cmd('/cleanup')
        lib.ClearCursor()
        return
    end

    -- Woodelf land
    if mq.TLO.Zone.ID() == 54 then
        craft_static(RID, cn, options)
        mq.delay(750)
        if l_ammo_slot_id ~= nil then swap_ammo_slot_back(l_ammo_slot_id) end
        -- Fishing
        if GLOBAL_PRIMARY_SLOT ~= nil then return_primary_item() end
        mq.cmd('/doevents flush')
        mq.delay(750)
        mq.cmd('/cleanup')
        lib.ClearCursor()
        return
    end

    -- Shrimps
    if mq.TLO.Zone.ID() == 55 then
        craft_static(RID, cn, options)
        mq.delay(750)
        if l_ammo_slot_id ~= nil then swap_ammo_slot_back(l_ammo_slot_id) end
        -- Fishing
        if GLOBAL_PRIMARY_SLOT ~= nil then return_primary_item() end
        mq.cmd('/doevents flush')
        mq.delay(750)
        mq.cmd('/cleanup')
        lib.ClearCursor()
        return
    end

    -- Ogreland
    if mq.TLO.Zone.ID() == 49 then
        craft_static(RID, cn, options)
        mq.delay(750)
        if l_ammo_slot_id ~= nil then swap_ammo_slot_back(l_ammo_slot_id) end
        -- Fishing
        if GLOBAL_PRIMARY_SLOT ~= nil then return_primary_item() end
        mq.cmd('/doevents flush')
        mq.delay(750)
        mq.cmd('/cleanup')
        lib.ClearCursor()
        return
    end

    -- make a list to make this more efficient

    -- Barbarians
    if mq.TLO.Zone.ID() == 29 then
        craft_static(RID, cn, options)
        mq.delay(750)
        if l_ammo_slot_id ~= nil then swap_ammo_slot_back(l_ammo_slot_id) end
        -- Fishing
        if GLOBAL_PRIMARY_SLOT ~= nil then return_primary_item() end
        mq.cmd('/doevents flush')
        mq.delay(750)
        mq.cmd('/cleanup')
        lib.ClearCursor()
        return
    end

    -- Drakkin
    if mq.TLO.Zone.ID() == 999394 then
        craft_static(RID, cn, options)
        mq.delay(750)
        if l_ammo_slot_id ~= nil then swap_ammo_slot_back(l_ammo_slot_id) end
        -- Fishing
        if GLOBAL_PRIMARY_SLOT ~= nil then return_primary_item() end
        mq.cmd('/doevents flush')
        mq.delay(750)
        mq.cmd('/cleanup')
        lib.ClearCursor()
        return
    end

    -- add  wood elf, erudite

    -- Lizardland
    if mq.TLO.Zone.ID() == 106 then
        craft_static(RID, cn, options)
        mq.delay(750)
        if l_ammo_slot_id ~= nil then swap_ammo_slot_back(l_ammo_slot_id) end
        -- Fishing
        if GLOBAL_PRIMARY_SLOT ~= nil then return_primary_item() end
        mq.cmd('/doevents flush')
        mq.delay(750)
        mq.cmd('/cleanup')
        lib.ClearCursor()
        return
    end

    -- Dark Elves
    if mq.TLO.Zone.ID() == 42 then
        craft_static(RID, cn, options)
        mq.delay(750)
        if l_ammo_slot_id ~= nil then swap_ammo_slot_back(l_ammo_slot_id) end
        -- Fishing
        if GLOBAL_PRIMARY_SLOT ~= nil then return_primary_item() end
        mq.cmd('/doevents flush')
        mq.delay(750)
        mq.cmd('/cleanup')
        lib.ClearCursor()
        return
    end

    -- Dwarves
    if mq.TLO.Zone.ID() == 60 then
        craft_static(RID, cn, options)
        mq.delay(750)
        if l_ammo_slot_id ~= nil then swap_ammo_slot_back(l_ammo_slot_id) end
        -- Fishing
        if GLOBAL_PRIMARY_SLOT ~= nil then return_primary_item() end
        mq.cmd('/doevents flush')
        mq.delay(750)
        mq.cmd('/cleanup')
        lib.ClearCursor()
        return
    end

    -- Trolls
    if mq.TLO.Zone.ID() == 52 then
        craft_static(RID, cn, options)
        mq.delay(750)
        if l_ammo_slot_id ~= nil then swap_ammo_slot_back(l_ammo_slot_id) end
        -- Fishing
        if GLOBAL_PRIMARY_SLOT ~= nil then return_primary_item() end
        mq.cmd('/doevents flush')
        mq.delay(750)
        mq.cmd('/cleanup')
        lib.ClearCursor()
        return
    end

    -- Cats
    if mq.TLO.Zone.ID() == 155 then
        craft_static(RID, cn, options)
        mq.delay(750)
        if l_ammo_slot_id ~= nil then swap_ammo_slot_back(l_ammo_slot_id) end
        -- Fishing
        if GLOBAL_PRIMARY_SLOT ~= nil then return_primary_item() end
        mq.cmd('/doevents flush')
        mq.delay(750)
        mq.cmd('/cleanup')
        lib.ClearCursor()
        return
    end

    -- Humans and Half Elfs
    if mq.TLO.Zone.ID() == 1 then
        craft_static(RID, cn, options)
        mq.delay(750)
        if l_ammo_slot_id ~= nil then swap_ammo_slot_back(l_ammo_slot_id) end
        -- Fishing
        if GLOBAL_PRIMARY_SLOT ~= nil then return_primary_item() end
        mq.cmd('/doevents flush')
        mq.delay(750)
        mq.cmd('/cleanup')
        lib.ClearCursor()
        return
    end

    -- High Elves
    if mq.TLO.Zone.ID() == 61 then
        craft_static(RID, cn, options)
        mq.delay(750)
        if l_ammo_slot_id ~= nil then swap_ammo_slot_back(l_ammo_slot_id) end
        -- Fishing
        if GLOBAL_PRIMARY_SLOT ~= nil then return_primary_item() end
        mq.cmd('/doevents flush')
        mq.delay(750)
        mq.cmd('/cleanup')
        lib.ClearCursor()
        return
    end

    -- Halfwits
    if mq.TLO.Zone.ID() == 19 then
        craft_static(RID, cn, options)
        mq.delay(750)
        if l_ammo_slot_id ~= nil then swap_ammo_slot_back(l_ammo_slot_id) end
        -- Fishing
        if GLOBAL_PRIMARY_SLOT ~= nil then return_primary_item() end
        mq.cmd('/doevents flush')
        mq.delay(750)
        mq.cmd('/cleanup')
        lib.ClearCursor()
        return
    end

    -- POK
    if mq.TLO.Zone.ID() == 202 then

        -- Special Containers
        local portables = {
            "Coffin Poison Bottle", "Reinforced Jeweler's Kit", "Mixing Bowl",
            "Glaze Mortar", "Mystical Furnace of Ro",
            "Druzzil's Mystical Sewing Kit", "Portable Drink Barrel",
            "Sacred Urn", "Guktan Sewing Kit", "Erudite Sewing Kit",
            "Teir`Dal Sewing Kit", "White Rose Assembly Kit",
            "Justice Plate Assembly Kit", "Northern Wolf Plate Assembly Kit",
            "Wind Spirits Assembly Kit", "Curing Kit", "Ogre Sewing Kit",
            "Feir`Dal Sewing Kit", "Crystalwing Sewing Kit",
            "Northman Sewing Kit", "Shar Vahl Sewing Kit", "Vale Sewing Kit",
            "Clockwork Sewing Kit", "Iksar Sewing Kit", "Troll Sewing Kit",
            "Half Elf Sewing Kit", "Antonican Sewing Kit",
            "Gnomish Recharging Kit", "Koada`Dal Sewing Kit", "Small Clay Jar",
            "Medium Clay Jar", "Surefall Fletching Kit",
            "Feir`Dal Fletching Kit"
        }

        for x = 1, #portables do
            if string.find(cn, portables[x]) then
                portable = 1
                -- changed 2/26/22
                break
            end
        end

        -- Make override for mixing bowl portable
        -- SIM
        if cn == "Mixing Bowl" and mq.TLO.FindItemCount('Mixing Bowl') == 0 then
            portable = 0
        end

        if cn == "Mixing Bowl" then portable = 0 end

        if portable == 1 then
            if mq.TLO.FindItemCount(cn)() > 0 then
                --  print(msg,"\ay[Portable Container] ", cn)
                craft_portable(RID)
                if l_ammo_slot_id ~= nil then
                    swap_ammo_slot_back(l_ammo_slot_id)
                    -- Fishing
                    if GLOBAL_PRIMARY_SLOT ~= nil then
                        return_primary_item()
                    end
                end
            else
                print(msg, "\ap[\ayPausing\ap] \ap[\agMissing ", cn,
                      " container\ap]")
                print(msg,
                      "\ap[\ayPlease, get container and we will continue\ap]")
                --  print(msg, "TCN_Craft Sorry We don't have: ", cn)

                print(msg,
                      "Waiting until container is placed in inventory, type /lua pause tcn when finished")

                mq.cmd('/squelch /lua pause tcn')

                if mq.TLO.Lua.Script('tcn').Status() == "PAUSED" then
                    while mq.TLO.FindItemCount(cn)() < 1 do
                        mq.delay(100)
                    end
                end

                craft_portable(RID)
            end
        end

        if portable == 0 then

            craft_static(RID, cn, options)
            mq.delay(750)

            -- print("slot ammo id: ",l_ammo_slot_id," global",GLOBAL_AMMO_SLOT)

            -- Fishing
            if GLOBAL_PRIMARY_SLOT ~= nil then return_primary_item() end

            if l_ammo_slot_id ~= nil then
                swap_ammo_slot_back(l_ammo_slot_id)
            end

            mq.cmd('/doevents flush')
            mq.delay(750)
            mq.cmd('/cleanup')

            lib.ClearCursor()

        end
        return
    end

    -- ADD inventory complete counts to portable! so we can know when we have enough

    -- Modest Guild Hall or Grand or Palatial,Standard, SRH
    if mq.TLO.Zone.ID() == 751 or mq.TLO.Zone.ID() == 738 or mq.TLO.Zone.ID() ==
        737 or mq.TLO.Zone.ID() == 345 or mq.TLO.Zone.ID() == 712 then
        -- craft using static.. but need to check for coffin and other portables

        local porty = 0

        -- Reinforced Jeweler's Kit for GH
        if cn == "Reinforced Jeweler's Kit" and mq.TLO.FindItemCount(62480)() >
            0 then
            porty = 1
            craft_portable(RID)
        end
        -- Coffin Poison Bottle for GH
        if cn == "Coffin Poison Bottle" and mq.TLO.FindItemCount(17149)() > 0 then
            porty = 1
            craft_portable(RID)
        end

        -- Glaze Mortar GH
        if cn == "Glaze Mortar" and mq.TLO.FindItemCount(17882)() > 0 then
            porty = 1
            craft_portable(RID)
        end

        -- Taxidermy Kit GH Pfft not a real container
        -- if cn == "Taxidermy Kit" and mq.TLO.FindItemCount(77683)() > 0 then
        --    porty = 1
        --    craft_portable(RID)
        -- end

        if porty == 0 then craft_static(RID, cn, options) end

        mq.delay(750)
        if l_ammo_slot_id ~= nil then swap_ammo_slot_back(l_ammo_slot_id) end
        -- Fishing
        if GLOBAL_PRIMARY_SLOT ~= nil then return_primary_item() end
        mq.cmd('/doevents flush')
        mq.delay(750)
        mq.cmd('/cleanup')
        lib.ClearCursor()
        return
    end

    -- Abysmal Sea
    if mq.TLO.Zone.ID() == 279 then
        -- Add spell kits for crescent reach freebie
        local abysmal_portables = {
            "Mixing Bowl", "Fletching Kit", "Mortar and Pestle", "Medicine Bag",
            "Toolbox", "Spit", "Jeweler's Kit"
        }

        for x = 1, #abysmal_portables do
            if string.find(cn, abysmal_portables[x]) then
                portable = 1
                -- break?
            end
        end

        local result = lib.return_available_container(cn)
        if result ~= nil then cn = result end

        if string.find(cn, "Oven") and mq.TLO.FindItemCount(17947)() > 0 then
            cn = "Spit"
            portable = 1
        end

        if portable == 1 then
            if mq.TLO.FindItemCount(cn)() > 0 then
                craft_portable(RID)
                if l_ammo_slot_id ~= nil then
                    swap_ammo_slot_back(l_ammo_slot_id)
                end
            else
                print(msg, "\ap[\ayPausing\ap] \ap[\agMissing ", cn,
                      " container\ap]")
                print(msg,
                      "\ap[\ayPlease, get container and we will continue\ap]")
                print(msg, "TCN_Craft Sorry We don't have: ", cn)

                mq.cmd('/squelch /lua pause tcn')

                craft_portable(RID)
                if l_ammo_slot_id ~= nil then
                    swap_ammo_slot_back(l_ammo_slot_id)
                end
                -- return
            end
        end

        if portable == 0 then
            craft_static(RID, cn, options)
            mq.delay(750)
            if l_ammo_slot_id ~= nil then
                swap_ammo_slot_back(l_ammo_slot_id)
            end
        end
    end

    -- Crescent Reach 
    if mq.TLO.Zone.ID() == 394 then

        if cn == "Spell Research Table" then cn = what_spell_kit() end
        if cn == "Fletching Table" then cn = "Fletching Kit" end
        if cn == "Poisoncrafting Table" then cn = "Mortar and Pestle" end
        if cn == "Jewelry Making Table" then cn = "Jeweler's Kit" end
        if cn == "Alchemy Table" then cn = "Medicine Bag" end
        if cn == "Tinkering Table" then cn = "Toolbox" end

        local crescent_portables = {
            "Mixing Bowl", "Fletching Kit", "Mortar and Pestle", "Medicine Bag",
            "Toolbox", "Spit", "Jeweler's Kit", "Spell Research Kit",
            "Prayer Writing Kit", "Song Writing Kit", "Hybrid Research Kit",
            "Tome Binding Kit"
        }

        for x = 1, #crescent_portables do
            if string.find(cn, crescent_portables[x]) then
                portable = 1
                -- break?
            end
        end

        local result = lib.return_available_container(cn)
        if result ~= nil then cn = result end

        if string.find(cn, "Oven") and mq.TLO.FindItemCount(17947)() > 0 then
            cn = "Spit"
            portable = 1
        end

        if portable == 1 then
            if mq.TLO.FindItemCount(cn)() > 0 then
                craft_portable(RID)
                if l_ammo_slot_id ~= nil then
                    swap_ammo_slot_back(l_ammo_slot_id)
                end
            else
                print(msg, "\ap[\ayPausing\ap] \ap[\agMissing ", cn,
                      " container\ap]")
                print(msg,
                      "\ap[\ayPlease, get container and we will continue\ap]")
                print(msg, "TCN_Craft Sorry We don't have: ", cn)

                mq.cmd('/squelch /lua pause tcn')

                craft_portable(RID)
                if l_ammo_slot_id ~= nil then
                    swap_ammo_slot_back(l_ammo_slot_id)
                end
                -- return
            end
        end

        if portable == 0 then
            craft_static(RID, cn, options)
            mq.delay(750)
            if l_ammo_slot_id ~= nil then
                swap_ammo_slot_back(l_ammo_slot_id)
            end
        end
    end

    local z_dh = 1

    -- need to make sure we do portables as needed, and go to POK for other stuff..
    -- Dragonscale Hills
    if mq.TLO.Zone.ID() == 442 and z_dh == 0 then
        craft_portable(RID)
        mq.delay(750)
        if l_ammo_slot_id ~= nil then swap_ammo_slot_back(l_ammo_slot_id) end
        -- Fishing
        if GLOBAL_PRIMARY_SLOT ~= nil then return_primary_item() end
        mq.cmd('/doevents flush')
        mq.delay(750)
        mq.cmd('/cleanup')
        lib.ClearCursor()
        return
    end

    -- swap_ammo_slot_back(l_ammo_slot_id)

    mq.cmd('/doevents flush')
    mq.delay(750)
    mq.cmd('/cleanup')
    lib.ClearCursor()
    return
end

return craft
